#!/usr/bin/env python3
"""Launch the minimal generic-kernel-smoke application."""

import uvicorn


if __name__ == "__main__":
    uvicorn.run("backend.generic_kernel.app:create_app_from_env", factory=True, host="127.0.0.1", port=8080)
