"""Runtime manifest for customer-neutral procurement."""

from __future__ import annotations

from typing import Any


MODULE_ID = "procurement"
MODULE_VERSION = "0.1.0-cp4"
OWNER_REF = f"{MODULE_ID}:order-owner"
TABLES = (
    "procurement_action_receipts",
    "procurement_audit_events",
    "procurement_order_lines",
    "procurement_orders",
    "procurement_receipts",
)


def procurement_module_manifest(
    source_commit: str,
    migrations: list[dict[str, Any]],
) -> dict[str, Any]:
    return {
        "schema_version": "bizhub.runtime-module-manifest.v1",
        "module_id": MODULE_ID,
        "module_version": MODULE_VERSION,
        "source": {"kind": "generic", "commit": source_commit},
        "package": {
            "backend": "backend.modules.procurement",
            "public_api": "backend.modules.procurement.public:preview_action",
            "frontend_entry": None,
        },
        "dependencies": [
            "kernel.profile_registry",
            "trade_core",
            "master_data",
            "inventory",
        ],
        "capabilities": {
            "provides": ["procurement.order", "procurement.receiving"],
            "requires": [
                "kernel.profile-registry",
                "trade.order-lifecycle",
                "master-data.identity",
                "inventory.movement",
            ],
        },
        "surfaces": {
            "routes": [
                {"surface_id": "generic_api", "method": "GET", "path": "/api/procurement/orders"},
                {"surface_id": "generic_api", "method": "POST", "path": "/api/procurement/preview"},
                {"surface_id": "generic_api", "method": "POST", "path": "/api/procurement/apply"},
            ],
            "ui_routes": [],
            "jobs": [],
            "mcp_tools": [],
            "actions": [{
                "action_id": "procurement.apply",
                "record_types": ["procurement_order", "procurement_receipt"],
                "owner_ref": OWNER_REF,
            }],
            "migrations": migrations,
        },
        "ownership": {
            "record_types": [
                {"record_type": "procurement_order", "owner_ref": OWNER_REF},
                {"record_type": "procurement_receipt", "owner_ref": OWNER_REF},
            ],
            "tables": [
                {"table": table, "mode": "formal_writer", "owner_ref": OWNER_REF}
                for table in TABLES
            ],
        },
        "activation": {"mode": "build-time", "retains_existing_data_when_disabled": True},
    }
