"""Canonical module identity for the customer-neutral Profile Registry kernel."""

from __future__ import annotations

import hashlib
import json
from copy import deepcopy
from pathlib import Path
from typing import Any, Iterable, Mapping


SHARED_MODULE_ID = "kernel.profile_registry"
SHARED_MODULE_VERSION = "0.1.0-cp1c"
SHARED_KERNEL_SOURCE_PATHS = (
    "backend/kernel/__init__.py",
    "backend/kernel/module_contract.py",
    "backend/kernel/profile_registry.py",
)


def canonical_json(payload: Any) -> bytes:
    return (json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n").encode()


def digest_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def digest_json(payload: Any) -> str:
    return digest_bytes(canonical_json(payload))


def module_contract_payload(manifest: Mapping[str, Any]) -> dict[str, Any]:
    """Return the stable module contract without a release-specific revision."""

    payload = deepcopy(dict(manifest))
    source = dict(payload.get("source") or {})
    source.pop("commit", None)
    payload["source"] = source
    return payload


def bind_module_contract_revision(
    candidate: Mapping[str, Any],
    previous: Mapping[str, Any] | None,
) -> dict[str, Any]:
    """Preserve the prior revision when the module contract did not change."""

    if previous is not None and module_contract_payload(candidate) == module_contract_payload(previous):
        return deepcopy(dict(previous))
    return deepcopy(dict(candidate))


def source_tree_digest(root: Path, paths: Iterable[str]) -> str:
    rows = [
        {"path": relative, "sha256": digest_bytes((root / relative).read_bytes())}
        for relative in sorted(paths)
    ]
    return digest_json(rows)


def shared_kernel_source_digest(root: Path) -> str:
    return source_tree_digest(root, SHARED_KERNEL_SOURCE_PATHS)


def shared_profile_registry_manifest(source_commit: str) -> dict[str, Any]:
    return {
        "schema_version": "bizhub.runtime-module-manifest.v1",
        "module_id": SHARED_MODULE_ID,
        "module_version": SHARED_MODULE_VERSION,
        "source": {"kind": "kernel", "commit": source_commit},
        "package": {
            "backend": "backend.kernel",
            "public_api": "backend.kernel.profile_registry:RuntimeRegistry",
            "frontend_entry": None,
        },
        "dependencies": [],
        "capabilities": {"provides": ["kernel.profile-registry"], "requires": []},
        "surfaces": {
            "routes": [],
            "ui_routes": [],
            "jobs": [],
            "mcp_tools": [],
            "actions": [],
            "migrations": [],
        },
        "ownership": {"record_types": [], "tables": []},
        "activation": {"mode": "build-time", "retains_existing_data_when_disabled": True},
    }
