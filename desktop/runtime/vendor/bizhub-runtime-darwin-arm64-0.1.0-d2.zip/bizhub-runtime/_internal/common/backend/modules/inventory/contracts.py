"""Typed input and preview contracts for the inventory Owner."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

from backend.modules.master_data.public import digest_json


@dataclass(frozen=True)
class InventoryCommand:
    action: str
    idempotency_key: str
    product_id: str = ""
    unit_id: str = ""
    quantity: str = ""
    from_location_id: str | None = None
    to_location_id: str | None = None
    target_movement_id: str | None = None
    actual_quantity: str | None = None
    occurred_at: str = ""
    source_ref: str = ""
    reason: str = ""

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> "InventoryCommand":
        return cls(**dict(payload))

    def to_dict(self) -> dict[str, Any]:
        return {
            "action": self.action,
            "idempotency_key": self.idempotency_key,
            "product_id": self.product_id,
            "unit_id": self.unit_id,
            "quantity": self.quantity,
            "from_location_id": self.from_location_id,
            "to_location_id": self.to_location_id,
            "target_movement_id": self.target_movement_id,
            "actual_quantity": self.actual_quantity,
            "occurred_at": self.occurred_at,
            "source_ref": self.source_ref,
            "reason": self.reason,
        }

    @property
    def command_digest(self) -> str:
        return digest_json(self.to_dict())


@dataclass(frozen=True)
class InventoryPreview:
    command: InventoryCommand
    state_generation: str
    planned_movements: tuple[dict[str, Any], ...]
    planned_stocktake: dict[str, Any] | None
    before_balances: tuple[dict[str, str], ...]
    preview_digest: str

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> "InventoryPreview":
        command = payload.get("command")
        if not isinstance(command, Mapping):
            raise TypeError("inventory command is required")
        stocktake = payload.get("planned_stocktake")
        return cls(
            command=InventoryCommand.from_dict(command),
            state_generation=str(payload["state_generation"]),
            planned_movements=tuple(
                dict(item) for item in (payload.get("planned_movements") or ())
            ),
            planned_stocktake=(
                dict(stocktake) if isinstance(stocktake, Mapping) else None
            ),
            before_balances=tuple(
                dict(item) for item in (payload.get("before_balances") or ())
            ),
            preview_digest=str(payload["preview_digest"]),
        )

    def content(self) -> dict[str, Any]:
        return {
            "command": self.command.to_dict(),
            "state_generation": self.state_generation,
            "planned_movements": list(self.planned_movements),
            "planned_stocktake": self.planned_stocktake,
            "before_balances": list(self.before_balances),
        }

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": "bizhub.inventory-preview.v1",
            **self.content(),
            "preview_digest": self.preview_digest,
        }
