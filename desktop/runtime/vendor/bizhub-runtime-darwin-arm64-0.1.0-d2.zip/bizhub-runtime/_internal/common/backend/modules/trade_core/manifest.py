"""Shared manifest for the pure customer-neutral trade lifecycle module."""

from __future__ import annotations

from typing import Any


MODULE_ID = "trade_core"
MODULE_VERSION = "0.1.0-cp4"


def trade_core_module_manifest(source_commit: str) -> dict[str, Any]:
    return {
        "schema_version": "bizhub.runtime-module-manifest.v1",
        "module_id": MODULE_ID,
        "module_version": MODULE_VERSION,
        "source": {"kind": "generic", "commit": source_commit},
        "package": {
            "backend": "backend.modules.trade_core",
            "public_api": "backend.modules.trade_core.public:project_order_progress",
            "frontend_entry": None,
        },
        "dependencies": ["kernel.profile_registry"],
        "capabilities": {
            "provides": ["trade.order-lifecycle"],
            "requires": ["kernel.profile-registry"],
        },
        "surfaces": {
            "routes": [],
            "ui_routes": [],
            "jobs": [],
            "mcp_tools": [],
            "actions": [],
            "migrations": [],
        },
        "ownership": {"record_types": [], "tables": []},
        "activation": {"mode": "build-time", "retains_existing_data_when_disabled": True},
    }
