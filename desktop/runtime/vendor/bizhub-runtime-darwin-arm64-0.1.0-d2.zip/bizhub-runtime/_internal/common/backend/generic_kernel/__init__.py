"""Minimal customer-neutral BizHub kernel smoke runtime."""
