"""Typed procurement commands and state-bound previews."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping

from backend.modules.trade_core.public import digest_json


@dataclass(frozen=True)
class ProcurementLine:
    line_id: str
    product_id: str
    unit_id: str
    quantity: str
    receive_location_id: str

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> "ProcurementLine":
        return cls(**{key: str(payload[key]) for key in cls.__dataclass_fields__})

    def to_dict(self) -> dict[str, str]:
        return {
            "line_id": self.line_id,
            "product_id": self.product_id,
            "unit_id": self.unit_id,
            "quantity": self.quantity,
            "receive_location_id": self.receive_location_id,
        }


@dataclass(frozen=True)
class ProcurementCommand:
    action: str
    idempotency_key: str
    order_id: str
    supplier_party_id: str = ""
    ordered_at: str = ""
    lines: tuple[ProcurementLine, ...] = field(default_factory=tuple)
    target_line_id: str = ""
    quantity: str = ""
    occurred_at: str = ""
    source_ref: str = ""
    evidence_refs: tuple[str, ...] = field(default_factory=tuple)
    reason: str = ""

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> "ProcurementCommand":
        values = dict(payload)
        values["lines"] = tuple(
            ProcurementLine.from_dict(item)
            for item in (payload.get("lines") or ())
            if isinstance(item, Mapping)
        )
        values["evidence_refs"] = tuple(str(item) for item in (payload.get("evidence_refs") or ()))
        return cls(**values)

    def to_dict(self) -> dict[str, Any]:
        return {
            "action": self.action,
            "idempotency_key": self.idempotency_key,
            "order_id": self.order_id,
            "supplier_party_id": self.supplier_party_id,
            "ordered_at": self.ordered_at,
            "lines": [item.to_dict() for item in self.lines],
            "target_line_id": self.target_line_id,
            "quantity": self.quantity,
            "occurred_at": self.occurred_at,
            "source_ref": self.source_ref,
            "evidence_refs": list(self.evidence_refs),
            "reason": self.reason,
        }

    @property
    def command_digest(self) -> str:
        return digest_json(self.to_dict())


@dataclass(frozen=True)
class ProcurementPreview:
    command: ProcurementCommand
    state_generation: str
    planned_order: dict[str, Any]
    planned_lines: tuple[dict[str, Any], ...]
    planned_receipt: dict[str, Any] | None
    inventory_preview: dict[str, Any] | None
    preview_digest: str

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> "ProcurementPreview":
        command_payload = payload.get("command")
        if not isinstance(command_payload, Mapping):
            raise TypeError("command is required")
        planned_order = payload.get("planned_order")
        if not isinstance(planned_order, Mapping):
            raise TypeError("planned_order is required")
        receipt = payload.get("planned_receipt")
        inventory = payload.get("inventory_preview")
        return cls(
            command=ProcurementCommand.from_dict(command_payload),
            state_generation=str(payload["state_generation"]),
            planned_order=dict(planned_order),
            planned_lines=tuple(dict(item) for item in (payload.get("planned_lines") or ())),
            planned_receipt=dict(receipt) if isinstance(receipt, Mapping) else None,
            inventory_preview=dict(inventory) if isinstance(inventory, Mapping) else None,
            preview_digest=str(payload["preview_digest"]),
        )

    def content(self) -> dict[str, Any]:
        return {
            "command": self.command.to_dict(),
            "state_generation": self.state_generation,
            "planned_order": self.planned_order,
            "planned_lines": list(self.planned_lines),
            "planned_receipt": self.planned_receipt,
            "inventory_preview": self.inventory_preview,
        }

    def to_dict(self) -> dict[str, Any]:
        return {**self.content(), "preview_digest": self.preview_digest}
