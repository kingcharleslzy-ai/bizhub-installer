"""Small customer-neutral helpers shared by procurement and sales."""

from __future__ import annotations

import hashlib
import json
from decimal import Decimal, InvalidOperation
from typing import Any, Iterable


class TradeRuleError(ValueError):
    """A customer-neutral trade invariant is not satisfied."""


def canonical_json(payload: object) -> bytes:
    return (
        json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        + "\n"
    ).encode()


def digest_json(payload: object) -> str:
    return hashlib.sha256(canonical_json(payload)).hexdigest()


def quantity_decimal(value: object, *, allow_zero: bool = False) -> Decimal:
    try:
        parsed = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise TradeRuleError("trade_quantity_invalid") from exc
    if not parsed.is_finite() or parsed < 0 or (not allow_zero and parsed == 0):
        raise TradeRuleError(
            "trade_quantity_must_be_nonnegative"
            if allow_zero
            else "trade_quantity_must_be_positive"
        )
    return parsed


def normalized_evidence_refs(values: Iterable[object]) -> tuple[str, ...]:
    refs = tuple(str(value).strip() for value in values)
    if not refs or any(not value for value in refs):
        raise TradeRuleError("trade_evidence_ref_required")
    if len(set(refs)) != len(refs):
        raise TradeRuleError("trade_evidence_ref_duplicate")
    return refs


def project_order_progress(
    *,
    ordered_quantity: object,
    completed_quantity: object,
    returned_quantity: object = 0,
    cancelled: bool = False,
) -> str:
    """Project a neutral order-line state without customer-specific policy."""

    ordered = quantity_decimal(ordered_quantity)
    completed = quantity_decimal(completed_quantity, allow_zero=True)
    returned = quantity_decimal(returned_quantity, allow_zero=True)
    if returned > completed:
        raise TradeRuleError("trade_return_exceeds_completed")
    if completed > ordered:
        raise TradeRuleError("trade_completion_exceeds_ordered")
    if cancelled:
        return "cancelled"
    if returned == completed and completed > 0:
        return "returned"
    if returned > 0:
        return "partially_returned"
    if completed == ordered:
        return "completed"
    if completed > 0:
        return "partial"
    return "open"


def aggregate_order_progress(states: Iterable[str]) -> str:
    values = tuple(states)
    if not values:
        raise TradeRuleError("trade_order_lines_required")
    if all(value == "cancelled" for value in values):
        return "cancelled"
    if all(value == "completed" for value in values):
        return "completed"
    if all(value == "returned" for value in values):
        return "returned"
    if any(value in {"partially_returned", "returned"} for value in values):
        return "partially_returned"
    if any(value in {"partial", "completed"} for value in values):
        return "partial"
    return "open"


__all__ = [
    "TradeRuleError",
    "aggregate_order_progress",
    "canonical_json",
    "digest_json",
    "normalized_evidence_refs",
    "project_order_progress",
    "quantity_decimal",
]
