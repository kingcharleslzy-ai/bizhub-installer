"""Customer-neutral BizHub kernel primitives."""
