"""Generic-kernel binding for the shared Profile Registry."""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from backend.kernel.profile_registry import RegistryFiles, RuntimeRegistry


GENERIC_REGISTRY_FILES = RegistryFiles(
    profile_id="generic-kernel-smoke",
    registry="backend/generated/generic_kernel_smoke_runtime_registry.v1.json",
    registry_digest="backend/generated/generic_kernel_smoke_runtime_registry.v1.sha256",
    profile_lock="backend/profiles/generic-kernel-smoke.lock.json",
)


@lru_cache(maxsize=1)
def get_generic_registry(repo_root: Path | None = None) -> RuntimeRegistry:
    return RuntimeRegistry.load(repo_root, files=GENERIC_REGISTRY_FILES)
