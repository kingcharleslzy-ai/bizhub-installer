"""Customer and generic business modules assembled by a Profile Registry."""
