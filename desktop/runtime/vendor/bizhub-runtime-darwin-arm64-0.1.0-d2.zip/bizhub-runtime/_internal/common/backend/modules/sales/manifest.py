"""Runtime manifest for customer-neutral sales."""

from __future__ import annotations

from typing import Any


MODULE_ID = "sales"
MODULE_VERSION = "0.1.0-cp4"
OWNER_REF = f"{MODULE_ID}:order-owner"
TABLES = (
    "sales_action_receipts",
    "sales_audit_events",
    "sales_fulfillments",
    "sales_order_lines",
    "sales_orders",
)


def sales_module_manifest(
    source_commit: str,
    migrations: list[dict[str, Any]],
) -> dict[str, Any]:
    return {
        "schema_version": "bizhub.runtime-module-manifest.v1",
        "module_id": MODULE_ID,
        "module_version": MODULE_VERSION,
        "source": {"kind": "generic", "commit": source_commit},
        "package": {
            "backend": "backend.modules.sales",
            "public_api": "backend.modules.sales.public:preview_action",
            "frontend_entry": None,
        },
        "dependencies": [
            "kernel.profile_registry",
            "trade_core",
            "master_data",
            "inventory",
            "procurement",
        ],
        "capabilities": {
            "provides": ["sales.order", "sales.fulfillment", "sales.return"],
            "requires": [
                "kernel.profile-registry",
                "trade.order-lifecycle",
                "master-data.identity",
                "inventory.movement",
            ],
        },
        "surfaces": {
            "routes": [
                {"surface_id": "generic_api", "method": "GET", "path": "/api/sales/orders"},
                {"surface_id": "generic_api", "method": "POST", "path": "/api/sales/preview"},
                {"surface_id": "generic_api", "method": "POST", "path": "/api/sales/apply"},
            ],
            "ui_routes": [],
            "jobs": [],
            "mcp_tools": [],
            "actions": [{
                "action_id": "sales.apply",
                "record_types": ["sales_order", "sales_fulfillment", "sales_return"],
                "owner_ref": OWNER_REF,
            }],
            "migrations": migrations,
        },
        "ownership": {
            "record_types": [
                {"record_type": "sales_order", "owner_ref": OWNER_REF},
                {"record_type": "sales_fulfillment", "owner_ref": OWNER_REF},
                {"record_type": "sales_return", "owner_ref": OWNER_REF},
            ],
            "tables": [
                {"table": table, "mode": "formal_writer", "owner_ref": OWNER_REF}
                for table in TABLES
            ],
        },
        "activation": {"mode": "build-time", "retains_existing_data_when_disabled": True},
    }
