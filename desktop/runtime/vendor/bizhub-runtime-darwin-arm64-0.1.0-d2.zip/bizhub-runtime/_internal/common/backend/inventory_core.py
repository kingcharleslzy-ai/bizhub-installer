"""Pure customer-neutral movement rules shared by both profiles."""

from __future__ import annotations

from decimal import Decimal, InvalidOperation
from typing import Iterable, Mapping


class InventoryRuleError(ValueError):
    pass


def quantity_decimal(value: object) -> Decimal:
    try:
        quantity = Decimal(str(value))
    except (InvalidOperation, ValueError) as exc:
        raise InventoryRuleError("inventory_quantity_invalid") from exc
    if not quantity.is_finite() or quantity <= 0:
        raise InventoryRuleError("inventory_quantity_must_be_positive")
    return quantity


def validate_direction(
    movement_kind: str,
    from_location_id: object | None,
    to_location_id: object | None,
) -> None:
    if movement_kind == "inbound":
        valid = from_location_id is None and to_location_id is not None
    elif movement_kind == "outbound":
        valid = from_location_id is not None and to_location_id is None
    elif movement_kind == "transfer":
        valid = (
            from_location_id is not None
            and to_location_id is not None
            and str(from_location_id) != str(to_location_id)
        )
    elif movement_kind in {"stocktake_adjustment", "reversal", "correction"}:
        valid = (from_location_id is None) != (to_location_id is None) or (
            from_location_id is not None
            and to_location_id is not None
            and str(from_location_id) != str(to_location_id)
        )
    else:
        raise InventoryRuleError("inventory_movement_kind_invalid")
    if not valid:
        raise InventoryRuleError("inventory_movement_direction_invalid")


def location_effect(
    *,
    location_id: object,
    quantity: object,
    from_location_id: object | None,
    to_location_id: object | None,
) -> Decimal:
    amount = quantity_decimal(quantity)
    effect = Decimal("0")
    if from_location_id is not None and str(from_location_id) == str(location_id):
        effect -= amount
    if to_location_id is not None and str(to_location_id) == str(location_id):
        effect += amount
    return effect


def project_balance(
    rows: Iterable[Mapping[str, object]],
    *,
    product_id: object,
    unit_id: object,
    location_id: object,
) -> Decimal:
    total = Decimal("0")
    for row in rows:
        if str(row["product_id"]) != str(product_id) or str(row["unit_id"]) != str(unit_id):
            continue
        total += location_effect(
            location_id=location_id,
            quantity=row["quantity"],
            from_location_id=row.get("from_location_id"),
            to_location_id=row.get("to_location_id"),
        )
    return total
