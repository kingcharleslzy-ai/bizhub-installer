"""Profile-bound backup and restore for the generic-kernel database."""

from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import uuid
from pathlib import Path

from .migrations import GenericKernelDatabaseError, readback_database


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _copy_sqlite(source: Path, target: Path) -> None:
    source_connection = sqlite3.connect(f"file:{source}?mode=ro", uri=True)
    target_connection = sqlite3.connect(target)
    try:
        source_connection.backup(target_connection)
        target_connection.commit()
    finally:
        target_connection.close()
        source_connection.close()


def create_backup(database_path: Path, backup_path: Path) -> Path:
    state = readback_database(database_path)
    backup_path = backup_path.resolve()
    backup_path.parent.mkdir(parents=True, exist_ok=True)
    temporary = backup_path.with_name(f".{backup_path.name}.{uuid.uuid4().hex}.tmp")
    _copy_sqlite(database_path, temporary)
    os.replace(temporary, backup_path)
    manifest = {
        "schema_version": "bizhub.generic-kernel-backup.v1",
        "profile_id": state["profile_id"],
        "lineage_id": state["lineage_id"],
        "migration_set_digest": state["migration_set_digest"],
        "schema_fingerprint": state["schema_fingerprint"],
        "database_sha256": _sha256(backup_path),
    }
    manifest_path = backup_path.with_suffix(backup_path.suffix + ".manifest.json")
    manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return manifest_path


def restore_backup(backup_path: Path, manifest_path: Path, target_path: Path) -> dict[str, object]:
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest.get("schema_version") != "bizhub.generic-kernel-backup.v1":
        raise GenericKernelDatabaseError("generic_backup_manifest_invalid", "unsupported manifest")
    if manifest.get("database_sha256") != _sha256(backup_path):
        raise GenericKernelDatabaseError("generic_backup_content_drift", "backup digest differs")
    source_state = readback_database(backup_path)
    for key in ("profile_id", "lineage_id", "migration_set_digest", "schema_fingerprint"):
        if manifest.get(key) != source_state.get(key):
            raise GenericKernelDatabaseError("generic_backup_identity_mismatch", f"{key} differs")
    target_path = target_path.resolve()
    target_path.parent.mkdir(parents=True, exist_ok=True)
    temporary = target_path.with_name(f".{target_path.name}.{uuid.uuid4().hex}.tmp")
    try:
        _copy_sqlite(backup_path, temporary)
        restored_state = readback_database(temporary)
        os.replace(temporary, target_path)
        return restored_state
    except Exception:
        temporary.unlink(missing_ok=True)
        raise
