"""Atomic migration governance for the independent generic-kernel lineage."""

from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Iterable, Sequence

from .models import MODEL_TABLES


PROFILE_ID = "generic-kernel-smoke"
LINEAGE_ID = "generic-kernel"


class GenericKernelDatabaseError(RuntimeError):
    def __init__(self, code: str, message: str):
        super().__init__(f"{code}: {message}")
        self.code = code
        self.message = message


def _canonical(payload: object) -> bytes:
    return (json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n").encode()


def _digest(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


@dataclass(frozen=True)
class KernelMigration:
    version: int
    migration_id: str
    dependencies: tuple[str, ...]
    statements: tuple[str, ...]
    owner_ref: str = "generic.kernel_smoke:runtime"

    @property
    def checksum(self) -> str:
        return _digest(
            _canonical(
                {
                    "lineage_id": LINEAGE_ID,
                    "version": self.version,
                    "migration_id": self.migration_id,
                    "dependencies": list(self.dependencies),
                    "statements": list(self.statements),
                }
            )
        )

    def descriptor(self) -> dict[str, object]:
        return {
            "version": self.version,
            "migration_id": self.migration_id,
            "owner_ref": self.owner_ref,
            "dependencies": list(self.dependencies),
            "checksum": self.checksum,
        }


MIGRATIONS: tuple[KernelMigration, ...] = (
    KernelMigration(
        version=1,
        migration_id="generic-kernel-baseline-v1",
        owner_ref="generic.kernel_smoke:runtime",
        dependencies=(),
        statements=(
            """CREATE TABLE kernel_instance_metadata (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            )""",
            """CREATE TABLE kernel_migration_ledger (
                lineage_id TEXT NOT NULL,
                migration_version INTEGER NOT NULL,
                migration_id TEXT NOT NULL,
                checksum TEXT NOT NULL,
                applied_at TEXT NOT NULL,
                PRIMARY KEY (lineage_id, migration_version),
                UNIQUE (lineage_id, migration_id)
            )""",
            """CREATE TABLE kernel_audit_events (
                event_id TEXT PRIMARY KEY,
                event_type TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                created_at TEXT NOT NULL
            )""",
        ),
    ),
    KernelMigration(
        version=2,
        migration_id="generic-master-data-catalog-v1",
        owner_ref="master_data:catalog-owner",
        dependencies=("generic-kernel-baseline-v1",),
        statements=(
            """CREATE TABLE master_data_parties (
                party_id TEXT PRIMARY KEY,
                canonical_name TEXT NOT NULL,
                normalized_name TEXT NOT NULL UNIQUE,
                status TEXT NOT NULL CHECK(status IN ('active', 'deprecated')),
                attributes_json TEXT NOT NULL
            )""",
            """CREATE TABLE master_data_products (
                product_id TEXT PRIMARY KEY,
                canonical_name TEXT NOT NULL,
                normalized_name TEXT NOT NULL UNIQUE,
                status TEXT NOT NULL CHECK(status IN ('active', 'deprecated')),
                attributes_json TEXT NOT NULL
            )""",
            """CREATE TABLE master_data_units (
                unit_id TEXT PRIMARY KEY,
                canonical_name TEXT NOT NULL,
                normalized_name TEXT NOT NULL UNIQUE,
                status TEXT NOT NULL CHECK(status IN ('active', 'deprecated')),
                attributes_json TEXT NOT NULL
            )""",
            """CREATE TABLE location_catalog (
                location_id TEXT PRIMARY KEY,
                canonical_name TEXT NOT NULL,
                normalized_name TEXT NOT NULL UNIQUE,
                status TEXT NOT NULL CHECK(status IN ('active', 'deprecated')),
                attributes_json TEXT NOT NULL
            )""",
            """CREATE TABLE master_data_external_identities (
                resource_kind TEXT NOT NULL CHECK(resource_kind IN ('party', 'product', 'unit', 'location')),
                source_id TEXT NOT NULL,
                external_id TEXT NOT NULL,
                resource_id TEXT NOT NULL,
                alias TEXT NOT NULL,
                normalized_alias TEXT NOT NULL,
                status TEXT NOT NULL CHECK(status IN ('active', 'deprecated')),
                PRIMARY KEY(resource_kind, source_id, external_id)
            )""",
            """CREATE UNIQUE INDEX uq_master_data_external_alias
                ON master_data_external_identities(resource_kind, source_id, normalized_alias)
                WHERE normalized_alias <> '' AND status = 'active'""",
            """CREATE TABLE master_data_audit_events (
                event_id TEXT PRIMARY KEY,
                event_type TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                created_at TEXT NOT NULL
            )""",
        ),
    ),
    KernelMigration(
        version=3,
        migration_id="generic-inventory-core-v1",
        owner_ref="inventory:movement-owner",
        dependencies=("generic-master-data-catalog-v1",),
        statements=(
            """CREATE TABLE inventory_movements (
                movement_id TEXT PRIMARY KEY,
                movement_kind TEXT NOT NULL CHECK(movement_kind IN (
                    'inbound', 'outbound', 'transfer', 'stocktake_adjustment', 'reversal', 'correction'
                )),
                product_id TEXT NOT NULL REFERENCES master_data_products(product_id) ON DELETE RESTRICT,
                unit_id TEXT NOT NULL REFERENCES master_data_units(unit_id) ON DELETE RESTRICT,
                quantity NUMERIC NOT NULL CHECK(quantity > 0),
                from_location_id TEXT REFERENCES location_catalog(location_id) ON DELETE RESTRICT,
                to_location_id TEXT REFERENCES location_catalog(location_id) ON DELETE RESTRICT,
                reverses_movement_id TEXT UNIQUE REFERENCES inventory_movements(movement_id) ON DELETE RESTRICT,
                occurred_at TEXT NOT NULL,
                source_ref TEXT NOT NULL,
                reason TEXT NOT NULL,
                CHECK(
                    (from_location_id IS NULL AND to_location_id IS NOT NULL) OR
                    (from_location_id IS NOT NULL AND to_location_id IS NULL) OR
                    (from_location_id IS NOT NULL AND to_location_id IS NOT NULL AND from_location_id <> to_location_id)
                )
            )""",
            """CREATE INDEX ix_inventory_movements_product_unit_time
                ON inventory_movements(product_id, unit_id, occurred_at, movement_id)""",
            """CREATE INDEX ix_inventory_movements_from_location
                ON inventory_movements(from_location_id, product_id, unit_id)""",
            """CREATE INDEX ix_inventory_movements_to_location
                ON inventory_movements(to_location_id, product_id, unit_id)""",
            """CREATE TRIGGER inventory_movements_immutable_update
                BEFORE UPDATE ON inventory_movements
                BEGIN SELECT RAISE(ABORT, 'inventory_movements_immutable'); END""",
            """CREATE TRIGGER inventory_movements_immutable_delete
                BEFORE DELETE ON inventory_movements
                BEGIN SELECT RAISE(ABORT, 'inventory_movements_immutable'); END""",
            """CREATE TABLE inventory_stocktakes (
                stocktake_id TEXT PRIMARY KEY,
                product_id TEXT NOT NULL REFERENCES master_data_products(product_id) ON DELETE RESTRICT,
                unit_id TEXT NOT NULL REFERENCES master_data_units(unit_id) ON DELETE RESTRICT,
                location_id TEXT NOT NULL REFERENCES location_catalog(location_id) ON DELETE RESTRICT,
                actual_quantity NUMERIC NOT NULL CHECK(actual_quantity >= 0),
                projected_quantity NUMERIC NOT NULL,
                occurred_at TEXT NOT NULL,
                source_ref TEXT NOT NULL
            )""",
            """CREATE TABLE inventory_audit_events (
                event_id TEXT PRIMARY KEY,
                event_type TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                created_at TEXT NOT NULL
            )""",
            """CREATE TABLE inventory_action_receipts (
                action_id TEXT PRIMARY KEY,
                idempotency_key TEXT NOT NULL UNIQUE,
                command_digest TEXT NOT NULL,
                preview_digest TEXT NOT NULL,
                movement_ids_json TEXT NOT NULL,
                stocktake_id TEXT REFERENCES inventory_stocktakes(stocktake_id) ON DELETE RESTRICT,
                audit_event_id TEXT NOT NULL REFERENCES inventory_audit_events(event_id) ON DELETE RESTRICT,
                created_at TEXT NOT NULL
            )""",
        ),
    ),
    KernelMigration(
        version=4,
        migration_id="generic-procurement-v1",
        owner_ref="procurement:order-owner",
        dependencies=("generic-inventory-core-v1",),
        statements=(
            """CREATE TABLE procurement_orders (
                order_id TEXT PRIMARY KEY,
                supplier_party_id TEXT NOT NULL REFERENCES master_data_parties(party_id) ON DELETE RESTRICT,
                ordered_at TEXT NOT NULL,
                status TEXT NOT NULL CHECK(status IN ('open', 'partially_received', 'received', 'cancelled')),
                revision INTEGER NOT NULL CHECK(revision >= 1),
                evidence_refs_json TEXT NOT NULL,
                source_ref TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )""",
            """CREATE TABLE procurement_order_lines (
                line_id TEXT PRIMARY KEY,
                order_id TEXT NOT NULL REFERENCES procurement_orders(order_id) ON DELETE RESTRICT,
                product_id TEXT NOT NULL REFERENCES master_data_products(product_id) ON DELETE RESTRICT,
                unit_id TEXT NOT NULL REFERENCES master_data_units(unit_id) ON DELETE RESTRICT,
                quantity NUMERIC NOT NULL CHECK(quantity > 0),
                received_quantity NUMERIC NOT NULL CHECK(received_quantity >= 0 AND received_quantity <= quantity),
                receive_location_id TEXT NOT NULL REFERENCES location_catalog(location_id) ON DELETE RESTRICT
            )""",
            """CREATE INDEX ix_procurement_order_lines_order
                ON procurement_order_lines(order_id, line_id)""",
            """CREATE TABLE procurement_receipts (
                receipt_id TEXT PRIMARY KEY,
                order_id TEXT NOT NULL REFERENCES procurement_orders(order_id) ON DELETE RESTRICT,
                line_id TEXT NOT NULL REFERENCES procurement_order_lines(line_id) ON DELETE RESTRICT,
                quantity NUMERIC NOT NULL CHECK(quantity > 0),
                inventory_action_id TEXT NOT NULL REFERENCES inventory_action_receipts(action_id) ON DELETE RESTRICT,
                inventory_movement_id TEXT NOT NULL REFERENCES inventory_movements(movement_id) ON DELETE RESTRICT,
                occurred_at TEXT NOT NULL,
                evidence_refs_json TEXT NOT NULL
            )""",
            """CREATE TABLE procurement_audit_events (
                event_id TEXT PRIMARY KEY,
                event_type TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                created_at TEXT NOT NULL
            )""",
            """CREATE TABLE procurement_action_receipts (
                action_id TEXT PRIMARY KEY,
                idempotency_key TEXT NOT NULL UNIQUE,
                command_digest TEXT NOT NULL,
                preview_digest TEXT NOT NULL,
                order_id TEXT NOT NULL REFERENCES procurement_orders(order_id) ON DELETE RESTRICT,
                audit_event_id TEXT NOT NULL REFERENCES procurement_audit_events(event_id) ON DELETE RESTRICT,
                inventory_action_id TEXT REFERENCES inventory_action_receipts(action_id) ON DELETE RESTRICT,
                created_at TEXT NOT NULL
            )""",
        ),
    ),
    KernelMigration(
        version=5,
        migration_id="generic-sales-v1",
        owner_ref="sales:order-owner",
        dependencies=("generic-procurement-v1",),
        statements=(
            """CREATE TABLE sales_orders (
                order_id TEXT PRIMARY KEY,
                customer_party_id TEXT NOT NULL REFERENCES master_data_parties(party_id) ON DELETE RESTRICT,
                ordered_at TEXT NOT NULL,
                status TEXT NOT NULL CHECK(status IN ('open', 'partially_fulfilled', 'fulfilled', 'partially_returned', 'returned', 'cancelled')),
                revision INTEGER NOT NULL CHECK(revision >= 1),
                evidence_refs_json TEXT NOT NULL,
                source_ref TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )""",
            """CREATE TABLE sales_order_lines (
                line_id TEXT PRIMARY KEY,
                order_id TEXT NOT NULL REFERENCES sales_orders(order_id) ON DELETE RESTRICT,
                product_id TEXT NOT NULL REFERENCES master_data_products(product_id) ON DELETE RESTRICT,
                unit_id TEXT NOT NULL REFERENCES master_data_units(unit_id) ON DELETE RESTRICT,
                quantity NUMERIC NOT NULL CHECK(quantity > 0),
                fulfilled_quantity NUMERIC NOT NULL CHECK(fulfilled_quantity >= 0 AND fulfilled_quantity <= quantity),
                returned_quantity NUMERIC NOT NULL CHECK(returned_quantity >= 0 AND returned_quantity <= fulfilled_quantity),
                ship_from_location_id TEXT NOT NULL REFERENCES location_catalog(location_id) ON DELETE RESTRICT
            )""",
            """CREATE INDEX ix_sales_order_lines_order
                ON sales_order_lines(order_id, line_id)""",
            """CREATE TABLE sales_fulfillments (
                fulfillment_id TEXT PRIMARY KEY,
                fulfillment_kind TEXT NOT NULL CHECK(fulfillment_kind IN ('shipment', 'return')),
                order_id TEXT NOT NULL REFERENCES sales_orders(order_id) ON DELETE RESTRICT,
                line_id TEXT NOT NULL REFERENCES sales_order_lines(line_id) ON DELETE RESTRICT,
                quantity NUMERIC NOT NULL CHECK(quantity > 0),
                inventory_action_id TEXT NOT NULL REFERENCES inventory_action_receipts(action_id) ON DELETE RESTRICT,
                inventory_movement_id TEXT NOT NULL REFERENCES inventory_movements(movement_id) ON DELETE RESTRICT,
                occurred_at TEXT NOT NULL,
                evidence_refs_json TEXT NOT NULL
            )""",
            """CREATE TABLE sales_audit_events (
                event_id TEXT PRIMARY KEY,
                event_type TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                created_at TEXT NOT NULL
            )""",
            """CREATE TABLE sales_action_receipts (
                action_id TEXT PRIMARY KEY,
                idempotency_key TEXT NOT NULL UNIQUE,
                command_digest TEXT NOT NULL,
                preview_digest TEXT NOT NULL,
                order_id TEXT NOT NULL REFERENCES sales_orders(order_id) ON DELETE RESTRICT,
                audit_event_id TEXT NOT NULL REFERENCES sales_audit_events(event_id) ON DELETE RESTRICT,
                inventory_action_id TEXT REFERENCES inventory_action_receipts(action_id) ON DELETE RESTRICT,
                created_at TEXT NOT NULL
            )""",
        ),
    ),
)


def validate_catalog(migrations: Sequence[KernelMigration] = MIGRATIONS) -> None:
    versions = [item.version for item in migrations]
    if versions != list(range(1, len(migrations) + 1)):
        raise GenericKernelDatabaseError("generic_migration_version_invalid", "versions must start at 1 and be contiguous")
    by_id = {item.migration_id: item for item in migrations}
    if len(by_id) != len(migrations):
        raise GenericKernelDatabaseError("generic_migration_identity_duplicate", "migration IDs must be unique")
    applied: set[str] = set()
    for migration in migrations:
        unknown = sorted(set(migration.dependencies) - set(by_id))
        if unknown:
            raise GenericKernelDatabaseError("generic_migration_dependency_unknown", str(unknown))
        unmet = sorted(set(migration.dependencies) - applied)
        if unmet:
            raise GenericKernelDatabaseError("generic_migration_dependency_order_invalid", str(unmet))
        applied.add(migration.migration_id)


def migration_set_digest(migrations: Sequence[KernelMigration] = MIGRATIONS) -> str:
    validate_catalog(migrations)
    return _digest(_canonical([item.descriptor() for item in migrations]))


def _connect(path: Path) -> sqlite3.Connection:
    connection = sqlite3.connect(path)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys=ON")
    if connection.execute("PRAGMA foreign_keys").fetchone()[0] != 1:
        connection.close()
        raise GenericKernelDatabaseError("generic_foreign_keys_disabled", "foreign key enforcement is required")
    return connection


def _schema_rows(connection: sqlite3.Connection) -> list[dict[str, str]]:
    rows = connection.execute(
        """SELECT type, name, COALESCE(sql, '') AS sql
           FROM sqlite_master
           WHERE name NOT LIKE 'sqlite_%'
           ORDER BY type, name"""
    ).fetchall()
    return [{"type": str(row["type"]), "name": str(row["name"]), "sql": " ".join(str(row["sql"]).split())} for row in rows]


def schema_fingerprint(connection: sqlite3.Connection) -> str:
    return _digest(_canonical(_schema_rows(connection)))


def expected_schema_fingerprint(
    migrations: Sequence[KernelMigration] = MIGRATIONS,
) -> str:
    connection = sqlite3.connect(":memory:")
    connection.row_factory = sqlite3.Row
    try:
        for migration in migrations:
            for statement in migration.statements:
                connection.execute(statement)
        return schema_fingerprint(connection)
    finally:
        connection.close()


def catalog_payload() -> dict[str, object]:
    return {
        "lineage_id": LINEAGE_ID,
        "current_schema_version": len(MIGRATIONS),
        "migration_set_digest": migration_set_digest(),
        "schema_fingerprint": expected_schema_fingerprint(),
        "items": [item.descriptor() for item in MIGRATIONS],
    }


def _metadata(connection: sqlite3.Connection) -> dict[str, str]:
    exists = connection.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name='kernel_instance_metadata'"
    ).fetchone()
    if not exists:
        return {}
    return {str(row["key"]): str(row["value"]) for row in connection.execute("SELECT key, value FROM kernel_instance_metadata")}


def _ledger(connection: sqlite3.Connection) -> list[dict[str, object]]:
    exists = connection.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name='kernel_migration_ledger'"
    ).fetchone()
    if not exists:
        return []
    rows = connection.execute(
        """SELECT lineage_id, migration_version, migration_id, checksum, applied_at
           FROM kernel_migration_ledger ORDER BY migration_version"""
    ).fetchall()
    return [dict(row) for row in rows]


def _recorded_migrations(
    connection: sqlite3.Connection,
    migrations: Sequence[KernelMigration],
) -> dict[int, dict[str, object]]:
    catalog = {item.version: item for item in migrations}
    recorded: dict[int, dict[str, object]] = {}
    for row in _ledger(connection):
        if row["lineage_id"] != LINEAGE_ID:
            raise GenericKernelDatabaseError(
                "generic_database_ledger_lineage_drift",
                f"unexpected lineage {row['lineage_id']!r}",
            )
        version = int(row["migration_version"])
        migration = catalog.get(version)
        if migration is None:
            raise GenericKernelDatabaseError(
                "generic_migration_content_drift",
                f"recorded migration version {version} is not in the catalog",
            )
        if row["migration_id"] != migration.migration_id or row["checksum"] != migration.checksum:
            raise GenericKernelDatabaseError(
                "generic_migration_content_drift",
                f"recorded migration {version} differs",
            )
        recorded[version] = row
    versions = sorted(recorded)
    if versions != list(range(1, len(versions) + 1)):
        raise GenericKernelDatabaseError(
            "generic_database_ledger_drift",
            f"recorded versions are not a contiguous prefix: {versions}",
        )
    return recorded


def _expected_table_names(migrations: Sequence[KernelMigration]) -> set[str]:
    active_owners = {item.owner_ref.split(":", 1)[0] for item in migrations}
    return {table.name for table in MODEL_TABLES if table.owner_ref in active_owners}


def migrations_for_modules(module_ids: Iterable[str]) -> tuple[KernelMigration, ...]:
    enabled = set(module_ids)
    if "inventory" in enabled and "master_data" not in enabled:
        raise GenericKernelDatabaseError(
            "generic_migration_dependency_module_missing",
            "inventory requires master_data",
        )
    if "procurement" in enabled and not {"master_data", "inventory"} <= enabled:
        raise GenericKernelDatabaseError(
            "generic_migration_dependency_module_missing",
            "procurement requires master_data and inventory",
        )
    if "sales" in enabled and not {"master_data", "inventory", "procurement"} <= enabled:
        raise GenericKernelDatabaseError(
            "generic_migration_dependency_module_missing",
            "sales requires master_data, inventory, and procurement "
            "for the current linear schema lineage",
        )
    highest_version = 1
    enabled_owner_ids = {"generic.kernel_smoke", *enabled}
    for item in MIGRATIONS:
        if item.owner_ref.split(":", 1)[0] in enabled_owner_ids:
            highest_version = max(highest_version, item.version)
    # A SQLite lineage is a contiguous prefix. Earlier module schema is retained
    # when its Runtime capability is disabled; this does not activate its writer.
    return MIGRATIONS[:highest_version]


def retained_migrations_for_database(
    path: Path,
    active_migrations: Sequence[KernelMigration],
) -> tuple[KernelMigration, ...]:
    """Retain already-applied module schema without activating its runtime."""

    if not path.exists():
        return tuple(active_migrations)
    connection = sqlite3.connect(f"file:{path.resolve()}?mode=ro", uri=True)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA query_only=ON")
    try:
        ledger = _ledger(connection)
    finally:
        connection.close()
    recorded_versions = [int(item["migration_version"]) for item in ledger]
    if any(version < 1 or version > len(MIGRATIONS) for version in recorded_versions):
        raise GenericKernelDatabaseError(
            "generic_migration_content_drift",
            f"recorded migration version outside catalog: {recorded_versions}",
        )
    active_versions = [item.version for item in active_migrations]
    target_version = max((*recorded_versions, *active_versions), default=0)
    return MIGRATIONS[:target_version]


def _verify_complete_state(
    connection: sqlite3.Connection,
    migrations: Sequence[KernelMigration],
    recorded: dict[int, dict[str, object]],
) -> None:
    expected_tables = _expected_table_names(migrations)
    actual_tables = {item["name"] for item in _schema_rows(connection) if item["type"] == "table"}
    if actual_tables != expected_tables:
        raise GenericKernelDatabaseError(
            "generic_schema_table_mismatch",
            f"expected={sorted(expected_tables)}, actual={sorted(actual_tables)}",
        )
    expected_metadata = {
        "profile_id": PROFILE_ID,
        "lineage_id": LINEAGE_ID,
        "migration_set_digest": migration_set_digest(migrations),
        "schema_fingerprint": schema_fingerprint(connection),
    }
    metadata = _metadata(connection)
    if metadata != expected_metadata:
        raise GenericKernelDatabaseError(
            "generic_database_metadata_drift",
            f"expected={expected_metadata}, actual={metadata}",
        )
    if sorted(recorded) != [item.version for item in migrations]:
        raise GenericKernelDatabaseError("generic_database_ledger_drift", "migration ledger differs")


def _apply_connection(
    connection: sqlite3.Connection,
    migrations: Sequence[KernelMigration],
    *,
    fail_after_statement: int | None = None,
) -> list[str]:
    validate_catalog(migrations)
    metadata = _metadata(connection)
    if metadata and (
        metadata.get("profile_id") != PROFILE_ID or metadata.get("lineage_id") != LINEAGE_ID
    ):
        raise GenericKernelDatabaseError("generic_database_identity_mismatch", "profile or lineage differs")
    existing = _recorded_migrations(connection, migrations)
    pending = [migration for migration in migrations if migration.version not in existing]
    if not pending:
        _verify_complete_state(connection, migrations, existing)
        return []

    applied_ids: list[str] = []
    statement_count = 0
    connection.execute("BEGIN IMMEDIATE")
    try:
        metadata = _metadata(connection)
        if metadata and (
            metadata.get("profile_id") != PROFILE_ID or metadata.get("lineage_id") != LINEAGE_ID
        ):
            raise GenericKernelDatabaseError("generic_database_identity_mismatch", "profile or lineage differs")
        existing = _recorded_migrations(connection, migrations)
        for migration in migrations:
            recorded = existing.get(migration.version)
            if recorded:
                continue
            applied_identities = {item["migration_id"] for item in existing.values()} | set(applied_ids)
            if not set(migration.dependencies).issubset(applied_identities):
                raise GenericKernelDatabaseError(
                    "generic_migration_dependency_unmet",
                    f"migration {migration.migration_id} dependencies are not applied",
                )
            for statement in migration.statements:
                connection.execute(statement)
                statement_count += 1
                if fail_after_statement is not None and statement_count >= fail_after_statement:
                    raise GenericKernelDatabaseError("generic_migration_injected_failure", "test-only failure")
            connection.execute(
                """INSERT INTO kernel_migration_ledger
                   (lineage_id, migration_version, migration_id, checksum, applied_at)
                   VALUES (?, ?, ?, ?, ?)""",
                (LINEAGE_ID, migration.version, migration.migration_id, migration.checksum, datetime.now(UTC).isoformat()),
            )
            applied_ids.append(migration.migration_id)

        expected_digest = migration_set_digest(migrations)
        fingerprint = schema_fingerprint(connection)
        values = {
            "profile_id": PROFILE_ID,
            "lineage_id": LINEAGE_ID,
            "migration_set_digest": expected_digest,
            "schema_fingerprint": fingerprint,
        }
        for key, value in values.items():
            connection.execute(
                "INSERT INTO kernel_instance_metadata(key, value) VALUES (?, ?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (key, value),
            )
        _verify_complete_state(connection, migrations, _recorded_migrations(connection, migrations))
        if applied_ids:
            connection.execute(
                "INSERT INTO kernel_audit_events(event_id, event_type, payload_json, created_at) VALUES (?, ?, ?, ?)",
                (
                    uuid.uuid4().hex,
                    "kernel_migrations_applied",
                    json.dumps({"migration_ids": applied_ids}, sort_keys=True, separators=(",", ":")),
                    datetime.now(UTC).isoformat(),
                ),
            )
        connection.commit()
        return applied_ids
    except Exception:
        connection.rollback()
        raise


def ensure_generic_database(
    path: Path,
    *,
    migrations: Sequence[KernelMigration] = MIGRATIONS,
    fail_after_statement: int | None = None,
) -> list[str]:
    """Create or verify the generic database without leaving a partial new file."""

    path = path.resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    is_new = not path.exists()
    working_path = path
    if is_new:
        working_path = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
    connection = _connect(working_path)
    try:
        applied = _apply_connection(connection, migrations, fail_after_statement=fail_after_statement)
    except Exception:
        connection.close()
        if is_new:
            working_path.unlink(missing_ok=True)
        raise
    connection.close()
    if is_new:
        os.replace(working_path, path)
    readback_database(path, migrations=migrations)
    return applied


def readback_database(
    path: Path,
    *,
    migrations: Sequence[KernelMigration] = MIGRATIONS,
) -> dict[str, object]:
    if not path.exists():
        raise GenericKernelDatabaseError("generic_database_missing", str(path))
    connection = _connect(path)
    try:
        metadata = _metadata(connection)
        ledger = _ledger(connection)
        tables = sorted(item["name"] for item in _schema_rows(connection) if item["type"] == "table")
        fingerprint = schema_fingerprint(connection)
        expected_ledger = [item.descriptor() for item in migrations]
        actual_ledger = [
            {
                "version": int(item["migration_version"]),
                "migration_id": str(item["migration_id"]),
                "owner_ref": migrations[int(item["migration_version"]) - 1].owner_ref,
                "dependencies": list(migrations[int(item["migration_version"]) - 1].dependencies),
                "checksum": str(item["checksum"]),
            }
            for item in ledger
        ]
        expected = {
            "profile_id": PROFILE_ID,
            "lineage_id": LINEAGE_ID,
            "migration_set_digest": migration_set_digest(migrations),
            "schema_fingerprint": fingerprint,
        }
        if metadata != expected:
            raise GenericKernelDatabaseError("generic_database_metadata_drift", f"expected={expected}, actual={metadata}")
        if actual_ledger != expected_ledger:
            raise GenericKernelDatabaseError("generic_database_ledger_drift", "migration ledger differs")
        if tables != sorted(_expected_table_names(migrations)):
            raise GenericKernelDatabaseError("generic_schema_table_mismatch", str(tables))
        return {
            **expected,
            "schema_version": len(migrations),
            "tables": tables,
            "migration_ids": [item.migration_id for item in migrations],
        }
    finally:
        connection.close()
