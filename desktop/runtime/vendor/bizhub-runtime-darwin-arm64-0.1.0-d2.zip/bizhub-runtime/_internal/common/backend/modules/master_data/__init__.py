"""Customer-neutral master-data module."""
