"""Append-only customer co-build state owned by the Generic kernel Runtime."""

from __future__ import annotations

import hashlib
import json
import re
import sqlite3
import uuid
from datetime import UTC, datetime
from pathlib import Path
from typing import Iterable, Literal

from .onboarding import MODULE_ID, OWNER_REF, read_workspace_onboarding


STATE_SCHEMA = "bizhub.workspace-cobuild-state.v1"
HANDOFF_SCHEMA = "bizhub.workspace-cobuild-handoff.v1"
ANSWER_EVENT = "workspace_cobuild_answer_recorded"
MATERIAL_EVENT = "workspace_cobuild_material_observed"
_ANSWER_SCHEMA = "bizhub.workspace-cobuild-answer.v1"
_MATERIAL_SCHEMA = "bizhub.workspace-cobuild-material.v1"
_IDEMPOTENCY_KEY_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{7,127}$")
_ACTOR_REF_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:@/-]{1,119}$")
_SOURCE_REF_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:@/-]{2,199}$")
_SENSITIVE_INPUT_PATTERN = re.compile(
    r"(?:pass(?:word|wd)|access[_ -]?token|api[_ -]?key|验证码|密码)\s*[:=：]\s*\S+|sk-[A-Za-z0-9_-]{12,}",
    re.IGNORECASE,
)

AnswerKind = Literal["answered", "unknown", "deferred", "skipped"]
MaterialKind = Literal["chat", "file", "image", "spreadsheet", "screenshot", "other"]


QUESTIONS: tuple[dict[str, object], ...] = (
    {
        "question_id": "priority_goal",
        "blueprint_target": "organization.priority_goal",
        "prompt": "你现在最希望系统先帮你解决什么？",
        "reason": "先从最有用的一件事开始，不需要一次讲完整家公司。",
        "examples": ["把微信群里的订单整理清楚", "知道库存还剩多少", "先看懂一张常用表格"],
    },
    {
        "question_id": "available_material",
        "blueprint_target": "data_sources.first_material",
        "prompt": "为了先做出一个能检查的结果，你手头最方便给我看的资料是什么？",
        "reason": "从平时就在用的资料开始，比重新填表更省事。",
        "examples": ["一张 Excel", "一段微信群聊天", "一张订单或库存截图"],
    },
    {
        "question_id": "actual_process",
        "blueprint_target": "processes.first_actual_flow",
        "prompt": "这件事现在通常是谁先开始，接着交给谁，最后怎样算完成？",
        "reason": "先弄清实际怎么做，系统才不会按想象改流程。",
        "examples": ["销售接单后交给仓库发货", "采购下单后由仓库确认收货", "负责人汇总后发给老板"],
    },
    {
        "question_id": "main_exception",
        "blueprint_target": "exceptions.first_risk",
        "prompt": "这件事最容易在哪一步出错、漏掉，或者需要重复做？",
        "reason": "找到最常见的麻烦，才能优先做出真正省事的改进。",
        "examples": ["同一个客户名字写法不一样", "图片里的批注被当成正式数字", "几个人说法不一致"],
    },
    {
        "question_id": "responsible_role",
        "blueprint_target": "organization.first_owner_role",
        "prompt": "这件事最终由哪个岗位或哪类人负责确认？",
        "reason": "系统需要知道遇到歧义时该找谁，而不是让每个人逐条审批。",
        "examples": ["销售负责人", "仓库管理员", "财务或老板本人"],
    },
)

EXPERIENCE_CARDS: tuple[dict[str, object], ...] = (
    {
        "card_id": "actual-before-ideal",
        "title": "先了解现在怎么做",
        "suggestion": "先复述实际流程，再讨论希望怎样改，避免系统按理想流程误判。",
        "question": "这件事现在实际上是怎样从开始走到完成的？",
        "applies_when": "客户开始描述流程或改进目标时",
        "not_a_customer_fact": True,
    },
    {
        "card_id": "visual-evidence-not-decision",
        "title": "图片和批注先当证据",
        "suggestion": "图片、红字和手写批注先保留来源；关系不明确时再请客户确认。",
        "question": "图片里的标记是正式业务内容，还是后来加的批注？",
        "applies_when": "收到图片、截图或 OCR 结果时",
        "not_a_customer_fact": True,
    },
    {
        "card_id": "complete-source-group",
        "title": "同一批资料一起看",
        "suggestion": "同一件事的多张图和多个文件先归在一起，再形成候选。",
        "question": "这些资料是不是同一件事的一整套？还有没有同批文件？",
        "applies_when": "一项业务由多份资料共同说明时",
        "not_a_customer_fact": True,
    },
    {
        "card_id": "ambiguity-needs-confirmation",
        "title": "关系不唯一就确认",
        "suggestion": "出现多个可能对象时保持待确认，不选择看起来最像的一个。",
        "question": "这里可能对应不止一个对象，你能帮我确认是哪一个吗？",
        "applies_when": "名称、人员、订单或文件关系不唯一时",
        "not_a_customer_fact": True,
    },
)


class WorkspaceCobuildError(RuntimeError):
    def __init__(self, code: str, message: str):
        super().__init__(f"{code}: {message}")
        self.code = code
        self.message = message


def _require_module_enabled(enabled_module_ids: Iterable[str] | None) -> set[str]:
    if enabled_module_ids is None:
        from .profile import get_generic_registry

        enabled_module_ids = [
            str(item["module_id"])
            for item in get_generic_registry().payload.get("modules", [])
        ]
    active = set(enabled_module_ids)
    if MODULE_ID not in active:
        raise WorkspaceCobuildError(
            "workspace_cobuild_module_disabled",
            f"{MODULE_ID} is not enabled",
        )
    return active


def _require_enterprise_context(
    path: Path,
    enabled_module_ids: Iterable[str] | None,
) -> tuple[set[str], dict[str, object]]:
    active = _require_module_enabled(enabled_module_ids)
    onboarding = read_workspace_onboarding(path, enabled_module_ids=active)
    if onboarding["stage"] != "enterprise_context_ready":
        raise WorkspaceCobuildError(
            "workspace_cobuild_enterprise_context_required",
            str(onboarding["stage"]),
        )
    return active, onboarding


def _connect(path: Path, *, readonly: bool) -> sqlite3.Connection:
    database_path = path.resolve()
    if not database_path.is_file():
        raise WorkspaceCobuildError("workspace_cobuild_database_missing", str(database_path))
    connection = sqlite3.connect(
        f"file:{database_path}?mode=ro" if readonly else database_path,
        uri=readonly,
    )
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys=ON")
    connection.execute("PRAGMA busy_timeout=10000")
    if readonly:
        connection.execute("PRAGMA query_only=ON")
    return connection


def _canonical(payload: object) -> bytes:
    return (
        json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        + "\n"
    ).encode()


def _digest(payload: object) -> str:
    return hashlib.sha256(_canonical(payload)).hexdigest()


def _stable_id(kind: str, workspace_id: str, key: str) -> str:
    return uuid.uuid5(
        uuid.NAMESPACE_URL,
        f"https://bizhub.local/workspace-cobuild/{kind}/{workspace_id}/{key}",
    ).hex


def _session_id(workspace_id: str) -> str:
    return f"cobuild-{_stable_id('session', workspace_id, 'v1')[:24]}"


def _validate_text(value: str, *, field: str, minimum: int, maximum: int) -> str:
    text = str(value or "").strip()
    if not minimum <= len(text) <= maximum:
        raise WorkspaceCobuildError(
            f"workspace_cobuild_{field}_invalid",
            f"{field} must contain {minimum} to {maximum} characters",
        )
    if _SENSITIVE_INPUT_PATTERN.search(text):
        raise WorkspaceCobuildError(
            "workspace_cobuild_sensitive_content_rejected",
            "sensitive credentials are not accepted",
        )
    return text


def _validate_ref(value: str, *, field: str, pattern: re.Pattern[str]) -> str:
    reference = str(value or "").strip()
    if not pattern.fullmatch(reference):
        raise WorkspaceCobuildError(f"workspace_cobuild_{field}_invalid", reference)
    return reference


def _load_events(connection: sqlite3.Connection) -> list[dict[str, object]]:
    rows = connection.execute(
        """SELECT event_id, event_type, payload_json, created_at
           FROM kernel_audit_events
           WHERE event_type IN (?, ?)""",
        (ANSWER_EVENT, MATERIAL_EVENT),
    ).fetchall()
    events: list[dict[str, object]] = []
    for row in rows:
        try:
            payload = json.loads(str(row["payload_json"]))
        except json.JSONDecodeError as exc:
            raise WorkspaceCobuildError(
                "workspace_cobuild_event_invalid",
                str(row["event_id"]),
            ) from exc
        if not isinstance(payload, dict):
            raise WorkspaceCobuildError(
                "workspace_cobuild_event_invalid",
                str(row["event_id"]),
            )
        events.append(
            {
                "event_id": str(row["event_id"]),
                "event_type": str(row["event_type"]),
                "created_at": str(row["created_at"]),
                "payload": payload,
            }
        )
    try:
        events.sort(key=lambda item: int(dict(item["payload"])["revision"]))
    except (KeyError, TypeError, ValueError) as exc:
        raise WorkspaceCobuildError("workspace_cobuild_event_invalid", "revision") from exc
    for expected, event in enumerate(events, start=1):
        payload = dict(event["payload"])
        if payload.get("revision") != expected:
            raise WorkspaceCobuildError(
                "workspace_cobuild_event_sequence_invalid",
                f"expected={expected}, actual={payload.get('revision')}",
            )
    return events


def _validate_event(event: dict[str, object], workspace_id: str, session_id: str) -> dict[str, object]:
    payload = dict(event["payload"])
    common = {
        "workspace_id": workspace_id,
        "session_id": session_id,
    }
    if any(payload.get(key) != value for key, value in common.items()):
        raise WorkspaceCobuildError("workspace_cobuild_event_identity_drift", str(event["event_id"]))
    if not re.fullmatch(r"[0-9a-f]{64}", str(payload.get("command_digest") or "")):
        raise WorkspaceCobuildError("workspace_cobuild_event_invalid", str(event["event_id"]))
    if not re.fullmatch(r"[0-9a-f]{64}", str(payload.get("idempotency_key_sha256") or "")):
        raise WorkspaceCobuildError("workspace_cobuild_event_invalid", str(event["event_id"]))
    event_type = str(event["event_type"])
    if event_type == ANSWER_EVENT:
        required = {
            "actor_ref",
            "answer_kind",
            "blueprint_target",
            "classification",
            "command_digest",
            "idempotency_key_sha256",
            "knowledge_id",
            "question_id",
            "revision",
            "schema_version",
            "session_id",
            "text",
            "valid_from",
            "workspace_id",
        }
        if set(payload) != required or payload.get("schema_version") != _ANSWER_SCHEMA:
            raise WorkspaceCobuildError("workspace_cobuild_event_invalid", str(event["event_id"]))
        question = next(
            (item for item in QUESTIONS if item["question_id"] == payload.get("question_id")),
            None,
        )
        if question is None or payload.get("blueprint_target") != question["blueprint_target"]:
            raise WorkspaceCobuildError("workspace_cobuild_question_invalid", str(payload.get("question_id")))
        kind = str(payload.get("answer_kind"))
        expected_classification = "user_confirmed" if kind == "answered" else "unresolved"
        if kind not in {"answered", "unknown", "deferred", "skipped"} or payload.get("classification") != expected_classification:
            raise WorkspaceCobuildError("workspace_cobuild_answer_kind_invalid", kind)
    elif event_type == MATERIAL_EVENT:
        required = {
            "blueprint_target",
            "classification",
            "command_digest",
            "display_name",
            "evidence_id",
            "idempotency_key_sha256",
            "knowledge_id",
            "material_kind",
            "observed_at",
            "provided_by",
            "revision",
            "schema_version",
            "session_id",
            "source_ref",
            "summary",
            "workspace_id",
        }
        if set(payload) != required or payload.get("schema_version") != _MATERIAL_SCHEMA:
            raise WorkspaceCobuildError("workspace_cobuild_event_invalid", str(event["event_id"]))
        if payload.get("classification") != "source_observed" or payload.get("blueprint_target") != "data_sources.observed_material":
            raise WorkspaceCobuildError("workspace_cobuild_event_invalid", str(event["event_id"]))
        if payload.get("material_kind") not in {"chat", "file", "image", "spreadsheet", "screenshot", "other"}:
            raise WorkspaceCobuildError("workspace_cobuild_material_kind_invalid", str(payload.get("material_kind")))
    else:
        raise WorkspaceCobuildError("workspace_cobuild_event_invalid", str(event["event_id"]))
    return payload


def _current_question(answered: set[str]) -> dict[str, object] | None:
    for question in QUESTIONS:
        if str(question["question_id"]) not in answered:
            return dict(question)
    return None


def _candidate_from_event(event: dict[str, object], payload: dict[str, object]) -> dict[str, object] | None:
    if event["event_type"] == MATERIAL_EVENT:
        return {
            "candidate_id": f"candidate-{str(event['event_id'])[:20]}",
            "candidate_type": "source_structure_preview",
            "title": f"资料预览：{payload['display_name']}",
            "summary": payload["summary"],
            "classification": "source_observed",
            "evidence_refs": [payload["evidence_id"]],
            "status": "candidate_requires_confirmation",
            "business_write_authorized": False,
            "module_activation_authorized": False,
        }
    if payload.get("answer_kind") != "answered":
        return None
    question_id = str(payload["question_id"])
    candidate_type = {
        "priority_goal": "improvement_opportunity",
        "available_material": "source_collection_plan",
        "actual_process": "actual_process_preview",
        "main_exception": "risk_opportunity",
        "responsible_role": "responsible_role_candidate",
    }[question_id]
    title = {
        "priority_goal": "第一项共建目标",
        "available_material": "第一份资料收集计划",
        "actual_process": "当前实际流程候选",
        "main_exception": "优先改进机会",
        "responsible_role": "责任岗位候选",
    }[question_id]
    return {
        "candidate_id": f"candidate-{str(event['event_id'])[:20]}",
        "candidate_type": candidate_type,
        "title": title,
        "summary": payload["text"],
        "classification": "user_confirmed",
        "evidence_refs": [f"answer-{str(event['event_id'])[:20]}"],
        "status": "candidate_requires_confirmation",
        "business_write_authorized": False,
        "module_activation_authorized": False,
    }


def _project_state(
    connection: sqlite3.Connection,
    onboarding: dict[str, object],
) -> dict[str, object]:
    workspace_id = str(onboarding["workspace_id"])
    session_id = _session_id(workspace_id)
    events = _load_events(connection)
    dialogue: list[dict[str, object]] = []
    knowledge: list[dict[str, object]] = []
    confirmations: list[dict[str, object]] = []
    candidates: list[dict[str, object]] = []
    answered_questions: set[str] = set()
    for event in events:
        payload = _validate_event(event, workspace_id, session_id)
        if event["event_type"] == ANSWER_EVENT:
            question_id = str(payload["question_id"])
            question = next(item for item in QUESTIONS if item["question_id"] == question_id)
            answered_questions.add(question_id)
            dialogue.extend(
                [
                    {
                        "message_id": f"question-{question_id}",
                        "role": "agent",
                        "text": question["prompt"],
                        "created_at": event["created_at"],
                    },
                    {
                        "message_id": f"answer-{str(event['event_id'])[:20]}",
                        "role": "customer",
                        "text": payload["text"],
                        "answer_kind": payload["answer_kind"],
                        "created_at": event["created_at"],
                    },
                ]
            )
            knowledge_item = {
                "knowledge_id": payload["knowledge_id"],
                "blueprint_target": payload["blueprint_target"],
                "classification": payload["classification"],
                "statement": payload["text"],
                "evidence_refs": [f"answer-{str(event['event_id'])[:20]}"],
                "provided_by": payload["actor_ref"],
                "valid_from": payload["valid_from"],
                "superseded_by": None,
                "blocks_activation": payload["classification"] == "unresolved",
            }
            knowledge.append(knowledge_item)
            if payload["classification"] == "unresolved":
                confirmations.append(
                    {
                        "confirmation_id": f"confirm-{str(event['event_id'])[:20]}",
                        "question_id": question_id,
                        "title": question["prompt"],
                        "status": payload["answer_kind"],
                        "reason": "这项信息尚未确定，可以以后再补充。",
                        "blocking_first_value": False,
                    }
                )
        else:
            dialogue.append(
                {
                    "message_id": f"material-{str(event['event_id'])[:20]}",
                    "role": "customer",
                    "text": f"提供了{payload['material_kind']}资料：{payload['display_name']}",
                    "created_at": event["created_at"],
                }
            )
            knowledge.append(
                {
                    "knowledge_id": payload["knowledge_id"],
                    "blueprint_target": payload["blueprint_target"],
                    "classification": "source_observed",
                    "statement": payload["summary"],
                    "evidence_refs": [payload["evidence_id"]],
                    "provided_by": payload["provided_by"],
                    "valid_from": payload["observed_at"],
                    "superseded_by": None,
                    "blocks_activation": False,
                }
            )
        candidate = _candidate_from_event(event, payload)
        if candidate is not None:
            candidates.append(candidate)

    next_question = _current_question(answered_questions)
    if not dialogue and next_question is not None:
        dialogue.append(
            {
                "message_id": f"question-{next_question['question_id']}",
                "role": "agent",
                "text": next_question["prompt"],
                "created_at": onboarding["enterprise_context_entered_at"],
            }
        )
    current_stage = "first_value_candidate_ready" if candidates else "collecting"
    return {
        "schema_version": STATE_SCHEMA,
        "owner_ref": OWNER_REF,
        "workspace_id": workspace_id,
        "workspace_display_name": onboarding["display_name"],
        "session_id": session_id,
        "stage": current_stage,
        "revision": len(events),
        "blueprint_projection": {
            "kind": "enterprise_blueprint_progressive_candidate",
            "description_only": True,
            "formal_blueprint_compiled": False,
            "production_change_authorized": False,
            "business_write_authorized": False,
            "runtime_self_modify_allowed": False,
            "knowledge_items": knowledge,
        },
        "views": {
            "dialogue": {"items": dialogue},
            "knowledge": {"items": knowledge},
            "confirmations": {"items": confirmations},
            "opportunities": {
                "items": candidates,
                "experience_cards": [dict(item) for item in EXPERIENCE_CARDS],
            },
        },
        "next_question": next_question,
        "first_value_candidate": candidates[0] if candidates else None,
        "can_resume": True,
        "read_only_handoff_available": True,
    }


def read_workspace_cobuild(
    path: Path,
    *,
    enabled_module_ids: Iterable[str] | None = None,
) -> dict[str, object]:
    """Read the four customer views without creating state on GET."""

    _, onboarding = _require_enterprise_context(path, enabled_module_ids)
    with _connect(path, readonly=True) as connection:
        return _project_state(connection, onboarding)


def answer_workspace_cobuild_question(
    path: Path,
    *,
    expected_revision: int,
    question_id: str,
    text: str,
    answer_kind: AnswerKind,
    actor_ref: str,
    idempotency_key: str,
    enabled_module_ids: Iterable[str] | None = None,
) -> dict[str, object]:
    """Record one answer to exactly the currently selected question."""

    active, onboarding = _require_enterprise_context(path, enabled_module_ids)
    if not isinstance(expected_revision, int) or isinstance(expected_revision, bool) or expected_revision < 0:
        raise WorkspaceCobuildError("workspace_cobuild_revision_invalid", str(expected_revision))
    key = _validate_ref(idempotency_key, field="idempotency_key", pattern=_IDEMPOTENCY_KEY_PATTERN)
    actor = _validate_ref(actor_ref, field="actor_ref", pattern=_ACTOR_REF_PATTERN)
    kind = str(answer_kind)
    if kind not in {"answered", "unknown", "deferred", "skipped"}:
        raise WorkspaceCobuildError("workspace_cobuild_answer_kind_invalid", kind)
    minimum = 1 if kind == "answered" else 0
    answer = _validate_text(text, field="answer", minimum=minimum, maximum=2000)
    if kind != "answered" and not answer:
        answer = {
            "unknown": "暂时不知道",
            "deferred": "以后再说",
            "skipped": "先跳过",
        }[kind]
    workspace_id = str(onboarding["workspace_id"])
    session_id = _session_id(workspace_id)
    command = {
        "workspace_id": workspace_id,
        "expected_revision": expected_revision,
        "question_id": str(question_id),
        "text": answer,
        "answer_kind": kind,
        "actor_ref": actor,
    }
    command_digest = _digest(command)
    event_id = _stable_id("answer", workspace_id, key)
    with _connect(path, readonly=False) as connection:
        connection.execute("BEGIN IMMEDIATE")
        try:
            replay = connection.execute(
                "SELECT payload_json FROM kernel_audit_events WHERE event_id=?",
                (event_id,),
            ).fetchone()
            if replay is not None:
                payload = json.loads(str(replay["payload_json"]))
                if payload.get("command_digest") != command_digest:
                    raise WorkspaceCobuildError(
                        "workspace_cobuild_idempotency_conflict",
                        "idempotency key was already used for another command",
                    )
                connection.rollback()
                return {**_project_state(connection, onboarding), "disposition": "idempotent_noop"}
            state = _project_state(connection, onboarding)
            if expected_revision != state["revision"]:
                raise WorkspaceCobuildError(
                    "workspace_cobuild_revision_drift",
                    f"expected={expected_revision}, actual={state['revision']}",
                )
            current = state["next_question"]
            if current is None or str(current["question_id"]) != str(question_id):
                raise WorkspaceCobuildError(
                    "workspace_cobuild_question_drift",
                    f"expected={None if current is None else current['question_id']}, actual={question_id}",
                )
            now = datetime.now(UTC).isoformat()
            revision = expected_revision + 1
            connection.execute(
                """INSERT INTO kernel_audit_events
                   (event_id, event_type, payload_json, created_at)
                   VALUES (?, ?, ?, ?)""",
                (
                    event_id,
                    ANSWER_EVENT,
                    _canonical(
                        {
                            "schema_version": _ANSWER_SCHEMA,
                            "workspace_id": workspace_id,
                            "session_id": session_id,
                            "revision": revision,
                            "question_id": str(question_id),
                            "blueprint_target": current["blueprint_target"],
                            "answer_kind": kind,
                            "text": answer,
                            "classification": "user_confirmed" if kind == "answered" else "unresolved",
                            "actor_ref": actor,
                            "knowledge_id": f"knowledge-answer-{event_id[:20]}",
                            "valid_from": now,
                            "command_digest": command_digest,
                            "idempotency_key_sha256": hashlib.sha256(key.encode()).hexdigest(),
                        }
                    ).decode().strip(),
                    now,
                ),
            )
            updated = _project_state(connection, onboarding)
            connection.commit()
            return {**updated, "disposition": "recorded"}
        except Exception:
            connection.rollback()
            raise


def observe_workspace_cobuild_material(
    path: Path,
    *,
    expected_revision: int,
    material_kind: MaterialKind,
    display_name: str,
    summary: str,
    source_ref: str,
    provided_by: str,
    idempotency_key: str,
    enabled_module_ids: Iterable[str] | None = None,
) -> dict[str, object]:
    """Store a bounded evidence summary, never raw file bytes or a business fact."""

    _, onboarding = _require_enterprise_context(path, enabled_module_ids)
    if not isinstance(expected_revision, int) or isinstance(expected_revision, bool) or expected_revision < 0:
        raise WorkspaceCobuildError("workspace_cobuild_revision_invalid", str(expected_revision))
    kind = str(material_kind)
    if kind not in {"chat", "file", "image", "spreadsheet", "screenshot", "other"}:
        raise WorkspaceCobuildError("workspace_cobuild_material_kind_invalid", kind)
    name = _validate_text(display_name, field="display_name", minimum=1, maximum=180)
    material_summary = _validate_text(summary, field="summary", minimum=1, maximum=4000)
    source = _validate_ref(source_ref, field="source_ref", pattern=_SOURCE_REF_PATTERN)
    actor = _validate_ref(provided_by, field="provided_by", pattern=_ACTOR_REF_PATTERN)
    key = _validate_ref(idempotency_key, field="idempotency_key", pattern=_IDEMPOTENCY_KEY_PATTERN)
    workspace_id = str(onboarding["workspace_id"])
    session_id = _session_id(workspace_id)
    command = {
        "workspace_id": workspace_id,
        "expected_revision": expected_revision,
        "material_kind": kind,
        "display_name": name,
        "summary": material_summary,
        "source_ref": source,
        "provided_by": actor,
    }
    command_digest = _digest(command)
    event_id = _stable_id("material", workspace_id, key)
    with _connect(path, readonly=False) as connection:
        connection.execute("BEGIN IMMEDIATE")
        try:
            replay = connection.execute(
                "SELECT payload_json FROM kernel_audit_events WHERE event_id=?",
                (event_id,),
            ).fetchone()
            if replay is not None:
                payload = json.loads(str(replay["payload_json"]))
                if payload.get("command_digest") != command_digest:
                    raise WorkspaceCobuildError(
                        "workspace_cobuild_idempotency_conflict",
                        "idempotency key was already used for another command",
                    )
                connection.rollback()
                return {**_project_state(connection, onboarding), "disposition": "idempotent_noop"}
            state = _project_state(connection, onboarding)
            if expected_revision != state["revision"]:
                raise WorkspaceCobuildError(
                    "workspace_cobuild_revision_drift",
                    f"expected={expected_revision}, actual={state['revision']}",
                )
            now = datetime.now(UTC).isoformat()
            revision = expected_revision + 1
            connection.execute(
                """INSERT INTO kernel_audit_events
                   (event_id, event_type, payload_json, created_at)
                   VALUES (?, ?, ?, ?)""",
                (
                    event_id,
                    MATERIAL_EVENT,
                    _canonical(
                        {
                            "schema_version": _MATERIAL_SCHEMA,
                            "workspace_id": workspace_id,
                            "session_id": session_id,
                            "revision": revision,
                            "material_kind": kind,
                            "display_name": name,
                            "summary": material_summary,
                            "source_ref": source,
                            "provided_by": actor,
                            "evidence_id": f"evidence-material-{event_id[:20]}",
                            "knowledge_id": f"knowledge-material-{event_id[:20]}",
                            "blueprint_target": "data_sources.observed_material",
                            "classification": "source_observed",
                            "observed_at": now,
                            "command_digest": command_digest,
                            "idempotency_key_sha256": hashlib.sha256(key.encode()).hexdigest(),
                        }
                    ).decode().strip(),
                    now,
                ),
            )
            updated = _project_state(connection, onboarding)
            connection.commit()
            return {**updated, "disposition": "recorded"}
        except Exception:
            connection.rollback()
            raise


def read_workspace_cobuild_handoff(
    path: Path,
    *,
    enabled_module_ids: Iterable[str] | None = None,
) -> dict[str, object]:
    """Return a bounded, read-only continuation summary for a successor Agent."""

    state = read_workspace_cobuild(path, enabled_module_ids=enabled_module_ids)
    knowledge = list(state["views"]["knowledge"]["items"])[-20:]
    confirmations = list(state["views"]["confirmations"]["items"])[-10:]
    opportunities = list(state["views"]["opportunities"]["items"])[-10:]
    return {
        "schema_version": HANDOFF_SCHEMA,
        "read_only": True,
        "owner_ref": OWNER_REF,
        "workspace_id": state["workspace_id"],
        "session_id": state["session_id"],
        "stage": state["stage"],
        "cobuild_revision": state["revision"],
        "profile_id": "generic-kernel-smoke",
        "blueprint_kind": state["blueprint_projection"]["kind"],
        "knowledge_summary": knowledge,
        "pending_confirmations": confirmations,
        "recent_candidates": opportunities,
        "next_question": state["next_question"],
        "experience_cards_are_suggestions_only": True,
        "business_write_authorized": False,
        "module_activation_authorized": False,
        "production_change_authorized": False,
        "successor_must_revalidate": [
            "workspace",
            "profile",
            "release",
            "permissions",
            "evidence_refs",
        ],
    }


__all__ = [
    "ANSWER_EVENT",
    "EXPERIENCE_CARDS",
    "HANDOFF_SCHEMA",
    "MATERIAL_EVENT",
    "QUESTIONS",
    "STATE_SCHEMA",
    "WorkspaceCobuildError",
    "answer_workspace_cobuild_question",
    "observe_workspace_cobuild_material",
    "read_workspace_cobuild",
    "read_workspace_cobuild_handoff",
]
