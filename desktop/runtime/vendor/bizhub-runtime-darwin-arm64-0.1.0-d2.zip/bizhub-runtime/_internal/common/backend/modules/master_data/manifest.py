"""Authoritative runtime manifest for the minimal master-data facade."""

from __future__ import annotations

from typing import Any


MODULE_ID = "master_data"
MODULE_VERSION = "0.1.0-cp3"
OWNER_REF = f"{MODULE_ID}:catalog-owner"
TABLES = (
    "location_catalog",
    "master_data_audit_events",
    "master_data_external_identities",
    "master_data_parties",
    "master_data_products",
    "master_data_units",
)


def master_data_module_manifest(source_commit: str, migrations: list[dict[str, Any]]) -> dict[str, Any]:
    return {
        "schema_version": "bizhub.runtime-module-manifest.v1",
        "module_id": MODULE_ID,
        "module_version": MODULE_VERSION,
        "source": {"kind": "generic", "commit": source_commit},
        "package": {
            "backend": "backend.modules.master_data",
            "public_api": "backend.modules.master_data.public:get_resource",
            "frontend_entry": None,
        },
        "dependencies": ["kernel.profile_registry"],
        "capabilities": {
            "provides": ["master-data.identity", "master-data.location-catalog"],
            "requires": ["kernel.profile-registry"],
        },
        "surfaces": {
            "routes": [
                {"surface_id": "generic_api", "method": "GET", "path": "/api/master-data/locations"},
            ],
            "ui_routes": [], "jobs": [], "mcp_tools": [],
            "actions": [{"action_id": "master_data.catalog.apply", "record_types": ["master_data_catalog"], "owner_ref": OWNER_REF}],
            "migrations": migrations,
        },
        "ownership": {
            "record_types": [{"record_type": "master_data_catalog", "owner_ref": OWNER_REF}],
            "tables": [{"table": table, "mode": "formal_writer", "owner_ref": OWNER_REF} for table in TABLES],
        },
        "activation": {"mode": "build-time", "retains_existing_data_when_disabled": True},
    }
