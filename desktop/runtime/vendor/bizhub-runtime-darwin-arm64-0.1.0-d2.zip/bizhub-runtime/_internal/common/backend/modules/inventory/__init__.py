"""Customer-neutral inventory module."""
