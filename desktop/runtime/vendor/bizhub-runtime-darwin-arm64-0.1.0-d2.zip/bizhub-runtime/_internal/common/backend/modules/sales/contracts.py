"""Typed sales commands and state-bound previews."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping

from backend.modules.trade_core.public import digest_json


@dataclass(frozen=True)
class SalesLine:
    line_id: str
    product_id: str
    unit_id: str
    quantity: str
    ship_from_location_id: str

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> "SalesLine":
        return cls(**{key: str(payload[key]) for key in cls.__dataclass_fields__})

    def to_dict(self) -> dict[str, str]:
        return {
            "line_id": self.line_id,
            "product_id": self.product_id,
            "unit_id": self.unit_id,
            "quantity": self.quantity,
            "ship_from_location_id": self.ship_from_location_id,
        }


@dataclass(frozen=True)
class SalesCommand:
    action: str
    idempotency_key: str
    order_id: str
    customer_party_id: str = ""
    ordered_at: str = ""
    lines: tuple[SalesLine, ...] = field(default_factory=tuple)
    target_line_id: str = ""
    quantity: str = ""
    occurred_at: str = ""
    source_ref: str = ""
    evidence_refs: tuple[str, ...] = field(default_factory=tuple)
    reason: str = ""

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> "SalesCommand":
        values = dict(payload)
        values["lines"] = tuple(
            SalesLine.from_dict(item)
            for item in (payload.get("lines") or ())
            if isinstance(item, Mapping)
        )
        values["evidence_refs"] = tuple(str(item) for item in (payload.get("evidence_refs") or ()))
        return cls(**values)

    def to_dict(self) -> dict[str, Any]:
        return {
            "action": self.action,
            "idempotency_key": self.idempotency_key,
            "order_id": self.order_id,
            "customer_party_id": self.customer_party_id,
            "ordered_at": self.ordered_at,
            "lines": [item.to_dict() for item in self.lines],
            "target_line_id": self.target_line_id,
            "quantity": self.quantity,
            "occurred_at": self.occurred_at,
            "source_ref": self.source_ref,
            "evidence_refs": list(self.evidence_refs),
            "reason": self.reason,
        }

    @property
    def command_digest(self) -> str:
        return digest_json(self.to_dict())


@dataclass(frozen=True)
class SalesPreview:
    command: SalesCommand
    state_generation: str
    planned_order: dict[str, Any]
    planned_lines: tuple[dict[str, Any], ...]
    planned_fulfillment: dict[str, Any] | None
    inventory_preview: dict[str, Any] | None
    preview_digest: str

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> "SalesPreview":
        command_payload = payload.get("command")
        if not isinstance(command_payload, Mapping):
            raise TypeError("command is required")
        planned_order = payload.get("planned_order")
        if not isinstance(planned_order, Mapping):
            raise TypeError("planned_order is required")
        fulfillment = payload.get("planned_fulfillment")
        inventory = payload.get("inventory_preview")
        return cls(
            command=SalesCommand.from_dict(command_payload),
            state_generation=str(payload["state_generation"]),
            planned_order=dict(planned_order),
            planned_lines=tuple(dict(item) for item in (payload.get("planned_lines") or ())),
            planned_fulfillment=(
                dict(fulfillment) if isinstance(fulfillment, Mapping) else None
            ),
            inventory_preview=dict(inventory) if isinstance(inventory, Mapping) else None,
            preview_digest=str(payload["preview_digest"]),
        )

    def content(self) -> dict[str, Any]:
        return {
            "command": self.command.to_dict(),
            "state_generation": self.state_generation,
            "planned_order": self.planned_order,
            "planned_lines": list(self.planned_lines),
            "planned_fulfillment": self.planned_fulfillment,
            "inventory_preview": self.inventory_preview,
        }

    def to_dict(self) -> dict[str, Any]:
        return {**self.content(), "preview_digest": self.preview_digest}
