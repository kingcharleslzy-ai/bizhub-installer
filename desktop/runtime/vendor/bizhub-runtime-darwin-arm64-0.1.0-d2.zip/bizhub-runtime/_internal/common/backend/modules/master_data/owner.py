"""Single writer for the generic master-data catalog."""

from __future__ import annotations

import json
import sqlite3
import uuid
from datetime import UTC, datetime
from pathlib import Path
from typing import Iterable

from .contracts import (
    RESOURCE_KINDS,
    CatalogDraft,
    CatalogPreview,
    digest_json,
    normalize_identity,
)
from .public import MasterDataError, get_resource, resolve_external_identity


MODULE_ID = "master_data"
OWNER_REF = f"{MODULE_ID}:catalog-owner"
_TABLES = {
    "party": ("master_data_parties", "party_id"),
    "product": ("master_data_products", "product_id"),
    "unit": ("master_data_units", "unit_id"),
    "location": ("location_catalog", "location_id"),
}
_INSERT_RESOURCE_SQL = {
    "party": """INSERT INTO master_data_parties
        (party_id, canonical_name, normalized_name, status, attributes_json)
        VALUES (?, ?, ?, 'active', ?)""",
    "product": """INSERT INTO master_data_products
        (product_id, canonical_name, normalized_name, status, attributes_json)
        VALUES (?, ?, ?, 'active', ?)""",
    "unit": """INSERT INTO master_data_units
        (unit_id, canonical_name, normalized_name, status, attributes_json)
        VALUES (?, ?, ?, 'active', ?)""",
    "location": """INSERT INTO location_catalog
        (location_id, canonical_name, normalized_name, status, attributes_json)
        VALUES (?, ?, ?, 'active', ?)""",
}


def _require_module_enabled(enabled_module_ids: Iterable[str] | None) -> None:
    if enabled_module_ids is None:
        from backend.generic_kernel.profile import get_generic_registry

        enabled_module_ids = [
            str(item["module_id"])
            for item in get_generic_registry().payload.get("modules", [])
        ]
    if MODULE_ID not in set(enabled_module_ids):
        raise MasterDataError("master_data_module_disabled", f"{MODULE_ID} is not enabled")


def _connect(path: Path, *, readonly: bool) -> sqlite3.Connection:
    connection = sqlite3.connect(f"file:{path}?mode=ro" if readonly else path, uri=readonly)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys=ON")
    connection.execute("PRAGMA busy_timeout=10000")
    if readonly:
        connection.execute("PRAGMA query_only=ON")
    return connection


def _state_generation(connection: sqlite3.Connection) -> str:
    payload: dict[str, list[dict[str, object]]] = {}
    for table in (*[item[0] for item in _TABLES.values()], "master_data_external_identities"):
        payload[table] = [dict(row) for row in connection.execute(f"SELECT * FROM {table} ORDER BY 1")]
    return digest_json(payload)


def preview_catalog(
    path: Path,
    drafts: Iterable[CatalogDraft],
    *,
    enabled_module_ids: Iterable[str] | None = None,
) -> CatalogPreview:
    _require_module_enabled(enabled_module_ids)
    items = tuple(drafts)
    identities: set[tuple[str, str]] = set()
    names: set[tuple[str, str]] = set()
    externals: set[tuple[str, str, str]] = set()
    for item in items:
        if item.resource_kind not in RESOURCE_KINDS:
            raise MasterDataError("master_data_resource_kind_invalid", item.resource_kind)
        if not item.resource_id.strip() or not item.canonical_name.strip():
            raise MasterDataError("master_data_identity_invalid", item.resource_id)
        identity = (item.resource_kind, item.resource_id)
        name = (item.resource_kind, normalize_identity(item.canonical_name))
        if identity in identities:
            raise MasterDataError("master_data_identity_duplicate", repr(identity))
        if name in names:
            raise MasterDataError("master_data_name_conflict", repr(name))
        identities.add(identity)
        names.add(name)
        if bool(item.source_id) != bool(item.external_id):
            raise MasterDataError("master_data_external_identity_incomplete", item.resource_id)
        if item.source_id:
            external = (item.resource_kind, item.source_id, item.external_id)
            if external in externals:
                raise MasterDataError("master_data_external_identity_duplicate", repr(external))
            externals.add(external)
    with _connect(path, readonly=True) as connection:
        generation = _state_generation(connection)
    body = {"state_generation": generation, "drafts": [item.to_dict() for item in items]}
    return CatalogPreview(generation, items, digest_json(body))


def _matching_audit_event(
    connection: sqlite3.Connection,
    preview_digest: str,
) -> sqlite3.Row | None:
    rows = connection.execute(
        """SELECT event_id, payload_json FROM master_data_audit_events
           WHERE event_type='catalog_bundle_applied' ORDER BY created_at, event_id"""
    ).fetchall()
    for row in rows:
        payload = json.loads(str(row["payload_json"]))
        if payload.get("preview_digest") == preview_digest:
            return row
    return None


def _readback_catalog(
    connection: sqlite3.Connection,
    preview: CatalogPreview,
    *,
    audit_event_id: str,
) -> dict[str, object]:
    resources: list[dict[str, object]] = []
    external_mappings: list[dict[str, str]] = []
    for item in preview.drafts:
        resource = get_resource(connection, item.resource_kind, item.resource_id)
        if resource["canonical_name"] != item.canonical_name:
            raise MasterDataError(
                "master_data_readback_drift",
                f"{item.resource_kind}:{item.resource_id}",
            )
        resources.append(
            {
                "resource_kind": item.resource_kind,
                "resource_id": item.resource_id,
                "canonical_name": str(resource["canonical_name"]),
            }
        )
        if item.source_id:
            resolved = resolve_external_identity(
                connection,
                resource_kind=item.resource_kind,
                source_id=item.source_id,
                external_id=item.external_id,
            )
            if resolved["resource_id"] != item.resource_id:
                raise MasterDataError(
                    "master_data_readback_drift",
                    f"{item.resource_kind}:{item.source_id}:{item.external_id}",
                )
            external_mappings.append(
                {
                    "resource_kind": item.resource_kind,
                    "source_id": item.source_id,
                    "external_id": item.external_id,
                    "resource_id": item.resource_id,
                    "alias": item.alias,
                }
            )
    return {
        "schema_version": "bizhub.master-data-catalog-readback.v1",
        "owner_ref": OWNER_REF,
        "preview_digest": preview.preview_digest,
        "resources": resources,
        "external_mappings": external_mappings,
        "audit_event_id": audit_event_id,
        "state_generation": _state_generation(connection),
    }


def apply_catalog(
    path: Path,
    preview: CatalogPreview,
    *,
    enabled_module_ids: Iterable[str] | None = None,
) -> dict[str, object]:
    _require_module_enabled(enabled_module_ids)
    expected = digest_json({
        "state_generation": preview.state_generation,
        "drafts": [item.to_dict() for item in preview.drafts],
    })
    if expected != preview.preview_digest:
        raise MasterDataError("master_data_preview_content_drift", "preview digest differs")
    with _connect(path, readonly=True) as read_connection:
        existing_event = _matching_audit_event(read_connection, preview.preview_digest)
        if existing_event is not None:
            result = _readback_catalog(
                read_connection,
                preview,
                audit_event_id=str(existing_event["event_id"]),
            )
            result["disposition"] = "idempotent_noop"
            return result
    authoritative = preview_catalog(
        path,
        preview.drafts,
        enabled_module_ids=enabled_module_ids,
    )
    if authoritative.preview_digest != preview.preview_digest:
        raise MasterDataError(
            "master_data_preview_content_drift",
            "preview differs from authoritative planning",
        )
    preview = authoritative
    with _connect(path, readonly=False) as connection:
        connection.execute("BEGIN IMMEDIATE")
        try:
            existing_event = _matching_audit_event(connection, preview.preview_digest)
            if existing_event is not None:
                connection.rollback()
                with _connect(path, readonly=True) as read_connection:
                    result = _readback_catalog(
                        read_connection,
                        preview,
                        audit_event_id=str(existing_event["event_id"]),
                    )
                    result["disposition"] = "idempotent_noop"
                    return result
            if _state_generation(connection) != preview.state_generation:
                raise MasterDataError("master_data_state_generation_drift", "catalog changed")
            created: list[dict[str, str]] = []
            for item in preview.drafts:
                attributes = json.dumps(item.attributes or {}, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
                connection.execute(
                    _INSERT_RESOURCE_SQL[item.resource_kind],
                    (item.resource_id, item.canonical_name, normalize_identity(item.canonical_name), attributes),
                )
                if item.source_id:
                    connection.execute(
                        """INSERT INTO master_data_external_identities
                           (resource_kind, source_id, external_id, resource_id, alias, normalized_alias, status)
                           VALUES (?, ?, ?, ?, ?, ?, 'active')""",
                        (
                            item.resource_kind,
                            item.source_id,
                            item.external_id,
                            item.resource_id,
                            item.alias,
                            normalize_identity(item.alias),
                        ),
                    )
                created.append({"resource_kind": item.resource_kind, "resource_id": item.resource_id})
            event_id = uuid.uuid4().hex
            connection.execute(
                """INSERT INTO master_data_audit_events(event_id, event_type, payload_json, created_at)
                   VALUES (?, 'catalog_bundle_applied', ?, ?)""",
                (
                    event_id,
                    json.dumps({"preview_digest": preview.preview_digest, "created": created}, sort_keys=True, separators=(",", ":")),
                    datetime.now(UTC).isoformat(),
                ),
            )
            result = _readback_catalog(
                connection,
                preview,
                audit_event_id=event_id,
            )
            connection.commit()
        except sqlite3.IntegrityError as exc:
            connection.rollback()
            raise MasterDataError("master_data_catalog_conflict", str(exc)) from exc
        except Exception:
            connection.rollback()
            raise
    result["created"] = created
    result["disposition"] = "applied"
    return result


__all__ = ["apply_catalog", "preview_catalog"]
