"""Small stable contracts shared by master-data consumers."""

from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from dataclasses import dataclass
from typing import Any


RESOURCE_KINDS = ("party", "product", "unit", "location")


def canonical_json(payload: object) -> bytes:
    return (
        json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        + "\n"
    ).encode()


def digest_json(payload: object) -> str:
    return hashlib.sha256(canonical_json(payload)).hexdigest()


def normalize_identity(value: object) -> str:
    return re.sub(r"\s+", "", unicodedata.normalize("NFKC", str(value or ""))).casefold()


@dataclass(frozen=True)
class CatalogDraft:
    resource_kind: str
    resource_id: str
    canonical_name: str
    source_id: str = ""
    external_id: str = ""
    alias: str = ""
    attributes: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "resource_kind": self.resource_kind,
            "resource_id": self.resource_id,
            "canonical_name": self.canonical_name,
            "source_id": self.source_id,
            "external_id": self.external_id,
            "alias": self.alias,
            "attributes": dict(self.attributes or {}),
        }

@dataclass(frozen=True)
class CatalogPreview:
    state_generation: str
    drafts: tuple[CatalogDraft, ...]
    preview_digest: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": "bizhub.master-data-catalog-preview.v1",
            "state_generation": self.state_generation,
            "drafts": [item.to_dict() for item in self.drafts],
            "preview_digest": self.preview_digest,
        }
