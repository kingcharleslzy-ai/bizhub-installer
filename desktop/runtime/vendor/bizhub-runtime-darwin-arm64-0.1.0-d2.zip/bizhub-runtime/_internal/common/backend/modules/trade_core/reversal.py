"""Shared reversal contract and journal; invoked only by the original trade Owner.

Original facts remain immutable. Existing domain audit/action receipts are the
reversal documents, including one durable manual-review item per target.
"""
from __future__ import annotations

import json
import sqlite3
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from typing import Any, Callable, Iterable, Mapping
from decimal import Decimal

from .public import TradeRuleError, business_datetime, decimal_sum, digest_json, normalized_evidence_refs


@dataclass(frozen=True)
class TradeNumericTools:
    """The Host supplies its existing quantity-parser functions to pure trade rules."""
    finite_decimal: Callable[[Any], Decimal | None]
    canonical_decimal_text: Callable[[Any], str | None]


@dataclass(frozen=True)
class TradeReversalCommand:
    action: str
    idempotency_key: str
    target_kind: str
    target_id: str
    occurred_at: str
    source_ref: str
    reason: str
    evidence_refs: tuple[str, ...] = ()

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> TradeReversalCommand:
        if not isinstance(payload, Mapping):
            raise TypeError("reversal command must be an object")
        values = dict(payload)
        refs = values.get("evidence_refs", ())
        if not isinstance(refs, (list, tuple)) or any(not isinstance(ref, str) for ref in refs):
            raise TypeError("evidence_refs must be an array of strings")
        if any(not isinstance(value, str) for key, value in values.items() if key != "evidence_refs"):
            raise TypeError("reversal fields must be strings")
        values["evidence_refs"] = tuple(refs)
        return cls(**values)

    def to_dict(self) -> dict[str, Any]:
        return {**asdict(self), "evidence_refs": list(self.evidence_refs)}


@dataclass(frozen=True)
class TradeReversalPreview:
    command: TradeReversalCommand
    state_generation: str
    targets: tuple[dict[str, Any], ...]
    blockers: tuple[dict[str, Any], ...]
    preview_digest: str

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> TradeReversalPreview:
        if not isinstance(payload, Mapping) or set(payload) != {"command", "state_generation", "targets", "blockers", "preview_digest"}:
            raise TypeError("invalid reversal preview")
        if any(not isinstance(payload[key], str) for key in ("state_generation", "preview_digest")):
            raise TypeError("preview digests must be strings")
        for key in ("targets", "blockers"):
            if not isinstance(payload[key], (list, tuple)) or any(not isinstance(item, Mapping) for item in payload[key]):
                raise TypeError(f"{key} must be an array of objects")
        return cls(TradeReversalCommand.from_dict(payload["command"]), payload["state_generation"],
                   tuple(dict(item) for item in payload["targets"]), tuple(dict(item) for item in payload["blockers"]), payload["preview_digest"])

    def content(self) -> dict[str, Any]:
        return {"command": self.command.to_dict(), "state_generation": self.state_generation,
                "targets": list(self.targets), "blockers": list(self.blockers)}

    def to_dict(self) -> dict[str, Any]:
        return {**self.content(), "preview_digest": self.preview_digest}


def reversed_movement(connection: sqlite3.Connection, movement_id: str) -> bool:
    return connection.execute("SELECT 1 FROM inventory_movements WHERE reverses_movement_id=?", (movement_id,)).fetchone() is not None


def reversal_documents(connection: sqlite3.Connection, domain: str) -> list[dict[str, Any]]:
    return [json.loads(row[0])["readback"] for row in connection.execute(
        f"SELECT payload_json FROM {domain}_audit_events WHERE event_type='trade_reversal_recorded' ORDER BY created_at, event_id")]


def target_voided(connection: sqlite3.Connection, domain: str, kind: str, identity: str) -> bool:
    return any(row["status"] == "reversed" and row["command"]["target_kind"] == kind and row["command"]["target_id"] == identity
               for row in reversal_documents(connection, domain))


def _generation(connection: sqlite3.Connection, domain: str) -> str:
    tables = [row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
              if row[0].startswith((domain + "_", "inventory_"))]
    return digest_json({table: [dict(row) for row in connection.execute(f'SELECT * FROM "{table}" ORDER BY rowid')] for table in tables})


def _targets(connection: sqlite3.Connection, domain: str, command: TradeReversalCommand) -> list[dict[str, Any]]:
    if domain == "procurement":
        if command.target_kind == "receipt_document":
            if not connection.execute("SELECT 1 FROM procurement_receipt_documents WHERE document_id=?", (command.target_id,)).fetchone():
                raise TradeRuleError("trade_reversal_target_missing")
            document = connection.execute("SELECT occurred_at FROM procurement_receipt_documents WHERE document_id=?", (command.target_id,)).fetchone()
            if business_datetime(command.occurred_at) < business_datetime(document[0]):
                raise TradeRuleError("trade_reversal_precedes_original")
            rows = connection.execute("""SELECT r.* FROM procurement_receipts r JOIN procurement_receipt_lines l ON l.line_id=r.receipt_line_id
                WHERE l.document_id=? AND NOT EXISTS (SELECT 1 FROM inventory_movements m WHERE m.reverses_movement_id=r.inventory_movement_id)
                ORDER BY r.receipt_id""", (command.target_id,)).fetchall()
        elif command.target_kind == "receipt":
            rows = connection.execute("SELECT * FROM procurement_receipts WHERE receipt_id=?", (command.target_id,)).fetchall()
        else:
            raise TradeRuleError("trade_reversal_target_kind_invalid")
    elif domain == "sales" and command.target_kind == "shipment":
        rows = connection.execute("SELECT * FROM sales_fulfillments WHERE fulfillment_id=? AND fulfillment_kind='shipment'", (command.target_id,)).fetchall()
    else:
        raise TradeRuleError("trade_reversal_target_kind_invalid")
    if not rows and command.target_kind != "receipt_document":
        raise TradeRuleError("trade_reversal_target_missing")
    targets = [dict(row) for row in rows]
    if target_voided(connection, domain, command.target_kind, command.target_id) or any(reversed_movement(connection, row["inventory_movement_id"]) for row in targets):
        raise TradeRuleError("trade_reversal_already_reversed")
    for row in targets:
        if business_datetime(command.occurred_at) < business_datetime(row["occurred_at"]):
            raise TradeRuleError("trade_reversal_precedes_original")
    return targets


def _blockers(connection: sqlite3.Connection, domain: str, targets: list[dict[str, Any]], numeric_tools: TradeNumericTools) -> list[dict[str, Any]]:
    blockers = []
    for row in targets:
        if domain == "procurement":
            # Retained revoked matches also count: an earlier reconciliation
            # requires a human decision, never an automatic unmatch.
            invoices = connection.execute("""SELECT DISTINCT i.invoice_id FROM procurement_invoice_matches m
                JOIN procurement_invoice_lines i ON i.line_id=m.invoice_line_id WHERE m.receipt_id=?""", (row["receipt_id"],)).fetchall()
        else:
            invoices = connection.execute("SELECT DISTINCT invoice_id FROM sales_invoice_lines WHERE order_id=? AND (order_line_id=? OR order_line_id IS NULL)",
                                          (row["order_id"], row["line_id"])).fetchall()
            returned = connection.execute("SELECT returned_quantity FROM sales_order_lines WHERE line_id=?", (row["line_id"],)).fetchone()
            if numeric_tools.finite_decimal(returned[0]) > 0 or connection.execute("SELECT 1 FROM sales_return_case_items WHERE order_line_id=?", (row["line_id"],)).fetchone():
                blockers.append({"code": "return_linked", "line_id": row["line_id"], "message": "该发货行已有退货处理，请人工核对后处理"})
        if domain == "procurement":
            payment_ids = [allocation[0] for allocation in connection.execute(
                "SELECT a.id FROM procurement_payment_allocations a JOIN procurement_order_lines l ON l.id=a.procurement_id WHERE l.line_id=?",
                (row["line_id"],))]
        else:
            payment_ids = [allocation[0] for invoice in invoices for allocation in connection.execute(
                "SELECT allocation_id FROM sales_payment_allocations WHERE invoice_id=?", (invoice[0],))]
        blockers.extend(reconciliation_reversal_blockers(
            invoice_ids=(invoice[0] for invoice in invoices), payment_allocation_ids=payment_ids))
    return sorted({digest_json(row): row for row in blockers}.values(), key=digest_json)


def reconciliation_reversal_blockers(*, invoice_ids: Iterable[Any] = (), payment_allocation_ids: Iterable[Any] = ()) -> list[dict[str, Any]]:
    """Any retained reconciliation requires human handling before a reversal.

    Owners supply their formal current and historical references; revoking a
    match never authorizes automatic deletion of the original receipt/shipment.
    """
    blockers = [
        {"code": "invoice_reconciled", "invoice_id": identity,
         "message": "已关联核对发票，须人工处理，不能直接作废"}
        for identity in invoice_ids
    ] + [
        {"code": "payment_reconciled", "allocation_id": identity,
         "message": "已核对付款/收款，须人工处理，不自动撤销核对"}
        for identity in payment_allocation_ids
    ]
    return sorted({digest_json(row): row for row in blockers}.values(), key=digest_json)


def preview_reversal(connection: sqlite3.Connection, domain: str, command: TradeReversalCommand, *, inventory_preview, inventory_command, enabled, numeric_tools: TradeNumericTools) -> TradeReversalPreview:
    if command.action not in {"void", "reverse"} or not all(isinstance(value, str) and value.strip() for value in
            (command.idempotency_key, command.target_id, command.source_ref, command.reason)):
        raise TradeRuleError("trade_reversal_fields_required")
    business_datetime(command.occurred_at)
    normalized_evidence_refs(command.evidence_refs)
    targets = _targets(connection, domain, command)
    blockers = _blockers(connection, domain, targets, numeric_tools)
    if not blockers:
        for index, row in enumerate(targets):
            inventory_preview(connection, inventory_command(action="reverse", idempotency_key=f"{domain}-reversal:{command.idempotency_key}:{index}",
                target_movement_id=row["inventory_movement_id"], occurred_at=command.occurred_at,
                source_ref=command.source_ref, reason=command.reason), enabled_module_ids=enabled, trade_owner_ref=f"{domain}:order-owner")
    content = {"command": command.to_dict(), "state_generation": _generation(connection, domain), "targets": targets, "blockers": blockers}
    return TradeReversalPreview(command, content["state_generation"], tuple(targets), tuple(blockers), digest_json(content))


def apply_reversal(connection: sqlite3.Connection, domain: str, preview: TradeReversalPreview, *, inventory_preview, inventory_apply, inventory_command, enabled, project_status, persist, numeric_tools: TradeNumericTools) -> dict[str, Any]:
    if not connection.in_transaction:
        raise TradeRuleError("trade_reversal_transaction_required")
    if digest_json(preview.content()) != preview.preview_digest:
        raise TradeRuleError("trade_reversal_preview_content_drift")
    command = preview.command
    command_digest = digest_json(command.to_dict())
    receipt_table = "procurement_action_receipts" if domain == "procurement" else "sales_document_action_receipts"
    existing = connection.execute(f"SELECT * FROM {receipt_table} WHERE idempotency_key=?", (command.idempotency_key,)).fetchone()
    if existing is not None:
        if existing["command_digest"] != command_digest or existing["document_kind"] != "reversal":
            raise TradeRuleError("trade_reversal_idempotency_conflict")
        stored = json.loads(connection.execute(f"SELECT payload_json FROM {domain}_audit_events WHERE event_id=?", (existing["audit_event_id"],)).fetchone()[0])["readback"]
        return {**stored, "disposition": "idempotent_noop"}
    authoritative = preview_reversal(connection, domain, command, inventory_preview=inventory_preview, inventory_command=inventory_command, enabled=enabled, numeric_tools=numeric_tools)
    if authoritative.preview_digest != preview.preview_digest:
        raise TradeRuleError("trade_reversal_state_generation_drift")
    # Different clicks on a blocked target share the same durable pending item.
    if preview.blockers:
        prior = next((row for row in reversal_documents(connection, domain) if row["status"] == "needs_manual_review"
                      and row["command"]["target_kind"] == command.target_kind and row["command"]["target_id"] == command.target_id), None)
        if prior is not None:
            return {**prior, "disposition": "idempotent_noop"}
    inventory_results = []
    line_changes = {}
    order_changes = {}
    if not preview.blockers:
        for index, target in enumerate(preview.targets):
            inventory = inventory_preview(connection, inventory_command(action="reverse", idempotency_key=f"{domain}-reversal:{command.idempotency_key}:{index}",
                target_movement_id=target["inventory_movement_id"], occurred_at=command.occurred_at,
                source_ref=command.source_ref, reason=command.reason), enabled_module_ids=enabled, trade_owner_ref=f"{domain}:order-owner")
            inventory_results.append(inventory_apply(connection, inventory, enabled_module_ids=enabled, trade_owner_ref=f"{domain}:order-owner"))
            field = "received_quantity" if domain == "procurement" else "fulfilled_quantity"
            line = connection.execute(f"SELECT {field} FROM {domain}_order_lines WHERE line_id=?", (target["line_id"],)).fetchone()
            remaining = decimal_sum((numeric_tools.finite_decimal(line_changes.get(target["line_id"], line[0])), numeric_tools.finite_decimal(target["quantity"]).copy_negate()))
            if remaining < 0:
                raise TradeRuleError("trade_reversal_quantity_inconsistent")
            line_changes[target["line_id"]] = numeric_tools.canonical_decimal_text(remaining)
        for order_id in sorted({row["order_id"] for row in preview.targets}):
            lines = [dict(row) for row in connection.execute(f"SELECT * FROM {domain}_order_lines WHERE order_id=?", (order_id,))]
            for line in lines:
                if line["line_id"] in line_changes:
                    line[field] = line_changes[line["line_id"]]
            order_changes[order_id] = project_status(lines)
    reversal_id = "rev-" + digest_json([domain, command.to_dict()])[:28]
    now = datetime.now(UTC).isoformat()
    result = {"schema_version": "bizhub.trade-reversal-readback.v1", "owner_ref": f"{domain}:order-owner",
              "reversal_id": reversal_id, "action_id": reversal_id, "command": command.to_dict(),
              "status": "needs_manual_review" if preview.blockers else "reversed", "blockers": list(preview.blockers),
              "message": "已生成一条人工处理待办；请先由人工核对发票、付款或退货关系，不自动撤销核对" if preview.blockers else "已冲销，可通过原交易入口重新登记正确数量",
              "targets": list(preview.targets), "inventory": inventory_results, "created_at": now}
    receipt = dict(action_id=reversal_id, idempotency_key=command.idempotency_key, command_digest=command_digest,
                   preview_digest=preview.preview_digest, document_kind="reversal", document_id=reversal_id,
                   order_id=preview.targets[0]["order_id"] if preview.targets else None, audit_event_id=reversal_id, created_at=now)
    if domain == "procurement":
        receipt["inventory_action_id"] = None
    persist(connection, preview, result, receipt, line_changes, order_changes)
    return {**result, "disposition": "applied"}
