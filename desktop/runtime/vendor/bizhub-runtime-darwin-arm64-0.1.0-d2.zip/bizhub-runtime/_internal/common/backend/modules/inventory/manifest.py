"""Authoritative runtime manifest for generic inventory."""

from __future__ import annotations

from typing import Any


MODULE_ID = "inventory"
MODULE_VERSION = "0.1.0-cp3"
OWNER_REF = f"{MODULE_ID}:movement-owner"
TABLES = (
    "inventory_action_receipts",
    "inventory_audit_events",
    "inventory_movements",
    "inventory_stocktakes",
)


def inventory_module_manifest(source_commit: str, migrations: list[dict[str, Any]]) -> dict[str, Any]:
    return {
        "schema_version": "bizhub.runtime-module-manifest.v1",
        "module_id": MODULE_ID,
        "module_version": MODULE_VERSION,
        "source": {"kind": "generic", "commit": source_commit},
        "package": {
            "backend": "backend.modules.inventory",
            "public_api": "backend.modules.inventory.public:get_balance",
            "frontend_entry": None,
        },
        "dependencies": ["kernel.profile_registry", "master_data"],
        "capabilities": {
            "provides": ["inventory.movement", "inventory.balance", "inventory.stocktake"],
            "requires": ["kernel.profile-registry", "master-data.identity", "master-data.location-catalog"],
        },
        "surfaces": {
            "routes": [
                {"surface_id": "generic_api", "method": "GET", "path": "/api/inventory/movements"},
                {"surface_id": "generic_api", "method": "GET", "path": "/api/inventory/balance"},
                {"surface_id": "generic_api", "method": "POST", "path": "/api/inventory/preview"},
                {"surface_id": "generic_api", "method": "POST", "path": "/api/inventory/apply"},
            ],
            "ui_routes": [], "jobs": [], "mcp_tools": [],
            "actions": [{"action_id": "inventory.apply", "record_types": ["inventory_movement", "inventory_stocktake"], "owner_ref": OWNER_REF}],
            "migrations": migrations,
        },
        "ownership": {
            "record_types": [
                {"record_type": "inventory_movement", "owner_ref": OWNER_REF},
                {"record_type": "inventory_stocktake", "owner_ref": OWNER_REF},
            ],
            "tables": [{"table": table, "mode": "formal_writer", "owner_ref": OWNER_REF} for table in TABLES],
        },
        "activation": {"mode": "build-time", "retains_existing_data_when_disabled": True},
    }
