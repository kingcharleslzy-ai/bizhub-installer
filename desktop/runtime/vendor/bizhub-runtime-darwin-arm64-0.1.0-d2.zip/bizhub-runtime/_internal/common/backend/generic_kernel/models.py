"""Explicit generic-kernel model catalog.

This catalog is intentionally independent from ``backend.models``. It is a
small schema descriptor used by the generic lineage and its artifact tests.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class KernelTable:
    name: str
    owner_ref: str
    purpose: str


MODEL_TABLES: tuple[KernelTable, ...] = (
    KernelTable("kernel_instance_metadata", "generic.kernel_smoke", "locked profile and lineage identity"),
    KernelTable("kernel_migration_ledger", "generic.kernel_smoke", "immutable migration identity and checksum"),
    KernelTable("kernel_audit_events", "generic.kernel_smoke", "customer-neutral lifecycle audit events"),
    KernelTable("master_data_parties", "master_data", "canonical party identity"),
    KernelTable("master_data_products", "master_data", "canonical product identity"),
    KernelTable("master_data_units", "master_data", "canonical measurement unit"),
    KernelTable("location_catalog", "master_data", "canonical generic location catalog"),
    KernelTable("master_data_external_identities", "master_data", "source identity and alias mapping"),
    KernelTable("master_data_audit_events", "master_data", "catalog write audit"),
    KernelTable("inventory_movements", "inventory", "immutable inventory movement"),
    KernelTable("inventory_stocktakes", "inventory", "physical stocktake record"),
    KernelTable("inventory_audit_events", "inventory", "inventory action audit"),
    KernelTable("inventory_action_receipts", "inventory", "idempotent action readback"),
    KernelTable("procurement_orders", "procurement", "customer-neutral purchase order"),
    KernelTable("procurement_order_lines", "procurement", "purchase order line state"),
    KernelTable("procurement_receipts", "procurement", "inventory-linked goods receipt"),
    KernelTable("procurement_audit_events", "procurement", "procurement action audit"),
    KernelTable("procurement_action_receipts", "procurement", "idempotent procurement readback"),
    KernelTable("sales_orders", "sales", "customer-neutral sales order"),
    KernelTable("sales_order_lines", "sales", "sales order fulfillment state"),
    KernelTable("sales_fulfillments", "sales", "inventory-linked shipment or return"),
    KernelTable("sales_audit_events", "sales", "sales action audit"),
    KernelTable("sales_action_receipts", "sales", "idempotent sales readback"),
)

MODEL_TABLE_NAMES = tuple(table.name for table in MODEL_TABLES)
