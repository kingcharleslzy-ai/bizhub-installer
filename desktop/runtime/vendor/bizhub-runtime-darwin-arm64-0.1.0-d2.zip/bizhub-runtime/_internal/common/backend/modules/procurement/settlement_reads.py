"""One read model for standard procurement settlement headers and allocations."""

from __future__ import annotations

import json
import sqlite3
from decimal import Decimal
from typing import Iterable, Mapping

from backend.modules.trade_core.public import decimal_sum

from .settlement_schema import PROCUREMENT_INVOICES, PROCUREMENT_PAYMENTS


def read_settlement_records(
    connection: sqlite3.Connection, *, procurement_ids: Iterable[int] = (),
    supplier_party_ids: Iterable[int] = (),
    expected_amounts: Mapping[tuple[int, str | None], Decimal | None] | None = None,
) -> dict:
    """Read confirmed facts in the caller's snapshot; never infer price or exchange money.

    Each allocation remains under its header currency. Supplier evidence includes
    unallocated headers; purchase-line totals include confirmed allocations only.
    Customer links and agreed purchase amounts remain with their formal adapters.
    """
    targets = json.dumps(sorted(set(map(int, procurement_ids))))
    suppliers = json.dumps(sorted(set(map(int, supplier_party_ids))))
    lines, headers, header_targets = {}, {}, {}
    for kind, table, allocation, owner_key, day in (
        ("invoice", PROCUREMENT_INVOICES, "procurement_invoice_allocations", "invoice_id", "invoice_date"),
        ("payment", PROCUREMENT_PAYMENTS, "procurement_payment_allocations", "payment_id", "business_date"),
    ):
        columns = ','.join(column.name for column in table.columns)
        headers[kind] = [dict(row) for row in connection.execute(
            f"SELECT {columns} FROM {table.name} WHERE status='confirmed' AND supplier_party_id IN (SELECT value FROM json_each(?)) ORDER BY {day} DESC,id DESC",
            (suppliers,))] if suppliers != '[]' else []
        rows = connection.execute(
            f"SELECT a.id,a.procurement_id,a.{owner_key} AS owner_id,a.allocated_amount,h.currency FROM {allocation} a JOIN {table.name} h ON h.id=a.{owner_key} WHERE a.status='confirmed' AND h.status='confirmed' AND a.procurement_id IN (SELECT value FROM json_each(?)) ORDER BY a.id",
            (targets,)) if targets != '[]' else ()
        header_targets[kind] = {}
        for row in rows:
            key = (int(row['procurement_id']), row['currency'])
            entry = lines.setdefault(key, {'invoice': [], 'payment': []})
            entry[kind].append(Decimal(str(row['allocated_amount'])))
            header_targets[kind].setdefault(int(row['owner_id']), set()).add(key[0])
    output = {}
    expected_amounts = expected_amounts or {}
    for key in lines.keys() | expected_amounts.keys():
        values = lines.get(key, {'invoice': [], 'payment': []})
        invoiced, paid = decimal_sum(values['invoice']), decimal_sum(values['payment'])
        expected = expected_amounts.get(key)
        difference = decimal_sum((expected, paid.copy_negate())) if expected is not None else None
        state = ('unregistered' if paid == 0 else 'allocated_amount_pending' if expected is None
                 else 'partial' if paid < expected else 'settled' if paid == expected else 'prepayment')
        output[key] = {'invoiced_amount': invoiced, 'invoice_allocation_count': len(values['invoice']),
                       'paid_amount': paid, 'payment_allocation_count': len(values['payment']),
                       'payable_amount': expected, 'remaining_payable': max(Decimal("0.00"), difference) if difference is not None else None,
                       'prepaid_amount': max(Decimal("0.00"), difference.copy_negate()) if difference is not None else None,
                       'payment_status': state}
    return {'lines': output, 'headers': headers, 'header_targets': header_targets}
