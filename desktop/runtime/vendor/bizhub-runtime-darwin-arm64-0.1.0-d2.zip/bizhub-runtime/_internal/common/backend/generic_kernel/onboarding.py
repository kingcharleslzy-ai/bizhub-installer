"""Single-Owner Workspace onboarding state for the Generic kernel."""

from __future__ import annotations

import hashlib
import json
import re
import sqlite3
import uuid
from datetime import UTC, datetime
from pathlib import Path
from typing import Iterable


MODULE_ID = "generic.kernel_smoke"
OWNER_REF = f"{MODULE_ID}:runtime"
STATE_SCHEMA = "bizhub.workspace-onboarding-state.v1"
INITIALIZED_EVENT = "workspace_onboarding_initialized"
ENTERED_EVENT = "workspace_onboarding_entered"
_INITIALIZED_SCHEMA = "bizhub.workspace-onboarding-initialized.v1"
_ENTERED_SCHEMA = "bizhub.workspace-onboarding-entered.v1"
_WORKSPACE_ID_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{2,159}$")
_IDEMPOTENCY_KEY_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{7,127}$")


class WorkspaceOnboardingError(RuntimeError):
    def __init__(self, code: str, message: str):
        super().__init__(f"{code}: {message}")
        self.code = code
        self.message = message


def _require_module_enabled(enabled_module_ids: Iterable[str] | None) -> None:
    if enabled_module_ids is None:
        from .profile import get_generic_registry

        enabled_module_ids = [
            str(item["module_id"])
            for item in get_generic_registry().payload.get("modules", [])
        ]
    if MODULE_ID not in set(enabled_module_ids):
        raise WorkspaceOnboardingError(
            "workspace_onboarding_module_disabled",
            f"{MODULE_ID} is not enabled",
        )


def _connect(path: Path, *, readonly: bool) -> sqlite3.Connection:
    database_path = path.resolve()
    if not database_path.is_file():
        raise WorkspaceOnboardingError(
            "workspace_onboarding_database_missing",
            str(database_path),
        )
    connection = sqlite3.connect(
        f"file:{database_path}?mode=ro" if readonly else database_path,
        uri=readonly,
    )
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys=ON")
    connection.execute("PRAGMA busy_timeout=10000")
    if readonly:
        connection.execute("PRAGMA query_only=ON")
    return connection


def _canonical(payload: object) -> bytes:
    return (
        json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        + "\n"
    ).encode()


def _digest(payload: object) -> str:
    return hashlib.sha256(_canonical(payload)).hexdigest()


def _event_id(kind: str, workspace_id: str, key: str) -> str:
    return uuid.uuid5(
        uuid.NAMESPACE_URL,
        f"https://bizhub.local/workspace-onboarding/{kind}/{workspace_id}/{key}",
    ).hex


def _validated_identity(
    workspace_id: str,
    display_name: str,
    data_authority_mode: str,
) -> dict[str, str]:
    identity = str(workspace_id or "").strip()
    name = str(display_name or "").strip()
    authority = str(data_authority_mode or "").strip()
    if not _WORKSPACE_ID_PATTERN.fullmatch(identity):
        raise WorkspaceOnboardingError(
            "workspace_onboarding_identity_invalid",
            "workspace_id is invalid",
        )
    if not 2 <= len(name) <= 100:
        raise WorkspaceOnboardingError(
            "workspace_onboarding_display_name_invalid",
            "display_name must contain 2 to 100 characters",
        )
    if authority not in {"local", "cloud"}:
        raise WorkspaceOnboardingError(
            "workspace_onboarding_authority_invalid",
            authority,
        )
    return {
        "workspace_id": identity,
        "display_name": name,
        "data_authority_mode": authority,
    }


def _events(connection: sqlite3.Connection) -> list[sqlite3.Row]:
    return connection.execute(
        """SELECT event_id, event_type, payload_json, created_at
           FROM kernel_audit_events
           WHERE event_type IN (?, ?)
           ORDER BY created_at, event_id""",
        (INITIALIZED_EVENT, ENTERED_EVENT),
    ).fetchall()


def _state(connection: sqlite3.Connection) -> dict[str, object]:
    initialized: list[tuple[sqlite3.Row, dict[str, object]]] = []
    entered: list[tuple[sqlite3.Row, dict[str, object]]] = []
    for row in _events(connection):
        try:
            payload = json.loads(str(row["payload_json"]))
        except json.JSONDecodeError as exc:
            raise WorkspaceOnboardingError(
                "workspace_onboarding_event_invalid",
                str(row["event_id"]),
            ) from exc
        if not isinstance(payload, dict):
            raise WorkspaceOnboardingError(
                "workspace_onboarding_event_invalid",
                str(row["event_id"]),
            )
        target = initialized if row["event_type"] == INITIALIZED_EVENT else entered
        target.append((row, payload))
    if len(initialized) != 1 or len(entered) > 1:
        raise WorkspaceOnboardingError(
            "workspace_onboarding_event_sequence_invalid",
            f"initialized={len(initialized)}, entered={len(entered)}",
        )
    initialized_row, identity = initialized[0]
    if set(identity) != {
        "data_authority_mode",
        "display_name",
        "schema_version",
        "workspace_id",
    } or identity.get("schema_version") != _INITIALIZED_SCHEMA:
        raise WorkspaceOnboardingError(
            "workspace_onboarding_event_invalid",
            str(initialized_row["event_id"]),
        )
    validated = _validated_identity(
        str(identity["workspace_id"]),
        str(identity["display_name"]),
        str(identity["data_authority_mode"]),
    )
    entered_at: str | None = None
    stage = "workspace_ready"
    revision = 1
    if entered:
        entered_row, payload = entered[0]
        if set(payload) != {
            "command_digest",
            "from_stage",
            "idempotency_key_sha256",
            "revision",
            "schema_version",
            "to_stage",
            "workspace_id",
        } or payload.get("schema_version") != _ENTERED_SCHEMA:
            raise WorkspaceOnboardingError(
                "workspace_onboarding_event_invalid",
                str(entered_row["event_id"]),
            )
        if (
            payload.get("workspace_id") != validated["workspace_id"]
            or payload.get("from_stage") != "workspace_ready"
            or payload.get("to_stage") != "enterprise_context_ready"
            or payload.get("revision") != 2
            or not re.fullmatch(r"[0-9a-f]{64}", str(payload.get("command_digest") or ""))
            or not re.fullmatch(r"[0-9a-f]{64}", str(payload.get("idempotency_key_sha256") or ""))
        ):
            raise WorkspaceOnboardingError(
                "workspace_onboarding_event_sequence_invalid",
                str(entered_row["event_id"]),
            )
        stage = "enterprise_context_ready"
        revision = 2
        entered_at = str(entered_row["created_at"])
    return {
        "schema_version": STATE_SCHEMA,
        "owner_ref": OWNER_REF,
        **validated,
        "stage": stage,
        "revision": revision,
        "created_at": str(initialized_row["created_at"]),
        "enterprise_context_entered_at": entered_at,
        "accepts_business_material": stage == "enterprise_context_ready",
    }


def initialize_workspace_onboarding(
    path: Path,
    *,
    workspace_id: str,
    display_name: str,
    data_authority_mode: str,
    enabled_module_ids: Iterable[str] | None = None,
) -> dict[str, object]:
    """Bind exactly one Workspace to the existing Generic kernel lineage."""

    _require_module_enabled(enabled_module_ids)
    identity = _validated_identity(workspace_id, display_name, data_authority_mode)
    with _connect(path, readonly=False) as connection:
        connection.execute("BEGIN IMMEDIATE")
        try:
            existing = _events(connection)
            if existing:
                state = _state(connection)
                if any(state[key] != identity[key] for key in identity):
                    raise WorkspaceOnboardingError(
                        "workspace_onboarding_identity_drift",
                        "the database is already bound to another Workspace identity",
                    )
                connection.rollback()
                return {**state, "disposition": "already_satisfied"}
            now = datetime.now(UTC).isoformat()
            connection.execute(
                """INSERT INTO kernel_audit_events
                   (event_id, event_type, payload_json, created_at)
                   VALUES (?, ?, ?, ?)""",
                (
                    _event_id("initialized", identity["workspace_id"], "v1"),
                    INITIALIZED_EVENT,
                    _canonical({"schema_version": _INITIALIZED_SCHEMA, **identity})
                    .decode()
                    .strip(),
                    now,
                ),
            )
            state = _state(connection)
            connection.commit()
            return {**state, "disposition": "initialized"}
        except Exception:
            connection.rollback()
            raise


def read_workspace_onboarding(
    path: Path,
    *,
    enabled_module_ids: Iterable[str] | None = None,
) -> dict[str, object]:
    _require_module_enabled(enabled_module_ids)
    with _connect(path, readonly=True) as connection:
        return _state(connection)


def enter_workspace(
    path: Path,
    *,
    expected_revision: int,
    idempotency_key: str,
    enabled_module_ids: Iterable[str] | None = None,
) -> dict[str, object]:
    """Close the public guide context and enter the enterprise context once."""

    _require_module_enabled(enabled_module_ids)
    if not isinstance(expected_revision, int) or isinstance(expected_revision, bool):
        raise WorkspaceOnboardingError(
            "workspace_onboarding_revision_invalid",
            str(expected_revision),
        )
    key = str(idempotency_key or "").strip()
    if not _IDEMPOTENCY_KEY_PATTERN.fullmatch(key):
        raise WorkspaceOnboardingError(
            "workspace_onboarding_idempotency_key_invalid",
            "idempotency_key is invalid",
        )
    with _connect(path, readonly=False) as connection:
        connection.execute("BEGIN IMMEDIATE")
        try:
            state = _state(connection)
            command = {
                "workspace_id": state["workspace_id"],
                "expected_revision": expected_revision,
                "to_stage": "enterprise_context_ready",
            }
            command_digest = _digest(command)
            event_id = _event_id("entered", str(state["workspace_id"]), key)
            replay = connection.execute(
                "SELECT payload_json FROM kernel_audit_events WHERE event_id=?",
                (event_id,),
            ).fetchone()
            if replay is not None:
                payload = json.loads(str(replay["payload_json"]))
                if payload.get("command_digest") != command_digest:
                    raise WorkspaceOnboardingError(
                        "workspace_onboarding_idempotency_conflict",
                        "idempotency key was already used for another command",
                    )
                connection.rollback()
                return {**state, "disposition": "idempotent_noop"}
            if state["stage"] == "enterprise_context_ready":
                connection.rollback()
                return {**state, "disposition": "already_satisfied"}
            if expected_revision != state["revision"]:
                raise WorkspaceOnboardingError(
                    "workspace_onboarding_revision_drift",
                    f"expected={expected_revision}, actual={state['revision']}",
                )
            now = datetime.now(UTC).isoformat()
            connection.execute(
                """INSERT INTO kernel_audit_events
                   (event_id, event_type, payload_json, created_at)
                   VALUES (?, ?, ?, ?)""",
                (
                    event_id,
                    ENTERED_EVENT,
                    _canonical(
                        {
                            "schema_version": _ENTERED_SCHEMA,
                            "workspace_id": state["workspace_id"],
                            "from_stage": "workspace_ready",
                            "to_stage": "enterprise_context_ready",
                            "revision": 2,
                            "command_digest": command_digest,
                            "idempotency_key_sha256": hashlib.sha256(key.encode()).hexdigest(),
                        }
                    )
                    .decode()
                    .strip(),
                    now,
                ),
            )
            updated = _state(connection)
            connection.commit()
            return {**updated, "disposition": "entered"}
        except Exception:
            connection.rollback()
            raise


__all__ = [
    "ENTERED_EVENT",
    "INITIALIZED_EVENT",
    "MODULE_ID",
    "OWNER_REF",
    "STATE_SCHEMA",
    "WorkspaceOnboardingError",
    "enter_workspace",
    "initialize_workspace_onboarding",
    "read_workspace_onboarding",
]
