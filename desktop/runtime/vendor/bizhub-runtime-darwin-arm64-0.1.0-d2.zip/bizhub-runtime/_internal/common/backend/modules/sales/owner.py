"""Single writer for customer-neutral sales orders, shipments, and returns."""

from __future__ import annotations

from backend.kernel.profile_registry import StorageTarget, read_storage, storage_connect, write_storage

import json
import sqlite3
import unicodedata
import uuid
from collections import Counter
from datetime import UTC, date, datetime
from fractions import Fraction
from decimal import Decimal
from pathlib import Path
from typing import Any, Iterable
from zoneinfo import ZoneInfo

from backend.modules.inventory.public import (
    InventoryCommand,
    InventoryPreview,
    apply_preview_in_transaction as apply_inventory_in_transaction,
    preview_action_in_transaction as preview_inventory_in_transaction,
    read_action_in_transaction as read_inventory_in_transaction,
)
from backend.modules.master_data.public import MasterDataError, get_resource, is_master_data_ref
from backend.modules.trade_core.public import (
    BUSINESS_TIMEZONE,
    business_datetime,
    check_decimal_range,
    decimal_sum as _decimal_sum,
    strict_money,
    TradeRuleError,
    aggregate_order_progress,
    digest_json,
    normalized_evidence_refs,
    project_order_progress,
    quantity_decimal,
)

from .contracts import SalesCommand, SalesPreview, SalesReturnCommand, SalesReturnPreview, SalesInvoiceCommand, SalesInvoicePreview, SalesPaymentCommand, SalesPaymentPreview


# Reversal state and physical writes remain under this original transaction Owner.
from backend.modules.trade_core.public import (
    TradeReversalCommand, TradeReversalPreview, apply_reversal as _apply_trade_reversal,
    preview_reversal as _preview_trade_reversal, reversal_documents as _reversal_documents,
)


MODULE_ID = "sales"
OWNER_REF = f"{MODULE_ID}:order-owner"
REQUIRED_MODULES = {
    MODULE_ID,
    "trade_core",
    "master_data",
    "inventory",
    "procurement",
}


class SalesOwnerError(RuntimeError):
    def __init__(self, code: str, message: str):
        super().__init__(f"{code}: {message}")
        self.code = code
        self.message = message


def _identity_text(value: str | None) -> str:
    return unicodedata.normalize("NFKC", value or "").strip().casefold()


def _invoice_facts(document: dict[str, Any], lines: Iterable[dict[str, Any]]) -> tuple[Any, ...]:
    header = tuple(document.get(key) or None for key in (
        "kind", "customer_party_id", "currency", "business_date", "original_invoice_id", "return_case_id"))
    details = []
    for line in lines:
        try:
            rate = quantity_decimal(line["tax_rate"], allow_zero=True) if line.get("tax_rate") is not None else None
        except TradeRuleError as exc:
            raise SalesOwnerError("sales_tax_rate_invalid", str(line["tax_rate"])) from exc
        details.append((_money(line["amount"]), rate,
                        _money(line["tax_amount"], allow_zero=True) if line.get("tax_amount") is not None else None,
                        line.get("order_id") or None, line.get("order_line_id") or None))
    return (*header, Counter(details))


def _check_invoice_identity(connection: sqlite3.Connection, command: SalesInvoiceCommand) -> None:
    number = _identity_text(command.document_number)
    if not number:
        return  # The typed credit-note entrypoint may allocate its own number.
    for row in connection.execute("SELECT * FROM sales_invoices"):
        if _identity_text(row["document_number"]) != number:
            continue
        if command.kind != "credit_note" and row["kind"] != "credit_note" and row["customer_party_id"] != command.customer_party_id:
            continue
        lines = [dict(line) for line in connection.execute("SELECT * FROM sales_invoice_lines WHERE invoice_id=?", (row["invoice_id"],))]
        same = _invoice_facts(dict(row), lines) == _invoice_facts(command.to_dict(), [item.to_dict() for item in command.lines])
        code = "sales_invoice_duplicate" if same else "sales_invoice_identity_conflict"
        raise SalesOwnerError(code, f"existing invoice_id={row['invoice_id']}")


def _check_decimal_range(value: Decimal, code: str) -> Decimal:
    try:
        return check_decimal_range(value, code)
    except TradeRuleError as exc:
        raise SalesOwnerError(code, "supports at most 18 integer digits and 4 fractional digits") from exc


def _sales_quantity(value: object, *, allow_zero: bool = False) -> Decimal:
    return _check_decimal_range(
        quantity_decimal(value, allow_zero=allow_zero), "sales_quantity_out_of_range",
    )


def _require_module_enabled(enabled_module_ids: Iterable[str] | None) -> set[str]:
    if enabled_module_ids is None:
        from backend.generic_kernel.profile import get_generic_registry

        enabled_module_ids = [
            str(item["module_id"])
            for item in get_generic_registry().payload.get("modules", [])
        ]
    enabled = set(enabled_module_ids)
    missing = sorted(REQUIRED_MODULES - enabled)
    if MODULE_ID not in enabled:
        raise SalesOwnerError("sales_module_disabled", f"{MODULE_ID} is not enabled")
    if missing:
        raise SalesOwnerError("sales_dependency_missing", ",".join(missing))
    return enabled


def _connect(path: Path, *, readonly: bool) -> sqlite3.Connection:
    connection = storage_connect(f"file:{path}?mode=ro" if readonly else path, uri=readonly)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys=ON")
    connection.execute("PRAGMA busy_timeout=10000")
    if readonly:
        connection.execute("PRAGMA query_only=ON")
    return connection


def _reading(storage: StorageTarget):
    return read_storage(storage, lambda path: _connect(path, readonly=True))


def _writing(storage: StorageTarget):
    return write_storage(storage, lambda path: _connect(path, readonly=False))


def _table_rows(connection: sqlite3.Connection, table: str, key: str) -> list[dict[str, Any]]:
    return [dict(row) for row in connection.execute(f"SELECT * FROM {table} ORDER BY {key}")]


def _state_generation(connection: sqlite3.Connection) -> str:
    return digest_json({
        "orders": _table_rows(connection, "sales_orders", "order_id"),
        "lines": _table_rows(connection, "sales_order_lines", "line_id"),
        "fulfillments": _table_rows(connection, "sales_fulfillments", "fulfillment_id"),
        "actions": _table_rows(connection, "sales_action_receipts", "action_id"),
    })


def _order(connection: sqlite3.Connection, order_id: str) -> dict[str, Any] | None:
    row = connection.execute(
        "SELECT * FROM sales_orders WHERE order_id=?", (order_id,)
    ).fetchone()
    return dict(row) if row else None


def _lines(connection: sqlite3.Connection, order_id: str) -> list[dict[str, Any]]:
    return [
        dict(row)
        for row in connection.execute(
            "SELECT * FROM sales_order_lines WHERE order_id=? ORDER BY line_id",
            (order_id,),
        )
    ]


def _validate_command(command: SalesCommand) -> tuple[str, ...]:
    if command.action not in {"create", "fulfill", "return", "cancel", "revise"}:
        raise SalesOwnerError("sales_action_invalid", command.action)
    if not isinstance(command.idempotency_key, str):
        raise SalesOwnerError("sales_idempotency_key_invalid", "use a string")
    if not command.idempotency_key.strip():
        raise SalesOwnerError("sales_idempotency_key_required", "idempotency key is required")
    for field in ("ordered_at", "occurred_at"):
        value = getattr(command, field)
        if value:
            try:
                business_datetime(value)
            except TradeRuleError as exc:
                raise SalesOwnerError("sales_" + field + "_invalid", "use an ISO date or timestamp with timezone") from exc
    if not command.order_id.strip():
        raise SalesOwnerError("sales_order_id_required", "order id is required")
    if not command.source_ref.strip():
        raise SalesOwnerError("sales_source_ref_required", "source ref is required")
    try:
        return normalized_evidence_refs(command.evidence_refs)
    except TradeRuleError as exc:
        raise SalesOwnerError(str(exc), "evidence refs are invalid") from exc


def _validated_lines(
    connection: sqlite3.Connection,
    command: SalesCommand,
) -> tuple[dict[str, Any], ...]:
    if not command.lines:
        raise SalesOwnerError("sales_lines_required", "at least one line is required")
    if len({item.line_id for item in command.lines}) != len(command.lines):
        raise SalesOwnerError("sales_line_id_duplicate", command.order_id)
    planned: list[dict[str, Any]] = []
    for item in command.lines:
        if not all((item.line_id.strip(), is_master_data_ref(item.product_id), is_master_data_ref(item.unit_id), item.ship_from_location_id.strip())):
            raise SalesOwnerError("sales_line_identity_required", item.line_id)
        try:
            get_resource(connection, "product", item.product_id)
            get_resource(connection, "unit", item.unit_id)
            get_resource(connection, "location", item.ship_from_location_id)
            quantity = _sales_quantity(item.quantity)
        except (MasterDataError, TradeRuleError) as exc:
            raise SalesOwnerError(getattr(exc, "code", str(exc)), item.line_id) from exc
        planned.append({
            "line_id": item.line_id,
            "product_id": item.product_id,
            "unit_id": item.unit_id,
            "quantity": format(quantity, "f"),
            "fulfilled_quantity": "0",
            "returned_quantity": "0",
            "ship_from_location_id": item.ship_from_location_id,
        })
    return tuple(planned)


def _validate_revision_references(
    connection: sqlite3.Connection,
    command: SalesCommand,
    current_lines: list[dict[str, Any]],
    planned_lines: tuple[dict[str, Any], ...],
) -> None:
    # Registered invoices bind the order at both granularities: any invoice
    # line pins the order's customer, and an order_line_id reference pins that
    # line's existence and product/unit identity. A revision that breaks a
    # live financial link is rejected before any plan is built.
    customers = {row[0] for row in connection.execute(
        """SELECT DISTINCT i.customer_party_id FROM sales_invoices i
           JOIN sales_invoice_lines l ON l.invoice_id=i.invoice_id WHERE l.order_id=?""",
        (command.order_id,),
    )}
    if customers and customers != {command.customer_party_id}:
        raise SalesOwnerError("sales_invoice_customer_mismatch", command.order_id)
    planned_by_id = {item["line_id"]: item for item in planned_lines}
    for row in connection.execute(
        "SELECT DISTINCT order_line_id FROM sales_invoice_lines WHERE order_id=? AND order_line_id IS NOT NULL",
        (command.order_id,),
    ):
        line_id = str(row[0])
        current = next((item for item in current_lines if item["line_id"] == line_id), None)
        planned = planned_by_id.get(line_id)
        if current is None or planned is None or (
            current["product_id"], current["unit_id"]
        ) != (planned["product_id"], planned["unit_id"]):
            raise SalesOwnerError("sales_invoice_linked_line_locked", line_id)


def _fulfillment_id(command: SalesCommand) -> str:
    return f"sls-{digest_json(command.to_dict())[:24]}"


def _project_order_status(lines: list[dict[str, Any]]) -> str:
    states = [
        project_order_progress(
            ordered_quantity=item["quantity"],
            completed_quantity=item["fulfilled_quantity"],
            returned_quantity=item["returned_quantity"],
        )
        for item in lines
    ]
    value = aggregate_order_progress(states)
    return {"completed": "fulfilled", "partial": "partially_fulfilled"}.get(value, value)



def _plan_line_effect(
    connection: sqlite3.Connection,
    command: SalesCommand | SalesReturnCommand,
    order: dict[str, Any],
    lines: list[dict[str, Any]],
    target: dict[str, Any],
    quantity: Decimal,
    stock_quantity: Decimal,
    *,
    enabled: Iterable[str],
    inventory_key: str | None = None,
) -> dict[str, Any]:
    if order["status"] == "cancelled":
        raise SalesOwnerError("sales_order_cancelled", command.order_id)
    fulfilled = _sales_quantity(target["fulfilled_quantity"], allow_zero=True)
    returned = _sales_quantity(target["returned_quantity"], allow_zero=True)
    outbound = command.action == "fulfill"
    limit = _decimal_sum((_sales_quantity(target["quantity"]), fulfilled.copy_negate())) if outbound else _decimal_sum((fulfilled, returned.copy_negate()))
    if quantity > limit:
        code = "sales_fulfillment_exceeds_remaining" if outbound else "sales_return_exceeds_fulfilled"
        raise SalesOwnerError(code, str(target["line_id"]))
    if not command.occurred_at.strip():
        raise SalesOwnerError("sales_occurred_at_required", command.order_id)
    inventory = None
    if stock_quantity > 0:
        inventory = preview_inventory_in_transaction(
            connection,
            InventoryCommand(
                action="outbound" if outbound else "inbound",
                idempotency_key=inventory_key or f"sales:{command.idempotency_key}",
                product_id=int(target["product_id"]),
                unit_id=int(target["unit_id"]),
                quantity=format(stock_quantity, "f"),
                from_location_id=str(target["ship_from_location_id"]) if outbound else None,
                to_location_id=str(target["ship_from_location_id"]) if not outbound else None,
                occurred_at=command.occurred_at,
                source_ref=command.source_ref,
                reason=command.reason,
            ),
            enabled_module_ids=enabled,
        ).to_dict()
    field = "fulfilled_quantity" if outbound else "returned_quantity"
    updated = [dict(item) for item in lines]
    for item in updated:
        if item["line_id"] == target["line_id"]:
            item[field] = format(_decimal_sum((Decimal(str(item[field])), quantity)), "f")
    return {
        "order_id": command.order_id,
        "line_id": target["line_id"],
        "quantity": format(quantity, "f"),
        "field": field,
        "order_status": _project_order_status(updated),
        "inventory_preview": inventory,
    }


def _apply_line_effect(connection: sqlite3.Connection, effect: dict[str, Any], now: str) -> None:
    field = effect["field"]
    current = connection.execute(
        f"SELECT {field} FROM sales_order_lines WHERE line_id=?", (effect["line_id"],),
    ).fetchone()
    cumulative = _decimal_sum((Decimal(str(current[0])), Decimal(effect["quantity"])))
    connection.execute(
        f"UPDATE sales_order_lines SET {field}=? WHERE line_id=?",
        (format(cumulative, "f"), effect["line_id"]),
    )
    connection.execute(
        "UPDATE sales_orders SET status=?, updated_at=? WHERE order_id=?",
        (effect["order_status"], now, effect["order_id"]),
    )


def _preview_on_connection(
    connection: sqlite3.Connection,
    command: SalesCommand,
    *,
    enabled_module_ids: Iterable[str] | None,
) -> SalesPreview:
    enabled = _require_module_enabled(enabled_module_ids)
    evidence_refs = _validate_command(command)
    generation = _state_generation(connection)
    existing = _order(connection, command.order_id)
    planned_lines: tuple[dict[str, Any], ...] = ()
    planned_fulfillment: dict[str, Any] | None = None
    inventory_preview: dict[str, Any] | None = None

    if command.action == "create":
        if existing is not None:
            raise SalesOwnerError("sales_order_already_exists", command.order_id)
        if not is_master_data_ref(command.customer_party_id) or not command.ordered_at.strip():
            raise SalesOwnerError("sales_order_identity_required", command.order_id)
        try:
            get_resource(connection, "party", command.customer_party_id)
        except MasterDataError as exc:
            raise SalesOwnerError(exc.code, exc.message) from exc
        planned_lines = _validated_lines(connection, command)
        planned_order = {
            "order_id": command.order_id,
            "customer_party_id": command.customer_party_id,
            "ordered_at": command.ordered_at,
            "status": "open",
            "revision": 1,
            "evidence_refs_json": json.dumps(evidence_refs, ensure_ascii=False),
            "source_ref": command.source_ref,
        }
    else:
        if existing is None:
            raise SalesOwnerError("sales_order_not_found", command.order_id)
        current_lines = _lines(connection, command.order_id)
        planned_order = dict(existing)
        if command.action in {"fulfill", "return"}:
            if existing["status"] == "cancelled":
                raise SalesOwnerError("sales_order_cancelled", command.order_id)
            target = next((item for item in current_lines if item["line_id"] == command.target_line_id), None)
            if target is None:
                raise SalesOwnerError("sales_line_not_found", command.target_line_id)
            try:
                quantity = _sales_quantity(command.quantity)
            except TradeRuleError as exc:
                raise SalesOwnerError(str(exc), command.quantity) from exc
            effect = _plan_line_effect(
                connection, command, existing, current_lines, target, quantity,
                quantity, enabled=enabled,
            )
            inventory_preview = effect["inventory_preview"]
            planned_fulfillment = {
                "fulfillment_id": _fulfillment_id(command),
                "fulfillment_kind": "shipment" if command.action == "fulfill" else "return",
                "order_id": command.order_id,
                "line_id": command.target_line_id,
                "quantity": format(quantity, "f"),
                "occurred_at": command.occurred_at,
                "evidence_refs_json": json.dumps(evidence_refs, ensure_ascii=False),
            }
            planned_order["status"] = effect["order_status"]
        elif command.action == "cancel":
            if existing["status"] == "cancelled":
                raise SalesOwnerError("sales_order_already_cancelled", command.order_id)
            if any(Decimal(str(item["fulfilled_quantity"])) > 0 for item in current_lines):
                raise SalesOwnerError("sales_fulfilled_order_not_cancellable", command.order_id)
            if not command.reason.strip():
                raise SalesOwnerError("sales_cancellation_reason_required", command.order_id)
            planned_order["status"] = "cancelled"
        else:
            if any(Decimal(str(item["fulfilled_quantity"])) > 0 for item in current_lines):
                raise SalesOwnerError("sales_fulfilled_order_not_revisable", command.order_id)
            if not command.reason.strip() or not is_master_data_ref(command.customer_party_id) or not command.ordered_at.strip():
                raise SalesOwnerError("sales_revision_fields_required", command.order_id)
            try:
                get_resource(connection, "party", command.customer_party_id)
            except MasterDataError as exc:
                raise SalesOwnerError(exc.code, exc.message) from exc
            planned_lines = _validated_lines(connection, command)
            _validate_revision_references(connection, command, current_lines, planned_lines)
            planned_order.update({
                "customer_party_id": command.customer_party_id,
                "ordered_at": command.ordered_at,
                "status": "open",
                "revision": int(existing["revision"]) + 1,
                "evidence_refs_json": json.dumps(evidence_refs, ensure_ascii=False),
                "source_ref": command.source_ref,
            })
    content = {
        "command": command.to_dict(),
        "state_generation": generation,
        "planned_order": planned_order,
        "planned_lines": list(planned_lines),
        "planned_fulfillment": planned_fulfillment,
        "inventory_preview": inventory_preview,
    }
    return SalesPreview(
        command=command,
        state_generation=generation,
        planned_order=planned_order,
        planned_lines=planned_lines,
        planned_fulfillment=planned_fulfillment,
        inventory_preview=inventory_preview,
        preview_digest=digest_json(content),
    )


def preview_action(
    storage: StorageTarget,
    command: SalesCommand,
    *,
    enabled_module_ids: Iterable[str] | None = None,
) -> SalesPreview:
    _require_module_enabled(enabled_module_ids)
    with _reading(storage) as connection:
        return _preview_on_connection(connection, command, enabled_module_ids=enabled_module_ids)


def read_action(
    storage: StorageTarget,
    idempotency_key: str,
    *,
    enabled_module_ids: Iterable[str] | None = None,
) -> dict[str, Any]:
    """Read one applied action by its idempotency key, without writing."""

    _require_module_enabled(enabled_module_ids)
    with _reading(storage) as connection:
        row = connection.execute(
            "SELECT action_id FROM sales_action_receipts WHERE idempotency_key=?",
            (idempotency_key,),
        ).fetchone()
        if row is None:
            raise SalesOwnerError("sales_readback_missing", idempotency_key)
        return _readback(connection, str(row["action_id"]))


def read_order(
    storage: StorageTarget,
    order_id: str,
    *,
    enabled_module_ids: Iterable[str] | None = None,
) -> dict[str, Any]:
    """Read one order with its lines and fulfillments, without writing."""

    _require_module_enabled(enabled_module_ids)
    with _reading(storage) as connection:
        order = _order(connection, order_id)
        if order is None:
            raise SalesOwnerError("sales_order_not_found", order_id)
        return {
            "schema_version": "bizhub.sales-order-read.v1",
            "order": order,
            "lines": _lines(connection, order_id),
            "fulfillments": [
                dict(row)
                for row in connection.execute(
                    "SELECT * FROM sales_fulfillments WHERE order_id=? ORDER BY fulfillment_id",
                    (order_id,),
                )
            ],
        }


def _readback(connection: sqlite3.Connection, action_id: str) -> dict[str, Any]:
    receipt = connection.execute(
        "SELECT * FROM sales_action_receipts WHERE action_id=?", (action_id,)
    ).fetchone()
    if receipt is None:
        raise SalesOwnerError("sales_readback_missing", action_id)
    order_id = str(receipt["order_id"])
    inventory = None
    if receipt["inventory_action_id"]:
        inventory = read_inventory_in_transaction(connection, str(receipt["inventory_action_id"]))
    audit = connection.execute(
        "SELECT * FROM sales_audit_events WHERE event_id=?",
        (receipt["audit_event_id"],),
    ).fetchone()
    return {
        "schema_version": "bizhub.sales-readback.v1",
        "owner_ref": OWNER_REF,
        "action_id": action_id,
        "idempotency_key": str(receipt["idempotency_key"]),
        "command_digest": str(receipt["command_digest"]),
        "preview_digest": str(receipt["preview_digest"]),
        "order": _order(connection, order_id),
        "lines": _lines(connection, order_id),
        "fulfillments": [
            dict(row)
            for row in connection.execute(
                "SELECT * FROM sales_fulfillments WHERE order_id=? ORDER BY fulfillment_id",
                (order_id,),
            )
        ],
        "inventory": inventory,
        "audit_event": dict(audit) if audit else None,
        "state_generation": _state_generation(connection),
    }


def apply_preview_in_transaction(connection: sqlite3.Connection, preview: SalesPreview, *, enabled_module_ids: Iterable[str] | None = None) -> dict[str, Any]:
    if not connection.in_transaction:
        raise SalesOwnerError("sales_transaction_required", "an outer transaction is required")
    enabled = _require_module_enabled(enabled_module_ids)
    if digest_json(preview.content()) != preview.preview_digest:
        raise SalesOwnerError("sales_preview_content_drift", "preview digest differs")
    try:
        existing = connection.execute(
            "SELECT action_id, command_digest FROM sales_action_receipts WHERE idempotency_key=?",
            (preview.command.idempotency_key,),
        ).fetchone()
        if existing is not None:
            if str(existing["command_digest"]) != preview.command.command_digest:
                raise SalesOwnerError("sales_idempotency_conflict", preview.command.idempotency_key)
            result = _readback(connection, str(existing["action_id"]))
            result["disposition"] = "idempotent_noop"
            return result
        if _state_generation(connection) != preview.state_generation:
            raise SalesOwnerError("sales_state_generation_drift", "sales changed")
        authoritative = _preview_on_connection(
            connection,
            preview.command,
            enabled_module_ids=enabled,
        )
        if authoritative.preview_digest != preview.preview_digest:
            raise SalesOwnerError("sales_preview_content_drift", "authoritative plan differs")
        inventory_result = None
        if authoritative.inventory_preview:
            inventory_result = apply_inventory_in_transaction(
                connection,
                InventoryPreview.from_dict(authoritative.inventory_preview),
                enabled_module_ids=enabled,
            )
        now = datetime.now(UTC).isoformat()
        order = authoritative.planned_order
        if preview.command.action == "create":
            connection.execute(
                """INSERT INTO sales_orders
                   (order_id, customer_party_id, ordered_at, status, revision,
                    evidence_refs_json, source_ref, created_at, updated_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    order["order_id"], order["customer_party_id"], order["ordered_at"],
                    order["status"], order["revision"], order["evidence_refs_json"],
                    order["source_ref"], now, now,
                ),
            )
            for line in authoritative.planned_lines:
                connection.execute(
                    """INSERT INTO sales_order_lines
                       (line_id, order_id, product_id, unit_id, quantity,
                        fulfilled_quantity, returned_quantity, ship_from_location_id)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        line["line_id"], preview.command.order_id, line["product_id"],
                        line["unit_id"], line["quantity"], line["fulfilled_quantity"],
                        line["returned_quantity"], line["ship_from_location_id"],
                    ),
                )
        elif preview.command.action in {"fulfill", "return"}:
            movement_ids = [item["movement_id"] for item in (inventory_result or {}).get("movements", [])]
            fulfillment = authoritative.planned_fulfillment or {}
            connection.execute(
                """INSERT INTO sales_fulfillments
                   (fulfillment_id, fulfillment_kind, order_id, line_id, quantity,
                    inventory_action_id, inventory_movement_id, occurred_at, evidence_refs_json)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    fulfillment["fulfillment_id"], fulfillment["fulfillment_kind"],
                    fulfillment["order_id"], fulfillment["line_id"], fulfillment["quantity"],
                    (inventory_result or {}).get("action_id"), movement_ids[0] if movement_ids else None,
                    fulfillment["occurred_at"], fulfillment["evidence_refs_json"],
                ),
            )
            _apply_line_effect(connection, {
                "order_id": preview.command.order_id,
                "line_id": fulfillment["line_id"],
                "quantity": fulfillment["quantity"],
                "field": "fulfilled_quantity" if preview.command.action == "fulfill" else "returned_quantity",
                "order_status": order["status"],
            }, now)
        elif preview.command.action == "cancel":
            connection.execute(
                "UPDATE sales_orders SET status='cancelled', updated_at=? WHERE order_id=?",
                (now, preview.command.order_id),
            )
        else:
            connection.execute(
                """UPDATE sales_orders SET customer_party_id=?, ordered_at=?, status=?,
                   revision=?, evidence_refs_json=?, source_ref=?, updated_at=? WHERE order_id=?""",
                (
                    order["customer_party_id"], order["ordered_at"], order["status"],
                    order["revision"], order["evidence_refs_json"], order["source_ref"],
                    now, preview.command.order_id,
                ),
            )
            # Revisions update lines in place: invoice lines reference
            # sales_order_lines.line_id, so surviving identities keep their
            # row; product/unit identity on unreferenced lines may change
            # (validation rejects it for invoice-referenced ones), and
            # unreferenced lines may be added or removed.
            planned_by_id = {line["line_id"]: line for line in authoritative.planned_lines}
            kept_ids: set[str] = set()
            for row in _lines(connection, preview.command.order_id):
                kept_ids.add(str(row["line_id"]))
                planned_line = planned_by_id.get(str(row["line_id"]))
                if planned_line is None:
                    connection.execute(
                        "DELETE FROM sales_order_lines WHERE line_id=?",
                        (row["line_id"],),
                    )
                else:
                    connection.execute(
                        """UPDATE sales_order_lines SET product_id=?, unit_id=?, quantity=?,
                           ship_from_location_id=? WHERE line_id=?""",
                        (
                            planned_line["product_id"], planned_line["unit_id"],
                            planned_line["quantity"], planned_line["ship_from_location_id"], row["line_id"],
                        ),
                    )
            for line in authoritative.planned_lines:
                if line["line_id"] in kept_ids:
                    continue
                connection.execute(
                    """INSERT INTO sales_order_lines
                       (line_id, order_id, product_id, unit_id, quantity,
                        fulfilled_quantity, returned_quantity, ship_from_location_id)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        line["line_id"], preview.command.order_id, line["product_id"],
                        line["unit_id"], line["quantity"], line["fulfilled_quantity"],
                        line["returned_quantity"], line["ship_from_location_id"],
                    ),
                )
        action_id = uuid.uuid4().hex
        audit_event_id = uuid.uuid4().hex
        connection.execute(
            "INSERT INTO sales_audit_events(event_id, event_type, payload_json, created_at) VALUES (?, ?, ?, ?)",
            (
                audit_event_id,
                f"sales_{preview.command.action}_applied",
                json.dumps(authoritative.to_dict(), ensure_ascii=False, sort_keys=True, separators=(",", ":")),
                now,
            ),
        )
        connection.execute(
            """INSERT INTO sales_action_receipts
               (action_id, idempotency_key, command_digest, preview_digest, order_id,
                audit_event_id, inventory_action_id, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                action_id, preview.command.idempotency_key, preview.command.command_digest,
                preview.preview_digest, preview.command.order_id, audit_event_id,
                (inventory_result or {}).get("action_id"), now,
            ),
        )
        result = _readback(connection, action_id)
    except sqlite3.IntegrityError as exc:
        raise SalesOwnerError("sales_write_conflict", str(exc)) from exc
    result["disposition"] = "applied"
    return result


def apply_preview(storage: StorageTarget, preview: SalesPreview, *, enabled_module_ids: Iterable[str] | None = None) -> dict[str, Any]:
    _require_module_enabled(enabled_module_ids)
    with _writing(storage) as connection:
        return apply_preview_in_transaction(connection, preview, enabled_module_ids=enabled_module_ids)



def _return_generation(connection: sqlite3.Connection) -> str:
    return digest_json({
        "sales": _state_generation(connection),
        "cases": _table_rows(connection, "sales_return_cases", "case_id"),
        "items": _table_rows(connection, "sales_return_case_items", "case_id, order_line_id"),
        "events": _table_rows(connection, "sales_return_case_events", "event_id"),
        "receipts": _table_rows(connection, "sales_document_action_receipts", "action_id"),
    })


def _return_case(connection: sqlite3.Connection, case_id: str) -> dict[str, Any]:
    row = connection.execute("SELECT * FROM sales_return_cases WHERE case_id=?", (case_id,)).fetchone()
    if row is None:
        raise SalesOwnerError("sales_return_case_not_found", case_id)
    return dict(row)


def _return_items(connection: sqlite3.Connection, case_id: str) -> list[dict[str, Any]]:
    return [dict(row) for row in connection.execute(
        "SELECT * FROM sales_return_case_items WHERE case_id=? ORDER BY order_line_id", (case_id,)
    )]


def _preview_return_on_connection(
    connection: sqlite3.Connection,
    command: SalesReturnCommand,
    *,
    enabled_module_ids: Iterable[str] | None,
) -> SalesReturnPreview:
    enabled = _require_module_enabled(enabled_module_ids)
    if command.action not in {"register", "inspect", "dispose"}:
        raise SalesOwnerError("sales_return_action_invalid", command.action)
    try:
        business_datetime(command.occurred_at)
    except TradeRuleError as exc:
        raise SalesOwnerError("sales_occurred_at_invalid", "use an ISO date or timestamp with timezone") from exc
    if not all((command.idempotency_key.strip(), command.order_id.strip(), command.source_ref.strip(), command.occurred_at.strip())):
        raise SalesOwnerError("sales_return_identity_required", command.order_id)
    try:
        evidence = normalized_evidence_refs(command.evidence_refs)
    except TradeRuleError as exc:
        raise SalesOwnerError(str(exc), "evidence refs are invalid") from exc
    if not command.items or len({item.order_line_id for item in command.items}) != len(command.items):
        raise SalesOwnerError("sales_return_items_invalid", "nonempty unique lines required")
    case_id = command.case_id or f"src-{digest_json({'key': command.idempotency_key})[:24]}"
    order = _order(connection, command.order_id)
    if order is None:
        raise SalesOwnerError("sales_order_not_found", command.order_id)
    if order["status"] == "cancelled":
        raise SalesOwnerError("sales_order_cancelled", command.order_id)
    lines = _lines(connection, command.order_id)
    if command.action == "register":
        if connection.execute("SELECT 1 FROM sales_return_cases WHERE case_id=?", (case_id,)).fetchone():
            raise SalesOwnerError("sales_return_case_already_exists", case_id)
        case = {
            "case_id": case_id, "order_id": command.order_id, "status": "registered",
            "occurred_at": command.occurred_at, "source_ref": command.source_ref,
            "evidence_refs_json": json.dumps(evidence, ensure_ascii=False), "reason": command.reason,
        }
        current_items: list[dict[str, Any]] = []
    else:
        if not command.case_id.strip():
            raise SalesOwnerError("sales_return_case_id_required", "stage requires case ID")
        case = _return_case(connection, case_id)
        if case["order_id"] != command.order_id:
            raise SalesOwnerError("sales_return_order_mismatch", case_id)
        allowed = {"registered"} if command.action == "inspect" else {"inspected", "partially_disposed"}
        if case["status"] not in allowed:
            raise SalesOwnerError("sales_return_state_invalid", str(case["status"]))
        # Generated timestamps are not part of the proposed plan.
        case = {key: value for key, value in case.items() if key not in {"created_at", "updated_at"}}
        current_items = _return_items(connection, case_id)
        if command.action == "inspect" and {item.order_line_id for item in command.items} != {item["order_line_id"] for item in current_items}:
            raise SalesOwnerError("sales_return_inspection_incomplete", case_id)
    planned = {item["order_line_id"]: dict(item) for item in current_items}
    effects = []
    for item in command.items:
        target = next((line for line in lines if line["line_id"] == item.order_line_id), None)
        if target is None:
            raise SalesOwnerError("sales_line_not_found", item.order_line_id)
        if target["unit_id"] != item.unit_id:
            raise SalesOwnerError("sales_return_unit_mismatch", item.order_line_id)
        try:
            quantity = _sales_quantity(item.quantity, allow_zero=command.action != "register")
            good = _sales_quantity(item.good_quantity, allow_zero=True)
            scrap = _sales_quantity(item.scrap_quantity, allow_zero=True)
        except TradeRuleError as exc:
            raise SalesOwnerError(str(exc), item.order_line_id) from exc
        remaining = _decimal_sum((_sales_quantity(target["fulfilled_quantity"], allow_zero=True), _sales_quantity(target["returned_quantity"], allow_zero=True).copy_negate()))
        disposition_quantity = _decimal_sum((good, scrap))
        if command.action == "register":
            if good or scrap:
                raise SalesOwnerError("sales_return_stage_fields_invalid", item.order_line_id)
            if quantity > remaining:
                raise SalesOwnerError("sales_return_exceeds_fulfilled", item.order_line_id)
            planned[item.order_line_id] = {
                "case_id": case_id, "order_line_id": item.order_line_id, "unit_id": item.unit_id,
                "quantity": format(quantity, "f"), "received_quantity": "0",
                "good_quantity": "0", "scrap_quantity": "0",
                "disposed_good_quantity": "0", "disposed_scrap_quantity": "0",
            }
        else:
            if item.order_line_id not in planned:
                raise SalesOwnerError("sales_return_case_line_mismatch", item.order_line_id)
            row = planned[item.order_line_id]
            if command.action == "inspect":
                if quantity > Decimal(str(row["quantity"])) or quantity > remaining:
                    raise SalesOwnerError("sales_return_inspection_exceeds_quantity", item.order_line_id)
                if disposition_quantity != quantity:
                    raise SalesOwnerError("sales_return_inspection_not_closed", item.order_line_id)
                if not command.reason.strip():
                    raise SalesOwnerError("sales_return_inspection_reason_required", case_id)
                row.update(received_quantity=format(quantity, "f"), good_quantity=format(good, "f"), scrap_quantity=format(scrap, "f"))
            else:
                if quantity or disposition_quantity <= 0:
                    raise SalesOwnerError("sales_return_disposition_quantity_invalid", item.order_line_id)
                if (_decimal_sum((good, Decimal(str(row["disposed_good_quantity"])))) > Decimal(str(row["good_quantity"]))
                        or _decimal_sum((scrap, Decimal(str(row["disposed_scrap_quantity"])))) > Decimal(str(row["scrap_quantity"]))):
                    raise SalesOwnerError("sales_return_disposition_exceeds_inspection", item.order_line_id)
                effect = _plan_line_effect(
                    connection, command, order, lines, target, disposition_quantity, good, enabled=enabled,
                    inventory_key="sales-document:" + digest_json({"key": command.idempotency_key, "line": item.order_line_id}),
                )
                effects.append(effect)
                # Subsequent line projections include preceding effects of this same command.
                target["returned_quantity"] = format(_decimal_sum((Decimal(str(target["returned_quantity"])), good, scrap)), "f")
                row["disposed_good_quantity"] = format(_decimal_sum((Decimal(str(row["disposed_good_quantity"])), good)), "f")
                row["disposed_scrap_quantity"] = format(_decimal_sum((Decimal(str(row["disposed_scrap_quantity"])), scrap)), "f")
    if command.action != "register":
        complete = all(
            _decimal_sum((Decimal(str(row["disposed_good_quantity"])), Decimal(str(row["disposed_scrap_quantity"])))) == Decimal(str(row["received_quantity"]))
            for row in planned.values()
        )
        case["status"] = ("disposed" if complete else "inspected") if command.action == "inspect" else ("disposed" if complete else "partially_disposed")
    content = {
        "command": command.to_dict(), "state_generation": _return_generation(connection),
        "planned_case": case, "planned_items": [planned[key] for key in sorted(planned)], "effects": effects,
    }
    return SalesReturnPreview(
        command, content["state_generation"], case, tuple(content["planned_items"]), tuple(effects), digest_json(content)
    )


def preview_return_action(storage: StorageTarget, command: SalesReturnCommand, *, enabled_module_ids: Iterable[str] | None = None) -> SalesReturnPreview:
    _require_module_enabled(enabled_module_ids)
    with _reading(storage) as connection:
        return _preview_return_on_connection(connection, command, enabled_module_ids=enabled_module_ids)


def _return_readback(connection: sqlite3.Connection, case_id: str) -> dict[str, Any]:
    case = _return_case(connection, case_id)
    events = []
    for row in connection.execute("SELECT * FROM sales_return_case_events WHERE case_id=? ORDER BY rowid", (case_id,)):
        event = dict(row)
        event["payload"] = json.loads(event.pop("payload_json"))
        event["inventory"] = [read_inventory_in_transaction(connection, action_id) for action_id in event["payload"]["inventory_action_ids"]]
        events.append(event)
    return {
        "schema_version": "bizhub.sales-return-case-read.v1", "owner_ref": OWNER_REF,
        "case": case, "items": _return_items(connection, case_id), "events": events,
        "order": _order(connection, str(case["order_id"])), "lines": _lines(connection, str(case["order_id"])),
    }


def read_return_case(storage: StorageTarget, case_id: str, *, enabled_module_ids: Iterable[str] | None = None) -> dict[str, Any]:
    _require_module_enabled(enabled_module_ids)
    with _reading(storage) as connection:
        return _return_readback(connection, case_id)


def _document_readback(connection: sqlite3.Connection, action_id: str) -> dict[str, Any]:
    row = connection.execute("SELECT * FROM sales_document_action_receipts WHERE action_id=?", (action_id,)).fetchone()
    if row is None:
        raise SalesOwnerError("sales_readback_missing", action_id)
    receipt = dict(row)
    audit = connection.execute("SELECT * FROM sales_audit_events WHERE event_id=?", (receipt["audit_event_id"],)).fetchone()
    if receipt["document_kind"] == "reversal":
        return json.loads(audit["payload_json"])["readback"]
    if receipt["document_kind"] == "return_case":
        document = _return_readback(connection, str(receipt["document_id"]))
    elif receipt["document_kind"] == "payment":
        document = _payment_readback(connection, str(receipt["document_id"]))
    elif receipt["document_kind"] in {"invoice", "credit_note"}:
        document = _invoice_readback(connection, str(receipt["document_id"]))
    else:
        raise SalesOwnerError("sales_document_kind_invalid", str(receipt["document_kind"]))
    return {
        **document,
        "schema_version": "bizhub.sales-document-readback.v1", "receipt": receipt,
        "action_id": action_id, "audit_event": dict(audit) if audit else None,
    }


def read_document_action(storage: StorageTarget, idempotency_key: str, *, enabled_module_ids: Iterable[str] | None = None) -> dict[str, Any]:
    _require_module_enabled(enabled_module_ids)
    with _reading(storage) as connection:
        row = connection.execute("SELECT action_id FROM sales_document_action_receipts WHERE idempotency_key=?", (idempotency_key,)).fetchone()
        if row is None:
            raise SalesOwnerError("sales_readback_missing", idempotency_key)
        return _document_readback(connection, str(row["action_id"]))


def apply_return_preview_in_transaction(connection: sqlite3.Connection, preview: SalesReturnPreview, *, enabled_module_ids: Iterable[str] | None = None) -> dict[str, Any]:
    if not connection.in_transaction:
        raise SalesOwnerError("sales_transaction_required", "an outer transaction is required")
    enabled = _require_module_enabled(enabled_module_ids)
    if digest_json(preview.content()) != preview.preview_digest:
        raise SalesOwnerError("sales_preview_content_drift", "preview digest differs")
    try:
        existing = connection.execute(
            "SELECT action_id, command_digest FROM sales_document_action_receipts WHERE idempotency_key=?",
            (preview.command.idempotency_key,),
        ).fetchone()
        if existing is not None:
            if existing["command_digest"] != preview.command.command_digest:
                raise SalesOwnerError("sales_idempotency_conflict", preview.command.idempotency_key)
            result = _document_readback(connection, str(existing["action_id"]))
            result["disposition"] = "idempotent_noop"
            return result
        if _return_generation(connection) != preview.state_generation:
            raise SalesOwnerError("sales_state_generation_drift", "return state changed")
        authoritative = _preview_return_on_connection(connection, preview.command, enabled_module_ids=enabled)
        if authoritative.preview_digest != preview.preview_digest:
            raise SalesOwnerError("sales_preview_content_drift", "authoritative plan differs")
        now = datetime.now(UTC).isoformat()
        inventory_action_ids = []
        for effect in authoritative.effects:
            if effect["inventory_preview"]:
                # The complete plan was revalidated before any write. Re-preview
                # under the same lock to include earlier lines in this transaction.
                inventory_preview = preview_inventory_in_transaction(
                    connection, InventoryCommand.from_dict(effect["inventory_preview"]["command"]),
                    enabled_module_ids=enabled,
                )
                inventory = apply_inventory_in_transaction(connection, inventory_preview, enabled_module_ids=enabled)
                inventory_action_ids.append(inventory["action_id"])
            _apply_line_effect(connection, effect, now)
        case = authoritative.planned_case
        if preview.command.action == "register":
            connection.execute(
                """INSERT INTO sales_return_cases
                   (case_id, order_id, status, occurred_at, source_ref, evidence_refs_json, reason, created_at, updated_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (case["case_id"], case["order_id"], case["status"], case["occurred_at"], case["source_ref"], case["evidence_refs_json"], case["reason"], now, now),
            )
            for item in authoritative.planned_items:
                connection.execute(
                    """INSERT INTO sales_return_case_items
                       (case_id, order_line_id, unit_id, quantity, received_quantity, good_quantity, scrap_quantity, disposed_good_quantity, disposed_scrap_quantity)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    tuple(item[key] for key in ("case_id", "order_line_id", "unit_id", "quantity", "received_quantity", "good_quantity", "scrap_quantity", "disposed_good_quantity", "disposed_scrap_quantity")),
                )
        else:
            connection.execute("UPDATE sales_return_cases SET status=?, updated_at=? WHERE case_id=?", (case["status"], now, case["case_id"]))
            for item in authoritative.planned_items:
                connection.execute(
                    """UPDATE sales_return_case_items SET received_quantity=?, good_quantity=?, scrap_quantity=?, disposed_good_quantity=?, disposed_scrap_quantity=?
                       WHERE case_id=? AND order_line_id=?""",
                    tuple(item[key] for key in ("received_quantity", "good_quantity", "scrap_quantity", "disposed_good_quantity", "disposed_scrap_quantity", "case_id", "order_line_id")),
                )
        action_id, event_id, audit_id = uuid.uuid4().hex, uuid.uuid4().hex, uuid.uuid4().hex
        payload = {"preview": authoritative.to_dict(), "inventory_action_ids": inventory_action_ids}
        connection.execute(
            """INSERT INTO sales_return_case_events(event_id, case_id, action, occurred_at, source_ref, evidence_refs_json, payload_json, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (event_id, case["case_id"], preview.command.action, preview.command.occurred_at, preview.command.source_ref,
             json.dumps(preview.command.evidence_refs, ensure_ascii=False), json.dumps(payload, ensure_ascii=False, sort_keys=True), now),
        )
        connection.execute(
            "INSERT INTO sales_audit_events(event_id, event_type, payload_json, created_at) VALUES (?, ?, ?, ?)",
            (audit_id, f"sales_return_{preview.command.action}_applied", json.dumps(payload, ensure_ascii=False, sort_keys=True), now),
        )
        connection.execute(
            """INSERT INTO sales_document_action_receipts(action_id, idempotency_key, command_digest, preview_digest, document_kind, document_id, order_id, audit_event_id, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (action_id, preview.command.idempotency_key, preview.command.command_digest, preview.preview_digest, "return_case", case["case_id"], case["order_id"], audit_id, now),
        )
        result = _document_readback(connection, action_id)
    except sqlite3.IntegrityError as exc:
        raise SalesOwnerError("sales_write_conflict", str(exc)) from exc
    result["disposition"] = "applied"
    return result


def apply_return_preview(storage: StorageTarget, preview: SalesReturnPreview, *, enabled_module_ids: Iterable[str] | None = None) -> dict[str, Any]:
    _require_module_enabled(enabled_module_ids)
    with _writing(storage) as connection:
        return apply_return_preview_in_transaction(connection, preview, enabled_module_ids=enabled_module_ids)


def _invoice_generation(connection: sqlite3.Connection) -> str:
    return digest_json({
        "sales": _state_generation(connection),
        "invoices": _table_rows(connection, "sales_invoices", "invoice_id"),
        "lines": _table_rows(connection, "sales_invoice_lines", "invoice_id, line_id"),
        "cases": _table_rows(connection, "sales_return_cases", "case_id"),
        "receipts": _table_rows(connection, "sales_document_action_receipts", "action_id"),
    })


def _invoice(connection: sqlite3.Connection, invoice_id: str) -> dict[str, Any]:
    row = connection.execute("SELECT * FROM sales_invoices WHERE invoice_id=?", (invoice_id,)).fetchone()
    if row is None:
        raise SalesOwnerError("sales_invoice_not_found", invoice_id)
    return dict(row)


def _money(value: str, *, allow_zero: bool = False) -> Decimal:
    try:
        return strict_money(value, allow_zero=allow_zero, invalid_code="sales_amount_invalid",
                            range_code="sales_amount_out_of_range", precision_code="sales_amount_precision_invalid")
    except TradeRuleError as exc:
        code = str(exc)
        message = "supports at most 18 integer digits and 4 fractional digits" if code == "sales_amount_out_of_range" else str(value)
        raise SalesOwnerError(code, message) from exc


def _uncredited_amount(connection: sqlite3.Connection, invoice: dict[str, Any]) -> Decimal:
    credited = _decimal_sum(Decimal(row["amount"]) for row in connection.execute(
        "SELECT amount FROM sales_invoices WHERE original_invoice_id=? AND kind='credit_note'", (invoice["invoice_id"],)
    ))
    return _decimal_sum((Decimal(invoice["amount"]), credited.copy_negate()))


def _preview_invoice_on_connection(connection: sqlite3.Connection, command: SalesInvoiceCommand) -> SalesInvoicePreview:
    from .contracts import InvoiceShipmentCoverage

    coverage = [InvoiceShipmentCoverage.from_dict(item.to_dict()).to_dict() for item in command.shipment_coverage]
    if len({item["coverage_id"] for item in coverage}) != len(coverage):
        raise SalesOwnerError("sales_invoice_coverage_duplicate", command.document_number)
    if not isinstance(command.opening_settled, bool) or (command.opening_settled and (
        command.kind != "invoice" or any(item.order_id for item in command.lines)
    )):
        raise SalesOwnerError("sales_opening_settled_header_only", command.document_number)
    if command.kind not in {"invoice", "credit_note"}:
        raise SalesOwnerError("sales_invoice_kind_invalid", command.kind)
    for name in ("idempotency_key", "source_ref"):
        if not getattr(command, name).strip():
            raise SalesOwnerError("sales_invoice_identity_required", name)
    if not is_master_data_ref(command.customer_party_id):
        raise SalesOwnerError("sales_invoice_identity_required", "customer_party_id")
    if command.currency not in {"CNY", "USD", "EUR"}:
        raise SalesOwnerError("sales_currency_invalid", command.currency)
    date.fromisoformat(command.business_date)
    try:
        evidence = normalized_evidence_refs(command.evidence_refs)
        get_resource(connection, "party", command.customer_party_id)
    except (TradeRuleError, MasterDataError) as exc:
        raise SalesOwnerError(getattr(exc, "code", str(exc)), "invoice evidence/customer is invalid") from exc
    _check_invoice_identity(connection, command)
    number = command.document_number.strip()
    if not number:
        if command.kind != "credit_note":
            raise SalesOwnerError("sales_invoice_identity_required", "document_number")
        original = _invoice(connection, command.original_invoice_id)
        if original.get("opening_settled"):
            raise SalesOwnerError("sales_opening_settled_header_only", command.original_invoice_id)
        prefix = f"CN-{original['document_number']}-"
        sequence = 1
        while any(_identity_text(row[0]) == _identity_text(f"{prefix}{sequence}")
                  for row in connection.execute("SELECT document_number FROM sales_invoices")):
            sequence += 1
        number = f"{prefix}{sequence}"
    if not command.lines or len({item.line_id for item in command.lines}) != len(command.lines):
        raise SalesOwnerError("sales_invoice_lines_invalid", "nonempty distinct lines required")
    invoice_id = f"inv-{command.command_digest[:24]}"
    lines = []
    for item in command.lines:
        if not item.line_id.strip():
            raise SalesOwnerError("sales_invoice_line_id_required", number)
        amount = _money(item.amount)
        if item.order_line_id and not item.order_id:
            raise SalesOwnerError("sales_invoice_order_required", item.order_line_id)
        if item.order_id:
            order = _order(connection, item.order_id)
            if order is None:
                raise SalesOwnerError("sales_order_not_found", item.order_id)
            if order["customer_party_id"] != command.customer_party_id:
                raise SalesOwnerError("sales_invoice_customer_mismatch", item.order_id)
        if item.order_line_id and not connection.execute("SELECT 1 FROM sales_order_lines WHERE order_id=? AND line_id=?", (item.order_id, item.order_line_id)).fetchone():
            raise SalesOwnerError("sales_invoice_order_line_mismatch", item.order_line_id)
        tax_rate = None
        if item.tax_rate is not None:
            try:
                rate = quantity_decimal(item.tax_rate, allow_zero=True)
            except TradeRuleError as exc:
                raise SalesOwnerError("sales_tax_rate_invalid", item.tax_rate) from exc
            if rate > 1:
                raise SalesOwnerError("sales_tax_rate_invalid", item.tax_rate)
            tax_rate = format(rate, "f")
        lines.append({
            "invoice_id": invoice_id, "line_id": item.line_id, "amount": format(amount, ".2f"),
            "order_id": item.order_id or None, "order_line_id": item.order_line_id or None,
            "tax_rate": tax_rate,
            "tax_amount": format(_money(item.tax_amount, allow_zero=True), ".2f") if item.tax_amount is not None else None,
        })
    total = _check_decimal_range(_decimal_sum(Decimal(item["amount"]) for item in lines), "sales_amount_out_of_range")
    if command.kind == "invoice":
        if command.original_invoice_id or command.return_case_id:
            raise SalesOwnerError("sales_invoice_reference_invalid", "only credit notes reference an original or return case")
    else:
        if not command.original_invoice_id:
            raise SalesOwnerError("sales_credit_original_required", number)
        original = _invoice(connection, command.original_invoice_id)
        if original["kind"] != "invoice":
            raise SalesOwnerError("sales_credit_original_invalid", command.original_invoice_id)
        if original.get("opening_settled"):
            raise SalesOwnerError("sales_opening_settled_header_only", command.original_invoice_id)
        if original["customer_party_id"] != command.customer_party_id or original["currency"] != command.currency:
            raise SalesOwnerError("sales_credit_identity_mismatch", command.original_invoice_id)
        if total > _uncredited_amount(connection, original):
            raise SalesOwnerError("sales_credit_exceeds_original", command.original_invoice_id)
        if command.return_case_id:
            case = _return_case(connection, command.return_case_id)
            if _order(connection, case["order_id"])["customer_party_id"] != command.customer_party_id:
                raise SalesOwnerError("sales_credit_return_customer_mismatch", command.return_case_id)
    invoice = {
        "invoice_id": invoice_id, "kind": command.kind, "document_number": number,
        "customer_party_id": command.customer_party_id, "currency": command.currency,
        "business_date": command.business_date, "amount": format(total, ".2f"),
        "original_invoice_id": command.original_invoice_id or None, "return_case_id": command.return_case_id or None,
        "source_ref": command.source_ref, "evidence_refs_json": json.dumps(evidence, ensure_ascii=False),
        "opening_settled": int(command.opening_settled),
        "shipment_coverage_json": json.dumps(coverage, ensure_ascii=False, sort_keys=True),
    }
    content = {"command": command.to_dict(), "state_generation": _invoice_generation(connection), "planned_invoice": invoice, "planned_lines": lines}
    return SalesInvoicePreview(command, content["state_generation"], invoice, tuple(lines), digest_json(content))


def preview_invoice_action(storage: StorageTarget, command: SalesInvoiceCommand, *, enabled_module_ids: Iterable[str] | None = None) -> SalesInvoicePreview:
    _require_module_enabled(enabled_module_ids)
    with _reading(storage) as connection:
        return _preview_invoice_on_connection(connection, command)


def _invoice_readback(connection: sqlite3.Connection, invoice_id: str) -> dict[str, Any]:
    invoice = _invoice(connection, invoice_id)
    original = invoice if invoice["kind"] == "invoice" else _invoice(connection, invoice["original_invoice_id"])
    net = _uncredited_amount(connection, original)
    allocated = _allocated_amount(connection, invoice_id=original["invoice_id"])
    remaining = Decimal("0") if original.get("opening_settled") else _decimal_sum((net, allocated.copy_negate()))
    return {
        "schema_version": "bizhub.sales-invoice-read.v1", "owner_ref": OWNER_REF, "invoice": invoice,
        "lines": [dict(row) for row in connection.execute("SELECT * FROM sales_invoice_lines WHERE invoice_id=? ORDER BY line_id", (invoice_id,))],
        "original_invoice": original if invoice["kind"] == "credit_note" else None,
        "credit_notes": [dict(row) for row in connection.execute("SELECT * FROM sales_invoices WHERE original_invoice_id=? ORDER BY invoice_id", (original["invoice_id"],))],
        "settlement": {"original_invoice_id": original["invoice_id"], "currency": original["currency"],
                       "opening_settled_amount": format(net if original.get("opening_settled") else Decimal("0"), ".2f"),
                       "invoice_amount": original["amount"], "credited_amount": format(_decimal_sum((Decimal(original["amount"]), net.copy_negate())), ".2f"),
                       "allocated_amount": format(allocated, ".2f"), "receivable_amount": format(remaining, ".2f"),
                       "credit_balance": format(remaining.copy_negate() if remaining < 0 else Decimal("0"), ".2f")},
    }


def read_invoice(storage: StorageTarget, invoice_id: str, *, enabled_module_ids: Iterable[str] | None = None) -> dict[str, Any]:
    _require_module_enabled(enabled_module_ids)
    with _reading(storage) as connection:
        return _invoice_readback(connection, invoice_id)


def _order_receivables(connection: sqlite3.Connection) -> list[dict[str, Any]]:
    # Allocate exact cents by explicit invoice-line amounts. Largest remainders
    # absorb the final cents deterministically, including unlinked lines.
    totals = {}
    for invoice in connection.execute("SELECT * FROM sales_invoices WHERE kind='invoice' ORDER BY invoice_id"):
        if invoice["opening_settled"]:
            continue
        lines = [dict(row) for row in connection.execute("SELECT * FROM sales_invoice_lines WHERE invoice_id=? ORDER BY line_id", (invoice["invoice_id"],))]
        cents = int(Fraction(_allocated_amount(connection, invoice_id=invoice["invoice_id"])) * 100)
        weights = [Fraction(Decimal(line["amount"])) for line in lines]
        total_weight = sum(weights)
        shares = [cents * weight / total_weight for weight in weights]
        rounded = [share.numerator // share.denominator for share in shares]
        for index in sorted(range(len(lines)), key=lambda i: (-(shares[i] - rounded[i]), lines[i]["line_id"]))[:cents - sum(rounded)]:
            rounded[index] += 1
        for line, paid in zip(lines, rounded):
            if not line["order_id"]:
                continue
            bucket = totals.setdefault((line["order_id"], invoice["currency"]), {"invoice": [], "credit": [], "paid": []})
            bucket["invoice"].append(Decimal(line["amount"]))
            bucket["paid"].append(Decimal(f"{paid // 100}.{paid % 100:02d}"))
    for row in connection.execute("SELECT l.order_id, i.currency, l.amount FROM sales_invoice_lines l JOIN sales_invoices i ON i.invoice_id=l.invoice_id WHERE i.kind='credit_note' AND l.order_id IS NOT NULL"):
        totals.setdefault((row["order_id"], row["currency"]), {"invoice": [], "credit": [], "paid": []})["credit"].append(Decimal(row["amount"]))
    items = []
    for (order_id, currency), bucket in sorted(totals.items()):
        gross, credit, paid = (_decimal_sum(bucket[key]) for key in ("invoice", "credit", "paid"))
        items.append({"order_id": order_id, "currency": currency, "invoice_amount": format(gross, ".2f"),
                      "credited_amount": format(credit, ".2f"), "allocated_amount": format(paid, ".2f"),
                      "receivable_amount": format(_decimal_sum((gross, credit.copy_negate(), paid.copy_negate())), ".2f")})
    return items


def read_receivables(storage: StorageTarget, *, enabled_module_ids: Iterable[str] | None = None) -> dict[str, Any]:
    _require_module_enabled(enabled_module_ids)
    totals = {}
    credit_balances = {}
    with _reading(storage) as connection:
        for row in connection.execute("SELECT * FROM sales_invoices"):
            if row["opening_settled"]:
                continue
            key = (row["customer_party_id"], row["currency"])
            bucket = totals.setdefault(key, {"invoice": [], "credit_note": [], "paid": []})
            bucket[row["kind"]].append(Decimal(row["amount"]))
            if row["kind"] == "invoice":
                paid = _allocated_amount(connection, invoice_id=row["invoice_id"])
                bucket["paid"].append(paid)
                remaining = _decimal_sum((_uncredited_amount(connection, dict(row)), paid.copy_negate()))
                if remaining < 0:
                    credit_balances.setdefault(key, []).append(remaining.copy_negate())
        orders = _order_receivables(connection)
    totals = {key: {kind: _decimal_sum(amounts) for kind, amounts in bucket.items()} for key, bucket in totals.items()}
    return {
        "schema_version": "bizhub.sales-receivables-read.v1", "owner_ref": OWNER_REF,
        "items": [{"customer_party_id": customer, "currency": currency,
                   "invoice_amount": format(values["invoice"], ".2f"), "credited_amount": format(values["credit_note"], ".2f"),
                   "receivable_amount": format(_decimal_sum((values["invoice"], values["credit_note"].copy_negate(), values["paid"].copy_negate())), ".2f")}
                  for (customer, currency), values in sorted(totals.items())],
        "orders": orders,
        "credit_balances": [{"customer_party_id": customer, "currency": currency, "credit_balance": format(_decimal_sum(amounts), ".2f")}
                            for (customer, currency), amounts in sorted(credit_balances.items())],
    }


def apply_invoice_preview_in_transaction(connection: sqlite3.Connection, preview: SalesInvoicePreview, *, enabled_module_ids: Iterable[str] | None = None) -> dict[str, Any]:
    if not connection.in_transaction:
        raise SalesOwnerError("sales_transaction_required", "an outer transaction is required")
    _require_module_enabled(enabled_module_ids)
    if digest_json(preview.content()) != preview.preview_digest:
        raise SalesOwnerError("sales_preview_content_drift", "preview digest differs")
    try:
        existing = connection.execute(
            "SELECT action_id, command_digest FROM sales_document_action_receipts WHERE idempotency_key=?",
            (preview.command.idempotency_key,),
        ).fetchone()
        if existing is not None:
            if existing["command_digest"] != preview.command.command_digest:
                raise SalesOwnerError("sales_idempotency_conflict", preview.command.idempotency_key)
            result = _document_readback(connection, str(existing["action_id"]))
            result["disposition"] = "idempotent_noop"
            return result
        _check_invoice_identity(connection, preview.command)
        if _invoice_generation(connection) != preview.state_generation:
            raise SalesOwnerError("sales_state_generation_drift", "invoice state changed")
        authoritative = _preview_invoice_on_connection(connection, preview.command)
        if authoritative.preview_digest != preview.preview_digest:
            raise SalesOwnerError("sales_preview_content_drift", "authoritative plan differs")
        now = datetime.now(UTC).isoformat()
        invoice = authoritative.planned_invoice
        connection.execute(
            """INSERT INTO sales_invoices(invoice_id, kind, document_number, customer_party_id, currency, business_date, amount,
               original_invoice_id, return_case_id, source_ref, evidence_refs_json, opening_settled, shipment_coverage_json, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (*[invoice[key] for key in ("invoice_id", "kind", "document_number", "customer_party_id", "currency", "business_date", "amount", "original_invoice_id", "return_case_id", "source_ref", "evidence_refs_json", "opening_settled", "shipment_coverage_json")], now),
        )
        for line in authoritative.planned_lines:
            connection.execute(
                """INSERT INTO sales_invoice_lines(invoice_id, line_id, amount, order_id, order_line_id, tax_rate, tax_amount)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                tuple(line[key] for key in ("invoice_id", "line_id", "amount", "order_id", "order_line_id", "tax_rate", "tax_amount")),
            )
        action_id, audit_id = uuid.uuid4().hex, uuid.uuid4().hex
        connection.execute(
            "INSERT INTO sales_audit_events(event_id, event_type, payload_json, created_at) VALUES (?, ?, ?, ?)",
            (audit_id, f"sales_{invoice['kind']}_registered", json.dumps(authoritative.to_dict(), ensure_ascii=False, sort_keys=True), now),
        )
        orders = {line["order_id"] for line in authoritative.planned_lines if line["order_id"]}
        connection.execute(
            """INSERT INTO sales_document_action_receipts(action_id, idempotency_key, command_digest, preview_digest, document_kind, document_id, order_id, audit_event_id, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (action_id, preview.command.idempotency_key, preview.command.command_digest, preview.preview_digest, invoice["kind"], invoice["invoice_id"], next(iter(orders)) if len(orders) == 1 else None, audit_id, now),
        )
        result = _document_readback(connection, action_id)
    except sqlite3.IntegrityError as exc:
        raise SalesOwnerError("sales_write_conflict", str(exc)) from exc
    result["disposition"] = "applied"
    return result


def apply_invoice_preview(storage: StorageTarget, preview: SalesInvoicePreview, *, enabled_module_ids: Iterable[str] | None = None) -> dict[str, Any]:
    _require_module_enabled(enabled_module_ids)
    with _writing(storage) as connection:
        return apply_invoice_preview_in_transaction(connection, preview, enabled_module_ids=enabled_module_ids)


__all__ = [
    "apply_payment_preview", "preview_payment_action", "read_payment", "read_payment_balances",
    "SalesOwnerError", "apply_preview", "preview_action", "read_action", "read_order",
    "apply_return_preview", "preview_return_action", "read_return_case", "read_document_action",
    "apply_invoice_preview", "preview_invoice_action", "read_invoice", "read_receivables",
]


def _payment(connection: sqlite3.Connection, payment_id: str) -> dict[str, Any]:
    row = connection.execute("SELECT * FROM sales_payments WHERE payment_id=?", (payment_id,)).fetchone()
    if row is None:
        raise SalesOwnerError("sales_payment_not_found", payment_id)
    return dict(row)


def _allocated_amount(connection: sqlite3.Connection, *, invoice_id: str = "", payment_id: str = "") -> Decimal:
    column, value = ("invoice_id", invoice_id) if invoice_id else ("payment_id", payment_id)
    return _decimal_sum(Decimal(row["amount"]) for row in connection.execute(
        f"SELECT amount FROM sales_payment_allocations WHERE {column}=? AND active=1", (value,)
    ))


def _payment_generation(connection: sqlite3.Connection) -> str:
    return digest_json({"invoices": _invoice_generation(connection),
                        "payments": _table_rows(connection, "sales_payments", "payment_id"),
                        "allocations": _table_rows(connection, "sales_payment_allocations", "allocation_id")})


def _registered_payment_lines(connection: sqlite3.Connection, payment: dict[str, Any]) -> list[dict[str, str]]:
    # Registration evidence is immutable and already committed in the same Sales transaction.
    row = connection.execute(
        """SELECT a.payload_json FROM sales_document_action_receipts r
           JOIN sales_audit_events a ON a.event_id=r.audit_event_id
           WHERE r.document_kind='payment' AND r.document_id=? AND a.event_type='sales_payment_register'""",
        (payment["payment_id"],),
    ).fetchone()
    if row:
        lines = json.loads(row["payload_json"])["planned_payment"].get("lines")
        if lines:
            return lines
    return [{"channel": payment["channel"], "amount": payment["amount"], "reference": payment["external_reference"] or ""}]


def _payment_line_identity(line: dict[str, str], customer: str | None, received_date: str) -> str:
    reference = line["reference"]
    if reference:
        return digest_json({"customer": customer, "reference": _identity_text(reference)})
    return digest_json({"reference": reference or None, "amount": line["amount"], "received_date": received_date,
                        **({"channel": line["channel"], "customer": customer} if not reference else {})})


def _check_payment_identity(connection: sqlite3.Connection, command: SalesPaymentCommand) -> None:
    if command.action != "register":
        return
    incoming = [item.to_dict() for item in command.lines] if command.lines else [
        {"channel": command.channel, "amount": command.amount, "reference": command.external_reference}]
    received = datetime.fromisoformat(command.received_at)
    day = received.astimezone(ZoneInfo(BUSINESS_TIMEZONE)).date().isoformat()
    identities: dict[str, tuple[Decimal, str]] = {}
    duplicate_id = None
    for line in incoming:
        reference = _identity_text(line["reference"])
        if not reference:
            continue  # Missing-reference typed receipts retain their legacy check.
        facts = (_money(line["amount"]), line["channel"].strip())
        if reference in identities:
            code = "sales_payment_duplicate" if identities[reference] == facts else "sales_payment_identity_conflict"
            raise SalesOwnerError(code, f"repeated external_reference={reference} within command")
        identities[reference] = facts
        for row in connection.execute("SELECT * FROM sales_payments WHERE customer_party_id IS ?", (command.customer_party_id or None,)):
            for existing in _registered_payment_lines(connection, dict(row)):
                if _identity_text(existing["reference"]) != reference:
                    continue
                same = (Decimal(existing["amount"]) == _money(line["amount"])
                        and row["currency"] == command.currency and row["received_date"] == day
                        and datetime.fromisoformat(row["received_at"]) == received
                        and row["business_at"] == command.business_at
                        and existing["channel"].strip() == line["channel"].strip())
                if not same:
                    raise SalesOwnerError("sales_payment_identity_conflict", f"existing payment_id={row['payment_id']}")
                duplicate_id = row["payment_id"]
    if duplicate_id is not None:
        raise SalesOwnerError("sales_payment_duplicate", f"existing payment_id={duplicate_id}")


def _preview_payment_on_connection(connection: sqlite3.Connection, command: SalesPaymentCommand) -> SalesPaymentPreview:
    if command.action not in {"register", "allocate", "unallocate"}:
        raise SalesOwnerError("sales_payment_action_invalid", command.action)
    if not command.idempotency_key.strip() or not command.source_ref.strip():
        raise SalesOwnerError("sales_payment_identity_required", "idempotency_key and source_ref required")
    try:
        evidence = normalized_evidence_refs(command.evidence_refs)
    except TradeRuleError as exc:
        raise SalesOwnerError(str(exc), "payment evidence invalid") from exc
    if command.action == "register":
        if command.payment_id or command.allocation_ids:
            raise SalesOwnerError("sales_payment_fields_invalid", "register cannot reference an existing payment/allocation")
        if command.currency not in {"CNY", "USD", "EUR"}:
            raise SalesOwnerError("sales_currency_invalid", command.currency)
        amount = _money(command.amount)
        if command.lines and (command.channel or command.external_reference):
            raise SalesOwnerError("sales_payment_fields_invalid", "use either lines or scalar channel/reference")
        lines = [item.to_dict() for item in command.lines] if command.lines else [
            {"channel": command.channel, "amount": command.amount, "reference": command.external_reference}]
        lines = [{"channel": item["channel"].strip(), "amount": format(_money(item["amount"]), ".2f"),
                  "reference": item["reference"].strip()} for item in lines]
        if any(not item["reference"] and not item["channel"] for item in lines) or command.reference_missing != any(not item["reference"] for item in lines):
            raise SalesOwnerError("sales_payment_reference_required", "reference or channel with explicit reference_missing required")
        if _decimal_sum(Decimal(item["amount"]) for item in lines) != amount:
            raise SalesOwnerError("sales_payment_lines_total_mismatch", "line amounts must equal payment amount")
        business_datetime(command.received_at)
        received = datetime.fromisoformat(command.received_at)
        if received.tzinfo is None:
            raise SalesOwnerError("sales_payment_received_at_invalid", "received_at needs an explicit timezone")
        received_date = received.astimezone(ZoneInfo(BUSINESS_TIMEZONE)).date().isoformat()
        business_datetime(command.business_at)
        if command.customer_party_id:
            try:
                get_resource(connection, "party", command.customer_party_id)
            except MasterDataError as exc:
                raise SalesOwnerError(exc.code, str(exc)) from exc
        _check_payment_identity(connection, command)
        identities = [_payment_line_identity(item, command.customer_party_id or None, received_date) for item in lines]
        existing_identities = set()
        for row in connection.execute("SELECT * FROM sales_payments WHERE received_date=?", (received_date,)):
            payment = dict(row)
            existing_identities.update(_payment_line_identity(item, payment["customer_party_id"], received_date)
                                       for item in _registered_payment_lines(connection, payment) if not item["reference"])
        missing_identities = {_payment_line_identity(item, command.customer_party_id or None, received_date)
                              for item in lines if not item["reference"]}
        if len(set(identities)) != len(identities) or existing_identities.intersection(missing_identities):
            raise SalesOwnerError("sales_payment_identity_conflict", "payment already registered")
        identity = digest_json(sorted(identities))
        # Legacy scalar fields project the first evidence line; lines carry the full receipt.
        channel, reference = lines[0]["channel"], lines[0]["reference"]
        payment = {"payment_id": f"pay-{command.command_digest[:24]}", "business_identity": identity,
                   "customer_party_id": command.customer_party_id or None, "currency": command.currency,
                   "amount": format(amount, ".2f"), "channel": channel, "external_reference": reference or None,
                   "reference_missing": int(not reference), "received_at": command.received_at,
                   "received_date": received_date, "business_at": command.business_at,
                   "source_ref": command.source_ref, "evidence_refs_json": json.dumps(evidence, ensure_ascii=False),
                   "lines": lines}
        available = amount
    else:
        if not command.payment_id or any((command.amount, command.currency, command.customer_party_id, command.channel,
                                          command.external_reference, command.received_at, command.business_at, command.reference_missing, command.lines)):
            raise SalesOwnerError("sales_payment_fields_invalid", "allocation actions only reference registered payment")
        payment = _payment(connection, command.payment_id)
        available = _decimal_sum((Decimal(payment["amount"]), _allocated_amount(connection, payment_id=command.payment_id).copy_negate()))
    planned = []
    if command.action == "unallocate":
        if command.allocations or not command.allocation_ids or len(set(command.allocation_ids)) != len(command.allocation_ids):
            raise SalesOwnerError("sales_payment_allocations_invalid", "distinct allocation_ids required")
        for allocation_id in command.allocation_ids:
            row = connection.execute("SELECT * FROM sales_payment_allocations WHERE allocation_id=?", (allocation_id,)).fetchone()
            if row is None or row["payment_id"] != payment["payment_id"] or not row["active"]:
                raise SalesOwnerError("sales_payment_allocation_not_active", allocation_id)
            planned.append(dict(row))
    else:
        if command.allocation_ids or (command.action == "allocate" and not command.allocations):
            raise SalesOwnerError("sales_payment_allocations_invalid", "allocate requires allocations")
        if len({item.invoice_id for item in command.allocations}) != len(command.allocations):
            raise SalesOwnerError("sales_payment_allocations_invalid", "one amount per invoice required")
        for index, item in enumerate(command.allocations):
            amount = _money(item.amount)
            invoice = _invoice(connection, item.invoice_id)
            if invoice.get("opening_settled"):
                raise SalesOwnerError("sales_opening_settled_header_only", item.invoice_id)
            if invoice["kind"] != "invoice":
                raise SalesOwnerError("sales_payment_invoice_invalid", item.invoice_id)
            if not payment["customer_party_id"] or invoice["customer_party_id"] != payment["customer_party_id"]:
                raise SalesOwnerError("sales_payment_customer_mismatch", item.invoice_id)
            if invoice["currency"] != payment["currency"]:
                raise SalesOwnerError("sales_payment_currency_mismatch", item.invoice_id)
            remaining = _decimal_sum((_uncredited_amount(connection, invoice), _allocated_amount(connection, invoice_id=item.invoice_id).copy_negate()))
            if amount > remaining:
                raise SalesOwnerError("sales_payment_exceeds_invoice", item.invoice_id)
            planned.append({"allocation_id": f"alloc-{command.command_digest[:24]}-{index}",
                            "payment_id": payment["payment_id"], "invoice_id": item.invoice_id, "amount": format(amount, ".2f"),
                            "active": 1, "source_ref": command.source_ref, "evidence_refs_json": json.dumps(evidence, ensure_ascii=False)})
        if _decimal_sum(Decimal(item["amount"]) for item in planned) > available:
            raise SalesOwnerError("sales_payment_exceeds_available", payment["payment_id"])
    content = {"command": command.to_dict(), "state_generation": _payment_generation(connection),
               "planned_payment": payment, "planned_allocations": planned}
    return SalesPaymentPreview(command, content["state_generation"], payment, tuple(planned), digest_json(content))


def preview_payment_action(storage: StorageTarget, command: SalesPaymentCommand, *, enabled_module_ids: Iterable[str] | None = None) -> SalesPaymentPreview:
    _require_module_enabled(enabled_module_ids)
    with _reading(storage) as connection:
        return _preview_payment_on_connection(connection, command)


def _payment_readback(connection: sqlite3.Connection, payment_id: str) -> dict[str, Any]:
    payment = _payment(connection, payment_id)
    allocated = _allocated_amount(connection, payment_id=payment_id)
    return {"schema_version": "bizhub.sales-payment-read.v1", "owner_ref": OWNER_REF, "payment": payment,
            "lines": _registered_payment_lines(connection, payment),
            "allocations": [dict(row) for row in connection.execute("SELECT * FROM sales_payment_allocations WHERE payment_id=? ORDER BY allocation_id", (payment_id,))],
            "balance": {"currency": payment["currency"], "payment_amount": payment["amount"], "allocated_amount": format(allocated, ".2f"),
                        "unallocated_amount": format(_decimal_sum((Decimal(payment["amount"]), allocated.copy_negate())), ".2f")}}


def read_payment(storage: StorageTarget, payment_id: str, *, enabled_module_ids: Iterable[str] | None = None) -> dict[str, Any]:
    _require_module_enabled(enabled_module_ids)
    with _reading(storage) as connection:
        return _payment_readback(connection, payment_id)


def read_payment_balances(storage: StorageTarget, *, enabled_module_ids: Iterable[str] | None = None) -> dict[str, Any]:
    _require_module_enabled(enabled_module_ids)
    with _reading(storage) as connection:
        totals = {}
        for row in connection.execute("SELECT * FROM sales_payments ORDER BY payment_id"):
            bucket = totals.setdefault((row["customer_party_id"], row["currency"]), {"payment": [], "allocated": []})
            bucket["payment"].append(Decimal(row["amount"]))
            bucket["allocated"].append(_allocated_amount(connection, payment_id=row["payment_id"]))
        items = []
        for (customer, currency), bucket in sorted(totals.items(), key=lambda item: (item[0][0] or "", item[0][1])):
            paid, allocated = _decimal_sum(bucket["payment"]), _decimal_sum(bucket["allocated"])
            items.append({"customer_party_id": customer, "currency": currency, "payment_amount": format(paid, ".2f"),
                          "allocated_amount": format(allocated, ".2f"), "unallocated_amount": format(_decimal_sum((paid, allocated.copy_negate())), ".2f")})
        return {"schema_version": "bizhub.sales-payment-balances-read.v1", "owner_ref": OWNER_REF, "items": items}


def apply_payment_preview_in_transaction(connection: sqlite3.Connection, preview: SalesPaymentPreview, *, enabled_module_ids: Iterable[str] | None = None) -> dict[str, Any]:
    if not connection.in_transaction:
        raise SalesOwnerError("sales_transaction_required", "an outer transaction is required")
    _require_module_enabled(enabled_module_ids)
    if digest_json(preview.content()) != preview.preview_digest:
        raise SalesOwnerError("sales_preview_content_drift", "preview digest differs")
    try:
        existing = connection.execute("SELECT action_id, command_digest FROM sales_document_action_receipts WHERE idempotency_key=?", (preview.command.idempotency_key,)).fetchone()
        if existing is not None:
            if existing["command_digest"] != preview.command.command_digest:
                raise SalesOwnerError("sales_idempotency_conflict", preview.command.idempotency_key)
            result = _document_readback(connection, existing["action_id"])
            result["disposition"] = "idempotent_noop"
            return result
        _check_payment_identity(connection, preview.command)
        if _payment_generation(connection) != preview.state_generation:
            raise SalesOwnerError("sales_state_generation_drift", "payment/invoice state changed")
        authoritative = _preview_payment_on_connection(connection, preview.command)
        if authoritative.preview_digest != preview.preview_digest:
            raise SalesOwnerError("sales_preview_content_drift", "authoritative plan differs")
        now = datetime.now(UTC).isoformat()
        payment = authoritative.planned_payment
        if preview.command.action == "register":
            connection.execute("""INSERT INTO sales_payments(payment_id, business_identity, customer_party_id, currency, amount,
                channel, external_reference, reference_missing, received_at, received_date, business_at, source_ref, evidence_refs_json, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (*[payment[key] for key in ("payment_id", "business_identity", "customer_party_id", "currency", "amount", "channel", "external_reference", "reference_missing", "received_at", "received_date", "business_at", "source_ref", "evidence_refs_json")], now))
        action_id, audit_id = uuid.uuid4().hex, uuid.uuid4().hex
        connection.execute("INSERT INTO sales_audit_events(event_id, event_type, payload_json, created_at) VALUES (?, ?, ?, ?)",
                           (audit_id, f"sales_payment_{preview.command.action}", json.dumps(authoritative.to_dict(), ensure_ascii=False, sort_keys=True), now))
        connection.execute("""INSERT INTO sales_document_action_receipts(action_id, idempotency_key, command_digest, preview_digest,
            document_kind, document_id, order_id, audit_event_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (action_id, preview.command.idempotency_key, preview.command.command_digest, preview.preview_digest, "payment", payment["payment_id"], None, audit_id, now))
        for allocation in authoritative.planned_allocations:
            if preview.command.action == "unallocate":
                connection.execute("UPDATE sales_payment_allocations SET active=0, revoked_at=?, revoked_action_id=? WHERE allocation_id=?",
                                   (now, action_id, allocation["allocation_id"]))
            else:
                connection.execute("""INSERT INTO sales_payment_allocations(allocation_id, payment_id, invoice_id, amount, active,
                    source_ref, evidence_refs_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                    (*[allocation[key] for key in ("allocation_id", "payment_id", "invoice_id", "amount", "active", "source_ref", "evidence_refs_json")], now))
        result = _document_readback(connection, action_id)
    except sqlite3.IntegrityError as exc:
        raise SalesOwnerError("sales_write_conflict", str(exc)) from exc
    result["disposition"] = "applied"
    return result


def apply_payment_preview(storage: StorageTarget, preview: SalesPaymentPreview, *, enabled_module_ids: Iterable[str] | None = None) -> dict[str, Any]:
    _require_module_enabled(enabled_module_ids)
    with _writing(storage) as connection:
        return apply_payment_preview_in_transaction(connection, preview, enabled_module_ids=enabled_module_ids)


def preview_action_in_transaction(connection: sqlite3.Connection, command, *, enabled_module_ids: Iterable[str] | None = None):
    enabled = _require_module_enabled(enabled_module_ids)
    return _preview_on_connection(connection, command, enabled_module_ids=enabled)


def preview_return_action_in_transaction(connection: sqlite3.Connection, command, *, enabled_module_ids: Iterable[str] | None = None):
    enabled = _require_module_enabled(enabled_module_ids)
    return _preview_return_on_connection(connection, command, enabled_module_ids=enabled)


def preview_invoice_action_in_transaction(connection: sqlite3.Connection, command, *, enabled_module_ids: Iterable[str] | None = None):
    enabled = _require_module_enabled(enabled_module_ids)
    return _preview_invoice_on_connection(connection, command)


def preview_payment_action_in_transaction(connection: sqlite3.Connection, command, *, enabled_module_ids: Iterable[str] | None = None):
    enabled = _require_module_enabled(enabled_module_ids)
    return _preview_payment_on_connection(connection, command)


def read_action_in_transaction(connection: sqlite3.Connection, idempotency_key: str, *, enabled_module_ids: Iterable[str] | None = None) -> dict[str, Any]:
    _require_module_enabled(enabled_module_ids)
    row = connection.execute("SELECT action_id FROM sales_action_receipts WHERE idempotency_key=?", (idempotency_key,)).fetchone()
    if row is None:
        raise SalesOwnerError("sales_readback_missing", idempotency_key)
    return _readback(connection, str(row["action_id"]))


def read_document_action_in_transaction(connection: sqlite3.Connection, idempotency_key: str, *, enabled_module_ids: Iterable[str] | None = None) -> dict[str, Any]:
    _require_module_enabled(enabled_module_ids)
    row = connection.execute("SELECT action_id FROM sales_document_action_receipts WHERE idempotency_key=?", (idempotency_key,)).fetchone()
    if row is None:
        raise SalesOwnerError("sales_readback_missing", idempotency_key)
    return _document_readback(connection, str(row["action_id"]))




def preview_reversal_action(storage: StorageTarget, command: TradeReversalCommand, *, numeric_tools, enabled_module_ids=None) -> TradeReversalPreview:
    enabled = _require_module_enabled(enabled_module_ids)
    with _reading(storage) as connection:
        try:
            return _preview_trade_reversal(connection, MODULE_ID, command, inventory_preview=preview_inventory_in_transaction, inventory_command=InventoryCommand, enabled=enabled, numeric_tools=numeric_tools)
        except TradeRuleError as exc:
            raise SalesOwnerError(str(exc), "冲销无法执行：" + str(exc)) from exc


def apply_reversal_preview(storage: StorageTarget, preview: TradeReversalPreview, *, numeric_tools, enabled_module_ids=None) -> dict[str, Any]:
    enabled = _require_module_enabled(enabled_module_ids)
    try:
        with _writing(storage) as connection:
            return _apply_trade_reversal(connection, MODULE_ID, preview, inventory_preview=preview_inventory_in_transaction,
                inventory_apply=apply_inventory_in_transaction, inventory_command=InventoryCommand, enabled=enabled, project_status=_project_order_status, persist=_persist_reversal, numeric_tools=numeric_tools)
    except TradeRuleError as exc:
        raise SalesOwnerError(str(exc), "冲销无法执行：" + str(exc)) from exc


def list_reversals(storage: StorageTarget, *, status: str = "", enabled_module_ids=None) -> dict[str, Any]:
    _require_module_enabled(enabled_module_ids)
    with _reading(storage) as connection:
        return {"items": [row for row in _reversal_documents(connection, MODULE_ID) if not status or row["status"] == status]}


def read_reversal(storage: StorageTarget, reversal_id: str, *, enabled_module_ids=None) -> dict[str, Any]:
    for row in list_reversals(storage, enabled_module_ids=enabled_module_ids)["items"]:
        if row["reversal_id"] == reversal_id:
            return row
    raise SalesOwnerError("trade_reversal_not_found", reversal_id)



def _persist_reversal(connection, preview, result, receipt, line_changes, order_changes):
    """The original Owner is the only physical writer of its transaction facts."""
    now = result["created_at"]
    for line_id, quantity in line_changes.items():
        connection.execute("UPDATE sales_order_lines SET fulfilled_quantity=? WHERE line_id=?", (quantity, line_id))
    for order_id, status in order_changes.items():
        connection.execute("UPDATE sales_orders SET status=?, updated_at=? WHERE order_id=?", (status, now, order_id))
    connection.execute("INSERT INTO sales_audit_events(event_id,event_type,payload_json,created_at) VALUES (?,?,?,?)",
        (result["reversal_id"], "trade_reversal_recorded", json.dumps({"preview": preview.to_dict(), "readback": result}, ensure_ascii=False), now))
    connection.execute(f"INSERT INTO sales_document_action_receipts ({','.join(receipt)}) VALUES ({','.join('?' for _ in receipt)})", tuple(receipt.values()))



def party_reference_counts(connection: sqlite3.Connection, party_id: int) -> dict[str, int]:
    """只读：本模块有多少张单据指向这个往来方（往来方合并前用来拦）。"""

    return {
        table: int(connection.execute(f"SELECT COUNT(*) FROM {table} WHERE customer_party_id=?", (int(party_id),)).fetchone()[0])
        for table in ("sales_orders", "sales_invoices", "sales_payments")
    }
