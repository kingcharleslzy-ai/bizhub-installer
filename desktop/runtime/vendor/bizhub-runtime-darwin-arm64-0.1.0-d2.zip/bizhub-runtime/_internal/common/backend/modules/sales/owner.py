"""Single writer for customer-neutral sales orders, shipments, and returns."""

from __future__ import annotations

import json
import sqlite3
import uuid
from datetime import UTC, datetime
from decimal import Decimal
from pathlib import Path
from typing import Any, Iterable

from backend.modules.inventory.public import (
    InventoryCommand,
    InventoryPreview,
    apply_preview_in_transaction as apply_inventory_in_transaction,
    preview_action_in_transaction as preview_inventory_in_transaction,
    read_action_in_transaction as read_inventory_in_transaction,
)
from backend.modules.master_data.public import MasterDataError, get_resource
from backend.modules.trade_core.public import (
    TradeRuleError,
    aggregate_order_progress,
    digest_json,
    normalized_evidence_refs,
    project_order_progress,
    quantity_decimal,
)

from .contracts import SalesCommand, SalesPreview


MODULE_ID = "sales"
OWNER_REF = f"{MODULE_ID}:order-owner"
REQUIRED_MODULES = {
    MODULE_ID,
    "trade_core",
    "master_data",
    "inventory",
    "procurement",
}


class SalesOwnerError(RuntimeError):
    def __init__(self, code: str, message: str):
        super().__init__(f"{code}: {message}")
        self.code = code
        self.message = message


def _require_module_enabled(enabled_module_ids: Iterable[str] | None) -> set[str]:
    if enabled_module_ids is None:
        from backend.generic_kernel.profile import get_generic_registry

        enabled_module_ids = [
            str(item["module_id"])
            for item in get_generic_registry().payload.get("modules", [])
        ]
    enabled = set(enabled_module_ids)
    missing = sorted(REQUIRED_MODULES - enabled)
    if MODULE_ID not in enabled:
        raise SalesOwnerError("sales_module_disabled", f"{MODULE_ID} is not enabled")
    if missing:
        raise SalesOwnerError("sales_dependency_missing", ",".join(missing))
    return enabled


def _connect(path: Path, *, readonly: bool) -> sqlite3.Connection:
    connection = sqlite3.connect(f"file:{path}?mode=ro" if readonly else path, uri=readonly)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys=ON")
    connection.execute("PRAGMA busy_timeout=10000")
    if readonly:
        connection.execute("PRAGMA query_only=ON")
    return connection


def _table_rows(connection: sqlite3.Connection, table: str, key: str) -> list[dict[str, Any]]:
    return [dict(row) for row in connection.execute(f"SELECT * FROM {table} ORDER BY {key}")]


def _state_generation(connection: sqlite3.Connection) -> str:
    return digest_json({
        "orders": _table_rows(connection, "sales_orders", "order_id"),
        "lines": _table_rows(connection, "sales_order_lines", "line_id"),
        "fulfillments": _table_rows(connection, "sales_fulfillments", "fulfillment_id"),
        "actions": _table_rows(connection, "sales_action_receipts", "action_id"),
    })


def _order(connection: sqlite3.Connection, order_id: str) -> dict[str, Any] | None:
    row = connection.execute(
        "SELECT * FROM sales_orders WHERE order_id=?", (order_id,)
    ).fetchone()
    return dict(row) if row else None


def _lines(connection: sqlite3.Connection, order_id: str) -> list[dict[str, Any]]:
    return [
        dict(row)
        for row in connection.execute(
            "SELECT * FROM sales_order_lines WHERE order_id=? ORDER BY line_id",
            (order_id,),
        )
    ]


def _validate_command(command: SalesCommand) -> tuple[str, ...]:
    if command.action not in {"create", "fulfill", "return", "cancel", "revise"}:
        raise SalesOwnerError("sales_action_invalid", command.action)
    if not command.idempotency_key.strip():
        raise SalesOwnerError("sales_idempotency_key_required", "idempotency key is required")
    if not command.order_id.strip():
        raise SalesOwnerError("sales_order_id_required", "order id is required")
    if not command.source_ref.strip():
        raise SalesOwnerError("sales_source_ref_required", "source ref is required")
    try:
        return normalized_evidence_refs(command.evidence_refs)
    except TradeRuleError as exc:
        raise SalesOwnerError(str(exc), "evidence refs are invalid") from exc


def _validated_lines(
    connection: sqlite3.Connection,
    command: SalesCommand,
) -> tuple[dict[str, Any], ...]:
    if not command.lines:
        raise SalesOwnerError("sales_lines_required", "at least one line is required")
    if len({item.line_id for item in command.lines}) != len(command.lines):
        raise SalesOwnerError("sales_line_id_duplicate", command.order_id)
    planned: list[dict[str, Any]] = []
    for item in command.lines:
        if not all((item.line_id.strip(), item.product_id.strip(), item.unit_id.strip(), item.ship_from_location_id.strip())):
            raise SalesOwnerError("sales_line_identity_required", item.line_id)
        try:
            get_resource(connection, "product", item.product_id)
            get_resource(connection, "unit", item.unit_id)
            get_resource(connection, "location", item.ship_from_location_id)
            quantity = quantity_decimal(item.quantity)
        except (MasterDataError, TradeRuleError) as exc:
            raise SalesOwnerError(getattr(exc, "code", str(exc)), item.line_id) from exc
        planned.append({
            "line_id": item.line_id,
            "product_id": item.product_id,
            "unit_id": item.unit_id,
            "quantity": format(quantity, "f"),
            "fulfilled_quantity": "0",
            "returned_quantity": "0",
            "ship_from_location_id": item.ship_from_location_id,
        })
    return tuple(planned)


def _fulfillment_id(command: SalesCommand) -> str:
    return f"sls-{digest_json(command.to_dict())[:24]}"


def _project_order_status(lines: list[dict[str, Any]]) -> str:
    states = [
        project_order_progress(
            ordered_quantity=item["quantity"],
            completed_quantity=item["fulfilled_quantity"],
            returned_quantity=item["returned_quantity"],
        )
        for item in lines
    ]
    value = aggregate_order_progress(states)
    return {"completed": "fulfilled", "partial": "partially_fulfilled"}.get(value, value)


def _preview_on_connection(
    connection: sqlite3.Connection,
    command: SalesCommand,
    *,
    enabled_module_ids: Iterable[str] | None,
) -> SalesPreview:
    enabled = _require_module_enabled(enabled_module_ids)
    evidence_refs = _validate_command(command)
    generation = _state_generation(connection)
    existing = _order(connection, command.order_id)
    planned_lines: tuple[dict[str, Any], ...] = ()
    planned_fulfillment: dict[str, Any] | None = None
    inventory_preview: dict[str, Any] | None = None

    if command.action == "create":
        if existing is not None:
            raise SalesOwnerError("sales_order_already_exists", command.order_id)
        if not command.customer_party_id.strip() or not command.ordered_at.strip():
            raise SalesOwnerError("sales_order_identity_required", command.order_id)
        try:
            get_resource(connection, "party", command.customer_party_id)
        except MasterDataError as exc:
            raise SalesOwnerError(exc.code, exc.message) from exc
        planned_lines = _validated_lines(connection, command)
        planned_order = {
            "order_id": command.order_id,
            "customer_party_id": command.customer_party_id,
            "ordered_at": command.ordered_at,
            "status": "open",
            "revision": 1,
            "evidence_refs_json": json.dumps(evidence_refs, ensure_ascii=False),
            "source_ref": command.source_ref,
        }
    else:
        if existing is None:
            raise SalesOwnerError("sales_order_not_found", command.order_id)
        current_lines = _lines(connection, command.order_id)
        planned_order = dict(existing)
        if command.action in {"fulfill", "return"}:
            if existing["status"] == "cancelled":
                raise SalesOwnerError("sales_order_cancelled", command.order_id)
            target = next((item for item in current_lines if item["line_id"] == command.target_line_id), None)
            if target is None:
                raise SalesOwnerError("sales_line_not_found", command.target_line_id)
            try:
                quantity = quantity_decimal(command.quantity)
            except TradeRuleError as exc:
                raise SalesOwnerError(str(exc), command.quantity) from exc
            fulfilled = Decimal(str(target["fulfilled_quantity"]))
            returned = Decimal(str(target["returned_quantity"]))
            limit = Decimal(str(target["quantity"])) - fulfilled if command.action == "fulfill" else fulfilled - returned
            if quantity > limit:
                code = "sales_fulfillment_exceeds_remaining" if command.action == "fulfill" else "sales_return_exceeds_fulfilled"
                raise SalesOwnerError(code, command.target_line_id)
            if not command.occurred_at.strip():
                raise SalesOwnerError("sales_occurred_at_required", command.order_id)
            inventory = preview_inventory_in_transaction(
                connection,
                InventoryCommand(
                    action="outbound" if command.action == "fulfill" else "inbound",
                    idempotency_key=f"sales:{command.idempotency_key}",
                    product_id=str(target["product_id"]),
                    unit_id=str(target["unit_id"]),
                    quantity=format(quantity, "f"),
                    from_location_id=str(target["ship_from_location_id"]) if command.action == "fulfill" else None,
                    to_location_id=str(target["ship_from_location_id"]) if command.action == "return" else None,
                    occurred_at=command.occurred_at,
                    source_ref=command.source_ref,
                    reason=command.reason,
                ),
                enabled_module_ids=enabled,
            )
            inventory_preview = inventory.to_dict()
            planned_fulfillment = {
                "fulfillment_id": _fulfillment_id(command),
                "fulfillment_kind": "shipment" if command.action == "fulfill" else "return",
                "order_id": command.order_id,
                "line_id": command.target_line_id,
                "quantity": format(quantity, "f"),
                "occurred_at": command.occurred_at,
                "evidence_refs_json": json.dumps(evidence_refs, ensure_ascii=False),
            }
            updated_lines = [dict(item) for item in current_lines]
            for item in updated_lines:
                if item["line_id"] == command.target_line_id:
                    key = "fulfilled_quantity" if command.action == "fulfill" else "returned_quantity"
                    item[key] = format(Decimal(str(item[key])) + quantity, "f")
            planned_order["status"] = _project_order_status(updated_lines)
        elif command.action == "cancel":
            if existing["status"] == "cancelled":
                raise SalesOwnerError("sales_order_already_cancelled", command.order_id)
            if any(Decimal(str(item["fulfilled_quantity"])) > 0 for item in current_lines):
                raise SalesOwnerError("sales_fulfilled_order_not_cancellable", command.order_id)
            if not command.reason.strip():
                raise SalesOwnerError("sales_cancellation_reason_required", command.order_id)
            planned_order["status"] = "cancelled"
        else:
            if any(Decimal(str(item["fulfilled_quantity"])) > 0 for item in current_lines):
                raise SalesOwnerError("sales_fulfilled_order_not_revisable", command.order_id)
            if not command.reason.strip() or not command.customer_party_id.strip() or not command.ordered_at.strip():
                raise SalesOwnerError("sales_revision_fields_required", command.order_id)
            try:
                get_resource(connection, "party", command.customer_party_id)
            except MasterDataError as exc:
                raise SalesOwnerError(exc.code, exc.message) from exc
            planned_lines = _validated_lines(connection, command)
            planned_order.update({
                "customer_party_id": command.customer_party_id,
                "ordered_at": command.ordered_at,
                "status": "open",
                "revision": int(existing["revision"]) + 1,
                "evidence_refs_json": json.dumps(evidence_refs, ensure_ascii=False),
                "source_ref": command.source_ref,
            })
    content = {
        "command": command.to_dict(),
        "state_generation": generation,
        "planned_order": planned_order,
        "planned_lines": list(planned_lines),
        "planned_fulfillment": planned_fulfillment,
        "inventory_preview": inventory_preview,
    }
    return SalesPreview(
        command=command,
        state_generation=generation,
        planned_order=planned_order,
        planned_lines=planned_lines,
        planned_fulfillment=planned_fulfillment,
        inventory_preview=inventory_preview,
        preview_digest=digest_json(content),
    )


def preview_action(
    path: Path,
    command: SalesCommand,
    *,
    enabled_module_ids: Iterable[str] | None = None,
) -> SalesPreview:
    _require_module_enabled(enabled_module_ids)
    with _connect(path, readonly=True) as connection:
        return _preview_on_connection(connection, command, enabled_module_ids=enabled_module_ids)


def _readback(connection: sqlite3.Connection, action_id: str) -> dict[str, Any]:
    receipt = connection.execute(
        "SELECT * FROM sales_action_receipts WHERE action_id=?", (action_id,)
    ).fetchone()
    if receipt is None:
        raise SalesOwnerError("sales_readback_missing", action_id)
    order_id = str(receipt["order_id"])
    inventory = None
    if receipt["inventory_action_id"]:
        inventory = read_inventory_in_transaction(connection, str(receipt["inventory_action_id"]))
    audit = connection.execute(
        "SELECT * FROM sales_audit_events WHERE event_id=?",
        (receipt["audit_event_id"],),
    ).fetchone()
    return {
        "schema_version": "bizhub.sales-readback.v1",
        "owner_ref": OWNER_REF,
        "action_id": action_id,
        "idempotency_key": str(receipt["idempotency_key"]),
        "command_digest": str(receipt["command_digest"]),
        "preview_digest": str(receipt["preview_digest"]),
        "order": _order(connection, order_id),
        "lines": _lines(connection, order_id),
        "fulfillments": [
            dict(row)
            for row in connection.execute(
                "SELECT * FROM sales_fulfillments WHERE order_id=? ORDER BY fulfillment_id",
                (order_id,),
            )
        ],
        "inventory": inventory,
        "audit_event": dict(audit) if audit else None,
        "state_generation": _state_generation(connection),
    }


def apply_preview(
    path: Path,
    preview: SalesPreview,
    *,
    enabled_module_ids: Iterable[str] | None = None,
) -> dict[str, Any]:
    enabled = _require_module_enabled(enabled_module_ids)
    if digest_json(preview.content()) != preview.preview_digest:
        raise SalesOwnerError("sales_preview_content_drift", "preview digest differs")
    with _connect(path, readonly=False) as connection:
        connection.execute("BEGIN IMMEDIATE")
        try:
            existing = connection.execute(
                "SELECT action_id, command_digest FROM sales_action_receipts WHERE idempotency_key=?",
                (preview.command.idempotency_key,),
            ).fetchone()
            if existing is not None:
                if str(existing["command_digest"]) != preview.command.command_digest:
                    raise SalesOwnerError("sales_idempotency_conflict", preview.command.idempotency_key)
                result = _readback(connection, str(existing["action_id"]))
                connection.commit()
                result["disposition"] = "idempotent_noop"
                return result
            if _state_generation(connection) != preview.state_generation:
                raise SalesOwnerError("sales_state_generation_drift", "sales changed")
            authoritative = _preview_on_connection(
                connection,
                preview.command,
                enabled_module_ids=enabled,
            )
            if authoritative.preview_digest != preview.preview_digest:
                raise SalesOwnerError("sales_preview_content_drift", "authoritative plan differs")
            inventory_result = None
            if authoritative.inventory_preview:
                inventory_result = apply_inventory_in_transaction(
                    connection,
                    InventoryPreview.from_dict(authoritative.inventory_preview),
                    enabled_module_ids=enabled,
                )
            now = datetime.now(UTC).isoformat()
            order = authoritative.planned_order
            if preview.command.action == "create":
                connection.execute(
                    """INSERT INTO sales_orders
                       (order_id, customer_party_id, ordered_at, status, revision,
                        evidence_refs_json, source_ref, created_at, updated_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        order["order_id"], order["customer_party_id"], order["ordered_at"],
                        order["status"], order["revision"], order["evidence_refs_json"],
                        order["source_ref"], now, now,
                    ),
                )
                for line in authoritative.planned_lines:
                    connection.execute(
                        """INSERT INTO sales_order_lines
                           (line_id, order_id, product_id, unit_id, quantity,
                            fulfilled_quantity, returned_quantity, ship_from_location_id)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                        (
                            line["line_id"], preview.command.order_id, line["product_id"],
                            line["unit_id"], line["quantity"], line["fulfilled_quantity"],
                            line["returned_quantity"], line["ship_from_location_id"],
                        ),
                    )
            elif preview.command.action in {"fulfill", "return"}:
                movement_ids = [item["movement_id"] for item in (inventory_result or {}).get("movements", [])]
                fulfillment = authoritative.planned_fulfillment or {}
                connection.execute(
                    """INSERT INTO sales_fulfillments
                       (fulfillment_id, fulfillment_kind, order_id, line_id, quantity,
                        inventory_action_id, inventory_movement_id, occurred_at, evidence_refs_json)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        fulfillment["fulfillment_id"], fulfillment["fulfillment_kind"],
                        fulfillment["order_id"], fulfillment["line_id"], fulfillment["quantity"],
                        (inventory_result or {}).get("action_id"), movement_ids[0] if movement_ids else None,
                        fulfillment["occurred_at"], fulfillment["evidence_refs_json"],
                    ),
                )
                field = "fulfilled_quantity" if preview.command.action == "fulfill" else "returned_quantity"
                connection.execute(
                    f"UPDATE sales_order_lines SET {field}={field}+? WHERE line_id=?",
                    (fulfillment["quantity"], fulfillment["line_id"]),
                )
                connection.execute(
                    "UPDATE sales_orders SET status=?, updated_at=? WHERE order_id=?",
                    (order["status"], now, preview.command.order_id),
                )
            elif preview.command.action == "cancel":
                connection.execute(
                    "UPDATE sales_orders SET status='cancelled', updated_at=? WHERE order_id=?",
                    (now, preview.command.order_id),
                )
            else:
                connection.execute(
                    """UPDATE sales_orders SET customer_party_id=?, ordered_at=?, status=?,
                       revision=?, evidence_refs_json=?, source_ref=?, updated_at=? WHERE order_id=?""",
                    (
                        order["customer_party_id"], order["ordered_at"], order["status"],
                        order["revision"], order["evidence_refs_json"], order["source_ref"],
                        now, preview.command.order_id,
                    ),
                )
                connection.execute("DELETE FROM sales_order_lines WHERE order_id=?", (preview.command.order_id,))
                for line in authoritative.planned_lines:
                    connection.execute(
                        """INSERT INTO sales_order_lines
                           (line_id, order_id, product_id, unit_id, quantity,
                            fulfilled_quantity, returned_quantity, ship_from_location_id)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                        (
                            line["line_id"], preview.command.order_id, line["product_id"],
                            line["unit_id"], line["quantity"], line["fulfilled_quantity"],
                            line["returned_quantity"], line["ship_from_location_id"],
                        ),
                    )
            action_id = uuid.uuid4().hex
            audit_event_id = uuid.uuid4().hex
            connection.execute(
                "INSERT INTO sales_audit_events(event_id, event_type, payload_json, created_at) VALUES (?, ?, ?, ?)",
                (
                    audit_event_id,
                    f"sales_{preview.command.action}_applied",
                    json.dumps(authoritative.to_dict(), ensure_ascii=False, sort_keys=True, separators=(",", ":")),
                    now,
                ),
            )
            connection.execute(
                """INSERT INTO sales_action_receipts
                   (action_id, idempotency_key, command_digest, preview_digest, order_id,
                    audit_event_id, inventory_action_id, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    action_id, preview.command.idempotency_key, preview.command.command_digest,
                    preview.preview_digest, preview.command.order_id, audit_event_id,
                    (inventory_result or {}).get("action_id"), now,
                ),
            )
            result = _readback(connection, action_id)
            connection.commit()
        except sqlite3.IntegrityError as exc:
            connection.rollback()
            raise SalesOwnerError("sales_write_conflict", str(exc)) from exc
        except Exception:
            connection.rollback()
            raise
    result["disposition"] = "applied"
    return result


__all__ = ["SalesOwnerError", "apply_preview", "preview_action"]
