"""Single writer for customer-neutral procurement orders and receipts."""

from __future__ import annotations

import json
import sqlite3
import uuid
from datetime import UTC, datetime
from decimal import Decimal
from pathlib import Path
from typing import Any, Iterable

from backend.modules.inventory.public import (
    InventoryCommand,
    InventoryPreview,
    apply_preview_in_transaction as apply_inventory_in_transaction,
    preview_action_in_transaction as preview_inventory_in_transaction,
    read_action_in_transaction as read_inventory_in_transaction,
)
from backend.modules.master_data.public import MasterDataError, get_resource
from backend.modules.trade_core.public import (
    TradeRuleError,
    aggregate_order_progress,
    digest_json,
    normalized_evidence_refs,
    project_order_progress,
    quantity_decimal,
)

from .contracts import ProcurementCommand, ProcurementPreview


MODULE_ID = "procurement"
OWNER_REF = f"{MODULE_ID}:order-owner"
REQUIRED_MODULES = {MODULE_ID, "trade_core", "master_data", "inventory"}


class ProcurementOwnerError(RuntimeError):
    def __init__(self, code: str, message: str):
        super().__init__(f"{code}: {message}")
        self.code = code
        self.message = message


def _require_module_enabled(enabled_module_ids: Iterable[str] | None) -> set[str]:
    if enabled_module_ids is None:
        from backend.generic_kernel.profile import get_generic_registry

        enabled_module_ids = [
            str(item["module_id"])
            for item in get_generic_registry().payload.get("modules", [])
        ]
    enabled = set(enabled_module_ids)
    missing = sorted(REQUIRED_MODULES - enabled)
    if MODULE_ID not in enabled:
        raise ProcurementOwnerError("procurement_module_disabled", f"{MODULE_ID} is not enabled")
    if missing:
        raise ProcurementOwnerError("procurement_dependency_missing", ",".join(missing))
    return enabled


def _connect(path: Path, *, readonly: bool) -> sqlite3.Connection:
    connection = sqlite3.connect(f"file:{path}?mode=ro" if readonly else path, uri=readonly)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys=ON")
    connection.execute("PRAGMA busy_timeout=10000")
    if readonly:
        connection.execute("PRAGMA query_only=ON")
    return connection


def _table_rows(connection: sqlite3.Connection, table: str, key: str) -> list[dict[str, Any]]:
    return [dict(row) for row in connection.execute(f"SELECT * FROM {table} ORDER BY {key}")]


def _state_generation(connection: sqlite3.Connection) -> str:
    return digest_json({
        "orders": _table_rows(connection, "procurement_orders", "order_id"),
        "lines": _table_rows(connection, "procurement_order_lines", "line_id"),
        "receipts": _table_rows(connection, "procurement_receipts", "receipt_id"),
        "actions": _table_rows(connection, "procurement_action_receipts", "action_id"),
    })


def _order(connection: sqlite3.Connection, order_id: str) -> dict[str, Any] | None:
    row = connection.execute(
        "SELECT * FROM procurement_orders WHERE order_id=?", (order_id,)
    ).fetchone()
    return dict(row) if row else None


def _lines(connection: sqlite3.Connection, order_id: str) -> list[dict[str, Any]]:
    return [
        dict(row)
        for row in connection.execute(
            "SELECT * FROM procurement_order_lines WHERE order_id=? ORDER BY line_id",
            (order_id,),
        )
    ]


def _validate_command(command: ProcurementCommand) -> tuple[str, ...]:
    if command.action not in {"create", "receive", "cancel", "revise"}:
        raise ProcurementOwnerError("procurement_action_invalid", command.action)
    if not command.idempotency_key.strip():
        raise ProcurementOwnerError("procurement_idempotency_key_required", "idempotency key is required")
    if not command.order_id.strip():
        raise ProcurementOwnerError("procurement_order_id_required", "order id is required")
    if not command.source_ref.strip():
        raise ProcurementOwnerError("procurement_source_ref_required", "source ref is required")
    try:
        return normalized_evidence_refs(command.evidence_refs)
    except TradeRuleError as exc:
        raise ProcurementOwnerError(str(exc), "evidence refs are invalid") from exc


def _validated_lines(
    connection: sqlite3.Connection,
    command: ProcurementCommand,
) -> tuple[dict[str, Any], ...]:
    if not command.lines:
        raise ProcurementOwnerError("procurement_lines_required", "at least one line is required")
    if len({item.line_id for item in command.lines}) != len(command.lines):
        raise ProcurementOwnerError("procurement_line_id_duplicate", command.order_id)
    planned: list[dict[str, Any]] = []
    for item in command.lines:
        if not all((item.line_id.strip(), item.product_id.strip(), item.unit_id.strip(), item.receive_location_id.strip())):
            raise ProcurementOwnerError("procurement_line_identity_required", item.line_id)
        try:
            get_resource(connection, "product", item.product_id)
            get_resource(connection, "unit", item.unit_id)
            get_resource(connection, "location", item.receive_location_id)
            quantity = quantity_decimal(item.quantity)
        except (MasterDataError, TradeRuleError) as exc:
            raise ProcurementOwnerError(getattr(exc, "code", str(exc)), item.line_id) from exc
        planned.append({
            "line_id": item.line_id,
            "product_id": item.product_id,
            "unit_id": item.unit_id,
            "quantity": format(quantity, "f"),
            "received_quantity": "0",
            "receive_location_id": item.receive_location_id,
        })
    return tuple(planned)


def _receipt_id(command: ProcurementCommand) -> str:
    return f"prc-{digest_json(command.to_dict())[:24]}"


def _project_order_status(lines: list[dict[str, Any]]) -> str:
    states = [
        project_order_progress(
            ordered_quantity=item["quantity"],
            completed_quantity=item["received_quantity"],
        )
        for item in lines
    ]
    value = aggregate_order_progress(states)
    return {"completed": "received", "partial": "partially_received"}.get(value, value)


def _preview_on_connection(
    connection: sqlite3.Connection,
    command: ProcurementCommand,
    *,
    enabled_module_ids: Iterable[str] | None,
) -> ProcurementPreview:
    enabled = _require_module_enabled(enabled_module_ids)
    evidence_refs = _validate_command(command)
    generation = _state_generation(connection)
    existing = _order(connection, command.order_id)
    planned_lines: tuple[dict[str, Any], ...] = ()
    planned_receipt: dict[str, Any] | None = None
    inventory_preview: dict[str, Any] | None = None

    if command.action == "create":
        if existing is not None:
            raise ProcurementOwnerError("procurement_order_already_exists", command.order_id)
        if not command.supplier_party_id.strip() or not command.ordered_at.strip():
            raise ProcurementOwnerError("procurement_order_identity_required", command.order_id)
        try:
            get_resource(connection, "party", command.supplier_party_id)
        except MasterDataError as exc:
            raise ProcurementOwnerError(exc.code, exc.message) from exc
        planned_lines = _validated_lines(connection, command)
        planned_order = {
            "order_id": command.order_id,
            "supplier_party_id": command.supplier_party_id,
            "ordered_at": command.ordered_at,
            "status": "open",
            "revision": 1,
            "evidence_refs_json": json.dumps(evidence_refs, ensure_ascii=False),
            "source_ref": command.source_ref,
        }
    else:
        if existing is None:
            raise ProcurementOwnerError("procurement_order_not_found", command.order_id)
        current_lines = _lines(connection, command.order_id)
        planned_order = dict(existing)
        if command.action == "receive":
            if existing["status"] == "cancelled":
                raise ProcurementOwnerError("procurement_order_cancelled", command.order_id)
            target = next((item for item in current_lines if item["line_id"] == command.target_line_id), None)
            if target is None:
                raise ProcurementOwnerError("procurement_line_not_found", command.target_line_id)
            try:
                quantity = quantity_decimal(command.quantity)
            except TradeRuleError as exc:
                raise ProcurementOwnerError(str(exc), command.quantity) from exc
            remaining = Decimal(str(target["quantity"])) - Decimal(str(target["received_quantity"]))
            if quantity > remaining:
                raise ProcurementOwnerError("procurement_receipt_exceeds_remaining", command.target_line_id)
            if not command.occurred_at.strip():
                raise ProcurementOwnerError("procurement_occurred_at_required", command.order_id)
            inventory = preview_inventory_in_transaction(
                connection,
                InventoryCommand(
                    action="inbound",
                    idempotency_key=f"procurement:{command.idempotency_key}",
                    product_id=str(target["product_id"]),
                    unit_id=str(target["unit_id"]),
                    quantity=format(quantity, "f"),
                    to_location_id=str(target["receive_location_id"]),
                    occurred_at=command.occurred_at,
                    source_ref=command.source_ref,
                    reason=command.reason,
                ),
                enabled_module_ids=enabled,
            )
            inventory_preview = inventory.to_dict()
            planned_receipt = {
                "receipt_id": _receipt_id(command),
                "order_id": command.order_id,
                "line_id": command.target_line_id,
                "quantity": format(quantity, "f"),
                "occurred_at": command.occurred_at,
                "evidence_refs_json": json.dumps(evidence_refs, ensure_ascii=False),
            }
            updated_lines = [dict(item) for item in current_lines]
            for item in updated_lines:
                if item["line_id"] == command.target_line_id:
                    item["received_quantity"] = format(
                        Decimal(str(item["received_quantity"])) + quantity,
                        "f",
                    )
            planned_order["status"] = _project_order_status(updated_lines)
        elif command.action == "cancel":
            if existing["status"] == "cancelled":
                raise ProcurementOwnerError("procurement_order_already_cancelled", command.order_id)
            if any(Decimal(str(item["received_quantity"])) > 0 for item in current_lines):
                raise ProcurementOwnerError(
                    "procurement_received_order_not_cancellable",
                    command.order_id,
                )
            if not command.reason.strip():
                raise ProcurementOwnerError("procurement_cancellation_reason_required", command.order_id)
            planned_order["status"] = "cancelled"
        else:
            if any(Decimal(str(item["received_quantity"])) > 0 for item in current_lines):
                raise ProcurementOwnerError("procurement_received_order_not_revisable", command.order_id)
            if not command.reason.strip() or not command.supplier_party_id.strip() or not command.ordered_at.strip():
                raise ProcurementOwnerError("procurement_revision_fields_required", command.order_id)
            try:
                get_resource(connection, "party", command.supplier_party_id)
            except MasterDataError as exc:
                raise ProcurementOwnerError(exc.code, exc.message) from exc
            planned_lines = _validated_lines(connection, command)
            planned_order.update({
                "supplier_party_id": command.supplier_party_id,
                "ordered_at": command.ordered_at,
                "status": "open",
                "revision": int(existing["revision"]) + 1,
                "evidence_refs_json": json.dumps(evidence_refs, ensure_ascii=False),
                "source_ref": command.source_ref,
            })
    content = {
        "command": command.to_dict(),
        "state_generation": generation,
        "planned_order": planned_order,
        "planned_lines": list(planned_lines),
        "planned_receipt": planned_receipt,
        "inventory_preview": inventory_preview,
    }
    return ProcurementPreview(
        command=command,
        state_generation=generation,
        planned_order=planned_order,
        planned_lines=planned_lines,
        planned_receipt=planned_receipt,
        inventory_preview=inventory_preview,
        preview_digest=digest_json(content),
    )


def preview_action(
    path: Path,
    command: ProcurementCommand,
    *,
    enabled_module_ids: Iterable[str] | None = None,
) -> ProcurementPreview:
    _require_module_enabled(enabled_module_ids)
    with _connect(path, readonly=True) as connection:
        return _preview_on_connection(
            connection,
            command,
            enabled_module_ids=enabled_module_ids,
        )


def _readback(connection: sqlite3.Connection, action_id: str) -> dict[str, Any]:
    receipt = connection.execute(
        "SELECT * FROM procurement_action_receipts WHERE action_id=?", (action_id,)
    ).fetchone()
    if receipt is None:
        raise ProcurementOwnerError("procurement_readback_missing", action_id)
    order_id = str(receipt["order_id"])
    order = _order(connection, order_id)
    inventory = None
    if receipt["inventory_action_id"]:
        inventory = read_inventory_in_transaction(connection, str(receipt["inventory_action_id"]))
    audit = connection.execute(
        "SELECT * FROM procurement_audit_events WHERE event_id=?",
        (receipt["audit_event_id"],),
    ).fetchone()
    return {
        "schema_version": "bizhub.procurement-readback.v1",
        "owner_ref": OWNER_REF,
        "action_id": action_id,
        "idempotency_key": str(receipt["idempotency_key"]),
        "command_digest": str(receipt["command_digest"]),
        "preview_digest": str(receipt["preview_digest"]),
        "order": order,
        "lines": _lines(connection, order_id),
        "receipts": [
            dict(row)
            for row in connection.execute(
                "SELECT * FROM procurement_receipts WHERE order_id=? ORDER BY receipt_id",
                (order_id,),
            )
        ],
        "inventory": inventory,
        "audit_event": dict(audit) if audit else None,
        "state_generation": _state_generation(connection),
    }


def apply_preview(
    path: Path,
    preview: ProcurementPreview,
    *,
    enabled_module_ids: Iterable[str] | None = None,
) -> dict[str, Any]:
    enabled = _require_module_enabled(enabled_module_ids)
    if digest_json(preview.content()) != preview.preview_digest:
        raise ProcurementOwnerError("procurement_preview_content_drift", "preview digest differs")
    with _connect(path, readonly=False) as connection:
        connection.execute("BEGIN IMMEDIATE")
        try:
            existing = connection.execute(
                "SELECT action_id, command_digest FROM procurement_action_receipts WHERE idempotency_key=?",
                (preview.command.idempotency_key,),
            ).fetchone()
            if existing is not None:
                if str(existing["command_digest"]) != preview.command.command_digest:
                    raise ProcurementOwnerError("procurement_idempotency_conflict", preview.command.idempotency_key)
                result = _readback(connection, str(existing["action_id"]))
                connection.commit()
                result["disposition"] = "idempotent_noop"
                return result
            if _state_generation(connection) != preview.state_generation:
                raise ProcurementOwnerError("procurement_state_generation_drift", "procurement changed")
            authoritative = _preview_on_connection(
                connection,
                preview.command,
                enabled_module_ids=enabled,
            )
            if authoritative.preview_digest != preview.preview_digest:
                raise ProcurementOwnerError("procurement_preview_content_drift", "authoritative plan differs")
            inventory_result = None
            if authoritative.inventory_preview:
                inventory_result = apply_inventory_in_transaction(
                    connection,
                    InventoryPreview.from_dict(authoritative.inventory_preview),
                    enabled_module_ids=enabled,
                )
            now = datetime.now(UTC).isoformat()
            order = authoritative.planned_order
            if preview.command.action == "create":
                connection.execute(
                    """INSERT INTO procurement_orders
                       (order_id, supplier_party_id, ordered_at, status, revision,
                        evidence_refs_json, source_ref, created_at, updated_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        order["order_id"], order["supplier_party_id"], order["ordered_at"],
                        order["status"], order["revision"], order["evidence_refs_json"],
                        order["source_ref"], now, now,
                    ),
                )
                for line in authoritative.planned_lines:
                    connection.execute(
                        """INSERT INTO procurement_order_lines
                           (line_id, order_id, product_id, unit_id, quantity,
                            received_quantity, receive_location_id)
                           VALUES (?, ?, ?, ?, ?, ?, ?)""",
                        (
                            line["line_id"], preview.command.order_id, line["product_id"],
                            line["unit_id"], line["quantity"], line["received_quantity"],
                            line["receive_location_id"],
                        ),
                    )
            elif preview.command.action == "receive":
                movement_ids = [item["movement_id"] for item in (inventory_result or {}).get("movements", [])]
                receipt = authoritative.planned_receipt or {}
                connection.execute(
                    """INSERT INTO procurement_receipts
                       (receipt_id, order_id, line_id, quantity, inventory_action_id,
                        inventory_movement_id, occurred_at, evidence_refs_json)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        receipt["receipt_id"], receipt["order_id"], receipt["line_id"],
                        receipt["quantity"], (inventory_result or {}).get("action_id"),
                        movement_ids[0] if movement_ids else None, receipt["occurred_at"],
                        receipt["evidence_refs_json"],
                    ),
                )
                connection.execute(
                    "UPDATE procurement_order_lines SET received_quantity=received_quantity+? WHERE line_id=?",
                    (receipt["quantity"], receipt["line_id"]),
                )
                connection.execute(
                    "UPDATE procurement_orders SET status=?, updated_at=? WHERE order_id=?",
                    (order["status"], now, preview.command.order_id),
                )
            elif preview.command.action == "cancel":
                connection.execute(
                    "UPDATE procurement_orders SET status='cancelled', updated_at=? WHERE order_id=?",
                    (now, preview.command.order_id),
                )
            else:
                connection.execute(
                    """UPDATE procurement_orders SET supplier_party_id=?, ordered_at=?, status=?,
                       revision=?, evidence_refs_json=?, source_ref=?, updated_at=? WHERE order_id=?""",
                    (
                        order["supplier_party_id"], order["ordered_at"], order["status"],
                        order["revision"], order["evidence_refs_json"], order["source_ref"],
                        now, preview.command.order_id,
                    ),
                )
                connection.execute("DELETE FROM procurement_order_lines WHERE order_id=?", (preview.command.order_id,))
                for line in authoritative.planned_lines:
                    connection.execute(
                        """INSERT INTO procurement_order_lines
                           (line_id, order_id, product_id, unit_id, quantity,
                            received_quantity, receive_location_id)
                           VALUES (?, ?, ?, ?, ?, ?, ?)""",
                        (
                            line["line_id"], preview.command.order_id, line["product_id"],
                            line["unit_id"], line["quantity"], line["received_quantity"],
                            line["receive_location_id"],
                        ),
                    )
            action_id = uuid.uuid4().hex
            audit_event_id = uuid.uuid4().hex
            connection.execute(
                "INSERT INTO procurement_audit_events(event_id, event_type, payload_json, created_at) VALUES (?, ?, ?, ?)",
                (
                    audit_event_id,
                    f"procurement_{preview.command.action}_applied",
                    json.dumps(authoritative.to_dict(), ensure_ascii=False, sort_keys=True, separators=(",", ":")),
                    now,
                ),
            )
            connection.execute(
                """INSERT INTO procurement_action_receipts
                   (action_id, idempotency_key, command_digest, preview_digest, order_id,
                    audit_event_id, inventory_action_id, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    action_id, preview.command.idempotency_key, preview.command.command_digest,
                    preview.preview_digest, preview.command.order_id, audit_event_id,
                    (inventory_result or {}).get("action_id"), now,
                ),
            )
            result = _readback(connection, action_id)
            connection.commit()
        except sqlite3.IntegrityError as exc:
            connection.rollback()
            raise ProcurementOwnerError("procurement_write_conflict", str(exc)) from exc
        except Exception:
            connection.rollback()
            raise
    result["disposition"] = "applied"
    return result


__all__ = ["ProcurementOwnerError", "apply_preview", "preview_action"]
