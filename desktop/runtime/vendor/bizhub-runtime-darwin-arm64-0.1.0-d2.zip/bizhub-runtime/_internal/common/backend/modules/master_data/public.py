"""The only public read facade used by generic business modules."""

from __future__ import annotations

import json
import sqlite3
from typing import Any

from .contracts import RESOURCE_KINDS, digest_json, normalize_identity


class MasterDataError(RuntimeError):
    def __init__(self, code: str, message: str):
        super().__init__(f"{code}: {message}")
        self.code = code
        self.message = message


_TABLES = {
    "party": ("master_data_parties", "party_id"),
    "product": ("master_data_products", "product_id"),
    "unit": ("master_data_units", "unit_id"),
    "location": ("location_catalog", "location_id"),
}


def get_resource(
    connection: sqlite3.Connection,
    resource_kind: str,
    resource_id: str,
    *,
    require_active: bool = True,
) -> dict[str, Any]:
    if resource_kind not in RESOURCE_KINDS:
        raise MasterDataError("master_data_resource_kind_invalid", resource_kind)
    table, id_column = _TABLES[resource_kind]
    row = connection.execute(
        f"SELECT * FROM {table} WHERE {id_column}=?", (str(resource_id),)
    ).fetchone()
    if row is None:
        raise MasterDataError(
            "master_data_resource_missing", f"{resource_kind}:{resource_id}"
        )
    payload = dict(row)
    if require_active and payload.get("status") != "active":
        raise MasterDataError(
            "master_data_resource_inactive", f"{resource_kind}:{resource_id}"
        )
    attributes = payload.get("attributes_json")
    if attributes is not None:
        payload["attributes"] = json.loads(str(attributes))
    payload["resource_kind"] = resource_kind
    payload["resource_id"] = str(payload[id_column])
    return payload


def resolve_external_identity(
    connection: sqlite3.Connection,
    *,
    resource_kind: str,
    source_id: str,
    external_id: str,
) -> dict[str, Any]:
    row = connection.execute(
        """SELECT resource_id, alias, status
           FROM master_data_external_identities
           WHERE resource_kind=? AND source_id=? AND external_id=?""",
        (resource_kind, source_id, external_id),
    ).fetchone()
    if row is None or str(row["status"]) != "active":
        raise MasterDataError(
            "master_data_external_identity_missing",
            f"{resource_kind}:{source_id}:{external_id}",
        )
    resource = get_resource(connection, resource_kind, str(row["resource_id"]))
    resource["external_identity"] = {
        "source_id": source_id,
        "external_id": external_id,
        "alias": str(row["alias"] or ""),
    }
    return resource


def resolve_alias(
    connection: sqlite3.Connection,
    *,
    resource_kind: str,
    source_id: str,
    alias: str,
) -> dict[str, Any]:
    normalized = normalize_identity(alias)
    rows = connection.execute(
        """SELECT resource_id FROM master_data_external_identities
           WHERE resource_kind=? AND source_id=? AND normalized_alias=? AND status='active'""",
        (resource_kind, source_id, normalized),
    ).fetchall()
    if len(rows) != 1:
        code = (
            "master_data_alias_missing"
            if not rows
            else "master_data_alias_ambiguous"
        )
        raise MasterDataError(code, f"{resource_kind}:{source_id}:{alias}")
    return get_resource(connection, resource_kind, str(rows[0]["resource_id"]))


def list_locations(connection: sqlite3.Connection) -> list[dict[str, Any]]:
    rows = connection.execute(
        """SELECT location_id, canonical_name, status, attributes_json
           FROM location_catalog WHERE status='active'
           ORDER BY canonical_name, location_id"""
    ).fetchall()
    return [
        {
            "resource_kind": "location",
            "resource_id": str(row["location_id"]),
            "location_id": str(row["location_id"]),
            "canonical_name": str(row["canonical_name"]),
            "status": str(row["status"]),
            "attributes": json.loads(str(row["attributes_json"])),
        }
        for row in rows
    ]


__all__ = [
    "MasterDataError",
    "get_resource",
    "digest_json",
    "list_locations",
    "resolve_alias",
    "resolve_external_identity",
]
