"""Stable read and action facade for generic inventory."""

from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Any

from backend.inventory_core import project_balance

from .contracts import InventoryCommand, InventoryPreview
from .owner import (
    InventoryOwnerError,
    apply_preview,
    apply_preview_in_transaction,
    preview_action,
    preview_action_in_transaction,
    read_action,
    read_action_in_transaction,
)


def _connect(path: Path) -> sqlite3.Connection:
    connection = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys=ON")
    connection.execute("PRAGMA query_only=ON")
    return connection


def list_movements(path: Path, *, limit: int = 100) -> list[dict[str, Any]]:
    with _connect(path) as connection:
        return [
            dict(row)
            for row in connection.execute(
                "SELECT * FROM inventory_movements ORDER BY occurred_at DESC, movement_id DESC LIMIT ?",
                (max(1, min(int(limit), 500)),),
            )
        ]


def get_balance(
    path: Path,
    *,
    product_id: str,
    unit_id: str,
    location_id: str,
) -> dict[str, str]:
    with _connect(path) as connection:
        rows = [dict(row) for row in connection.execute("SELECT * FROM inventory_movements")]
    return {
        "product_id": product_id,
        "unit_id": unit_id,
        "location_id": location_id,
        "quantity": format(project_balance(rows, product_id=product_id, unit_id=unit_id, location_id=location_id), "f"),
    }


__all__ = [
    "InventoryCommand",
    "InventoryOwnerError",
    "InventoryPreview",
    "apply_preview",
    "apply_preview_in_transaction",
    "get_balance",
    "list_movements",
    "project_balance",
    "preview_action",
    "preview_action_in_transaction",
    "read_action",
    "read_action_in_transaction",
]
