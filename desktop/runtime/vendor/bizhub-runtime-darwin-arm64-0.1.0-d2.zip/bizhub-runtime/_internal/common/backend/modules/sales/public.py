"""Stable facade for generic sales actions and reads."""

from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Any

from .contracts import SalesCommand, SalesLine, SalesPreview
from .owner import SalesOwnerError, apply_preview, preview_action


def list_orders(path: Path, *, limit: int = 100) -> list[dict[str, Any]]:
    connection = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA query_only=ON")
    try:
        return [
            dict(row)
            for row in connection.execute(
                "SELECT * FROM sales_orders ORDER BY ordered_at DESC, order_id DESC LIMIT ?",
                (max(1, min(int(limit), 500)),),
            )
        ]
    finally:
        connection.close()


__all__ = [
    "SalesCommand",
    "SalesLine",
    "SalesOwnerError",
    "SalesPreview",
    "apply_preview",
    "list_orders",
    "preview_action",
]
