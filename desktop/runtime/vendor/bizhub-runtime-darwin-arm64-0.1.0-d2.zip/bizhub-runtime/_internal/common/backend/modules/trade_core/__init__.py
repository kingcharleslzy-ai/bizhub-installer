"""Customer-neutral trade lifecycle primitives."""
