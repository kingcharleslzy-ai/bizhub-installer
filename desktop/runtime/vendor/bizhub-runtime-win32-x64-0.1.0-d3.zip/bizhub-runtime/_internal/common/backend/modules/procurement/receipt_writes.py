"""到货认领写入原语：在调用方借出的连接、同一个事务里用裸 SQL 写认领标准表（``receipt_schema``）。

页面、Agent、单据内核都经各自 Owner 走到这里；这里只管"这笔能不能认、认成什么样"，不提交、不开事务。
规则和首家客户生产上一直用的一致：

- 只认已确认、未冲销的入库流水；采购明细和流水的货品、单位必须一致，认领单位也要一致。
- 一条明细和一笔流水之间只有一条认领行：再认一次就是改数量（原行重新确认），不另起一行。
- 一张明细认领累计不超过它的采购数量，一笔流水认领累计不超过它的入库数量（改数量时先把原行自己那份让出来）。
- 撤销只改状态，留下撤销人、撤销时间；已撤销的再撤零写入。

"明细"和"流水"的事实（货品、单位、数量、是否已确认入库）由调用方按自己的表提供。
"""

from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from datetime import UTC, datetime
from decimal import Decimal, InvalidOperation
from typing import Any, Mapping

from backend.modules.trade_core.public import allocation_exceeded

from .receipt_schema import RECEIPT_ALLOCATIONS


class ReceiptWriteError(RuntimeError):
    def __init__(self, code: str, message: str = ""):
        super().__init__(f"{code}: {message}" if message else code)
        self.code = code
        self.message = message


@dataclass(frozen=True)
class LineFacts:
    """被认领的采购明细：货品、单位、采购数量；``receivable`` 为假时拒绝（原因码由调用方给）。"""

    line_id: int
    item_id: int | None
    unit_id: int | None
    quantity: Decimal
    receivable: bool = True
    refusal: str = "procurement_not_receivable"
    # 调用方声明的超收容差：只放宽这张明细自己的上限，累计认领仍不超过 数量 + 容差。
    tolerance: Decimal = Decimal("0")


@dataclass(frozen=True)
class ReceiptFacts:
    """认领的入库流水：货品、单位、入库数量；``confirmed_inbound`` 为假时拒绝。"""

    event_id: int
    item_id: int | None
    unit_id: int | None
    quantity: Decimal
    confirmed_inbound: bool = True


@dataclass(frozen=True)
class Provenance:
    source_kind: str = "management_confirmed"
    source_ref: str = ""
    notes: str = ""
    actor: str = "management"


def _stamp(value: datetime | None = None) -> str:
    # Same text the customer's ORM stores for a naive DateTime.
    return (value or datetime.now(UTC).replace(tzinfo=None)).strftime("%Y-%m-%d %H:%M:%S.%f")


def _positive(value: Any, code: str) -> Decimal:
    try:
        parsed = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise ReceiptWriteError(f"{code}_invalid") from exc
    if not parsed.is_finite() or parsed <= 0:
        raise ReceiptWriteError(f"{code}_must_be_positive")
    return parsed


def _row(connection: sqlite3.Connection, sql: str, params: tuple) -> sqlite3.Row | None:
    connection.row_factory = sqlite3.Row
    return connection.execute(sql, params).fetchone()


def allocated_for_line(connection: sqlite3.Connection, line_id: int) -> Decimal:
    rows = connection.execute(
        f"SELECT allocated_quantity FROM {RECEIPT_ALLOCATIONS} WHERE procurement_id=? AND status='confirmed'",
        (int(line_id),),
    )
    return sum((Decimal(str(row[0])) for row in rows), Decimal("0"))


def allocated_for_receipt(connection: sqlite3.Connection, event_id: int) -> Decimal:
    rows = connection.execute(
        f"SELECT allocated_quantity FROM {RECEIPT_ALLOCATIONS} WHERE receipt_event_id=? AND status='confirmed'",
        (int(event_id),),
    )
    return sum((Decimal(str(row[0])) for row in rows), Decimal("0"))


def allocate(
    connection: sqlite3.Connection,
    *,
    line: LineFacts,
    receipt: ReceiptFacts,
    quantity: Any,
    quantity_unit_id: int,
    provenance: Provenance = Provenance(),
    now: datetime | None = None,
    extra: Mapping[str, Any] | None = None,
) -> tuple[int, str]:
    """把一笔入库流水的一部分认领到一张采购明细。返回 (认领行编号, created / replaced)。

    ``extra`` 是调用方扩展列的取值（如通用小库的文字到货键、流水键）；标准列只由这里决定。"""

    amount = _positive(quantity, "allocated_quantity")
    if not receipt.confirmed_inbound:
        raise ReceiptWriteError("receipt_event_not_confirmed_inbound")
    if not line.receivable:
        raise ReceiptWriteError(line.refusal)
    if line.item_id is None or line.unit_id is None:
        raise ReceiptWriteError("procurement_material_or_unit_missing")
    if int(line.item_id) != int(receipt.item_id or -1):
        raise ReceiptWriteError("procurement_receipt_material_conflict")
    if int(line.unit_id) != int(quantity_unit_id) or int(receipt.unit_id or -1) != int(quantity_unit_id):
        raise ReceiptWriteError("procurement_receipt_unit_conflict")
    line_quantity = _positive(line.quantity, "procurement_quantity")
    receipt_quantity = _positive(receipt.quantity, "receipt_event_quantity")
    existing = _row(
        connection,
        f"SELECT * FROM {RECEIPT_ALLOCATIONS} WHERE procurement_id=? AND receipt_event_id=?",
        (int(line.line_id), int(receipt.event_id)),
    )
    held = Decimal(str(existing["allocated_quantity"])) if existing is not None and existing["status"] == "confirmed" else Decimal("0")
    # 改数量时先把原行自己那份让出来，再看其余认领还剩多少额度。
    if allocation_exceeded(line_quantity + held, allocated_for_line(connection, line.line_id), amount, tolerance=line.tolerance):
        raise ReceiptWriteError("procurement_receipt_overallocated")
    if allocation_exceeded(receipt_quantity + held, allocated_for_receipt(connection, receipt.event_id), amount):
        raise ReceiptWriteError("receipt_event_overallocated")
    stamp = _stamp(now)
    values = {
        "allocated_quantity": format(amount, "f"), "quantity_unit_id": int(quantity_unit_id), "status": "confirmed",
        "source_kind": provenance.source_kind, "source_ref": provenance.source_ref, "notes": provenance.notes,
        "confirmed_by": provenance.actor, "confirmed_at": stamp, "reversed_by": "", "reversed_at": None, **dict(extra or {}),
    }
    if existing is None:
        values = {"procurement_id": int(line.line_id), "receipt_event_id": int(receipt.event_id), **values, "created_at": stamp}
        cursor = connection.execute(
            f"INSERT INTO {RECEIPT_ALLOCATIONS} ({', '.join(values)}) VALUES ({', '.join('?' for _ in values)})",
            tuple(values.values()),
        )
        return int(cursor.lastrowid), "created"
    connection.execute(
        f"UPDATE {RECEIPT_ALLOCATIONS} SET {', '.join(f'{name}=?' for name in values)} WHERE id=?",
        (*values.values(), int(existing["id"])),
    )
    return int(existing["id"]), "replaced"


def reverse(
    connection: sqlite3.Connection,
    allocation_id: int,
    *,
    line_id: int,
    reversed_by: str,
    notes: str = "",
    now: datetime | None = None,
) -> str:
    """撤销一条认领：改状态、留撤销人和时间；已撤销的零写入。返回撤销后的状态。"""

    row = _row(connection, f"SELECT * FROM {RECEIPT_ALLOCATIONS} WHERE id=?", (int(allocation_id),))
    if row is None:
        raise ReceiptWriteError("procurement_receipt_allocation_not_found")
    if int(row["procurement_id"]) != int(line_id):
        raise ReceiptWriteError("procurement_receipt_allocation_owner_conflict")
    if row["status"] == "reversed":
        return "reversed"
    merged = f"{row['notes']}；{notes}".strip("；") if notes else row["notes"]
    connection.execute(
        f"UPDATE {RECEIPT_ALLOCATIONS} SET status='reversed', reversed_by=?, reversed_at=?, notes=? WHERE id=?",
        (str(reversed_by or ""), _stamp(now), merged, int(allocation_id)),
    )
    return "reversed"


__all__ = [
    "LineFacts",
    "Provenance",
    "ReceiptFacts",
    "ReceiptWriteError",
    "allocate",
    "allocated_for_line",
    "allocated_for_receipt",
    "reverse",
]
