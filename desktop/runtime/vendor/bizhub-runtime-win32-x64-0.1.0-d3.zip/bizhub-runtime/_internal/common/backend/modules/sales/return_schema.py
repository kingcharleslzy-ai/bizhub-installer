"""销售退货标准表：退货事件头、关联订单、来源、明细、生命周期事件、待人工判定的来源。

和销售结算标准表同一套做法（``settlement_schema``）：这里是唯一定义，取的是首家客户生产库现在的形状
（数字编号、一个退货事件可挂多张订单、来源只属于一个事件、事件只追加）。客户库里的同名表必须等于
“标准表 + 该客户登记的扩展”，由一致性检查逐项核对；首家客户按克重退货的列登记在它自己的扩展里。

生命周期：客户提出 → 我方同意 → 已寄出 → 已签收待检验 → 已检验 → 已闭合，只进不退
（状态名沿用首家客户的写法，``received_pending_weigh``/``weighed`` 即“待检验/已检验”）。

检验结果：一条退货明细检验后拆成几个去向（好件回可售库存、坏件留存、退回客户），每个去向一行，
记检验数量和已处置数量；去向名沿用首家客户片子退货检验的写法。
"""

from __future__ import annotations

from backend.modules.master_data.schema import (
    Check,
    Column,
    ExpressionCheck,
    ForeignKey,
    Index,
    Table,
    create_table_sql,
)

LIFECYCLE_STATES = ("reported", "accepted", "in_transit", "received_pending_weigh", "weighed", "closed")
PHYSICAL_RETURN_MODES = ("required", "not_required", "mixed", "unknown")
FINANCIAL_ADJUSTMENT_STATUSES = ("pending", "confirmed", "not_applicable")
INVENTORY_RESOLUTION_STATUSES = ("pending", "review_required", "applied", "not_applicable")
INSPECTION_OUTCOMES = ("restocked_saleable", "retained_defective", "returned_to_customer")

CASES = "sales_return_cases"
_PERCENTAGE = "claimed_deduction_percentage IS NULL OR (claimed_deduction_percentage >= 0 AND claimed_deduction_percentage <= 100)"


def _c(name: str, type_: str, *, nullable: bool = False) -> Column:
    return Column(name, type_, nullable)


def _case_fk() -> ForeignKey:
    return ForeignKey("sales_return_case_id", CASES, "id", "CASCADE")


SALES_RETURN_CASES = Table(
    CASES,
    (
        _c("id", "INTEGER"),
        _c("customer_key", "VARCHAR(80)"),
        _c("customer_name", "VARCHAR(240)"),
        _c("po_number", "VARCHAR(120)"),
        _c("shipment_num", "VARCHAR(80)"),
        _c("product_name", "VARCHAR(240)"),
        _c("lifecycle_status", "VARCHAR(40)"),
        _c("physical_return_mode", "VARCHAR(30)"),
        _c("waybill_no", "VARCHAR(120)"),
        _c("claimed_deduction_percentage", "NUMERIC", nullable=True),
        _c("financial_adjustment_status", "VARCHAR(40)"),
        _c("inventory_resolution_status", "VARCHAR(40)"),
        _c("mismatch_note", "TEXT"),
        _c("notes", "TEXT"),
        _c("created_by", "VARCHAR(120)"),
        _c("created_at", "DATETIME"),
        _c("updated_at", "DATETIME"),
    ),
    checks=(
        Check("ck_sales_return_cases_lifecycle", "lifecycle_status", LIFECYCLE_STATES),
        Check("ck_sales_return_cases_physical_mode", "physical_return_mode", PHYSICAL_RETURN_MODES),
        Check("ck_sales_return_cases_financial_status", "financial_adjustment_status", FINANCIAL_ADJUSTMENT_STATUSES),
        Check("ck_sales_return_cases_inventory_resolution", "inventory_resolution_status", INVENTORY_RESOLUTION_STATUSES),
    ),
    expression_checks=(ExpressionCheck("ck_sales_return_cases_deduction_percentage", _PERCENTAGE),),
    indexes=(
        Index("ix_sales_return_cases_customer_status", ("customer_key", "lifecycle_status")),
        Index("ix_sales_return_cases_po_num", ("po_number", "shipment_num")),
        Index("uq_sales_return_case_waybill", ("waybill_no",), unique=True, where="waybill_no <> ''"),
    ),
)

SALES_RETURN_CASE_ORDER_LINKS = Table(
    "sales_return_case_order_links",
    (_c("id", "INTEGER"), _c("sales_return_case_id", "INTEGER"), _c("sales_order_id", "INTEGER"), _c("created_at", "DATETIME")),
    uniques=(("uq_sales_return_case_order_link", ("sales_return_case_id", "sales_order_id")),),
    foreign_keys=(_case_fk(), ForeignKey("sales_order_id", "sales_orders", "id", "RESTRICT")),
    indexes=(Index("ix_sales_return_case_order_links_order", ("sales_order_id",)),),
)

SALES_RETURN_CASE_SOURCES = Table(
    "sales_return_case_sources",
    (
        _c("id", "INTEGER"),
        _c("sales_return_case_id", "INTEGER"),
        _c("source_channel", "VARCHAR(30)"),
        _c("source_id", "VARCHAR(160)"),
        _c("source_item_key", "VARCHAR(160)"),
        _c("source_role", "VARCHAR(60)"),
        _c("evidence_hash", "VARCHAR(64)"),
        _c("payload_json", "TEXT"),
        _c("created_at", "DATETIME"),
    ),
    uniques=(("uq_sales_return_case_source_identity", ("source_channel", "source_id", "source_item_key")),),
    foreign_keys=(_case_fk(),),
    indexes=(Index("ix_sales_return_case_sources_case", ("sales_return_case_id",)),),
)

SALES_RETURN_CASE_ITEMS = Table(
    "sales_return_case_items",
    (
        _c("id", "INTEGER"),
        _c("sales_return_case_id", "INTEGER"),
        _c("item_index", "INTEGER"),
        _c("item_name", "VARCHAR(240)"),
        _c("spec", "VARCHAR(240)"),
        _c("claimed_quantity", "NUMERIC", nullable=True),
        _c("claimed_unit", "VARCHAR(40)"),
        _c("claimed_deduction_percentage", "NUMERIC", nullable=True),
        _c("physical_return_required", "BOOLEAN", nullable=True),
        _c("notes", "TEXT"),
        _c("created_at", "DATETIME"),
        _c("updated_at", "DATETIME"),
    ),
    uniques=(("uq_sales_return_case_item_index", ("sales_return_case_id", "item_index")),),
    expression_checks=(ExpressionCheck("ck_sales_return_case_items_deduction_percentage", _PERCENTAGE),),
    foreign_keys=(_case_fk(),),
    indexes=(Index("ix_sales_return_case_items_case", ("sales_return_case_id",)),),
)

SALES_RETURN_CASE_EVENTS = Table(
    "sales_return_case_events",
    (
        _c("id", "INTEGER"),
        _c("sales_return_case_id", "INTEGER"),
        _c("event_type", "VARCHAR(60)"),
        _c("event_at", "DATETIME"),
        _c("source_channel", "VARCHAR(30)"),
        _c("source_id", "VARCHAR(160)"),
        _c("actor", "VARCHAR(120)"),
        _c("idempotency_key", "VARCHAR(200)"),
        _c("payload_json", "TEXT"),
        _c("created_at", "DATETIME"),
    ),
    uniques=(("uq_sales_return_case_event_key", ("idempotency_key",)),),
    foreign_keys=(_case_fk(),),
    indexes=(Index("ix_sales_return_case_events_case_time", ("sales_return_case_id", "event_at")),),
)

SALES_RETURN_CASE_REVIEWS = Table(
    "sales_return_case_reviews",
    (
        _c("id", "INTEGER"),
        _c("source_channel", "VARCHAR(30)"),
        _c("source_id", "VARCHAR(160)"),
        _c("source_item_key", "VARCHAR(160)"),
        _c("record_type", "VARCHAR(60)"),
        _c("po_number", "VARCHAR(120)"),
        _c("shipment_num", "VARCHAR(80)"),
        _c("reason_code", "VARCHAR(120)"),
        _c("candidate_sales_order_ids_json", "TEXT"),
        _c("payload_json", "TEXT"),
        _c("status", "VARCHAR(20)"),
        _c("resolved_case_id", "INTEGER", nullable=True),
        _c("created_at", "DATETIME"),
        _c("updated_at", "DATETIME"),
    ),
    uniques=(("uq_sales_return_case_review_source", ("source_channel", "source_id", "source_item_key")),),
    checks=(Check("ck_sales_return_case_reviews_status", "status", ("pending", "resolved")),),
    foreign_keys=(ForeignKey("resolved_case_id", CASES, "id", "SET NULL"),),
    indexes=(Index("ix_sales_return_case_reviews_status_updated", ("status", "updated_at")),),
)

SALES_RETURN_CASE_INSPECTION_RESULTS = Table(
    "sales_return_case_inspection_results",
    (
        _c("id", "INTEGER"),
        _c("sales_return_case_item_id", "INTEGER"),
        _c("outcome_kind", "VARCHAR(40)"),
        _c("quantity", "NUMERIC"),
        _c("disposed_quantity", "NUMERIC"),
        _c("notes", "TEXT"),
        _c("created_at", "DATETIME"),
        _c("updated_at", "DATETIME"),
    ),
    uniques=(("uq_sales_return_case_inspection_result", ("sales_return_case_item_id", "outcome_kind")),),
    checks=(Check("ck_sales_return_case_inspection_results_outcome", "outcome_kind", INSPECTION_OUTCOMES),),
    expression_checks=(ExpressionCheck(
        "ck_sales_return_case_inspection_results_quantity",
        "quantity > 0 AND disposed_quantity >= 0 AND disposed_quantity <= quantity",
    ),),
    foreign_keys=(ForeignKey("sales_return_case_item_id", "sales_return_case_items", "id", "CASCADE"),),
)

RETURN_STANDARD_TABLES: tuple[Table, ...] = (
    SALES_RETURN_CASES,
    SALES_RETURN_CASE_ORDER_LINKS,
    SALES_RETURN_CASE_SOURCES,
    SALES_RETURN_CASE_ITEMS,
    SALES_RETURN_CASE_EVENTS,
    SALES_RETURN_CASE_REVIEWS,
    SALES_RETURN_CASE_INSPECTION_RESULTS,
)


def return_schema_sql() -> tuple[str, ...]:
    return tuple(statement for table in RETURN_STANDARD_TABLES for statement in create_table_sql(table))


__all__ = [
    "FINANCIAL_ADJUSTMENT_STATUSES",
    "INSPECTION_OUTCOMES",
    "INVENTORY_RESOLUTION_STATUSES",
    "LIFECYCLE_STATES",
    "PHYSICAL_RETURN_MODES",
    "RETURN_STANDARD_TABLES",
    "return_schema_sql",
]
