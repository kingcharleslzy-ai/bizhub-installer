"""通用库存账：双边流水 ``stock_moves``，一行是一次“从库位 → 到库位”的数量移动。

照 Odoo ``stock.move``（``location_id`` → ``location_dest_id``）与 ERPNext Stock Ledger Entry：

- 库存数 = 截至某日的流水累加，不另存现存量；库位是 ``locations`` 标准表的行。
- 盘点：每个盘点到的库位记一行盘点行（数量 0，``qty_after_move`` = 盘后数量），同 ERPNext
  Stock Reconciliation 的 ``qty_after_transaction``：该库位以最近一次盘点为准，盘点日及以前的流水
  不再计入（盘点后补录的旧单已在实盘里）。同一来源重新盘点时旧盘点行作废、写新行。
- 开账（同 ERPNext Opening Stock、Odoo 期初调整）：一类库存可以从开账日收盘起记账，期初数是从期初库位
  进各库位的期初行（按件、按克重都能记）。开账后读账只认开账日之后的移动和期初行；开账日之前的单据和流水
  原样留着，问开账日之前某天的数照旧读全部历史（只读可查）。开账日之前的历史汇总（批次、结案件、履历、月度）
  可以冻结成一份开账前只读底数，页面读开账前的数读底数、读开账后的数读逐单记的账。
- 读取选项是客户配置（``StockLedgerRules``）：出库扣减顺序（Odoo removal strategy）、负数互抵、
  工序倒冲（ERPNext backflush）、移出以在库为限、按族合并记数。

本模块不认识任何一家客户：物品类别、库位、顺序都由客户规则给出。
"""

from __future__ import annotations

import re
from collections import defaultdict
from collections.abc import Callable, Iterable, Mapping, Sequence
from dataclasses import dataclass, field
from datetime import date
from decimal import ROUND_HALF_EVEN, Decimal
from functools import cached_property
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from sqlalchemy.ext.asyncio import AsyncSession

# (key, 显示名, usage, 计入总数, 可售, 排序)
LocationRow = tuple[str, str, str, bool, bool, int]
# (组, 库位) → (盘点日, 盘后数量)
Anchor = dict[tuple[str, str], tuple[date, int]]

_DEMAND_PREFIX = "sale:"


@dataclass(frozen=True)
class StockLedgerRules:
    """一类物品的库存账规则（客户配置）。"""

    item_kind: str
    locations: tuple[LocationRow, ...]
    # 出库需求库位 → 依次扣减的库位（Odoo removal strategy）；需求行在读取最后按此顺序扣。
    removal_order: Mapping[str, tuple[str, ...]]
    # 累加后为负的库位从这些库位冲抵。
    negative_cover: Mapping[str, tuple[str, ...]] = field(default_factory=dict)
    # 工序链（上游 → 下游）：理论账里下游为负时从上游倒冲（ERPNext backflush）。
    process_chain: tuple[str, ...] = ()
    # 盘点后从这些库位移出、而配对的移入在盘点前，以盘点数为限。
    capped_locations: frozenset[str] = frozenset()
    # 这些库位按族合并记数；``family_of`` 给出规格所属的族（不属于任何族返回 None）。
    pooled_locations: frozenset[str] = frozenset()
    family_of: Callable[[str], str | None] = lambda spec: None
    # 出库需求行的行键；同日结算行的先后（行键 → 次序）。
    demand_line_key: str = "sale"
    line_order: Mapping[str, int] = field(default_factory=dict)
    stocktake_location: str = "stocktake"

    @cached_property
    def stock_locations(self) -> tuple[str, ...]:
        return tuple(row[0] for row in sorted(self.locations, key=lambda row: row[5]) if row[2] != "virtual")

    @cached_property
    def available_locations(self) -> frozenset[str]:
        return frozenset(row[0] for row in self.locations if row[4])

    def group(self, spec: str, location: str) -> str:
        if location in self.pooled_locations:
            return self.family_of(spec) or spec
        return spec


@dataclass(frozen=True)
class StockSourceRule:
    """出库物品从哪个库存物品扣（客户配置）：物品键整体匹配 ``pattern`` 时，自己的库存不够就从 ``source``
    （正则替换得到的物品键）扣，数量、克重照扣。例：``StockSourceRule(r"part:used:(.*)", r"part:new:\\1")``
    表示旧件出自同规格新件。不登记就只按物品自己的键扣。
    """

    pattern: str
    source: str


def stock_source_spec(rules: Iterable[StockSourceRule], spec: str) -> str:
    for rule in rules:
        if re.fullmatch(rule.pattern, spec):
            return re.sub(rule.pattern, rule.source, spec)
    return spec


# 编号物品的无编号池：盘点只记了总数（件数 + 克重）、没逐件记编号的那部分库存。编号物品出库时，编号在
# 编号库存里的照扣；不在的（以及没编号的整件），从按盘点口径（``StockCountBasis``）合在一起的池里按来源先后
# 整件扣，克重按来源平均单件重拆，编号和型号只写在出库行上留痕，不补逐件入库。出库件数超出池的部分是盘盈（只差克重照实重记）：
# 写明原因、经所有者确认一次后从盘点库位记入，不拿假入库单顶替真实收货。哪件出自哪个池由模型和单据定，
# 这里只核件数、克重算得上。


@dataclass(frozen=True)
class StockCountBasis:
    """盘点按哪些身份维度数（客户配置）：``category`` 这类物品盘点时只按 ``dimensions`` 数总数，其余维度
    （大小、型号……）都并进同一个无编号池，出库不论这些维度都从这个池扣。没登记的类别按全部维度数。"""

    category: str
    dimensions: tuple[str, ...] = ()


def pool_identity(bases: Iterable[StockCountBasis], category: str, identity: Mapping[str, Any]) -> tuple[Any, ...]:
    """物品所属的无编号池：类别加盘点口径数的那几个维度的值。"""

    basis = next((basis for basis in bases if basis.category == category), None)
    names = tuple(identity) if basis is None else basis.dimensions
    return (category, *(identity.get(name) for name in names))


@dataclass(frozen=True)
class PoolLot:
    """无编号池的一笔来源（调用方按先后排好）。"""

    ref: str
    count: Decimal
    weight: Decimal


@dataclass(frozen=True)
class PoolDraw:
    """一次从池里扣：扣了几件、多少克（池的账面克重），超出池的盘盈，池里剩下的来源。"""

    count: Decimal
    weight: Decimal
    gain_count: Decimal
    gain_weight: Decimal
    remaining: tuple[PoolLot, ...]

    @property
    def needs_confirmation(self) -> bool:
        """件数超出池才是盘盈、要确认；只差克重（池的克重是盘点估的、单件重是平均拆分）照实重记，不问。"""

        return self.gain_count > 0


POOL_GAIN_REASON = "盘点按总数数、不分型号，部分收回的件没逐件登记编号，出库超出的部分按盘盈记"


def draw_from_pool(lots: Sequence[PoolLot], *, count: Any, weight: Any = None) -> PoolDraw:
    """从池里按来源先后整件扣 ``count`` 件；``weight`` 是出库实重（没称给 None：不算克重盘盈）。

    来源件数不是整数或没克重的不扣（没有可扣的账面克重，不能凭件数重复出库）；部分扣的来源按平均单件重拆，
    四位小数银行家舍入。
    """

    zero, scale = Decimal("0"), Decimal("0.0001")
    requested = Decimal(str(count))
    remaining, drawn_weight, rest = requested, zero, []
    for lot in lots:
        used = min(lot.count, remaining) if requested == requested.to_integral_value() else zero
        allocated = (lot.weight * used / lot.count).quantize(scale, ROUND_HALF_EVEN) if used > 0 else zero
        if (lot.weight <= 0 or lot.count != lot.count.to_integral_value() or allocated <= 0
                or (used < lot.count and allocated >= lot.weight)):
            rest.append(lot)
            continue
        remaining -= used
        drawn_weight += allocated
        if lot.count > used:
            rest.append(PoolLot(lot.ref, lot.count - used, lot.weight - allocated))
    drawn = requested - remaining
    gain_weight = zero if weight is None else Decimal(str(weight)) - drawn_weight
    return PoolDraw(drawn, drawn_weight, remaining, gain_weight, tuple(rest))


@dataclass(frozen=True)
class LedgerMove:
    """库存账的一行（``stock_moves``）；盘点行 ``qty_after`` 不为空。"""

    move_date: date
    spec: str
    from_location: str
    to_location: str
    quantity: int
    source_model: str
    source_id: int
    source_line_key: str
    crystal_id: str | None = None
    source_wechat_message_id: int | None = None
    qty_after: int | None = None
    # 移出与移入的配对键（如外发单）；空时就是来源表+来源号。
    pair_source: tuple[str, int] | None = field(default=None, compare=False)

    @property
    def key(self) -> tuple[str, int, str]:
        return (self.source_model, self.source_id, self.source_line_key)

    @property
    def pair_key(self) -> tuple[str, int]:
        return self.pair_source or (self.source_model, self.source_id)


def move_sort_key(rules: StockLedgerRules, move: LedgerMove) -> tuple[Any, ...]:
    return (
        move.move_date,
        move.from_location in rules.capped_locations,
        move.source_model,
        move.source_id,
        rules.line_order.get(move.source_line_key, 9),
        move.source_line_key,
    )


def stored_move(row: Any) -> LedgerMove:
    return LedgerMove(
        move_date=row.move_date,
        spec=str(row.spec),
        from_location=str(row.from_location),
        to_location=str(row.to_location),
        quantity=int(row.quantity),
        source_model=str(row.source_model),
        source_id=int(row.source_id),
        source_line_key=str(row.source_line_key or ""),
        crystal_id=row.crystal_id,
        source_wechat_message_id=row.source_wechat_message_id,
        qty_after=None if row.qty_after_move is None else int(row.qty_after_move),
    )


async def read_moves(db: AsyncSession, rules: StockLedgerRules, *, start: date, end: date) -> list[LedgerMove]:
    """有效行（作废行由 ORM 默认过滤），含盘点行。"""

    # 客户库的表模型与 ORM：通用产物（单独启动的通用应用）不带它们，只在用到时导入。
    from sqlalchemy import select

    from backend.models.inventory import StockMove

    query = select(StockMove).where(
        StockMove.item_kind == rules.item_kind, StockMove.move_date >= start, StockMove.move_date <= end
    )
    query = opening_window(query, await opening_date(db, rules.item_kind), as_of=end)
    rows = await db.execute(query)
    return [stored_move(row) for row in rows.scalars().all()]


def latest_counts(rules: StockLedgerRules, counts: Iterable[LedgerMove], *, as_of: date) -> Anchor:
    """截至 ``as_of`` 每个（组, 库位）最近一次盘点的盘后数量。"""

    anchor: Anchor = {}
    order: dict[tuple[str, str], tuple[date, int]] = {}
    for move in counts:
        if move.qty_after is None or move.move_date > as_of:
            continue
        key = (rules.group(move.spec, move.to_location), move.to_location)
        rank = (move.move_date, move.source_id)
        if key not in order or rank > order[key]:
            order[key] = rank
            anchor[key] = (move.move_date, int(move.qty_after))
    return anchor


def roll(
    rules: StockLedgerRules,
    moves: Sequence[LedgerMove],
    *,
    as_of: date,
    anchor: Anchor | None = None,
    effects: dict[tuple[str, int, str], int] | None = None,
) -> dict[tuple[str, str], int]:
    """Net balance per (group, location): anchor + later moves through ``as_of``.

    ``moves`` are sorted by ``move_sort_key`` and hold no count rows.  Demand
    moves (``demand_line_key`` out of a ``removal_order`` location) are kept as
    ``sale:<location>`` and drawn at the end by ``resolve``.  A move out of a
    capped location after an anchor, whose paired move in was on or before the
    anchor (or is not recorded), draws on the anchor's count; what exceeds it
    was already counted.  Without an anchor every move counts.  ``effects``
    records the effective quantity of capped moves.
    """

    anchor = anchor or {}
    balances: dict[tuple[str, str], int] = defaultdict(int)
    for key, (_cutoff, quantity) in anchor.items():
        balances[key] += quantity
    sent_on = {move.pair_key: move.move_date for move in moves if move.to_location in rules.capped_locations}
    anchor_pool = {key: quantity for key, (_cutoff, quantity) in anchor.items() if key[1] in rules.capped_locations}
    stock_locations = set(rules.stock_locations)
    for move in moves:
        if move.move_date > as_of:
            break
        demand = move.source_line_key == rules.demand_line_key and move.from_location in rules.removal_order
        quantity = move.quantity
        if move.from_location in rules.capped_locations:
            from_key = (rules.group(move.spec, move.from_location), move.from_location)
            anchored = anchor.get(from_key)
            if anchored is not None and move.move_date > anchored[0]:
                sent = sent_on.get(move.pair_key)
                if sent is None or sent <= anchored[0]:
                    quantity = min(quantity, anchor_pool.get(from_key, 0))
                    anchor_pool[from_key] = anchor_pool.get(from_key, 0) - quantity
                    if effects is not None and quantity != move.quantity:
                        effects[move.key] = quantity
        for location, sign in ((move.from_location, -1), (move.to_location, 1)):
            if location not in stock_locations:
                continue
            key = (rules.group(move.spec, location), location)
            anchored = anchor.get(key)
            if anchored is not None and move.move_date <= anchored[0]:
                continue
            if demand:
                balances[(key[0], _DEMAND_PREFIX + location)] += quantity
            else:
                balances[key] += sign * quantity
    return balances


def net_quantity(balances: Mapping[tuple[str, str], int], group: str, location: str) -> int:
    return int(balances.get((group, location), 0)) - int(balances.get((group, _DEMAND_PREFIX + location), 0))


def external_material_balances(rules: StockLedgerRules, moves: Sequence[LedgerMove], counts: Iterable[LedgerMove],
        *, as_of: date, location: str, loss_locations: frozenset[str]) -> list[dict[str, Any]]:
    """委外整类账：复用盘点锚点和移动的实际扣量，借出/归还按移动方向计入。"""
    anchor = latest_counts(rules, counts, as_of=as_of)
    effects: dict[tuple[str, int, str], int] = {}
    balances = roll(rules, moves, as_of=as_of, anchor=anchor, effects=effects)
    actual = resolve(rules, balances)
    groups = {group for group, place in balances if place == location}
    result = []
    for group in sorted(groups):
        baseline = anchor.get((group, location))
        opening = baseline[1] if baseline else None
        sent = returned = loss = 0
        for move in moves:
            if move.move_date > as_of or (baseline and move.move_date <= baseline[0]):
                continue
            quantity = effects.get(move.key, move.quantity)
            if move.to_location == location and rules.group(move.spec, location) == group:
                if move.from_location == "opening":
                    opening = (opening or 0) + quantity
                else:
                    sent += quantity
            if move.from_location == location and rules.group(move.spec, location) == group:
                if move.to_location in loss_locations:
                    loss += quantity
                else:
                    returned += quantity
        result.append({"item_key": group, "opening_quantity": opening, "opening_attribution": "unknown",
            "sent_quantity": sent, "returned_quantity": returned, "loss_quantity": loss,
            "outstanding_quantity": actual.get((group, location), 0),
            "cutoff_date": baseline[0].isoformat() if baseline else None})
    return result


def theory(
    rules: StockLedgerRules,
    balances: Mapping[tuple[str, str], int],
    backflush: dict[str, int] | None = None,
) -> dict[tuple[str, str], int]:
    """理论账：各库位照实累加，需求只扣本库位，不取非负（用于对账找漏记）。

    工序链下游为负时从前一道工序倒冲（漏记的上游转移）；``backflush`` 按组记倒冲量。
    """

    values = {
        (group, location): net_quantity(balances, group, location)
        for group, location in {(g, l.removeprefix(_DEMAND_PREFIX)) for g, l in balances}
    }
    chain = rules.process_chain
    for group in sorted({group for group, _location in values}):
        for upstream, downstream in reversed(tuple(zip(chain, chain[1:]))):
            shortage = -values.get((group, downstream), 0)
            if shortage > 0:
                values[(group, downstream)] = 0
                values[(group, upstream)] = values.get((group, upstream), 0) - shortage
                if backflush is not None:
                    backflush[group] = backflush.get(group, 0) + shortage
    return values


def resolve(
    rules: StockLedgerRules,
    balances: Mapping[tuple[str, str], int],
    trace: list[tuple[str, str, str, int]] | None = None,
) -> dict[tuple[str, str], int]:
    """Cover negative locations (``negative_cover``), floor at zero, then draw
    demand location by location in ``removal_order``.

    ``trace`` receives (group, location, step, amount) for every cover, floor
    and demand draw, so an audit can itemize the difference to the plain sum.
    """

    def note(group: str, location: str, step: str, amount: int) -> None:
        if trace is not None and amount:
            trace.append((group, location, step, amount))

    resolved = {key: value for key, value in balances.items() if not key[1].startswith(_DEMAND_PREFIX)}
    groups = sorted({group for group, _location in balances})
    for group in groups:
        for location in rules.stock_locations:
            shortage = -int(resolved.get((group, location), 0))
            if shortage <= 0:
                continue
            for other in rules.negative_cover.get(location, ()):
                available = max(0, int(resolved.get((group, other), 0)))
                taken = min(available, shortage)
                resolved[(group, other)] = available - taken
                note(group, other, f"cover:{location}", -taken)
                note(group, location, f"cover:{location}", taken)
                shortage -= taken
            resolved[(group, location)] = -shortage
    for key, value in list(resolved.items()):
        if value < 0:
            note(key[0], key[1], "floor", -value)
            resolved[key] = 0
    for group in groups:
        for demand, locations in rules.removal_order.items():
            remaining = int(balances.get((group, _DEMAND_PREFIX + demand), 0))
            for location in locations:
                if remaining <= 0:
                    break
                available = int(resolved.get((group, location), 0))
                taken = min(available, remaining)
                resolved[(group, location)] = available - taken
                note(group, location, f"draw:{demand}", -taken)
                remaining -= taken
            note(group, demand, "undrawn", remaining)
    return resolved


# ---------------------------------------------------------------------------
# 出库超过库存（只读检查，只出提醒，不改账）
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class OutboundStockRule:
    """出库超过库存的企业参数。

    出到 ``destinations``（客户等对方库位）的移动就是要查的出库，不论来自哪种单据；可用库位是
    ``StockLedgerRules`` 里标“可售”的库位，按 ``group`` 合并记数（族合并的库位全族共用）。
    ``enabled`` 关掉就不查；``severity`` 是报出的严重程度。
    """

    destinations: frozenset[str]
    severity: str = "critical"
    enabled: bool = True


@dataclass(frozen=True)
class OutboundCheck:
    """一次出库：出库前的可用数与缺口（缺口为 0 就是够）；``counted_by`` 是起算的那次盘点的盘点行。

    盘点日及以前的出库已含在盘点数里，不再查：``available`` 为 None。
    """

    move: LedgerMove
    available: int | None
    shortage: int
    counted_by: LedgerMove | None


def outbound_checks(
    rules: StockLedgerRules,
    rule: OutboundStockRule,
    moves: Sequence[LedgerMove],
    counts: Iterable[LedgerMove],
    *,
    as_of: date,
) -> list[OutboundCheck]:
    """逐个物品回放可用库存，给出每次出库当时可用多少、缺多少。

    起点是可用库位最近一次盘点的盘后数（没盘过从 ``moves`` 的第一行起，开账后期初行就是起点）；
    之后流入可用库位的加上，别的流出扣到 0 为止，要查的出库不够时记缺口、余额归 0。同日先记
    其他移动、后记出库。``moves`` 按 ``move_sort_key`` 排好、不含盘点行。
    """

    if not rule.enabled:
        return []
    available = rules.available_locations
    counts = list(counts)
    found: list[OutboundCheck] = []
    for spec in sorted({move.spec for move in moves if move.to_location in rule.destinations}):
        keys = {(rules.group(spec, location), location) for location in available}
        scoped = [
            move for move in counts
            if move.move_date <= as_of and (rules.group(move.spec, move.to_location), move.to_location) in keys
        ]
        anchor = latest_counts(rules, scoped, as_of=as_of)
        counted_by = max(scoped, key=lambda move: (move.move_date, move.source_id), default=None)
        since = counted_by.move_date if counted_by is not None else None
        balance = sum(quantity for _cutoff, quantity in anchor.values())
        events = []
        for move in moves:
            if move.move_date > as_of:
                continue
            inflow = (rules.group(move.spec, move.to_location), move.to_location) in keys
            outflow = (rules.group(move.spec, move.from_location), move.from_location) in keys
            checked = outflow and not inflow and move.spec == spec and move.to_location in rule.destinations
            if since is not None and move.move_date <= since:
                if checked:
                    found.append(OutboundCheck(move, None, 0, counted_by))
            elif inflow != outflow:
                events.append((move.move_date, checked, move.source_id, inflow, move))
        for _day, checked, _source_id, inflow, move in sorted(events, key=lambda item: item[:3]):
            if inflow:
                balance += move.quantity
            elif not checked:
                balance = max(0, balance - move.quantity)
            else:
                shortage = max(0, move.quantity - balance)
                found.append(OutboundCheck(move, balance, shortage, counted_by))
                balance = max(0, balance - move.quantity)
    return found


# ---------------------------------------------------------------------------
# 写入：盘点行（单据移动由单据内核的台账端口写；库位行由客户的库位 Owner 先写好）
# ---------------------------------------------------------------------------


def count_rows(
    rules: StockLedgerRules, *, source_model: str, source_id: int, counts: Mapping[tuple[str, str], tuple[date, int]]
) -> list[LedgerMove]:
    """一次盘点的盘点行：``counts`` 是（规格或族, 库位）→（盘点日, 盘后数量）。"""

    return sorted(
        (
            LedgerMove(
                move_date=cutoff, spec=spec, from_location=rules.stocktake_location, to_location=location,
                quantity=0, source_model=source_model, source_id=int(source_id),
                source_line_key=f"{spec}:{location}"[:120], qty_after=int(quantity),
            )
            for (spec, location), (cutoff, quantity) in counts.items()
        ),
        key=lambda move: move.source_line_key,
    )


async def post_counts(
    db: AsyncSession, rules: StockLedgerRules, *, source_model: str, source_ids: Iterable[int], rows: Sequence[LedgerMove]
) -> dict[str, int]:
    """把 ``source_ids`` 这几次盘点的盘点行改成 ``rows``：内容不变的不动，其余旧行作废、写新行。"""

    from sqlalchemy import select, update

    from backend.models.inventory import StockMove
    from backend.timeutils import utc_now

    ids = sorted({int(value) for value in source_ids})
    existing = {
        (row.source_id, row.source_line_key): row
        for row in (
            await db.execute(
                select(StockMove).where(
                    StockMove.item_kind == rules.item_kind,
                    StockMove.source_model == source_model,
                    StockMove.source_id.in_(ids),
                )
            )
        ).scalars()
    } if ids else {}
    wanted = {(move.source_id, move.source_line_key): move for move in rows}
    stale = [
        row.id for key, row in existing.items()
        if key not in wanted or stored_move(row) != wanted[key]
    ]
    if stale:
        await db.execute(
            update(StockMove)
            .where(StockMove.id.in_(stale))
            .values(is_cancelled=True, cancelled_at=utc_now())
            .execution_options(synchronize_session="fetch")
        )
        await db.flush()
    inserted = [move for key, move in wanted.items() if key not in existing or existing[key].id in stale]
    db.add_all(
        StockMove(
            move_date=move.move_date, item_kind=rules.item_kind, spec=move.spec,
            from_location=move.from_location, to_location=move.to_location, quantity=0,
            qty_after_move=move.qty_after, source_model=move.source_model, source_id=move.source_id,
            source_line_key=move.source_line_key,
        )
        for move in inserted
    )
    await db.flush()
    return {"cancelled": len(stale), "inserted": len(inserted), "unchanged": len(wanted) - len(inserted)}


# ---------------------------------------------------------------------------
# 单据过账的移动行：按量台账端口记账、作废都经这里落行
# ---------------------------------------------------------------------------


async def insert_stock_moves(db: AsyncSession, rows: Sequence[Mapping[str, Any]]) -> list[int]:
    """写入一批移动行（每行是一组列值），返回行号。"""

    from backend.models.inventory import StockMove

    moves = [StockMove(**row) for row in rows]
    db.add_all(moves)
    await db.flush()
    return [int(move.id) for move in moves]


async def cancel_stock_moves(db: AsyncSession, move_ids: Sequence[int], *, version: int) -> int:
    """作废移动行：只打作废标记并记下是哪个单据版本作废的；已作废的不动。"""

    from sqlalchemy import update

    from backend.models.inventory import StockMove
    from backend.timeutils import utc_now

    if not move_ids:
        return 0
    result = await db.execute(
        update(StockMove)
        .where(StockMove.id.in_([int(value) for value in move_ids]), StockMove.is_cancelled.is_(False))
        .values(is_cancelled=True, cancelled_at=utc_now(), cancelled_by_version=int(version))
        .execution_options(synchronize_session="fetch")
    )
    return int(result.rowcount or 0)


# ---------------------------------------------------------------------------
# 开账：期初行与开账后的读账范围
# ---------------------------------------------------------------------------

OPENING_SOURCE = "opening_balance"


@dataclass(frozen=True)
class OpeningLine:
    """一行期初：某物品在某库位的期初数。按重量记的类别 ``quantity`` 记 1、``weight_g`` 记克重。"""

    item_key: str
    location: str
    quantity: int
    weight_g: Any = None
    party_id: int | None = None


async def opening_date(db: AsyncSession, item_kind: str) -> date | None:
    """这类库存的开账日；没有有效期初行就是没开账（读账照旧读全部历史）。"""

    from sqlalchemy import func, select

    from backend.models.inventory import StockMove

    return await db.scalar(
        select(func.max(StockMove.move_date)).where(
            StockMove.item_kind == item_kind, StockMove.source_model == OPENING_SOURCE
        )
    )


def opening_window(query: Any, opening: date | None, *, as_of: date | None = None) -> Any:
    """给读 ``stock_moves`` 的查询加开账范围：开账后只认开账日之后的移动和期初行。

    问开账日之前的日子（``as_of`` 早于开账日）不加：读全部历史，期初行日期在后面本来就读不到。
    """

    if opening is None or (as_of is not None and as_of < opening):
        return query
    from sqlalchemy import or_

    from backend.models.inventory import StockMove

    return query.where(or_(StockMove.move_date > opening, StockMove.source_model == OPENING_SOURCE))


def _opening_line_key(line: OpeningLine) -> str:
    import hashlib

    text = f"{line.location}:{line.item_key}"
    return text if len(text) <= 120 else hashlib.sha256(text.encode("utf-8")).hexdigest()[:24]


async def post_opening(
    db: AsyncSession, *, item_kind: str, day: date, opening_location: str, lines: Sequence[OpeningLine]
) -> dict[str, int]:
    """把这类库存的期初行改成 ``lines``（日期 ``day``）：内容不变的不动，其余旧期初行作废、写新行。"""

    from sqlalchemy import select, update

    from backend.models.inventory import StockMove
    from backend.timeutils import utc_now

    def shape(move_date: date, spec: str, location: str, quantity: int, weight: Any, party: int | None) -> tuple:
        from decimal import Decimal

        return (move_date, spec, location, int(quantity), None if weight is None else Decimal(str(weight)), party)

    existing = {
        row.source_line_key: row
        for row in (
            await db.execute(
                select(StockMove).where(StockMove.item_kind == item_kind, StockMove.source_model == OPENING_SOURCE)
            )
        ).scalars()
    }
    wanted = {_opening_line_key(line): line for line in lines}
    if len(wanted) != len(lines):
        raise ValueError("opening_line_duplicated")
    stale = [
        row.id for key, row in existing.items()
        if key not in wanted or shape(row.move_date, row.spec, row.to_location, row.quantity, row.weight_g, row.party_id)
        != shape(day, wanted[key].item_key, wanted[key].location, wanted[key].quantity, wanted[key].weight_g,
                 wanted[key].party_id)
    ]
    if stale:
        await db.execute(
            update(StockMove)
            .where(StockMove.id.in_(stale))
            .values(is_cancelled=True, cancelled_at=utc_now())
            .execution_options(synchronize_session="fetch")
        )
        await db.flush()
    inserted = [(key, line) for key, line in wanted.items() if key not in existing or existing[key].id in stale]
    db.add_all(
        StockMove(
            move_date=day, item_kind=item_kind, spec=line.item_key, from_location=opening_location,
            to_location=line.location, quantity=int(line.quantity), weight_g=line.weight_g, party_id=line.party_id,
            source_model=OPENING_SOURCE, source_id=int(day.strftime("%Y%m%d")), source_line_key=key,
        )
        for key, line in inserted
    )
    await db.flush()
    return {"cancelled": len(stale), "inserted": len(inserted), "unchanged": len(wanted) - len(inserted)}


# 开账前只读底数：开账日之前的历史汇总（批次的投入与结案、结案件、器具履历、月度数字……）冻结成一份，
# 存在开账旁边（``stock_opening_histories``，一类库存一行）。页面读开账日之前的数读这份底数，读开账日之后的数
# 读逐单记的账；开账日之前的单据和流水原样留着，照常能查，只是不再参与计算。底数里放什么由客户的读账规则决定
# （本模块只管存取，不解读内容）；写入走客户的决策包（预览 → 执行 → 回读），取开账那天系统给出的数。


@dataclass(frozen=True)
class OpeningHistory:
    day: date
    pack_version: str
    payload: Mapping[str, Any]
    sha256: str


def opening_history_digest(payload: Mapping[str, Any]) -> str:
    import hashlib
    import json

    text = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


async def opening_history(db: AsyncSession, item_kind: str) -> OpeningHistory | None:
    """这类库存的开账前只读底数；没存过是 None。"""

    import json

    from sqlalchemy import select

    from backend.models.inventory import StockOpeningHistory

    row = await db.scalar(select(StockOpeningHistory).where(StockOpeningHistory.item_kind == item_kind))
    if row is None:
        return None
    return OpeningHistory(day=row.opening_date, pack_version=row.pack_version,
                          payload=json.loads(row.payload_json), sha256=row.payload_sha256)


async def post_opening_history(
    db: AsyncSession, *, item_kind: str, day: date, pack_version: str, payload: Mapping[str, Any]
) -> str:
    """把这类库存的开账前只读底数存成 ``payload``（须能原样存成 JSON）：内容和开账日都不变就不动（unchanged），
    否则写入（inserted）或换掉旧的（replaced）。"""

    import json

    from sqlalchemy import select

    from backend.models.inventory import StockOpeningHistory

    digest = opening_history_digest(payload)
    row = await db.scalar(select(StockOpeningHistory).where(StockOpeningHistory.item_kind == item_kind))
    if row is not None and row.payload_sha256 == digest and row.opening_date == day:
        return "unchanged"
    text = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    if row is None:
        db.add(StockOpeningHistory(item_kind=item_kind, opening_date=day, pack_version=pack_version,
                                   payload_json=text, payload_sha256=digest))
        outcome = "inserted"
    else:
        row.opening_date, row.pack_version, row.payload_json, row.payload_sha256 = day, pack_version, text, digest
        outcome = "replaced"
    await db.flush()
    return outcome


# ---------------------------------------------------------------------------
# 委外加工按重量记账（料账）
# ---------------------------------------------------------------------------
#
# 投入 ＝ 本次发出 ＋ 加工方手里上批的余料 ＝ 回库 ＋ 本次留下的余料 ＋ 损耗。
# 一批委外在途记在它自己的批次库位：外发把件和料转进去；回库结算时
# - 同编号的件从批次库位转回在库，新件从外来库位转进在库；
# - 本次留下的余料留在批次库位，下一批外发时转过去；
# - 其余投入（加工掉的、损耗）转到加工消耗库位。
# 回库写的投入多出批次里的料时，多出的是加工方手里上批的余料（企业参数“结转余料”），按来源顺序转进本批。
# 企业参数：要不要结转余料、能不能分次结算（没回来的件留在批次里，只结算回来的部分）、闭合容差。

# (物品类别, 物品键, 库位) → (件数, 克重)；按重量记的类别件数记 0。
ProcessingHoldings = Mapping[tuple[str, str, str], tuple[Any, Any]]


@dataclass(frozen=True)
class ProcessingRule:
    """一家企业的委外加工料账参数。"""

    carry_residual: bool = True
    partial_settlement: bool = False
    closure_tolerance_g: Any = 0


@dataclass(frozen=True)
class ProcessingSites:
    """料账用到的库位：在库、外来（加工产出的新件、余料）、加工消耗（加工掉的投入与损耗）。"""

    stock: str
    external: str
    consumed: str


@dataclass(frozen=True)
class ProcessingMove:
    item_kind: str
    item_key: str
    from_location: str
    to_location: str
    count: Any
    weight_g: Any


@dataclass(frozen=True)
class ProcessingSettlement:
    """一次回库结算：移动，以及闭合式两边（投入 ＝ 批次里结算的 ＋ 转进来的上批余料）。"""

    moves: tuple[ProcessingMove, ...]
    input_g: Any
    carried_g: Any
    output_g: Any
    difference_g: Any
    closed: bool
    # 分次结算时没回来、留在批次里的件：(类别, 物品键, 件数, 克重)。
    staying: tuple[tuple[str, str, Any, Any], ...]


def carry_residual(
    holdings: ProcessingHoldings, *, residual: tuple[str, str], sources: Sequence[str], target: str, weight: Any
) -> list[ProcessingMove]:
    """把余料从来源库位（按顺序）转进 ``target``，最多 ``weight`` 克；来源不够就转多少算多少。"""

    from decimal import Decimal

    moves, rest = [], Decimal(str(weight))
    for source in sources:
        available = Decimal(str(holdings.get((*residual, source), (0, 0))[1] or 0))
        amount = min(available, rest)
        if source == target or amount <= 0:
            continue
        moves.append(ProcessingMove(*residual, source, target, Decimal("0"), amount))
        rest -= amount
        if rest <= 0:
            break
    return moves


def settle_processing(
    rule: ProcessingRule,
    holdings: ProcessingHoldings,
    *,
    batch: str,
    sites: ProcessingSites,
    counted_kind: str,
    residual: tuple[str, str],
    returned: Sequence[tuple[str, str, Any, Any]],
    retained_g: Any = None,
    loss_g: Any = 0,
    declared_input_g: Any = None,
    carry_from: Sequence[str] = (),
) -> ProcessingSettlement:
    """结算一批委外加工：``returned`` 是回库明细 (类别, 物品键, 件数, 克重)，``retained_g`` 本次留在加工方的余料，
    ``declared_input_g`` 回库单写的投入（没写为 None：按批次里全部结算，不结转）。"""

    from decimal import Decimal

    zero = Decimal("0")
    tolerance = Decimal(str(rule.closure_tolerance_g or 0))

    def near(left: Decimal, right: Decimal) -> bool:
        return abs(left - right) <= tolerance

    cells: dict[tuple[str, str], list[Decimal]] = {
        (kind, key): [Decimal(str(count or 0)), Decimal(str(weight or 0))]
        for (kind, key, location), (count, weight) in holdings.items()
        if location == batch and (count or weight)
    }
    declared = None if declared_input_g is None else Decimal(str(declared_input_g))
    total = sum((weight for _count, weight in cells.values()), zero)
    returned_keys = {(kind, key) for kind, key, _count, _weight in returned}
    unreturned = [(kind, key, count, weight) for (kind, key), (count, weight) in cells.items()
                  if kind == counted_kind and count > 0 and (kind, key) not in returned_keys]
    staying: tuple[tuple[str, str, Decimal, Decimal], ...] = ()
    base = total
    retained = None if retained_g is None else Decimal(str(retained_g))
    left_over = sum((weight for *_head, weight in unreturned), zero)
    if declared is not None:
        # 分次结算：写的投入正好是批次里除去没回来的件那部分。
        partial = not near(declared, total) and near(declared, total - left_over)
    else:
        # 没写投入：回来的（连同损耗、留存）不够整批，就是只回了一部分。
        covered = (sum((Decimal(str(weight or 0)) for *_head, weight in returned), zero)
                   + Decimal(str(loss_g or 0)) + (retained or zero))
        partial = covered < total - tolerance
        if partial and retained is None:
            # 余料没有加工掉的凭据，照旧留在加工方。
            retained = cells.get(residual, [zero, zero])[1]
    if rule.partial_settlement and unreturned and partial:
        staying, base = tuple(unreturned), total - left_over
    moves: list[ProcessingMove] = []
    carried = zero
    if rule.carry_residual and declared is not None and declared - base > tolerance:
        moves = carry_residual(holdings, residual=residual, sources=carry_from, target=batch, weight=declared - base)
        carried = sum((move.weight_g for move in moves), zero)
        cells.setdefault(residual, [zero, zero])[1] += carried
    target = {(kind, key): (count, weight) for kind, key, count, weight in staying}
    if retained:
        target[residual] = (zero, retained)
    leaving = {item: [count - target.get(item, (zero, zero))[0], weight - target.get(item, (zero, zero))[1]]
               for item, (count, weight) in cells.items()}
    for item in target:
        leaving.setdefault(item, [-target[item][0], -target[item][1]])
    for kind, key, count, weight in returned:
        count, weight = Decimal(str(count or 0)), Decimal(str(weight or 0))
        out = leaving.get((kind, key))
        if kind == counted_kind:
            take = max(zero, min(count, out[0])) if out else zero
            if take > 0:
                per_piece = cells[(kind, key)][1] / cells[(kind, key)][0]
                moves.append(ProcessingMove(kind, key, batch, sites.stock, take, per_piece * take))
                out[0] -= take
                out[1] -= per_piece * take
            if count > take:
                moves.append(ProcessingMove(kind, key, sites.external, sites.stock, count - take,
                                            weight * (count - take) / count))
            continue
        take = max(zero, min(weight, out[1])) if out else zero
        if take > 0:
            moves.append(ProcessingMove(kind, key, batch, sites.stock, zero, take))
            out[1] -= take
        if weight > take:
            moves.append(ProcessingMove(kind, key, sites.external, sites.stock, zero, weight - take))
    for (kind, key), (count, weight) in sorted(leaving.items()):
        if count > 0 or (kind != counted_kind and weight > 0):
            moves.append(ProcessingMove(kind, key, batch, sites.consumed, max(count, zero), weight))
        elif weight < 0:
            # 留下的余料多于批次里的余料：多出的是这次加工产出的。
            moves.append(ProcessingMove(kind, key, sites.external, batch, zero, -weight))
    input_weight = base + carried
    output = (sum((Decimal(str(weight or 0)) for *_head, weight in returned), zero) + (retained or zero)
              + Decimal(str(loss_g or 0)))
    return ProcessingSettlement(
        moves=tuple(moves), input_g=input_weight, carried_g=carried, output_g=output,
        difference_g=input_weight - output, closed=near(input_weight, output), staying=staying,
    )


__all__ = [
    "Anchor",
    "LedgerMove",
    "POOL_GAIN_REASON",
    "PoolDraw",
    "PoolLot",
    "StockCountBasis",
    "draw_from_pool",
    "pool_identity",
    "StockSourceRule",
    "stock_source_spec",
    "OPENING_SOURCE",
    "OpeningHistory",
    "OpeningLine",
    "OutboundCheck",
    "OutboundStockRule",
    "ProcessingHoldings",
    "ProcessingMove",
    "ProcessingRule",
    "ProcessingSettlement",
    "ProcessingSites",
    "StockLedgerRules",
    "carry_residual",
    "count_rows",
    "external_material_balances",
    "latest_counts",
    "move_sort_key",
    "net_quantity",
    "opening_date",
    "opening_history",
    "opening_history_digest",
    "opening_window",
    "outbound_checks",
    "post_counts",
    "post_opening",
    "post_opening_history",
    "read_moves",
    "resolve",
    "roll",
    "settle_processing",
    "stored_move",
    "theory",
]
