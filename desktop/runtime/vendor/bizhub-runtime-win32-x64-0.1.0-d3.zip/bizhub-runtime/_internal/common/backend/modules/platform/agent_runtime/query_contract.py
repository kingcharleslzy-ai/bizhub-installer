"""Customer-neutral query policy contributed by an enabled role's module.

These trusted build-time providers select knowledge and restricted read tools.
They do not grant authorization or own a task loop, database, or business writer.
The Host still authorizes every invocation under the shared execution budget.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Awaitable, Callable


@dataclass(frozen=True)
class QueryKnowledge:
    prompt_text: str
    knowledge_text: str
    fingerprint: str


@dataclass(frozen=True)
class AgentQueryPolicy:
    agent_name: str
    load_knowledge: Callable[[], QueryKnowledge]
    build_planner_prompt: Callable[..., str]
    execute_tool: Callable[..., Awaitable[tuple[dict[str, Any], int]]]
    run_data_tools: Callable[..., Awaitable[dict[str, Any]]]
    search_knowledge: Callable[..., list[dict[str, str]]]
    has_formal_evidence: Callable[[dict[str, Any]], bool]
    tool_definitions: tuple[dict[str, Any], ...]
    # Called at Host assembly with the enabled modules and the Registry being
    # installed (not yet queryable through get_runtime_registry).
    bind_modules: Callable[[frozenset[str], Any], AgentQueryPolicy] | None = None
    # Zero-argument loader of the deployment's ``QuestionUnderstandingPolicy``;
    # absent, the platform question understanding answers its own routes only.
    question_understanding: Callable[[], Any] | None = None
    # Zero-argument loader of the deployment's director ``RetrievalPolicy``
    # (knowledge documents, extra code-search roots, whitelist queries).
    retrieval: Callable[[], Any] | None = None
    # The ``DirectorPolicy`` this policy was built from (platform director tools).
    director: Any = None
