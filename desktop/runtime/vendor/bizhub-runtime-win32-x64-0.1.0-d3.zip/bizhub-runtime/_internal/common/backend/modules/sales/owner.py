"""Single writer for customer-neutral sales orders, shipments, and returns."""

from __future__ import annotations

from backend.kernel.profile_registry import StorageTarget, read_storage, storage_connect, write_storage

import json
import sqlite3
import uuid
from datetime import UTC, date, datetime
from decimal import Decimal
from pathlib import Path
from typing import Any, Iterable

from backend.modules.inventory.public import (
    InventoryCommand,
    InventoryPreview,
    apply_preview_in_transaction as apply_inventory_in_transaction,
    preview_action_in_transaction as preview_inventory_in_transaction,
    read_action_in_transaction as read_inventory_in_transaction,
)
from backend.modules.master_data.public import MasterDataError, get_resource, is_master_data_ref
from backend.modules.trade_core.public import (
    business_datetime,
    check_decimal_range,
    decimal_sum as _decimal_sum,
    TradeRuleError,
    aggregate_order_progress,
    digest_json,
    normalized_evidence_refs,
    project_order_progress,
    quantity_decimal,
)

from . import fulfillment_writes
from .order_writes import SalesRecordWriter
from . import return_writes as returns
from .contracts import SalesCommand, SalesPreview, SalesReturnCommand, SalesReturnPreview


# Reversal state and physical writes remain under this original transaction Owner.
from backend.modules.trade_core.public import (
    TradeReversalCommand, TradeReversalPreview, apply_reversal as _apply_trade_reversal,
    preview_reversal as _preview_trade_reversal, reversal_documents as _reversal_documents,
)


MODULE_ID = "sales"
OWNER_REF = f"{MODULE_ID}:order-owner"
REQUIRED_MODULES = {
    MODULE_ID,
    "trade_core",
    "master_data",
    "inventory",
    "procurement",
}


# From v22 the order, line and fulfillment tables are the sales standard tables plus this database's extension columns
# (generic_kernel.migrations). These projections keep the text-keyed row shape its commands, previews, readbacks and
# generations are built on; writes go to the physical tables. The customer lives on the lines (standard), so the order
# row reads it back from them.
ORDER_ROWS = ("(SELECT b.id, b.order_id, (SELECT MIN(l.customer_party_id) FROM sales_orders l WHERE l.batch_id=b.id) AS customer_party_id,"
              " b.ordered_at, b.status, b.revision, b.evidence_refs_json, b.source_ref, b.created_at, b.updated_at FROM sales_batches b)")
LINE_ROWS = ("(SELECT l.line_id, b.order_id, l.product_id, l.quantity_unit_id AS unit_id, l.quantity_num AS quantity,"
             " l.fulfilled_quantity, l.returned_quantity, l.ship_from_location_id FROM sales_orders l JOIN sales_batches b ON b.id=l.batch_id)")
FULFILLMENT_ROWS = ("(SELECT fulfillment_id, fulfillment_kind, order_id, line_id, quantity, inventory_action_id, inventory_movement_id,"
                    " occurred_at, evidence_refs_json FROM sales_fulfillments)")
_ROWS = {"sales_orders": ORDER_ROWS, "sales_order_lines": LINE_ROWS, "sales_fulfillments": FULFILLMENT_ROWS}
# Allocations and return links join the line back to its order key (alias ``o`` keeps ``o.order_id`` in the queries).
_LINE_ORDER_JOIN = "JOIN sales_orders ln ON ln.id=a.sales_order_id JOIN sales_batches o ON o.id=ln.batch_id"
# 两张标准表的物理写入只经这一个写入程序（与客户销售单据 Owner 同一个）。
_HEADER_WRITER = SalesRecordWriter("header")
_LINE_WRITER = SalesRecordWriter("line")


class SalesOwnerError(RuntimeError):
    def __init__(self, code: str, message: str):
        super().__init__(f"{code}: {message}")
        self.code = code
        self.message = message


def _check_decimal_range(value: Decimal, code: str) -> Decimal:
    try:
        return check_decimal_range(value, code)
    except TradeRuleError as exc:
        raise SalesOwnerError(code, "supports at most 18 integer digits and 4 fractional digits") from exc


def _sales_quantity(value: object, *, allow_zero: bool = False) -> Decimal:
    return _check_decimal_range(
        quantity_decimal(value, allow_zero=allow_zero), "sales_quantity_out_of_range",
    )


def _require_module_enabled(enabled_module_ids: Iterable[str] | None) -> set[str]:
    if enabled_module_ids is None:
        from backend.generic_kernel.profile import get_generic_registry

        enabled_module_ids = [
            str(item["module_id"])
            for item in get_generic_registry().payload.get("modules", [])
        ]
    enabled = set(enabled_module_ids)
    missing = sorted(REQUIRED_MODULES - enabled)
    if MODULE_ID not in enabled:
        raise SalesOwnerError("sales_module_disabled", f"{MODULE_ID} is not enabled")
    if missing:
        raise SalesOwnerError("sales_dependency_missing", ",".join(missing))
    return enabled


def _connect(path: Path, *, readonly: bool) -> sqlite3.Connection:
    connection = storage_connect(f"file:{path}?mode=ro" if readonly else path, uri=readonly)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys=ON")
    connection.execute("PRAGMA busy_timeout=10000")
    if readonly:
        connection.execute("PRAGMA query_only=ON")
    return connection


def _reading(storage: StorageTarget):
    return read_storage(storage, lambda path: _connect(path, readonly=True))


def _writing(storage: StorageTarget):
    return write_storage(storage, lambda path: _connect(path, readonly=False))


def _table_rows(connection: sqlite3.Connection, table: str, key: str) -> list[dict[str, Any]]:
    return [dict(row) for row in connection.execute(f"SELECT * FROM {_ROWS.get(table, table)} ORDER BY {key}")]


def _state_generation(connection: sqlite3.Connection) -> str:
    return digest_json({
        "orders": _table_rows(connection, "sales_orders", "order_id"),
        "lines": _table_rows(connection, "sales_order_lines", "line_id"),
        "fulfillments": _table_rows(connection, "sales_fulfillments", "fulfillment_id"),
        "actions": _table_rows(connection, "sales_action_receipts", "action_id"),
    })


def _order(connection: sqlite3.Connection, order_id: str) -> dict[str, Any] | None:
    row = connection.execute(
        f"SELECT * FROM {ORDER_ROWS} WHERE order_id=?", (order_id,)
    ).fetchone()
    return dict(row) if row else None


def _lines(connection: sqlite3.Connection, order_id: str) -> list[dict[str, Any]]:
    return [
        dict(row)
        for row in connection.execute(
            f"SELECT * FROM {LINE_ROWS} WHERE order_id=? ORDER BY line_id",
            (order_id,),
        )
    ]


def _require_goods_order(lines: list[dict[str, Any]]) -> None:
    # Only service contracts can have a line without a shipping location.
    if any(line["ship_from_location_id"] is None for line in lines):
        raise SalesOwnerError("sales_service_action_required", "服务合同请通过服务签收入口办理")


def _fulfillments(connection: sqlite3.Connection, order_id: str) -> list[dict[str, Any]]:
    return [dict(row) for row in connection.execute(
        f"SELECT * FROM {FULFILLMENT_ROWS} WHERE order_id=? ORDER BY fulfillment_id", (order_id,))]


def _line_target(connection: sqlite3.Connection, order_id: str) -> int:
    """The standard allocation and return-link target is a line; this database's order-keyed commands resolve to the
    order's only line (a generic order with several lines cannot be allocated as a whole)."""
    ids = [int(row[0]) for row in connection.execute(
        "SELECT l.id FROM sales_orders l JOIN sales_batches b ON b.id=l.batch_id WHERE b.order_id=? ORDER BY l.seq_no, l.id", (order_id,))]
    if len(ids) != 1:
        raise SalesOwnerError("sales_order_line_target_ambiguous", f"{order_id}：该订单有 {len(ids)} 行明细，整单分摊只支持单行订单")
    return ids[0]


def _business_date(ordered_at: str) -> str:
    return business_datetime(ordered_at).date().isoformat()


def _header_pk(connection: sqlite3.Connection, order_id: str) -> int:
    row = connection.execute("SELECT id FROM sales_batches WHERE order_id=?", (order_id,)).fetchone()
    if row is None:
        raise SalesOwnerError("sales_order_not_found", order_id)
    return int(row[0])


def _line_pk(connection: sqlite3.Connection, line_id: str) -> int:
    row = connection.execute("SELECT id FROM sales_orders WHERE line_id=?", (line_id,)).fetchone()
    if row is None:
        raise SalesOwnerError("sales_line_not_found", line_id)
    return int(row[0])


def materialize(connection: sqlite3.Connection, order_id: str, *, now: str, **columns: Any) -> None:
    """The one place this Owner writes an existing order header's columns (status, revision, header facts)."""
    _HEADER_WRITER.materialize(connection, _header_pk(connection, order_id), {**columns, "updated_at": now})


def _write_lines(connection: sqlite3.Connection, order_id: str, customer_party_id: int, business_date: str,
                 lines: Iterable[dict[str, Any]], now: str, *, keep: set[str] = frozenset()) -> None:
    """Insert the planned lines (or update those in ``keep`` in place: return items reference their line key). Standard columns the generic order does not carry get their neutral values; the item name is the
    product's; the customer is the order's."""
    batch_id = _header_pk(connection, order_id)
    for seq_no, line in enumerate(lines, start=1):
        product = connection.execute("SELECT canonical_name FROM products WHERE id=?", (line["product_id"],)).fetchone()
        values = {"seq_no": seq_no, "customer_party_id": customer_party_id, "product_id": line["product_id"],
                  "product_name": product[0] if product else None, "quantity_num": line["quantity"], "quantity_unit_id": line["unit_id"],
                  "business_date": business_date, "ship_from_location_id": line["ship_from_location_id"]}
        if line["line_id"] in keep:
            _LINE_WRITER.materialize(connection, _line_pk(connection, line["line_id"]), values)
        else:
            _LINE_WRITER.materialize(connection, None, {**values, "batch_id": batch_id, "created_at": now, "line_id": line["line_id"],
                                                        "fulfilled_quantity": line["fulfilled_quantity"], "returned_quantity": line["returned_quantity"]})


def _validate_command(command: SalesCommand) -> tuple[str, ...]:
    if command.action not in {"create", "fulfill", "return", "cancel", "revise"}:
        raise SalesOwnerError("sales_action_invalid", command.action)
    if not isinstance(command.idempotency_key, str):
        raise SalesOwnerError("sales_idempotency_key_invalid", "use a string")
    if not command.idempotency_key.strip():
        raise SalesOwnerError("sales_idempotency_key_required", "idempotency key is required")
    for field in ("ordered_at", "occurred_at"):
        value = getattr(command, field)
        if value:
            try:
                business_datetime(value)
            except TradeRuleError as exc:
                raise SalesOwnerError("sales_" + field + "_invalid", "use an ISO date or timestamp with timezone") from exc
    if not command.order_id.strip():
        raise SalesOwnerError("sales_order_id_required", "order id is required")
    if not command.source_ref.strip():
        raise SalesOwnerError("sales_source_ref_required", "source ref is required")
    try:
        return normalized_evidence_refs(command.evidence_refs)
    except TradeRuleError as exc:
        raise SalesOwnerError(str(exc), "evidence refs are invalid") from exc


def _validated_lines(
    connection: sqlite3.Connection,
    command: SalesCommand,
) -> tuple[dict[str, Any], ...]:
    if not command.lines:
        raise SalesOwnerError("sales_lines_required", "at least one line is required")
    if len({item.line_id for item in command.lines}) != len(command.lines):
        raise SalesOwnerError("sales_line_id_duplicate", command.order_id)
    planned: list[dict[str, Any]] = []
    for item in command.lines:
        if not all((item.line_id.strip(), is_master_data_ref(item.product_id), is_master_data_ref(item.unit_id), item.ship_from_location_id.strip())):
            raise SalesOwnerError("sales_line_identity_required", item.line_id)
        try:
            get_resource(connection, "product", item.product_id)
            get_resource(connection, "unit", item.unit_id)
            get_resource(connection, "location", item.ship_from_location_id)
            quantity = _sales_quantity(item.quantity)
        except (MasterDataError, TradeRuleError) as exc:
            raise SalesOwnerError(getattr(exc, "code", str(exc)), item.line_id) from exc
        planned.append({
            "line_id": item.line_id,
            "product_id": item.product_id,
            "unit_id": item.unit_id,
            "quantity": format(quantity, "f"),
            "fulfilled_quantity": "0",
            "returned_quantity": "0",
            "ship_from_location_id": item.ship_from_location_id,
        })
    return tuple(planned)


def _fulfillment_id(command: SalesCommand) -> str:
    return f"sls-{digest_json(command.to_dict())[:24]}"


def _project_order_status(lines: list[dict[str, Any]]) -> str:
    states = [
        project_order_progress(
            ordered_quantity=item["quantity"],
            completed_quantity=item["fulfilled_quantity"],
            returned_quantity=item["returned_quantity"],
        )
        for item in lines
    ]
    value = aggregate_order_progress(states)
    return {"completed": "fulfilled", "partial": "partially_fulfilled"}.get(value, value)



def _plan_line_effect(
    connection: sqlite3.Connection,
    command: SalesCommand | SalesReturnCommand,
    order: dict[str, Any],
    lines: list[dict[str, Any]],
    target: dict[str, Any],
    quantity: Decimal,
    stock_quantity: Decimal,
    *,
    enabled: Iterable[str],
    inventory_key: str | None = None,
) -> dict[str, Any]:
    if order["status"] == "cancelled":
        raise SalesOwnerError("sales_order_cancelled", command.order_id)
    fulfilled = _sales_quantity(target["fulfilled_quantity"], allow_zero=True)
    returned = _sales_quantity(target["returned_quantity"], allow_zero=True)
    outbound = command.action == "fulfill"
    limit = _decimal_sum((_sales_quantity(target["quantity"]), fulfilled.copy_negate())) if outbound else _decimal_sum((fulfilled, returned.copy_negate()))
    if quantity > limit:
        code = "sales_fulfillment_exceeds_remaining" if outbound else "sales_return_exceeds_fulfilled"
        raise SalesOwnerError(code, str(target["line_id"]))
    if not command.occurred_at.strip():
        raise SalesOwnerError("sales_occurred_at_required", command.order_id)
    inventory = None
    if stock_quantity > 0:
        inventory = preview_inventory_in_transaction(
            connection,
            InventoryCommand(
                action="outbound" if outbound else "inbound",
                idempotency_key=inventory_key or f"sales:{command.idempotency_key}",
                product_id=int(target["product_id"]),
                unit_id=int(target["unit_id"]),
                quantity=format(stock_quantity, "f"),
                from_location_id=str(target["ship_from_location_id"]) if outbound else None,
                to_location_id=str(target["ship_from_location_id"]) if not outbound else None,
                occurred_at=command.occurred_at,
                source_ref=command.source_ref,
                reason=command.reason,
            ),
            enabled_module_ids=enabled,
        ).to_dict()
    field = "fulfilled_quantity" if outbound else "returned_quantity"
    updated = [dict(item) for item in lines]
    for item in updated:
        if item["line_id"] == target["line_id"]:
            item[field] = format(_decimal_sum((Decimal(str(item[field])), quantity)), "f")
    return {
        "order_id": command.order_id,
        "line_id": target["line_id"],
        "quantity": format(quantity, "f"),
        "field": field,
        "order_status": _project_order_status(updated),
        "inventory_preview": inventory,
    }


def _apply_line_effect(connection: sqlite3.Connection, effect: dict[str, Any], now: str) -> None:
    # 已发 / 已退累计列只经发货写入原语改（8.3b 前收口：通用 Owner 不再裸写标准表列）。
    fulfillment_writes.accumulate_line_quantity(
        connection, line_where=("line_id", effect["line_id"]), field=effect["field"], quantity=effect["quantity"],
    )
    materialize(connection, effect["order_id"], now=now, status=effect["order_status"])


def _preview_on_connection(
    connection: sqlite3.Connection,
    command: SalesCommand,
    *,
    enabled_module_ids: Iterable[str] | None,
) -> SalesPreview:
    enabled = _require_module_enabled(enabled_module_ids)
    evidence_refs = _validate_command(command)
    generation = _state_generation(connection)
    existing = _order(connection, command.order_id)
    planned_lines: tuple[dict[str, Any], ...] = ()
    planned_fulfillment: dict[str, Any] | None = None
    inventory_preview: dict[str, Any] | None = None

    if command.action == "create":
        if existing is not None:
            raise SalesOwnerError("sales_order_already_exists", command.order_id)
        if not is_master_data_ref(command.customer_party_id) or not command.ordered_at.strip():
            raise SalesOwnerError("sales_order_identity_required", command.order_id)
        try:
            get_resource(connection, "party", command.customer_party_id)
        except MasterDataError as exc:
            raise SalesOwnerError(exc.code, exc.message) from exc
        planned_lines = _validated_lines(connection, command)
        planned_order = {
            "order_id": command.order_id,
            "customer_party_id": command.customer_party_id,
            "ordered_at": command.ordered_at,
            "status": "open",
            "revision": 1,
            "evidence_refs_json": json.dumps(evidence_refs, ensure_ascii=False),
            "source_ref": command.source_ref,
        }
    else:
        if existing is None:
            raise SalesOwnerError("sales_order_not_found", command.order_id)
        current_lines = _lines(connection, command.order_id)
        _require_goods_order(current_lines)
        planned_order = dict(existing)
        if command.action in {"fulfill", "return"}:
            if existing["status"] == "cancelled":
                raise SalesOwnerError("sales_order_cancelled", command.order_id)
            target = next((item for item in current_lines if item["line_id"] == command.target_line_id), None)
            if target is None:
                raise SalesOwnerError("sales_line_not_found", command.target_line_id)
            try:
                quantity = _sales_quantity(command.quantity)
            except TradeRuleError as exc:
                raise SalesOwnerError(str(exc), command.quantity) from exc
            effect = _plan_line_effect(
                connection, command, existing, current_lines, target, quantity,
                quantity, enabled=enabled,
            )
            inventory_preview = effect["inventory_preview"]
            planned_fulfillment = {
                "fulfillment_id": _fulfillment_id(command),
                "fulfillment_kind": "shipment" if command.action == "fulfill" else "return",
                "order_id": command.order_id,
                "line_id": command.target_line_id,
                "quantity": format(quantity, "f"),
                "occurred_at": command.occurred_at,
                "evidence_refs_json": json.dumps(evidence_refs, ensure_ascii=False),
            }
            planned_order["status"] = effect["order_status"]
        elif command.action == "cancel":
            if existing["status"] == "cancelled":
                raise SalesOwnerError("sales_order_already_cancelled", command.order_id)
            if any(Decimal(str(item["fulfilled_quantity"])) > 0 for item in current_lines):
                raise SalesOwnerError("sales_fulfilled_order_not_cancellable", command.order_id)
            if not command.reason.strip():
                raise SalesOwnerError("sales_cancellation_reason_required", command.order_id)
            planned_order["status"] = "cancelled"
        else:
            if any(Decimal(str(item["fulfilled_quantity"])) > 0 for item in current_lines):
                raise SalesOwnerError("sales_fulfilled_order_not_revisable", command.order_id)
            if not command.reason.strip() or not is_master_data_ref(command.customer_party_id) or not command.ordered_at.strip():
                raise SalesOwnerError("sales_revision_fields_required", command.order_id)
            try:
                get_resource(connection, "party", command.customer_party_id)
            except MasterDataError as exc:
                raise SalesOwnerError(exc.code, exc.message) from exc
            planned_lines = _validated_lines(connection, command)
            planned_order.update({
                "customer_party_id": command.customer_party_id,
                "ordered_at": command.ordered_at,
                "status": "open",
                "revision": int(existing["revision"]) + 1,
                "evidence_refs_json": json.dumps(evidence_refs, ensure_ascii=False),
                "source_ref": command.source_ref,
            })
    content = {
        "command": command.to_dict(),
        "state_generation": generation,
        "planned_order": planned_order,
        "planned_lines": list(planned_lines),
        "planned_fulfillment": planned_fulfillment,
        "inventory_preview": inventory_preview,
    }
    return SalesPreview(
        command=command,
        state_generation=generation,
        planned_order=planned_order,
        planned_lines=planned_lines,
        planned_fulfillment=planned_fulfillment,
        inventory_preview=inventory_preview,
        preview_digest=digest_json(content),
    )


def preview_action(
    storage: StorageTarget,
    command: SalesCommand,
    *,
    enabled_module_ids: Iterable[str] | None = None,
) -> SalesPreview:
    _require_module_enabled(enabled_module_ids)
    with _reading(storage) as connection:
        return _preview_on_connection(connection, command, enabled_module_ids=enabled_module_ids)


def read_action(
    storage: StorageTarget,
    idempotency_key: str,
    *,
    enabled_module_ids: Iterable[str] | None = None,
) -> dict[str, Any]:
    """Read one applied action by its idempotency key, without writing."""

    _require_module_enabled(enabled_module_ids)
    with _reading(storage) as connection:
        row = connection.execute(
            "SELECT action_id FROM sales_action_receipts WHERE idempotency_key=?",
            (idempotency_key,),
        ).fetchone()
        if row is None:
            raise SalesOwnerError("sales_readback_missing", idempotency_key)
        return _readback(connection, str(row["action_id"]))


def read_order(
    storage: StorageTarget,
    order_id: str,
    *,
    enabled_module_ids: Iterable[str] | None = None,
) -> dict[str, Any]:
    """Read one order with its lines and fulfillments, without writing."""

    _require_module_enabled(enabled_module_ids)
    with _reading(storage) as connection:
        order = _order(connection, order_id)
        if order is None:
            raise SalesOwnerError("sales_order_not_found", order_id)
        lines = _lines(connection, order_id)
        _require_goods_order(lines)
        return {
            "schema_version": "bizhub.sales-order-read.v1",
            "order": order,
            "lines": lines,
            "fulfillments": _fulfillments(connection, order_id),
        }


def _readback(connection: sqlite3.Connection, action_id: str) -> dict[str, Any]:
    receipt = connection.execute(
        "SELECT * FROM sales_action_receipts WHERE action_id=?", (action_id,)
    ).fetchone()
    if receipt is None:
        raise SalesOwnerError("sales_readback_missing", action_id)
    order_id = str(receipt["order_id"])
    inventory = None
    if receipt["inventory_action_id"]:
        inventory = read_inventory_in_transaction(connection, str(receipt["inventory_action_id"]))
    audit = connection.execute(
        "SELECT * FROM sales_audit_events WHERE event_id=?",
        (receipt["audit_event_id"],),
    ).fetchone()
    return {
        "schema_version": "bizhub.sales-readback.v1",
        "owner_ref": OWNER_REF,
        "action_id": action_id,
        "idempotency_key": str(receipt["idempotency_key"]),
        "command_digest": str(receipt["command_digest"]),
        "preview_digest": str(receipt["preview_digest"]),
        "order": _order(connection, order_id),
        "lines": _lines(connection, order_id),
        "fulfillments": _fulfillments(connection, order_id),
        "inventory": inventory,
        "audit_event": dict(audit) if audit else None,
        "state_generation": _state_generation(connection),
    }


def apply_preview_in_transaction(connection: sqlite3.Connection, preview: SalesPreview, *, enabled_module_ids: Iterable[str] | None = None) -> dict[str, Any]:
    if not connection.in_transaction:
        raise SalesOwnerError("sales_transaction_required", "an outer transaction is required")
    enabled = _require_module_enabled(enabled_module_ids)
    if digest_json(preview.content()) != preview.preview_digest:
        raise SalesOwnerError("sales_preview_content_drift", "preview digest differs")
    try:
        existing = connection.execute(
            "SELECT action_id, command_digest FROM sales_action_receipts WHERE idempotency_key=?",
            (preview.command.idempotency_key,),
        ).fetchone()
        if existing is not None:
            if str(existing["command_digest"]) != preview.command.command_digest:
                raise SalesOwnerError("sales_idempotency_conflict", preview.command.idempotency_key)
            result = _readback(connection, str(existing["action_id"]))
            result["disposition"] = "idempotent_noop"
            return result
        if _state_generation(connection) != preview.state_generation:
            raise SalesOwnerError("sales_state_generation_drift", "sales changed")
        authoritative = _preview_on_connection(
            connection,
            preview.command,
            enabled_module_ids=enabled,
        )
        if authoritative.preview_digest != preview.preview_digest:
            raise SalesOwnerError("sales_preview_content_drift", "authoritative plan differs")
        inventory_result = None
        if authoritative.inventory_preview:
            inventory_result = apply_inventory_in_transaction(
                connection,
                InventoryPreview.from_dict(authoritative.inventory_preview),
                enabled_module_ids=enabled,
            )
        now = datetime.now(UTC).isoformat()
        order = authoritative.planned_order
        if preview.command.action == "create":
            _HEADER_WRITER.materialize(connection, None, {
                "order_id": order["order_id"], "ordered_at": order["ordered_at"], "business_date": _business_date(order["ordered_at"]),
                "status": order["status"], "revision": order["revision"], "evidence_refs_json": order["evidence_refs_json"],
                "source_ref": order["source_ref"], "created_at": now, "updated_at": now,
            })
            _write_lines(connection, preview.command.order_id, order["customer_party_id"], _business_date(order["ordered_at"]),
                         authoritative.planned_lines, now)
        elif preview.command.action in {"fulfill", "return"}:
            movement_ids = [item["movement_id"] for item in (inventory_result or {}).get("movements", [])]
            fulfillment = authoritative.planned_fulfillment or {}
            line = connection.execute("SELECT id, quantity_unit_id FROM sales_orders WHERE line_id=?", (fulfillment["line_id"],)).fetchone()
            movement = connection.execute("SELECT id FROM material_inventory_events WHERE movement_id=?",
                                          (movement_ids[0] if movement_ids else None,)).fetchone()
            try:
                fulfillment_writes.record_fulfillment(
                    connection, sales_order_id=int(line["id"]), kind=fulfillment["fulfillment_kind"], quantity=fulfillment["quantity"],
                    quantity_unit_id=line["quantity_unit_id"], event_id=None if movement is None else int(movement["id"]),
                    business_date=_business_date(fulfillment["occurred_at"]),
                    provenance=fulfillment_writes.Provenance("generic_fulfillment", (inventory_result or {}).get("action_id") or ""),
                    now=datetime.fromisoformat(now),
                    extra={key: fulfillment[key] for key in ("fulfillment_id", "order_id", "line_id", "occurred_at", "evidence_refs_json")}
                    | {"inventory_action_id": (inventory_result or {}).get("action_id"),
                       "inventory_movement_id": movement_ids[0] if movement_ids else None})
            except fulfillment_writes.FulfillmentWriteError as exc:
                raise SalesOwnerError(exc.code, exc.message) from exc
            _apply_line_effect(connection, {
                "order_id": preview.command.order_id,
                "line_id": fulfillment["line_id"],
                "quantity": fulfillment["quantity"],
                "field": "fulfilled_quantity" if preview.command.action == "fulfill" else "returned_quantity",
                "order_status": order["status"],
            }, now)
        elif preview.command.action == "cancel":
            materialize(connection, preview.command.order_id, now=now, status="cancelled")
        else:
            materialize(connection, preview.command.order_id, now=now, business_date=_business_date(order["ordered_at"]),
                        **{key: order[key] for key in ("ordered_at", "status", "revision", "evidence_refs_json", "source_ref")})
            # Revisions update lines in place: return items reference the line key, so surviving identities keep
            # their row, and unreferenced lines may be added or removed.
            planned_ids = {line["line_id"] for line in authoritative.planned_lines}
            kept_ids = {str(row["line_id"]) for row in _lines(connection, preview.command.order_id)}
            for line_id in kept_ids - planned_ids:
                _LINE_WRITER.delete(connection, _line_pk(connection, line_id))
            _write_lines(connection, preview.command.order_id, order["customer_party_id"], _business_date(order["ordered_at"]),
                         authoritative.planned_lines, now, keep=kept_ids & planned_ids)
        action_id = uuid.uuid4().hex
        audit_event_id = uuid.uuid4().hex
        record_audit_event(connection, audit_event_id, f"sales_{preview.command.action}_applied",
                           json.dumps(authoritative.to_dict(), ensure_ascii=False, sort_keys=True, separators=(",", ":")), now)
        connection.execute(
            """INSERT INTO sales_action_receipts
               (action_id, idempotency_key, command_digest, preview_digest, order_id,
                audit_event_id, inventory_action_id, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                action_id, preview.command.idempotency_key, preview.command.command_digest,
                preview.preview_digest, preview.command.order_id, audit_event_id,
                (inventory_result or {}).get("action_id"), now,
            ),
        )
        result = _readback(connection, action_id)
    except sqlite3.IntegrityError as exc:
        raise SalesOwnerError("sales_write_conflict", str(exc)) from exc
    result["disposition"] = "applied"
    return result


def apply_preview(storage: StorageTarget, preview: SalesPreview, *, enabled_module_ids: Iterable[str] | None = None) -> dict[str, Any]:
    _require_module_enabled(enabled_module_ids)
    with _writing(storage) as connection:
        return apply_preview_in_transaction(connection, preview, enabled_module_ids=enabled_module_ids)



# Return cases live in the sales return standard tables (``return_schema``); this small database adds the
# text case key its API uses and the order line/unit of each item. Good units restock, scrap is kept.
_RETURN_TABLES = (
    "sales_return_cases", "sales_return_case_order_links", "sales_return_case_items",
    "sales_return_case_inspection_results", "sales_return_case_events",
)
_GOOD, _SCRAP = "restocked_saleable", "retained_defective"
_RETURN_EVENT = {"register": "accepted", "inspect": "weighed", "dispose": "disposed"}


def _return_generation(connection: sqlite3.Connection) -> str:
    return digest_json({
        "sales": _state_generation(connection),
        **{table: _table_rows(connection, table, "id") for table in _RETURN_TABLES},
        "receipts": _table_rows(connection, "sales_document_action_receipts", "action_id"),
    })


def _return_case(connection: sqlite3.Connection, case_id: str) -> dict[str, Any]:
    row = connection.execute(
        """SELECT c.*, o.order_id FROM sales_return_cases c
           JOIN sales_return_case_order_links k ON k.sales_return_case_id=c.id
           JOIN sales_orders ln ON ln.id=k.sales_order_id JOIN sales_batches o ON o.id=ln.batch_id WHERE c.case_id=?""",
        (case_id,),
    ).fetchone()
    if row is None:
        raise SalesOwnerError("sales_return_case_not_found", case_id)
    return dict(row)


def _return_items(connection: sqlite3.Connection, case_pk: int) -> list[dict[str, Any]]:
    """Each item in the command's terms: received = good + scrap from its inspection results."""
    items = []
    for row in connection.execute(
        """SELECT i.*, c.case_id FROM sales_return_case_items i JOIN sales_return_cases c ON c.id=i.sales_return_case_id
           WHERE c.id=? ORDER BY i.item_index""", (case_pk,)
    ):
        results = returns.inspection_results(connection, int(row["id"]))
        good, scrap = results.get(_GOOD, {}), results.get(_SCRAP, {})

        def amount(result: dict[str, Any], key: str) -> Decimal:
            return Decimal(str(result.get(key, 0)))

        items.append({
            "item_id": row["id"], "case_id": row["case_id"], "order_line_id": row["order_line_id"], "unit_id": row["unit_id"],
            "quantity": format(Decimal(str(row["claimed_quantity"])), "f"),
            "received_quantity": format(_decimal_sum((amount(good, "quantity"), amount(scrap, "quantity"))), "f"),
            "good_quantity": format(amount(good, "quantity"), "f"),
            "scrap_quantity": format(amount(scrap, "quantity"), "f"),
            "disposed_good_quantity": format(amount(good, "disposed_quantity"), "f"),
            "disposed_scrap_quantity": format(amount(scrap, "disposed_quantity"), "f"),
        })
    return items


def _preview_return_on_connection(
    connection: sqlite3.Connection,
    command: SalesReturnCommand,
    *,
    enabled_module_ids: Iterable[str] | None,
) -> SalesReturnPreview:
    enabled = _require_module_enabled(enabled_module_ids)
    if command.action not in {"register", "inspect", "dispose"}:
        raise SalesOwnerError("sales_return_action_invalid", command.action)
    try:
        business_datetime(command.occurred_at)
    except TradeRuleError as exc:
        raise SalesOwnerError("sales_occurred_at_invalid", "use an ISO date or timestamp with timezone") from exc
    if not all((command.idempotency_key.strip(), command.order_id.strip(), command.source_ref.strip(), command.occurred_at.strip())):
        raise SalesOwnerError("sales_return_identity_required", command.order_id)
    try:
        normalized_evidence_refs(command.evidence_refs)
    except TradeRuleError as exc:
        raise SalesOwnerError(str(exc), "evidence refs are invalid") from exc
    if not command.items or len({item.order_line_id for item in command.items}) != len(command.items):
        raise SalesOwnerError("sales_return_items_invalid", "nonempty unique lines required")
    case_id = command.case_id or f"src-{digest_json({'key': command.idempotency_key})[:24]}"
    order = _order(connection, command.order_id)
    if order is None:
        raise SalesOwnerError("sales_order_not_found", command.order_id)
    if order["status"] == "cancelled":
        raise SalesOwnerError("sales_order_cancelled", command.order_id)
    lines = _lines(connection, command.order_id)
    _require_goods_order(lines)
    if command.action == "register":
        if connection.execute("SELECT 1 FROM sales_return_cases WHERE case_id=?", (case_id,)).fetchone():
            raise SalesOwnerError("sales_return_case_already_exists", case_id)
        customer = connection.execute(
            "SELECT canonical_name FROM business_parties WHERE id=?", (order["customer_party_id"],)
        ).fetchone()
        case = {
            "case_id": case_id, "order_id": command.order_id, "customer_key": str(order["customer_party_id"]),
            "customer_name": customer[0] if customer else "", "lifecycle_status": "accepted",
            "physical_return_mode": "required", "financial_adjustment_status": "not_applicable",
            "inventory_resolution_status": "pending", "notes": command.reason,
        }
        current_items: list[dict[str, Any]] = []
    else:
        if not command.case_id.strip():
            raise SalesOwnerError("sales_return_case_id_required", "stage requires case ID")
        stored = _return_case(connection, case_id)
        if stored["order_id"] != command.order_id:
            raise SalesOwnerError("sales_return_order_mismatch", case_id)
        if stored["lifecycle_status"] != ("accepted" if command.action == "inspect" else "weighed"):
            raise SalesOwnerError("sales_return_state_invalid", str(stored["lifecycle_status"]))
        case = {key: stored[key] for key in (
            "case_id", "order_id", "customer_key", "customer_name", "lifecycle_status", "physical_return_mode",
            "financial_adjustment_status", "inventory_resolution_status", "notes",
        )}
        current_items = [{key: value for key, value in item.items() if key != "item_id"} for item in _return_items(connection, int(stored["id"]))]
        if command.action == "inspect" and {item.order_line_id for item in command.items} != {item["order_line_id"] for item in current_items}:
            raise SalesOwnerError("sales_return_inspection_incomplete", case_id)
    planned = {item["order_line_id"]: dict(item) for item in current_items}
    effects = []
    for item in command.items:
        target = next((line for line in lines if line["line_id"] == item.order_line_id), None)
        if target is None:
            raise SalesOwnerError("sales_line_not_found", item.order_line_id)
        if target["unit_id"] != item.unit_id:
            raise SalesOwnerError("sales_return_unit_mismatch", item.order_line_id)
        try:
            quantity = _sales_quantity(item.quantity, allow_zero=command.action != "register")
            good = _sales_quantity(item.good_quantity, allow_zero=True)
            scrap = _sales_quantity(item.scrap_quantity, allow_zero=True)
        except TradeRuleError as exc:
            raise SalesOwnerError(str(exc), item.order_line_id) from exc
        remaining = _decimal_sum((_sales_quantity(target["fulfilled_quantity"], allow_zero=True), _sales_quantity(target["returned_quantity"], allow_zero=True).copy_negate()))
        disposition_quantity = _decimal_sum((good, scrap))
        if command.action == "register":
            if good or scrap:
                raise SalesOwnerError("sales_return_stage_fields_invalid", item.order_line_id)
            if quantity > remaining:
                raise SalesOwnerError("sales_return_exceeds_fulfilled", item.order_line_id)
            planned[item.order_line_id] = {
                "case_id": case_id, "order_line_id": item.order_line_id, "unit_id": item.unit_id,
                "quantity": format(quantity, "f"), "received_quantity": "0",
                "good_quantity": "0", "scrap_quantity": "0",
                "disposed_good_quantity": "0", "disposed_scrap_quantity": "0",
            }
        else:
            if item.order_line_id not in planned:
                raise SalesOwnerError("sales_return_case_line_mismatch", item.order_line_id)
            row = planned[item.order_line_id]
            if command.action == "inspect":
                if quantity > Decimal(str(row["quantity"])) or quantity > remaining:
                    raise SalesOwnerError("sales_return_inspection_exceeds_quantity", item.order_line_id)
                if disposition_quantity != quantity:
                    raise SalesOwnerError("sales_return_inspection_not_closed", item.order_line_id)
                if not command.reason.strip():
                    raise SalesOwnerError("sales_return_inspection_reason_required", case_id)
                row.update(received_quantity=format(quantity, "f"), good_quantity=format(good, "f"), scrap_quantity=format(scrap, "f"))
            else:
                if quantity or disposition_quantity <= 0:
                    raise SalesOwnerError("sales_return_disposition_quantity_invalid", item.order_line_id)
                if (_decimal_sum((good, Decimal(str(row["disposed_good_quantity"])))) > Decimal(str(row["good_quantity"]))
                        or _decimal_sum((scrap, Decimal(str(row["disposed_scrap_quantity"])))) > Decimal(str(row["scrap_quantity"]))):
                    raise SalesOwnerError("sales_return_disposition_exceeds_inspection", item.order_line_id)
                effect = _plan_line_effect(
                    connection, command, order, lines, target, disposition_quantity, good, enabled=enabled,
                    inventory_key="sales-document:" + digest_json({"key": command.idempotency_key, "line": item.order_line_id}),
                )
                effects.append(effect)
                # Subsequent line projections include preceding effects of this same command.
                target["returned_quantity"] = format(_decimal_sum((Decimal(str(target["returned_quantity"])), good, scrap)), "f")
                row["disposed_good_quantity"] = format(_decimal_sum((Decimal(str(row["disposed_good_quantity"])), good)), "f")
                row["disposed_scrap_quantity"] = format(_decimal_sum((Decimal(str(row["disposed_scrap_quantity"])), scrap)), "f")
    case["lifecycle_status"] = returns.advanced_state(case["lifecycle_status"], _RETURN_EVENT[command.action])
    if command.action != "register" and all(
        _decimal_sum((Decimal(str(row["disposed_good_quantity"])), Decimal(str(row["disposed_scrap_quantity"])))) == Decimal(str(row["received_quantity"]))
        for row in planned.values()
    ):
        case["inventory_resolution_status"] = "applied"
        if not returns.close_blockers(case):
            case["lifecycle_status"] = returns.advanced_state(case["lifecycle_status"], "closed")
    content = {
        "command": command.to_dict(), "state_generation": _return_generation(connection),
        "planned_case": case, "planned_items": [planned[key] for key in sorted(planned)], "effects": effects,
    }
    return SalesReturnPreview(
        command, content["state_generation"], case, tuple(content["planned_items"]), tuple(effects), digest_json(content)
    )


def preview_return_action(storage: StorageTarget, command: SalesReturnCommand, *, enabled_module_ids: Iterable[str] | None = None) -> SalesReturnPreview:
    _require_module_enabled(enabled_module_ids)
    with _reading(storage) as connection:
        return _preview_return_on_connection(connection, command, enabled_module_ids=enabled_module_ids)


def _return_readback(connection: sqlite3.Connection, case_id: str) -> dict[str, Any]:
    case = _return_case(connection, case_id)
    events = []
    for row in connection.execute("SELECT * FROM sales_return_case_events WHERE sales_return_case_id=? ORDER BY id", (case["id"],)):
        event = dict(row)
        event["payload"] = json.loads(event.pop("payload_json"))
        event["inventory"] = [read_inventory_in_transaction(connection, action_id) for action_id in event["payload"]["inventory_action_ids"]]
        events.append(event)
    return {
        "schema_version": "bizhub.sales-return-case-read.v2", "owner_ref": OWNER_REF,
        "case": case, "items": _return_items(connection, int(case["id"])), "events": events,
        "order": _order(connection, str(case["order_id"])), "lines": _lines(connection, str(case["order_id"])),
    }


def read_return_case(storage: StorageTarget, case_id: str, *, enabled_module_ids: Iterable[str] | None = None) -> dict[str, Any]:
    _require_module_enabled(enabled_module_ids)
    with _reading(storage) as connection:
        return _return_readback(connection, case_id)


def record_audit_event(connection, event_id, event_type, payload_json, now):
    connection.execute(
        "INSERT INTO sales_audit_events(event_id,event_type,payload_json,created_at) VALUES (?,?,?,?)",
        (event_id, event_type, payload_json, now),
    )


def record_document_receipt(connection, *, action_id, idempotency_key, command_digest, preview_digest,
                            document_kind, document_id, order_id, audit_event_id, created_at):
    connection.execute(
        """INSERT INTO sales_document_action_receipts(action_id,idempotency_key,command_digest,preview_digest,
                  document_kind,document_id,order_id,audit_event_id,created_at) VALUES (?,?,?,?,?,?,?,?,?)""",
        (action_id, idempotency_key, command_digest, preview_digest, document_kind, document_id,
         order_id, audit_event_id, created_at),
    )


def _document_readback(connection: sqlite3.Connection, action_id: str) -> dict[str, Any]:
    row = connection.execute("SELECT * FROM sales_document_action_receipts WHERE action_id=?", (action_id,)).fetchone()
    if row is None:
        raise SalesOwnerError("sales_readback_missing", action_id)
    receipt = dict(row)
    audit = connection.execute("SELECT * FROM sales_audit_events WHERE event_id=?", (receipt["audit_event_id"],)).fetchone()
    if receipt["document_kind"] in {"reversal", "service"}:
        return json.loads(audit["payload_json"])["readback"]
    if receipt["document_kind"] == "return_case":
        document = _return_readback(connection, str(receipt["document_id"]))
    else:
        raise SalesOwnerError("sales_document_kind_invalid", str(receipt["document_kind"]))
    return {
        **document,
        "schema_version": "bizhub.sales-document-readback.v1", "receipt": receipt,
        "action_id": action_id, "audit_event": dict(audit) if audit else None,
    }


def read_document_action(storage: StorageTarget, idempotency_key: str, *, enabled_module_ids: Iterable[str] | None = None) -> dict[str, Any]:
    _require_module_enabled(enabled_module_ids)
    with _reading(storage) as connection:
        row = connection.execute("SELECT action_id FROM sales_document_action_receipts WHERE idempotency_key=?", (idempotency_key,)).fetchone()
        if row is None:
            raise SalesOwnerError("sales_readback_missing", idempotency_key)
        return _document_readback(connection, str(row["action_id"]))


def apply_return_preview_in_transaction(connection: sqlite3.Connection, preview: SalesReturnPreview, *, enabled_module_ids: Iterable[str] | None = None) -> dict[str, Any]:
    if not connection.in_transaction:
        raise SalesOwnerError("sales_transaction_required", "an outer transaction is required")
    enabled = _require_module_enabled(enabled_module_ids)
    if digest_json(preview.content()) != preview.preview_digest:
        raise SalesOwnerError("sales_preview_content_drift", "preview digest differs")
    try:
        existing = connection.execute(
            "SELECT action_id, command_digest FROM sales_document_action_receipts WHERE idempotency_key=?",
            (preview.command.idempotency_key,),
        ).fetchone()
        if existing is not None:
            if existing["command_digest"] != preview.command.command_digest:
                raise SalesOwnerError("sales_idempotency_conflict", preview.command.idempotency_key)
            result = _document_readback(connection, str(existing["action_id"]))
            result["disposition"] = "idempotent_noop"
            return result
        if _return_generation(connection) != preview.state_generation:
            raise SalesOwnerError("sales_state_generation_drift", "return state changed")
        authoritative = _preview_return_on_connection(connection, preview.command, enabled_module_ids=enabled)
        if authoritative.preview_digest != preview.preview_digest:
            raise SalesOwnerError("sales_preview_content_drift", "authoritative plan differs")
        now = datetime.now(UTC).isoformat()
        stamp = datetime.now(UTC).replace(tzinfo=None)
        inventory_action_ids = []
        for effect in authoritative.effects:
            if effect["inventory_preview"]:
                # The complete plan was revalidated before any write. Re-preview
                # under the same lock to include earlier lines in this transaction.
                inventory_preview = preview_inventory_in_transaction(
                    connection, InventoryCommand.from_dict(effect["inventory_preview"]["command"]),
                    enabled_module_ids=enabled,
                )
                inventory = apply_inventory_in_transaction(connection, inventory_preview, enabled_module_ids=enabled)
                inventory_action_ids.append(inventory["action_id"])
            _apply_line_effect(connection, effect, now)
        command, case = preview.command, authoritative.planned_case
        if command.action == "register":
            header = {key: value for key, value in case.items() if key != "order_id"} | {
                "po_number": "", "shipment_num": "", "product_name": "", "waybill_no": "", "mismatch_note": "",
                "created_by": "generic", "created_at": stamp, "updated_at": stamp,
            }
            names = sorted(header)
            case_pk = int(connection.execute(
                f"INSERT INTO sales_return_cases ({', '.join(names)}) VALUES ({', '.join('?' for _ in names)})",
                tuple(str(header[name]) if name in {"created_at", "updated_at"} else header[name] for name in names),
            ).lastrowid)
            # The standard link is to a line: the case links to its order's first line; its items carry the per-line detail.
            returns.link_order(connection, case_pk, int(connection.execute(
                "SELECT MIN(l.id) FROM sales_orders l JOIN sales_batches b ON b.id=l.batch_id WHERE b.order_id=?",
                (case["order_id"],)).fetchone()[0]), now=stamp)
            lines = {line["line_id"]: line for line in _lines(connection, case["order_id"])}
            returns.append_items(connection, case_pk, [{
                "order_line_id": item["order_line_id"], "unit_id": item["unit_id"],
                "item_name": connection.execute("SELECT canonical_name FROM products WHERE id=?", (lines[item["order_line_id"]]["product_id"],)).fetchone()[0],
                "claimed_quantity": Decimal(item["quantity"]),
                "claimed_unit": connection.execute("SELECT canonical_code FROM measurement_units WHERE id=?", (item["unit_id"],)).fetchone()[0],
                "physical_return_required": True,
            } for item in authoritative.planned_items], identity=lambda item: str(item["order_line_id"]), now=stamp)
        else:
            stored = _return_case(connection, case["case_id"])
            case_pk = int(stored["id"])
            item_ids = {item["order_line_id"]: int(item["item_id"]) for item in _return_items(connection, case_pk)}
            for item in command.items:
                item_pk = item_ids[item.order_line_id]
                good, scrap = Decimal(item.good_quantity), Decimal(item.scrap_quantity)
                if command.action == "inspect":
                    returns.record_inspection(connection, case_pk, item_pk, {_GOOD: good, _SCRAP: scrap}, now=stamp)
                    continue
                for kind, quantity in ((_GOOD, good), (_SCRAP, scrap)):
                    if quantity > 0:
                        returns.dispose_inspected(connection, case_pk, item_pk, kind, quantity, now=stamp)
            connection.execute(
                "UPDATE sales_return_cases SET lifecycle_status=?, inventory_resolution_status=?, updated_at=? WHERE id=?",
                (case["lifecycle_status"], case["inventory_resolution_status"], str(stamp), case_pk),
            )
        audit_id, action_id = uuid.uuid4().hex, uuid.uuid4().hex
        payload = {"preview": authoritative.to_dict(), "inventory_action_ids": inventory_action_ids}
        returns.record_event(
            connection, case_pk, event_type=_RETURN_EVENT[command.action], event_at=command.occurred_at,
            source_channel="generic", source_id=command.source_ref, actor="generic",
            idempotency_key=command.idempotency_key,
            payload_json=json.dumps(payload, ensure_ascii=False, sort_keys=True), now=stamp,
        )
        record_audit_event(connection, audit_id, f"sales_return_{command.action}_applied",
                           json.dumps(payload, ensure_ascii=False, sort_keys=True), now)
        record_document_receipt(connection, action_id=action_id, idempotency_key=command.idempotency_key,
                                command_digest=command.command_digest, preview_digest=preview.preview_digest,
                                document_kind="return_case", document_id=case["case_id"], order_id=case["order_id"],
                                audit_event_id=audit_id, created_at=now)
        result = _document_readback(connection, action_id)
    except sqlite3.IntegrityError as exc:
        raise SalesOwnerError("sales_write_conflict", str(exc)) from exc
    except returns.ReturnWriteError as exc:
        raise SalesOwnerError(exc.code, exc.message) from exc
    result["disposition"] = "applied"
    return result


def apply_return_preview(storage: StorageTarget, preview: SalesReturnPreview, *, enabled_module_ids: Iterable[str] | None = None) -> dict[str, Any]:
    _require_module_enabled(enabled_module_ids)
    with _writing(storage) as connection:
        return apply_return_preview_in_transaction(connection, preview, enabled_module_ids=enabled_module_ids)


def preview_action_in_transaction(connection: sqlite3.Connection, command, *, enabled_module_ids: Iterable[str] | None = None):
    enabled = _require_module_enabled(enabled_module_ids)
    return _preview_on_connection(connection, command, enabled_module_ids=enabled)


def preview_return_action_in_transaction(connection: sqlite3.Connection, command, *, enabled_module_ids: Iterable[str] | None = None):
    enabled = _require_module_enabled(enabled_module_ids)
    return _preview_return_on_connection(connection, command, enabled_module_ids=enabled)


def read_action_in_transaction(connection: sqlite3.Connection, idempotency_key: str, *, enabled_module_ids: Iterable[str] | None = None) -> dict[str, Any]:
    _require_module_enabled(enabled_module_ids)
    row = connection.execute("SELECT action_id FROM sales_action_receipts WHERE idempotency_key=?", (idempotency_key,)).fetchone()
    if row is None:
        raise SalesOwnerError("sales_readback_missing", idempotency_key)
    return _readback(connection, str(row["action_id"]))


def read_document_action_in_transaction(connection: sqlite3.Connection, idempotency_key: str, *, enabled_module_ids: Iterable[str] | None = None) -> dict[str, Any]:
    _require_module_enabled(enabled_module_ids)
    row = connection.execute("SELECT action_id FROM sales_document_action_receipts WHERE idempotency_key=?", (idempotency_key,)).fetchone()
    if row is None:
        raise SalesOwnerError("sales_readback_missing", idempotency_key)
    return _document_readback(connection, str(row["action_id"]))




def preview_reversal_action(storage: StorageTarget, command: TradeReversalCommand, *, numeric_tools, enabled_module_ids=None) -> TradeReversalPreview:
    enabled = _require_module_enabled(enabled_module_ids)
    with _reading(storage) as connection:
        try:
            return _preview_trade_reversal(connection, MODULE_ID, command, inventory_preview=preview_inventory_in_transaction, inventory_command=InventoryCommand, enabled=enabled, numeric_tools=numeric_tools)
        except TradeRuleError as exc:
            raise SalesOwnerError(str(exc), "冲销无法执行：" + str(exc)) from exc


def apply_reversal_preview(storage: StorageTarget, preview: TradeReversalPreview, *, numeric_tools, enabled_module_ids=None) -> dict[str, Any]:
    enabled = _require_module_enabled(enabled_module_ids)
    try:
        with _writing(storage) as connection:
            return _apply_trade_reversal(connection, MODULE_ID, preview, inventory_preview=preview_inventory_in_transaction,
                inventory_apply=apply_inventory_in_transaction, inventory_command=InventoryCommand, enabled=enabled, project_status=_project_order_status, persist=_persist_reversal, numeric_tools=numeric_tools)
    except TradeRuleError as exc:
        raise SalesOwnerError(str(exc), "冲销无法执行：" + str(exc)) from exc


def list_reversals(storage: StorageTarget, *, status: str = "", enabled_module_ids=None) -> dict[str, Any]:
    _require_module_enabled(enabled_module_ids)
    with _reading(storage) as connection:
        return {"items": [row for row in _reversal_documents(connection, MODULE_ID) if not status or row["status"] == status]}


def read_reversal(storage: StorageTarget, reversal_id: str, *, enabled_module_ids=None) -> dict[str, Any]:
    for row in list_reversals(storage, enabled_module_ids=enabled_module_ids)["items"]:
        if row["reversal_id"] == reversal_id:
            return row
    raise SalesOwnerError("trade_reversal_not_found", reversal_id)



def _persist_reversal(connection, preview, result, receipt, line_changes, order_changes):
    """The original Owner is the only physical writer of its transaction facts."""
    now = result["created_at"]
    for line_id, quantity in line_changes.items():
        fulfillment_writes.set_line_quantity(connection, line_where=("line_id", line_id), field="fulfilled_quantity", quantity=quantity)
    for order_id, status in order_changes.items():
        materialize(connection, order_id, now=now, status=status)
    record_audit_event(connection, result["reversal_id"], "trade_reversal_recorded",
                       json.dumps({"preview": preview.to_dict(), "readback": result}, ensure_ascii=False), now)
    record_document_receipt(connection, **receipt)



def party_reference_counts(connection: sqlite3.Connection, party_id: int) -> dict[str, int]:
    """只读：本模块有多少张单据指向这个往来方（往来方合并前用来拦）。"""

    return {
        table: int(connection.execute(f"SELECT COUNT(*) FROM {table} WHERE customer_party_id=?", (int(party_id),)).fetchone()[0])
        for table in ("sales_orders", "sales_invoices", "sales_payments")
    }
