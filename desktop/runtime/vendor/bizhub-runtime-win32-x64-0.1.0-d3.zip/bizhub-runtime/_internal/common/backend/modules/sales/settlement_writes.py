"""销售结算分摊写入原语：在调用方借出的连接、同一个事务里用裸 SQL 写标准表（``settlement_schema``）。

页面、Agent、单据内核都经各自 Owner 走到这里；这里只管“这笔能不能记、记成什么样”，
不提交、不开事务。规则和首家客户生产上一直用的一致：

- 收款、发票都分到销售订单；同一笔收款（发票）对同一张订单只能有一条有效分摊，
  同额重放返回原分摊（零写入），异额必须走更正（先冲销再记）。
- 分摊金额为正；收款按分摊累计不超收款额，发票按分摊累计不超票面。
- 收款、发票都必须是有效状态，订单客户必须与收款（发票）客户一致。
- 冲销只改状态并留下冲销人、冲销时间，不删行。

“订单”的事实（客户、能否作为结算对象、是否按开票定价）由调用方按自己的订单表提供
（第 8 步销售订单统一前，各部署的订单表不同）。
"""

from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from datetime import UTC, datetime
from decimal import Decimal
from typing import Callable

from backend.modules.trade_core.public import allocation_exceeded, decimal_sum


class SettlementWriteError(RuntimeError):
    def __init__(self, code: str, message: str = ""):
        super().__init__(f"{code}: {message}" if message else code)
        self.code = code
        self.message = message


@dataclass(frozen=True)
class OrderFacts:
    """分摊目标订单的事实。``settleable`` 为假：订单不能作为结算对象（客户未确认等）；
    ``invoicing`` 为假：订单按不开票定价，不接受发票分摊。"""

    sales_order_id: int
    customer_party_id: int | None
    settleable: bool = True
    invoicing: bool = True
    refusal: str = ""


OrderFactsReader = Callable[[sqlite3.Connection, int], "OrderFacts | None"]


@dataclass(frozen=True)
class Provenance:
    """谁、凭什么记的这一笔。"""

    source_kind: str = "management_confirmed"
    source_ref: str = ""
    notes: str = ""
    actor: str = "management"


@dataclass(frozen=True)
class AllocationResult:
    allocation_id: int
    allocated_amount: Decimal
    deduplicated: bool


_TABLES = {
    "payment": ("sales_payment_allocations", "payment_id", "sales_payments", "amount"),
    "invoice": ("sales_invoice_allocations", "invoice_id", "sales_invoices", "total_amount"),
}


def _stamp(now: datetime | None) -> str:
    # Same text the customer's ORM stores for a naive-UTC DateTime.
    return (now or datetime.now(UTC).replace(tzinfo=None)).strftime("%Y-%m-%d %H:%M:%S.%f")


def _amount(value: object) -> Decimal:
    return Decimal(str(value or 0))


def _row(connection: sqlite3.Connection, sql: str, params: tuple) -> sqlite3.Row | None:
    connection.row_factory = sqlite3.Row
    return connection.execute(sql, params).fetchone()


def allocated(connection: sqlite3.Connection, kind: str, owner_id: int) -> Decimal:
    table, owner_column, _owner_table, _total = _TABLES[kind]
    rows = connection.execute(
        f"SELECT allocated_amount FROM {table} WHERE {owner_column}=? AND status='confirmed'", (int(owner_id),)
    ).fetchall()
    return decimal_sum(_amount(row[0]) for row in rows)


def allocate(
    connection: sqlite3.Connection,
    kind: str,
    *,
    owner_id: int,
    sales_order_id: int,
    amount: Decimal,
    read_order: OrderFactsReader,
    provenance: Provenance,
    transfer: bool = False,
    before_new_row: Callable[[], None] | None = None,
    now: datetime | None = None,
) -> AllocationResult:
    """记一条收款或发票分摊。``transfer=True``：把一条已核对过的分摊原样迁到另一张发票（收款），
    调用方已按迁入方票面核过总额，这里只核同键唯一。``before_new_row``：同额重放之外、真要新记一笔时
    调用方自己的拦截（客户专属规则）。"""

    table, owner_column, owner_table, total_column = _TABLES[kind]
    if amount <= 0:
        raise SettlementWriteError(f"{kind}_allocation_not_positive", str(amount))
    if len(format(amount, "f").replace(".", "").strip("0")) > 15:
        # NUMERIC columns keep 15 significant digits; refuse rather than silently round money.
        raise SettlementWriteError(f"{kind}_allocation_precision_exceeded", str(amount))
    existing = _row(
        connection,
        f"SELECT id, allocated_amount FROM {table} WHERE {owner_column}=? AND sales_order_id=? AND status='confirmed'",
        (int(owner_id), int(sales_order_id)),
    )
    if existing is not None:
        if _amount(existing["allocated_amount"]) != amount:
            raise SettlementWriteError(f"{kind}_allocation_already_exists", str(existing["id"]))
        return AllocationResult(int(existing["id"]), amount, True)
    if before_new_row is not None:
        before_new_row()
    if not transfer:
        owner = _row(connection, f"SELECT * FROM {owner_table} WHERE id=?", (int(owner_id),))
        if owner is None or owner["status"] != "confirmed":
            raise SettlementWriteError(f"{kind}_not_confirmed", str(owner_id))
        order = read_order(connection, int(sales_order_id))
        if order is None:
            raise SettlementWriteError("sales_order_not_found", str(sales_order_id))
        if not order.settleable:
            raise SettlementWriteError(order.refusal or "sales_order_not_settleable", str(sales_order_id))
        if order.customer_party_id is None or int(order.customer_party_id) != int(owner["customer_party_id"]):
            raise SettlementWriteError(f"{kind}_sales_customer_conflict", str(sales_order_id))
        if kind == "invoice" and not order.invoicing:
            raise SettlementWriteError("sales_order_uses_no_invoice_pricing", str(sales_order_id))
        if allocation_exceeded(_amount(owner[total_column]), allocated(connection, kind, owner_id), amount):
            raise SettlementWriteError(f"{kind}_overallocated", str(owner_id))
    stamp = _stamp(now)
    cursor = connection.execute(
        f"""INSERT INTO {table} (
               {owner_column}, sales_order_id, allocated_amount, status, source_kind, source_ref, notes,
               confirmed_by, confirmed_at, reversed_by, reversed_at, created_at)
           VALUES (?, ?, ?, 'confirmed', ?, ?, ?, ?, ?, '', NULL, ?)""",
        (int(owner_id), int(sales_order_id), str(amount), provenance.source_kind, provenance.source_ref,
         provenance.notes, provenance.actor, stamp, stamp),
    )
    return AllocationResult(int(cursor.lastrowid), amount, False)


def reverse_allocation(
    connection: sqlite3.Connection,
    kind: str,
    *,
    owner_id: int,
    allocation_id: int,
    reversed_by: str,
    notes: str = "",
    now: datetime | None = None,
) -> bool:
    """冲销一条分摊；已冲销的原样返回 False（零写入）。"""

    table, owner_column, _owner_table, _total = _TABLES[kind]
    row = _row(connection, f"SELECT {owner_column} AS owner_id, status, notes FROM {table} WHERE id=?",
               (int(allocation_id),))
    if row is None:
        raise SettlementWriteError(f"{kind}_allocation_not_found", str(allocation_id))
    if int(row["owner_id"]) != int(owner_id):
        raise SettlementWriteError(f"{kind}_allocation_owner_conflict", str(allocation_id))
    if row["status"] == "reversed":
        return False
    merged_notes = "；".join(value for value in (str(row["notes"] or ""), notes) if value)
    connection.execute(
        f"UPDATE {table} SET status='reversed', reversed_by=?, reversed_at=?, notes=? WHERE id=?",
        (reversed_by or "management", _stamp(now), merged_notes, int(allocation_id)),
    )
    return True


__all__ = [
    "AllocationResult",
    "OrderFacts",
    "OrderFactsReader",
    "Provenance",
    "SettlementWriteError",
    "allocate",
    "allocated",
    "reverse_allocation",
]
