"""Customer-neutral candidate matching and resolution-gate rules.

Pure functions only: no service or customer imports, no SQL, no customer
constants. Callers inject their own text normalizer and the set of match
methods they treat as server-exact.
"""

from __future__ import annotations

import re
import unicodedata
from typing import Any, Callable, Iterable


def normalize_identity(value: object) -> str:
    """Name identity key: NFKC, every whitespace removed, case folded."""

    return re.sub(r"\s+", "", unicodedata.normalize("NFKC", str(value or ""))).casefold()


def match_score(
    query: str,
    candidate: str,
    *,
    exact_score: float,
    contains_score: float,
    normalize: Callable[[str | None], str],
) -> float:
    normalized = normalize(candidate)
    if not query or not normalized:
        return 0
    if normalized == query:
        return exact_score
    if query in normalized or normalized in query:
        return contains_score
    return 0


def candidate_payload(
    *,
    domain: str,
    entity_id: int | str,
    label: str,
    status: str,
    method: str,
    matched: str,
    score: float,
    attributes: dict[str, Any] | None = None,
) -> dict[str, Any]:
    return {
        "canonical_ref": f"{domain}:{entity_id}",
        "domain": domain,
        "entity_id": entity_id,
        "canonical_label": label,
        "status": status,
        "match_method": method,
        "matched_text": matched,
        "score": score,
        "attributes": attributes or {},
    }


def resolve_server_selection(
    *,
    candidates: Iterable[dict[str, Any]],
    selected_canonical_ref: str | None,
    exact_match_methods: frozenset[str],
    exact_score_threshold: float = 0.99,
) -> tuple[dict[str, Any] | None, bool, bool]:
    """Return (selected, server_selected_exact, exact_selected)."""
    candidates = list(candidates)
    selected = next(
        (item for item in candidates if item["canonicalRef"] == selected_canonical_ref),
        None,
    )
    server_selected_exact = False
    if not selected_canonical_ref:
        exact_candidates = [
            item
            for item in candidates
            if item["status"] == "active"
            and float(item["score"]) >= exact_score_threshold
            and item["matchMethod"] in exact_match_methods
        ]
        if len(exact_candidates) == 1:
            # Callers may derive wording (for example from an image) only after
            # their own pipeline ran, so it cannot always appear in a
            # pre-model context. One unique exact active entity still closes
            # the formal canonical reference deterministically.
            selected = exact_candidates[0]
            server_selected_exact = True
    exact_selected = bool(
        selected
        and float(selected["score"]) >= exact_score_threshold
        and selected["matchMethod"] in exact_match_methods
    )
    return selected, server_selected_exact, exact_selected


def resolution_gate_reasons(
    *,
    selected: dict[str, Any] | None,
    server_selected_exact: bool,
    selected_canonical_ref: str | None,
    candidates: Iterable[dict[str, Any]],
    ambiguity_reasons: Iterable[str],
    exact_match_methods: frozenset[str],
    exact_score_threshold: float = 0.99,
    confidence: Any = None,
    verified_anchor_types: Iterable[str] = (),
) -> tuple[list[str], bool, dict[str, Any] | None, bool]:
    """Return (gate_reasons, server_selected_exact, selected, exact_selected)."""
    candidates = list(candidates)
    gate_reasons: list[str] = []
    exact_selected = bool(
        selected
        and float(selected["score"]) >= exact_score_threshold
        and selected["matchMethod"] in exact_match_methods
    )
    if selected_canonical_ref and selected is None:
        gate_reasons.append("selected_candidate_not_in_server_candidate_set")
    if selected and selected["status"] != "active":
        gate_reasons.append("selected_master_data_entity_not_active")
    if not selected:
        gate_reasons.append("no_existing_master_data_entity_selected")
    if ambiguity_reasons and not server_selected_exact:
        gate_reasons.append("agent_reported_master_data_ambiguity")
    if not exact_selected:
        if confidence is None or float(confidence) < 0.95:
            gate_reasons.append("master_data_confidence_below_0_95")
        if not verified_anchor_types:
            gate_reasons.append("strong_business_anchor_missing")
        reasonable = [item for item in candidates if float(item["score"]) >= 0.75]
        if len(reasonable) > 1:
            gate_reasons.append("multiple_reasonable_master_data_candidates")
    return gate_reasons, server_selected_exact, selected, exact_selected


def edit_distance(left: str, right: str) -> int:
    """Levenshtein distance (insert / delete / substitute, each cost 1)."""

    if left == right:
        return 0
    if not left or not right:
        return len(left) or len(right)
    previous = list(range(len(right) + 1))
    for row, left_char in enumerate(left, start=1):
        current = [row]
        for column, right_char in enumerate(right, start=1):
            current.append(
                min(
                    previous[column] + 1,
                    current[column - 1] + 1,
                    previous[column - 1] + (left_char != right_char),
                )
            )
        previous = current
    return previous[-1]


def max_fuzzy_distance(
    core_length: int,
    distance_by_length: Iterable[tuple[int | None, int | None]],
) -> int | None:
    """Allowed distance for one core-name length; ``None`` means exact only.

    ``distance_by_length`` is an ordered ``(max_length, max_distance)`` table
    supplied by the caller's configuration; ``max_length=None`` closes it.
    """

    for max_length, max_distance in distance_by_length:
        if max_length is None or core_length <= max_length:
            return max_distance
    return None


def unique_nearest_entity(
    query_core: str,
    names_by_entity: dict[Any, Iterable[str]],
    *,
    distance_by_length: Iterable[tuple[int | None, int | None]],
    min_gap: int = 1,
) -> tuple[str, Any, int | None, list[Any]]:
    """Pick the single entity whose closest core name is within tolerance.

    Returns ``(status, entity, distance, tied_entities)`` where ``status`` is
    ``resolved`` (one nearest entity, the runner-up at least ``min_gap``
    farther), ``ambiguous`` (several entities too close to tell apart) or
    ``none``.  Callers inject already-normalized core names; this function
    knows nothing about any customer vocabulary.
    """

    if not query_core:
        return "none", None, None, []
    # "Exact only" still admits a unique equal core name (``上海派朗德金属有限公司``
    # and ``派朗德贵金属`` share the core ``派朗德``); it only forbids slips.
    limit = max_fuzzy_distance(len(query_core), distance_by_length) or 0
    nearest: dict[Any, int] = {}
    for entity, names in names_by_entity.items():
        distances = [
            edit_distance(query_core, name)
            for name in names
            if name and abs(len(name) - len(query_core)) <= limit
        ]
        if distances and min(distances) <= limit:
            nearest[entity] = min(distances)
    if not nearest:
        return "none", None, None, []
    ranked = sorted(nearest.items(), key=lambda item: item[1])
    best_entity, best_distance = ranked[0]
    tied = [
        entity
        for entity, distance in ranked
        if distance < best_distance + max(1, int(min_gap))
    ]
    if len(tied) > 1:
        return "ambiguous", None, best_distance, tied
    return "resolved", best_entity, best_distance, [best_entity]
