"""Stable facade for generic procurement actions and reads."""

from __future__ import annotations


from backend.kernel.profile_registry import StorageTarget, read_storage, storage_connect

import sqlite3
from pathlib import Path
from typing import Any

from .contracts import (ProcurementCommand, ProcurementLine, ProcurementPreview, ProcurementReceiptCommand,
                        ProcurementReceiptLine, ProcurementReceiptAllocation, ProcurementReceiptPreview)
from .owner import (ORDER_ROWS, LINE_ROWS, RECEIPT_ROWS, ProcurementOwnerError, apply_preview, preview_action, preview_receipt_action,
                    apply_receipt_preview, read_receipt_document, read_action)


def _connect(path: Path) -> sqlite3.Connection:
    connection = storage_connect(f"file:{path}?mode=ro", uri=True)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA query_only=ON")
    return connection


def _connect_snapshot(path: Path) -> sqlite3.Connection:
    connection = _connect(path)
    connection.execute("BEGIN")
    return connection


def list_orders(storage: StorageTarget, *, limit: int = 100) -> list[dict[str, Any]]:
    with read_storage(storage, _connect) as connection:
        return [
            dict(row)
            for row in connection.execute(
                f"SELECT * FROM {ORDER_ROWS} ORDER BY ordered_at DESC, order_id DESC LIMIT ?",
                (max(1, min(int(limit), 500)),),
            )
        ]


def list_receipt_documents(storage: StorageTarget, *, query: str = "", offset: int = 0, limit: int = 100) -> dict[str, Any]:
    limit = max(1, min(int(limit), 500))
    offset = max(0, int(offset))
    with read_storage(storage, _connect_snapshot) as connection:
        rows = connection.execute(
            """SELECT * FROM procurement_receipt_documents
               WHERE instr(document_id, ?) OR instr(source_identity, ?) OR instr(supplier_party_id, ?)
               ORDER BY occurred_at DESC, document_id DESC LIMIT ? OFFSET ?""",
            (query, query, query, limit + 1, offset)).fetchall()
        from backend.modules.trade_core.public import reversal_documents
        voided_ids = {row["command"]["target_id"] for row in reversal_documents(connection, "procurement")
                      if row["status"] == "reversed" and row["command"]["target_kind"] == "receipt_document"}
    return {"items": [{**dict(row), **({"status": "voided"} if row["document_id"] in voided_ids else {})} for row in rows[:limit]],
            "next_offset": offset + limit if len(rows) > limit else None}


__all__ = [
    "ProcurementReceiptCommand", "ProcurementReceiptLine", "ProcurementReceiptAllocation", "ProcurementReceiptPreview",
    "preview_receipt_action", "apply_receipt_preview", "read_receipt_document", "read_action", "list_receipt_documents",
    "ProcurementCommand",
    "ProcurementLine",
    "ProcurementOwnerError",
    "ProcurementPreview",
    "apply_preview",
    "list_orders",
    "preview_action",
]


from .owner import (
    preview_action_in_transaction,
    preview_receipt_action_in_transaction,
    apply_preview_in_transaction,
    apply_receipt_preview_in_transaction,
    read_action_in_transaction
)

__all__ += ['preview_action_in_transaction', 'preview_receipt_action_in_transaction', 'apply_preview_in_transaction', 'apply_receipt_preview_in_transaction', 'read_action_in_transaction']

from .owner import preview_reversal_action, apply_reversal_preview, list_reversals, read_reversal
from backend.modules.trade_core.public import TradeReversalCommand, TradeReversalPreview
__all__ += ["ORDER_ROWS", "LINE_ROWS", "RECEIPT_ROWS"]
__all__ += ["TradeReversalCommand", "TradeReversalPreview", "preview_reversal_action", "apply_reversal_preview", "list_reversals", "read_reversal"]

from .owner import party_reference_counts
__all__ += ["party_reference_counts"]

# 采购结算写入原语（迁移第 3 步）：各客户经自己的 Owner 在同一事务里调用。
from . import settlement_writes  # noqa: E402

__all__ += ["settlement_writes"]

from .settlement_reads import read_settlement_records, settlement_state
__all__ += ["read_settlement_records", "settlement_state"]

from . import order_schema, receipt_schema, receipt_writes  # noqa: E402

__all__ += ["order_schema", "receipt_schema", "receipt_writes"]

from .relation_reads import ProcurementRelationExtension, read_order_relation_candidates  # noqa: E402
__all__ += ["ProcurementRelationExtension", "read_order_relation_candidates"]
