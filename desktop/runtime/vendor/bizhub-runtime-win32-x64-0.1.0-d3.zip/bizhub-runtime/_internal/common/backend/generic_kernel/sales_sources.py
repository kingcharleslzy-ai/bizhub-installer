"""Immutable source lifecycle for the thin generic sales agent.

One channel message is one source, identified by the channel-provided stable
``source_ref``. A source stores two immutable ``kernel_audit_events`` rows:

* ``sales_agent_source_received`` — the verbatim text, business time, raw
  ``extra`` payload and the content digest.
* ``sales_agent_source_prepared`` — the first fixed typed proposal (stable
  ``SalesCommand`` or an explicit clarification), never rewritten.

Applied state is read back from the existing Sales Owner receipts; this module
never writes business facts and never stores a third "applied" event.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Iterable
from contextlib import closing

from backend.modules.sales.contracts import SalesCommand, SalesReturnCommand
from backend.modules.sales.public import (
    LINE_ROWS,
    SalesOwnerError,
    preview_action as preview_sales_action,
    read_action as read_sales_action,
    read_document_action,
    preview_return_action,
)
from backend.modules.trade_core.public import digest_json

from .agent_common import SourceStore, MAX_TEXT_LENGTH as MAX_TEXT_LENGTH, MAX_SOURCE_REF_LENGTH as MAX_SOURCE_REF_LENGTH


MODULE_ID = "generic.kernel_smoke"
OWNER_REF = f"{MODULE_ID}:runtime"
RECEIVED_EVENT = "sales_agent_source_received"
PREPARED_EVENT = "sales_agent_source_prepared"
RECEIVED_SCHEMA = "bizhub.sales-agent-source-received.v1"
PREPARED_SCHEMA = "bizhub.sales-agent-source-prepared.v2"
STATE_SCHEMA = "bizhub.sales-agent-source-state.v1"
COMMAND_DISPOSITIONS = {"create_order", "fulfill", "return"}
PLAIN_DISPOSITIONS = {"needs_clarification", "not_covered"}


class SalesSourceError(RuntimeError):
    def __init__(self, code: str, message: str):
        super().__init__(f"{code}: {message}")
        self.code = code
        self.message = message


def validate_prepared_proposal(proposal: dict[str, Any], *, source_id: str, historical: bool = False) -> None:
    """Fail closed on any proposal shape this kernel cannot replay."""

    allowed = {"schema_version", "source_id", "disposition", "command", "command_digest", "unsupported_details", "clarifications", "not_covered_reason"}
    from .agent_common import validate_clarification_references
    validate_clarification_references(proposal, "sales", SalesSourceError)
    if set(proposal) - {"references"} != allowed:
        raise SalesSourceError("sales_agent_proposal_fields_invalid", ",".join(sorted(set(proposal) ^ allowed)))
    version = proposal["schema_version"]
    if version not in {PREPARED_SCHEMA, "bizhub.sales-agent-source-prepared.v1"}:
        raise SalesSourceError("sales_agent_proposal_schema_invalid", str(version))
    if version.endswith(".v1") and proposal["disposition"] == "return":
        raise SalesSourceError("sales_agent_proposal_disposition_invalid", str(proposal["disposition"]))
    if proposal["source_id"] != source_id:
        raise SalesSourceError("sales_agent_proposal_source_mismatch", str(proposal["source_id"]))
    disposition = proposal["disposition"]
    command = proposal["command"]
    if historical and disposition in {"invoice", "payment"}:
        if (not isinstance(command, dict) or digest_json(command) != proposal["command_digest"]
                or command.get("idempotency_key") != assigned_idempotency_key(source_id)
                or evidence_ref(source_id) not in (command.get("evidence_refs") or [])):
            raise SalesSourceError("sales_agent_proposal_command_invalid", "historical command identity differs")
        return
    if disposition in PLAIN_DISPOSITIONS:
        if command is not None or proposal["command_digest"] is not None:
            raise SalesSourceError("sales_agent_proposal_command_not_allowed", disposition)
        return
    if disposition not in COMMAND_DISPOSITIONS:
        raise SalesSourceError("sales_agent_proposal_disposition_invalid", str(disposition))
    if not isinstance(command, dict):
        raise SalesSourceError("sales_agent_proposal_command_required", disposition)
    try:
        parsed = command_from_proposal(proposal)
    except (TypeError, KeyError) as exc:
        raise SalesSourceError("sales_agent_proposal_command_invalid", str(exc)) from exc
    if parsed.command_digest != proposal.get("command_digest"):
        raise SalesSourceError("sales_agent_proposal_command_invalid", "command digest mismatch")
    if parsed.idempotency_key != assigned_idempotency_key(source_id):
        raise SalesSourceError("sales_agent_proposal_command_invalid", "idempotency key must be server-assigned")
    if not parsed.evidence_refs or evidence_ref(source_id) not in parsed.evidence_refs:
        raise SalesSourceError("sales_agent_proposal_command_invalid", "missing source evidence ref")
    if proposal["clarifications"] or proposal["not_covered_reason"]:
        raise SalesSourceError("sales_agent_proposal_command_invalid", "command cannot carry unresolved actions")
    if disposition == "return" and parsed.action not in {"register", "inspect", "dispose"}:
        raise SalesSourceError("sales_agent_proposal_command_invalid", "invalid document action")
    if disposition == "create_order" and parsed.order_id != assigned_order_id(source_id):
        raise SalesSourceError("sales_agent_proposal_command_invalid", "create order id must be server-assigned")
    if disposition == "create_order" and parsed.action != "create":
        raise SalesSourceError("sales_agent_proposal_command_invalid", "create_order requires create")
    if disposition == "fulfill" and parsed.action != "fulfill":
        raise SalesSourceError("sales_agent_proposal_command_invalid", "fulfill disposition requires a fulfill command")
    if disposition == "return" and parsed.action == "register" and parsed.case_id:
        raise SalesSourceError("sales_agent_proposal_command_invalid", "new case id must be Owner-assigned")


def command_from_proposal(proposal: dict[str, Any]):
    command_type = SalesReturnCommand if proposal["disposition"] == "return" else SalesCommand
    return command_type.from_dict(proposal["command"])


def preview_prepared(path: Path, proposal: dict[str, Any], *, enabled_module_ids: Iterable[str] | None = None):
    preview = preview_return_action if proposal["disposition"] == "return" else preview_sales_action
    return preview(path, command_from_proposal(proposal), enabled_module_ids=enabled_module_ids)


def _applied_readback(
    path: Path,
    command: SalesCommand | SalesReturnCommand,
    *,
    enabled_module_ids: Iterable[str] | None,
) -> dict[str, Any] | None:
    try:
        reader = read_sales_action if isinstance(command, SalesCommand) else read_document_action
        readback = reader(
            path, command.idempotency_key, enabled_module_ids=enabled_module_ids
        )
    except SalesOwnerError as exc:
        if exc.code == "sales_readback_missing":
            return None
        raise
    receipt_digest = readback["command_digest"] if isinstance(command, SalesCommand) else readback["receipt"]["command_digest"]
    if receipt_digest != command.command_digest:
        raise SalesSourceError(
            "sales_agent_receipt_command_conflict",
            "an applied receipt exists for a different command",
        )
    return readback


# A return case's orders: header -> order links -> orders (aliases c, o).
_RETURN_CASE_ORDERS = """(sales_return_cases c JOIN sales_return_case_order_links k ON k.sales_return_case_id=c.id
    JOIN sales_orders ln ON ln.id=k.sales_order_id JOIN sales_batches o ON o.id=ln.batch_id)"""
# From v22 the lines are the sales standard line table; the Owner's projection keeps the text-keyed row shape.
_LINES = LINE_ROWS


def record_orders(connection, record_type, record_id):
    """Resolve one typed record through every formal link, including history."""
    if not record_id:
        return set()
    if record_type == "payment_allocation" and isinstance(record_id, bool):
        return set()
    if record_type == "order":
        return {record_id}
    if record_type == "return_line":
        # Composite primary key: a historical bare line ID cannot identify a row and must not resolve across documents.
        if not isinstance(record_id, dict) or set(record_id) != {"case_id", "order_line_id"} or not all(record_id.values()):
            return set()
        parent_id, line_id = record_id["case_id"], record_id["order_line_id"]
        query = f"""SELECT o.order_id FROM {_RETURN_CASE_ORDERS} JOIN sales_return_case_items i ON i.sales_return_case_id=c.id
            WHERE c.case_id=? AND i.order_line_id=? UNION SELECT l.order_id FROM sales_return_cases c
            JOIN sales_return_case_items i ON i.sales_return_case_id=c.id
            JOIN {_LINES} l ON l.line_id=i.order_line_id WHERE c.case_id=? AND i.order_line_id=?"""
        return {row[0] for row in connection.execute(query, (parent_id, line_id, parent_id, line_id))} - {"", None}
    queries = {
        "customer": "SELECT b.order_id FROM sales_orders l JOIN sales_batches b ON b.id=l.batch_id WHERE l.customer_party_id=?",
        "product": f"SELECT order_id FROM {_LINES} WHERE product_id=?",
        "order_line": f"SELECT order_id FROM {_LINES} WHERE line_id=?",
        "shipment": f"SELECT order_id FROM sales_fulfillments WHERE fulfillment_id=? UNION SELECT l.order_id FROM sales_fulfillments f JOIN {_LINES} l ON l.line_id=f.line_id WHERE f.fulfillment_id=?",
        "return": f"SELECT o.order_id FROM {_RETURN_CASE_ORDERS} WHERE c.case_id=? UNION SELECT l.order_id FROM sales_return_cases c JOIN sales_return_case_items i ON i.sales_return_case_id=c.id JOIN {_LINES} l ON l.line_id=i.order_line_id WHERE c.case_id=?",
        "invoice": "SELECT DISTINCT order_id FROM sales_invoice_lines WHERE invoice_id=?",
        "payment": "SELECT DISTINCT b.order_id FROM sales_payments p JOIN sales_payment_allocations a ON a.payment_id=p.id JOIN sales_orders l ON l.id=a.sales_order_id JOIN sales_batches b ON b.id=l.batch_id WHERE p.payment_id=?",
        "payment_allocation": """SELECT DISTINCT b.order_id FROM sales_payment_allocations a
            JOIN sales_orders l ON l.id=a.sales_order_id JOIN sales_batches b ON b.id=l.batch_id
            WHERE (typeof(?)='integer' AND a.id=?) OR EXISTS (
                SELECT 1 FROM json_each(CASE WHEN json_valid(a.notes) THEN a.notes ELSE '[]' END) legacy
                WHERE a.source_kind='generic_migration' AND json_extract(
                    CASE WHEN legacy.type='object' THEN legacy.value ELSE '{}' END, '$.legacy_allocation_id')=?)""",
    }
    record_type = {"shipment_line": "shipment"}.get(record_type, record_type)
    if record_type not in queries:
        return set()
    query = queries[record_type]
    return {row[0] for row in connection.execute(query, (record_id,) * query.count("?"))} - {"", None}


def _reference_orders(connection, references):
    orders = set()
    # Unambiguous historical keys remain readable; a bare line_id cannot grant an identity.
    legacy = {"order_id": "order", "fulfillment_id": "shipment", "case_id": "return",
              "invoice_id": "invoice", "payment_id": "payment"}
    for kind, ids in references.items():
        for record_id in ids:
            orders |= record_orders(connection, legacy.get(kind, kind), record_id)
    return orders


def _command_orders(connection, proposal):
    command = proposal.get("command")
    if not isinstance(command, dict):
        return set()
    references = {}

    def add(kind, value):
        if value:
            references.setdefault(kind, []).append(value)

    for key, kind in {"order_id": "order", "target_line_id": "order_line", "case_id": "return",
                      "return_case_id": "return", "invoice_id": "invoice", "payment_id": "payment"}.items():
        add(kind, command.get(key))
    for line in command.get("lines", []):
        add("order", line.get("order_id"))
        add("order_line", line.get("order_line_id"))
    for allocation in command.get("allocations", []):
        add("invoice", allocation.get("invoice_id"))
        add("order", allocation.get("order_id"))
    for allocation_id in command.get("allocation_ids", []):
        add("payment_allocation", allocation_id)
    for item in command.get("items", []):
        if proposal.get("disposition") == "return" and command.get("action") != "register":
            add("return_line", {"case_id": command.get("case_id"), "order_line_id": item.get("order_line_id")})
        else:
            add("order_line", item.get("order_line_id"))
    receipt = connection.execute("""SELECT document_kind, document_id FROM sales_document_action_receipts
        WHERE idempotency_key=? AND command_digest=?""", (command["idempotency_key"], proposal["command_digest"])).fetchone()
    if receipt:
        add({"return_case": "return"}.get(receipt[0], receipt[0]), receipt[1])
    return _reference_orders(connection, references)


class _SalesSourceStore(SourceStore):
    order_prefix = "so"
    PLAIN_DISPOSITIONS = PLAIN_DISPOSITIONS
    owner_error_type = SalesOwnerError
    validate_prepared_proposal = staticmethod(validate_prepared_proposal)
    command_from_proposal = staticmethod(command_from_proposal)
    preview_prepared = staticmethod(preview_prepared)
    _applied_readback = staticmethod(_applied_readback)
    command_orders = staticmethod(_command_orders)
    reference_orders = staticmethod(_reference_orders)

    def _prepared_state(self, path, state, *, include_preview, enabled_module_ids):
        proposal = state["proposal"]
        if proposal.get("disposition") not in {"invoice", "payment"}:
            return super()._prepared_state(path, state, include_preview=include_preview, enabled_module_ids=enabled_module_ids)
        validate_prepared_proposal({key: value for key, value in proposal.items() if key != "prepared_at"},
                                  source_id=state["source_id"], historical=True)
        with closing(self._connect(path, readonly=True)) as connection:
            receipt = connection.execute("SELECT * FROM sales_document_action_receipts WHERE idempotency_key=?",
                                         (proposal["command"]["idempotency_key"],)).fetchone()
            if receipt is not None:
                if receipt["command_digest"] != proposal["command_digest"]:
                    raise SalesSourceError("sales_agent_receipt_command_conflict", "historical receipt differs")
                state["applied"] = {"receipt": dict(receipt)}
        state["status"] = "not_covered"
        state["preview_error"] = {"code": "sales_agent_historical_command_retired",
            "message": "原收款或开票提案仅供查看；继续办理请使用当前收款、开票入口重新确认。"}
        return state


_store = _SalesSourceStore("sales", SalesSourceError, PREPARED_SCHEMA)
resolution_store = _store
preview_resolution = _store.preview_resolution
apply_resolution = _store.apply_resolution
prepare_context = _store.prepare_context
source_id_for_ref = _store.source_id_for_ref
evidence_ref = _store.evidence_ref
assigned_order_id = _store.assigned_order_id
assigned_idempotency_key = _store.assigned_idempotency_key
receive_source = _store.receive_source
record_prepared = _store.record_prepared
load_source_state = _store.load_source_state
list_sources = _store.list_sources
_parse_payload = _store._parse_payload
__all__ = [
    "resolution_store", "preview_resolution", "apply_resolution", "prepare_context",
    "COMMAND_DISPOSITIONS",
    "OWNER_REF",
    "PLAIN_DISPOSITIONS",
    "PREPARED_EVENT",
    "PREPARED_SCHEMA",
    "RECEIVED_EVENT",
    "RECEIVED_SCHEMA",
    "STATE_SCHEMA",
    "SalesSourceError",
    "assigned_idempotency_key",
    "assigned_order_id",
    "evidence_ref",
    "list_sources",
    "load_source_state",
    "receive_source",
    "record_prepared",
    "source_id_for_ref",
    "validate_prepared_proposal",
    "command_from_proposal",
    "preview_prepared",
]


from backend.modules.sales.public import (
    preview_action_in_transaction,
    preview_return_action_in_transaction,
    apply_preview_in_transaction,
    apply_return_preview_in_transaction,
    read_action_in_transaction,
    read_document_action_in_transaction
)
from backend.modules.platform.agent_runtime.prepared_owner_execution import OwnerEffect, VerifiedReadback, OwnerStateChanged
from .agent_common import generic_owner_plan, apply_prepared_source as _apply_prepared_source

class _PreparedSalesOwner:
    def __init__(self, connection, proposal, enabled_module_ids, profile_source_digest):
        self.connection, self.proposal, self.enabled = connection, proposal, enabled_module_ids
        self.profile_source_digest = profile_source_digest
        self.command = command_from_proposal(proposal)

    def _read(self):
        reader = read_action_in_transaction if isinstance(self.command, SalesCommand) else read_document_action_in_transaction
        return reader(self.connection, self.command.idempotency_key, enabled_module_ids=self.enabled)

    def applied_readback(self):
        try:
            readback = self._read()
        except SalesOwnerError as exc:
            if exc.code == "sales_readback_missing":
                return None
            raise
        if (readback["command_digest"] if isinstance(self.command, SalesCommand) else readback["receipt"]["command_digest"]) != self.command.command_digest:
            raise SalesSourceError("sales_agent_receipt_command_conflict", "an applied receipt exists for a different command")
        return readback

    async def preview(self):
        preview = preview_return_action_in_transaction if self.proposal["disposition"] == "return" else preview_action_in_transaction
        return generic_owner_plan("sales", self.proposal, preview(self.connection, self.command, enabled_module_ids=self.enabled),
            profile_source_digest=self.profile_source_digest)

    async def apply(self, plan):
        writer = apply_return_preview_in_transaction if self.proposal["disposition"] == "return" else apply_preview_in_transaction
        try:
            result = writer(self.connection, plan.preview, enabled_module_ids=self.enabled)
        except SalesOwnerError as exc:
            if exc.code in {"sales_state_generation_drift", "sales_preview_content_drift"}:
                raise OwnerStateChanged(str(exc)) from exc
            raise
        return OwnerEffect("applied", result)

    async def readback(self, plan, effect):
        readback = self._read()
        expected = {key: value for key, value in effect.result.items() if key != "disposition"}
        mismatches = () if readback == expected else ({"check": "owner_readback", "expected": expected, "actual": readback},)
        return VerifiedReadback(not mismatches, mismatches, readback)


def apply_prepared_source(path, source_id, *, preview_digest, profile_source_digest, enabled_module_ids=None):
    return _apply_prepared_source(_store, path, source_id, preview_digest=preview_digest,
        enabled_module_ids=enabled_module_ids, profile_source_digest=profile_source_digest, owner_type=_PreparedSalesOwner)
