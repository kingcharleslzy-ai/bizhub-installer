"""库存流水写入原语：在调用方借出的连接、同一个事务里用裸 SQL 写流水标准表（``movement_schema``），
外加纯规则。页面、Agent、单据内核都经各自 Owner 走到这里；这里不提交、不开事务。
规则和首家客户生产上一直用的一致：

- 类型只有收、领、退、调、废；入只有去向、出只有来源、调拨两头不同。
- 同一来源键重放零写入；来源键相同而内容不同拒绝。
- 一行最多冲销一次：同一来源键的重复冲销零写入，换来源键再冲拒绝；冲销日不早于原日；原行状态改 reversed。
- 余额：按日期顺序累加，任一时点为负整体拒绝（``minimum_running_balance``）；换算单位、月结基准等
  按客户口径由调用方算好再给。
"""

from __future__ import annotations

import sqlite3
from datetime import UTC, date, datetime
from decimal import Decimal, InvalidOperation
from typing import Any, Iterable, Mapping

from backend.inventory_core import InventoryRuleError, validate_direction

from .movement_schema import EVENT_TYPES


class MovementWriteError(RuntimeError):
    def __init__(self, code: str, message: str = "", *, risk_code: str | None = None):
        super().__init__(f"{code}: {message}" if message else code)
        self.code = code
        self.message = message
        # 写入程序自报的审核原因，接住异常转成结果的地方原样带出（不再按错误字眼归类）。
        self.risk_code = risk_code


_KIND_OF_TYPE = {"receipt": "inbound", "return": "inbound", "usage": "outbound", "scrap": "outbound", "transfer": "transfer"}
_IDENTITY = ("event_date", "event_type", "product_id", "quantity", "quantity_unit_id", "from_location_id", "to_location_id")
_REVERSAL_COPIES = ("event_type", "product_id", "quantity", "quantity_unit_id", "from_location_id", "to_location_id", "evidence_ref")


# ---- 纯规则 ----------------------------------------------------------------------------

def movement_kind(event_type: str) -> str:
    """收、退是入库；领、废是出库；调拨两头都动。"""

    kind = _KIND_OF_TYPE.get(str(event_type or "").strip())
    if kind is None:
        raise MovementWriteError("event_type_invalid", str(event_type))
    return kind


def check_direction(event_type: str, from_location_id: Any, to_location_id: Any) -> None:
    try:
        validate_direction(movement_kind(event_type), from_location_id, to_location_id)
    except InventoryRuleError as exc:
        raise MovementWriteError("event_direction_invalid", risk_code="business_direction_conflict") from exc


def minimum_running_balance(
    opening: Decimal,
    effects: Iterable[tuple[date, Decimal]],
    proposed: tuple[date, Decimal] | None = None,
) -> Decimal:
    """从期初按日期顺序累加已有增减（调用方已按日期、编号排好），返回途中最低余额。

    ``proposed`` 是要新记的一笔：插在第一条晚于它的日期之前（同日排在已有之后）。"""

    running = minimum = Decimal(opening)
    inserted = proposed is None
    for effect_date, effect in effects:
        if not inserted and effect_date > proposed[0]:
            running += proposed[1]
            minimum = min(minimum, running)
            inserted = True
        running += effect
        minimum = min(minimum, running)
    if not inserted:
        running += proposed[1]
        minimum = min(minimum, running)
    return minimum


# ---- 写入 ------------------------------------------------------------------------------

def _stamp(value: datetime | None = None) -> str:
    # Same text the customer's ORM stores for a naive DateTime.
    return (value or datetime.now(UTC).replace(tzinfo=None)).strftime("%Y-%m-%d %H:%M:%S.%f")


def _bind(value: Any) -> Any:
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, Decimal):
        return format(value, "f")
    if isinstance(value, datetime):
        return _stamp(value)
    if isinstance(value, date):
        return value.isoformat()
    return value


def _comparable(value: Any) -> Any:
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, (int, float, Decimal)):
        return Decimal(str(value)).normalize()
    if isinstance(value, (date, datetime)):
        return _bind(value)
    return value


def _columns(connection: sqlite3.Connection) -> dict[str, tuple[bool, bool]]:
    """列名 → (NOT NULL, 是文字列)；客户扩展列也在里面。"""

    return {
        str(row[1]): (bool(row[3]), any(word in str(row[2]).upper() for word in ("CHAR", "TEXT")))
        for row in connection.execute("PRAGMA table_info(material_inventory_events)")
    }


def _insert(connection: sqlite3.Connection, values: Mapping[str, Any], *, now: str) -> int:
    columns = _columns(connection)
    unknown = sorted(set(values) - set(columns))
    if unknown:
        raise MovementWriteError("inventory_movement_column_unknown", str(unknown))
    row = {key: _bind(value) for key, value in values.items()}
    row.setdefault("created_at", now)
    for name, (not_null, text) in columns.items():
        if not_null and text and row.get(name) is None and name != "id":
            row[name] = ""
    names = sorted(row)
    cursor = connection.execute(
        f"INSERT INTO material_inventory_events ({', '.join(names)}) VALUES ({', '.join('?' for _ in names)})",
        tuple(row[name] for name in names),
    )
    return int(cursor.lastrowid)


def _row(connection: sqlite3.Connection, sql: str, params: tuple) -> sqlite3.Row | None:
    connection.row_factory = sqlite3.Row
    return connection.execute(sql, params).fetchone()


def _source_key(value: Any) -> str:
    key = str(value or "").strip()
    if not key or len(key) > 500:
        raise MovementWriteError("source_record_key_invalid")
    return key


def record_movement(
    connection: sqlite3.Connection,
    values: Mapping[str, Any],
    *,
    identity: Iterable[str] = (),
    now: datetime | None = None,
) -> tuple[int, bool]:
    """记一笔流水。同一来源键已有同样一笔时零写入返回 (原编号, False)；内容不同拒绝。

    ``identity`` 是客户扩展里也参与“同样一笔”判断的列（如首家客户的物料品目）。"""

    row = dict(values)
    row["event_type"] = str(row.get("event_type") or "").strip()
    check_direction(row["event_type"], row.get("from_location_id"), row.get("to_location_id"))
    try:
        quantity = Decimal(str(row.get("quantity")))
    except (InvalidOperation, ValueError, TypeError) as exc:
        raise MovementWriteError("quantity_invalid", risk_code="numeric_closure_failed") from exc
    if not quantity.is_finite() or quantity <= 0:
        raise MovementWriteError("quantity_invalid", risk_code="numeric_closure_failed")
    row["quantity"] = quantity
    row["source_record_key"] = _source_key(row.get("source_record_key"))
    row.setdefault("source_kind", "manual")
    row.setdefault("evidence_ref", "")
    row.setdefault("status", "confirmed")
    row.setdefault("notes", "")
    row.setdefault("created_by", "system")
    row["is_reversal"] = False
    row["reverses_event_id"] = None
    existing = _row(connection, "SELECT * FROM material_inventory_events WHERE source_record_key=?", (row["source_record_key"],))
    if existing is not None:
        same = not existing["is_reversal"] and all(
            _comparable(existing[name]) == _comparable(row.get(name)) for name in (*_IDENTITY, *identity)
        )
        if not same:
            raise MovementWriteError("source_record_key_conflict", row["source_record_key"],
                                     risk_code="duplicate_identity_conflict")
        return int(existing["id"]), False
    return _insert(connection, row, now=_stamp(now)), True


def reverse_movement(
    connection: sqlite3.Connection,
    original_id: int,
    *,
    event_date: date,
    source_record_key: str,
    reason: str,
    created_by: str = "system",
    extra: Mapping[str, Any] | None = None,
    now: datetime | None = None,
) -> tuple[int, bool]:
    """按原行追加一条冲销行、原行状态改 reversed。已按同一来源键冲销过的零写入返回 (冲销行编号, False)。

    ``extra`` 是客户扩展列的取值（如首家客户的物料品目、主数据状态）；标准列从原行照抄。"""

    original = _row(connection, "SELECT * FROM material_inventory_events WHERE id=?", (int(original_id),))
    if original is None or original["is_reversal"]:
        raise MovementWriteError("reversal_target_invalid", str(original_id), risk_code="owner_lifecycle_conflict")
    if not str(reason or "").strip():
        raise MovementWriteError("reversal_reason_required")
    if event_date.isoformat() < str(original["event_date"]):
        raise MovementWriteError("reversal_date_before_original")
    source_record_key = _source_key(source_record_key)
    existing = _row(connection, "SELECT id, source_record_key FROM material_inventory_events WHERE reverses_event_id=?", (int(original_id),))
    if existing is not None:
        if str(existing["source_record_key"]) != source_record_key:
            raise MovementWriteError("event_already_reversed", str(original_id), risk_code="owner_lifecycle_conflict")
        return int(existing["id"]), False
    if _row(connection, "SELECT 1 FROM material_inventory_events WHERE source_record_key=?", (source_record_key,)):
        raise MovementWriteError("source_record_key_conflict", source_record_key, risk_code="duplicate_identity_conflict")
    values = {name: original[name] for name in _REVERSAL_COPIES}
    values.update({
        "event_date": event_date, "source_kind": "reversal", "source_record_key": source_record_key,
        "is_reversal": True, "reverses_event_id": int(original_id), "status": "confirmed",
        "notes": str(reason).strip(), "created_by": str(created_by or "system")[:120],
        **dict(extra or {}),
    })
    stamp = _stamp(now)
    reversal_id = _insert(connection, values, now=stamp)
    connection.execute("UPDATE material_inventory_events SET status='reversed' WHERE id=?", (int(original_id),))
    return reversal_id, True


_FIXED = frozenset({*_IDENTITY, "status", "is_reversal", "reverses_event_id", "source_record_key"})


def fill_blanks(connection: sqlite3.Connection, event_id: int, values: Mapping[str, Any]) -> int:
    """给已记的一笔补上还空着的登记列（来源、备注、单据号等）。业务列不许改，已有值的列不覆盖。"""

    fixed = sorted(set(values) & _FIXED)
    if fixed:
        raise MovementWriteError("inventory_movement_column_fixed", str(fixed))
    unknown = sorted(set(values) - set(_columns(connection)))
    if unknown:
        raise MovementWriteError("inventory_movement_column_unknown", str(unknown))
    return sum(
        connection.execute(
            f"UPDATE material_inventory_events SET {name}=? WHERE id=? AND ({name} IS NULL OR {name}='')",
            (_bind(value), int(event_id)),
        ).rowcount
        for name, value in values.items()
    )


__all__ = [
    "EVENT_TYPES",
    "MovementWriteError",
    "check_direction",
    "fill_blanks",
    "minimum_running_balance",
    "movement_kind",
    "record_movement",
    "reverse_movement",
]
