"""Customer-neutral, cent-exact per-gram pricing; no storage or write authority."""
from __future__ import annotations

from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from typing import Any, Mapping, Sequence


def _number(value: Any, field: str, *, zero: bool = False) -> Decimal:
    try:
        number = Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError) as exc:
        raise ValueError(f"invalid {field}") from exc
    if not number.is_finite() or number < 0 or (not zero and number == 0):
        raise ValueError(f"invalid {field}")
    return number


def calculate_segmented_pricing(segments: Sequence[Mapping[str, Any]], *, quantity_g: Any) -> dict[str, Any]:
    """Sum cent-rounded source lines; never reconstruct money from a blended price.

    A segment without an invoice must explicitly carry a decision reference.
    Source identities are unique within an order to prevent counting a line twice.
    """
    quantity = _number(quantity_g, "quantity_g")
    if not isinstance(segments, (list, tuple)) or not segments:
        raise ValueError("pricing segments required")
    lines: list[dict[str, Any]] = []
    sources: set[tuple[str, str]] = set()
    total_weight = Decimal("0")
    for segment in segments:
        if not isinstance(segment, Mapping):
            raise ValueError("invalid pricing segment")
        weight = _number(segment.get("weight_g"), "weight_g")
        price = _number(segment.get("input_unit_price"), "input_unit_price")
        rate = _number(segment.get("tax_rate"), "tax_rate", zero=True)
        if rate > 1:
            raise ValueError("invalid tax_rate")
        source = segment.get("source")
        if not isinstance(source, Mapping):
            raise ValueError("pricing segment source required")
        invoice = str(source.get("invoice_number") or "").strip()
        line = str(source.get("line") or "").strip()
        decision = str(source.get("decision_ref") or "").strip()
        if not line or (not invoice and not decision):
            raise ValueError("invoice number and line or decision reference required")
        identity = (invoice or decision, line)
        if identity in sources:
            raise ValueError("duplicate pricing segment source")
        sources.add(identity)
        pretax = (weight * price).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        tax = (pretax * rate).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        calculated_tax = tax
        if segment.get("source_tax_amount") is not None:
            source_tax = _number(segment["source_tax_amount"], "source_tax_amount", zero=True)
            if not invoice or source_tax != source_tax.quantize(Decimal("0.01")) or abs(source_tax - tax) > Decimal("0.01"):
                raise ValueError("source tax must be invoice-backed cents within one cent of calculated tax")
            tax = source_tax
        lines.append({"weight_g": str(weight), "input_unit_price": str(price), "tax_rate": str(rate),
                      "source": dict(source), "pretax_amount": str(pretax), "tax_amount": str(tax),
                      "receivable": str(pretax + tax),
                      **({"source_tax_amount": str(tax), "calculated_tax_amount": str(calculated_tax)}
                         if segment.get("source_tax_amount") is not None else {})})
        total_weight += weight
    if total_weight != quantity:
        raise ValueError("pricing segment weights must equal outbound weight")
    return {"segments": lines, "quantity_g": str(quantity),
            **{field: str(sum((Decimal(line[field]) for line in lines), Decimal("0.00")))
               for field in ("pretax_amount", "tax_amount", "receivable")}}
