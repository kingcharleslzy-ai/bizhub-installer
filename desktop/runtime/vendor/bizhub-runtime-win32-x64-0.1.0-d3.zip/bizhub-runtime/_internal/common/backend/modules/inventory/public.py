"""Stable read and action facade for generic inventory."""

from __future__ import annotations

from backend.kernel.profile_registry import StorageTarget, read_storage, storage_connect

import sqlite3
from collections import defaultdict
from pathlib import Path
from typing import Any

from .contracts import InventoryCommand, InventoryPreview
from .stocktake_ledger import InventoryLedgerStocktake
from .owner import (
    InventoryOwnerError,
    balance_as_of,
    _ROWS_SQL,
    _movement_row,
    _rows,
    project_balance,
    apply_preview,
    apply_preview_in_transaction,
    preview_action,
    preview_action_in_transaction,
    read_action,
    read_action_in_transaction,
)


def _connect(path: Path) -> sqlite3.Connection:
    connection = storage_connect(f"file:{path}?mode=ro", uri=True)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys=ON")
    connection.execute("PRAGMA query_only=ON")
    return connection


def list_movements(storage: StorageTarget, *, limit: int = 100) -> list[dict[str, Any]]:
    with read_storage(storage, _connect) as connection:
        return [
            _movement_row(row)
            for row in connection.execute(
                _ROWS_SQL + " ORDER BY m.occurred_at DESC, m.movement_id DESC LIMIT ?",
                (max(1, min(int(limit), 500)),),
            )
        ]


def list_balances(storage: StorageTarget) -> list[dict[str, Any]]:
    """Return the complete book balance per product, unit and location."""
    movements = defaultdict(list)
    with read_storage(storage, _connect) as connection:
        for row in _rows(connection):
            for location in {row["from_location_id"], row["to_location_id"]} - {None}:
                movements[(row["product_id"], row["unit_id"], location)].append(row)
    balances = []
    for (product, unit, location), rows in sorted(movements.items()):
        quantity = project_balance(rows, product_id=product, unit_id=unit, location_id=location)
        balances.append({"product_id": product, "unit_id": unit, "location_id": location, "quantity": format(quantity, "f")})
    return balances


def get_balance(
    storage: StorageTarget,
    *,
    product_id: int,
    unit_id: int,
    location_id: str,
) -> dict[str, str]:
    with read_storage(storage, _connect) as connection:
        rows = _rows(connection)
    return {
        "product_id": product_id,
        "unit_id": unit_id,
        "location_id": location_id,
        "quantity": format(project_balance(rows, product_id=product_id, unit_id=unit_id, location_id=location_id), "f"),
    }


__all__ = [
    "InventoryCommand",
    "InventoryLedgerStocktake",
    "InventoryOwnerError",
    "InventoryPreview",
    "apply_preview",
    "apply_preview_in_transaction",
    "balance_as_of",
    "get_balance",
    "list_movements",
    "list_balances",
    "project_balance",
    "preview_action",
    "preview_action_in_transaction",
    "read_action",
    "read_action_in_transaction",
]

from . import location_schema, movement_schema, movement_writes, stock_move_schema  # noqa: E402
from .stock_ledger import (  # noqa: E402
    OPENING_SOURCE,
    Anchor,
    LedgerMove,
    cancel_stock_moves,
    insert_stock_moves,
    OpeningHistory,
    OpeningLine,
    OutboundCheck,
    OutboundStockRule,
    POOL_GAIN_REASON,
    PoolDraw,
    PoolLot,
    StockCountBasis,
    ProcessingMove,
    ProcessingRule,
    ProcessingSettlement,
    ProcessingSites,
    StockLedgerRules,
    StockSourceRule,
    count_rows,
    draw_from_pool,
    pool_identity,
    external_material_balances,
    latest_counts,
    move_sort_key,
    net_quantity,
    opening_date,
    opening_history,
    opening_history_digest,
    opening_window,
    outbound_checks,
    post_counts,
    post_opening,
    post_opening_history,
    carry_residual,
    read_moves,
    resolve,
    roll,
    settle_processing,
    stock_source_spec,
    stored_move,
    theory,
)

__all__ += [
    "cancel_stock_moves", "insert_stock_moves",
    "Anchor", "LedgerMove", "OPENING_SOURCE", "OpeningHistory", "OpeningLine", "ProcessingMove", "ProcessingRule",
    "ProcessingSettlement", "ProcessingSites", "StockLedgerRules", "carry_residual", "settle_processing", "StockSourceRule", "opening_date", "opening_history", "opening_history_digest",
    "opening_window", "stock_source_spec", "POOL_GAIN_REASON", "PoolDraw", "PoolLot", "StockCountBasis", "draw_from_pool", "pool_identity", "OutboundCheck", "OutboundStockRule", "outbound_checks",
    "post_opening", "post_opening_history", "count_rows", "latest_counts", "location_schema", "move_sort_key",
    "movement_schema", "movement_writes", "net_quantity", "post_counts", "read_moves", "resolve", "roll",
    "stock_move_schema", "stored_move", "theory", "external_material_balances",
]
