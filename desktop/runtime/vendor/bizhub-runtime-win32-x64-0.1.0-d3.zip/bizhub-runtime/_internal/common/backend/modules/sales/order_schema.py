"""销售单标准表：单头（一条来源消息一张）、明细（一行一个产品 / 规格 / 数量）、发货流水。

和采购单标准表同一套做法（``procurement.order_schema``）：这里是唯一定义，列名取首家客户生产库现在的写法
（单头 ``sales_batches``、明细 ``sales_orders``），客户库里的同名表必须等于"标准表 + 该客户登记的扩展"，
由一致性检查逐项核对；通用独立小库的文字键放在它自己的扩展里。

- 单头：业务日、状态（只进不退：open → partially_fulfilled → fulfilled，中途可 partially_returned / returned，
  或 cancelled）、备注。客户放在明细上（一条消息可能是几个客户），单头不存客户。
- 明细：挂哪张单头、第几行、客户、产品与规格、数量（数值 + 单位）、单价、应收、业务日 / 发货日、备注。
  数量文字、定价细节、来源、状态机都是客户扩展。
- 发货流水：哪张明细、发货还是退货、数量（+ 单位）、对应的库存流水、业务日、来源。首家客户第一轮不建
  这张表（发货事实仍是明细发货日 + 库存流水），通用小库用它。
"""

from __future__ import annotations

from backend.modules.master_data.schema import Check, Column, ExpressionCheck, ForeignKey, Index, Table, create_table_sql

BATCHES = "sales_batches"
LINES = "sales_orders"
FULFILLMENTS = "sales_fulfillments"
ORDER_STATUSES = ("open", "partially_fulfilled", "fulfilled", "partially_returned", "returned", "cancelled")
FULFILLMENT_KINDS = ("shipment", "return")


def _c(name: str, type_: str, *, nullable: bool = False, default: str | None = None) -> Column:
    return Column(name, type_, nullable, default)


SALES_BATCHES = Table(
    BATCHES,
    (
        _c("id", "INTEGER"),
        _c("business_date", "DATE", nullable=True),
        _c("status", "VARCHAR(30)", default="open"),
        _c("notes", "TEXT", nullable=True),
        _c("created_at", "DATETIME"),
    ),
    checks=(Check("ck_sales_batches_status", "status", ORDER_STATUSES),),
)

SALES_ORDERS = Table(
    LINES,
    (
        _c("id", "INTEGER"),
        _c("batch_id", "INTEGER"),
        _c("seq_no", "INTEGER", nullable=True),
        _c("customer_party_id", "INTEGER", nullable=True),
        _c("product_id", "INTEGER", nullable=True),
        _c("product_name", "VARCHAR(200)", nullable=True),
        _c("spec", "VARCHAR(50)", nullable=True),
        _c("quantity_num", "NUMERIC", nullable=True),
        _c("quantity_unit_id", "INTEGER", nullable=True),
        _c("unit_price", "NUMERIC", nullable=True),
        _c("receivable", "NUMERIC", nullable=True),
        _c("business_date", "DATE", nullable=True),
        _c("ship_date", "DATE", nullable=True),
        _c("notes", "TEXT", nullable=True),
        _c("created_at", "DATETIME"),
    ),
    foreign_keys=(
        ForeignKey("batch_id", BATCHES, "id", "NO ACTION"),
        ForeignKey("customer_party_id", "business_parties", "id", "SET NULL"),
        ForeignKey("product_id", "products", "id", "SET NULL"),
        ForeignKey("quantity_unit_id", "measurement_units", "id", "SET NULL"),
    ),
    indexes=(Index("ix_sales_orders_customer_party", ("customer_party_id",)),),
)

SALES_FULFILLMENTS = Table(
    FULFILLMENTS,
    (
        _c("id", "INTEGER"),
        _c("sales_order_id", "INTEGER"),
        _c("fulfillment_kind", "VARCHAR(20)"),
        _c("quantity", "NUMERIC"),
        _c("quantity_unit_id", "INTEGER", nullable=True),
        _c("event_id", "INTEGER", nullable=True),
        _c("business_date", "DATE", nullable=True),
        _c("source_kind", "VARCHAR(60)", default=""),
        _c("source_ref", "TEXT", default=""),
        _c("notes", "TEXT", nullable=True),
        _c("created_at", "DATETIME"),
    ),
    checks=(Check("ck_sales_fulfillments_kind", "fulfillment_kind", FULFILLMENT_KINDS),),
    expression_checks=(ExpressionCheck("ck_sales_fulfillments_positive", "quantity > 0"),),
    foreign_keys=(
        ForeignKey("sales_order_id", LINES, "id", "RESTRICT"),
        ForeignKey("quantity_unit_id", "measurement_units", "id", "SET NULL"),
        ForeignKey("event_id", "material_inventory_events", "id", "RESTRICT"),
    ),
    indexes=(Index("ix_sales_fulfillments_order", ("sales_order_id", "fulfillment_kind")),),
)

ORDER_STANDARD_TABLES: tuple[Table, ...] = (SALES_BATCHES, SALES_ORDERS)
FULFILLMENT_STANDARD_TABLES: tuple[Table, ...] = (SALES_FULFILLMENTS,)


def order_schema_sql() -> tuple[str, ...]:
    return tuple(statement for table in ORDER_STANDARD_TABLES for statement in create_table_sql(table))


def fulfillment_schema_sql() -> tuple[str, ...]:
    return tuple(statement for table in FULFILLMENT_STANDARD_TABLES for statement in create_table_sql(table))


__all__ = [
    "BATCHES",
    "FULFILLMENTS",
    "FULFILLMENT_KINDS",
    "FULFILLMENT_STANDARD_TABLES",
    "LINES",
    "ORDER_STANDARD_TABLES",
    "ORDER_STATUSES",
    "SALES_BATCHES",
    "SALES_FULFILLMENTS",
    "SALES_ORDERS",
    "fulfillment_schema_sql",
    "order_schema_sql",
]
