"""单据目录里的通用文字提示词：补发、更正（``document.catalog.master_data``）。

同一张单据再发一次（补发明细、重发截图）挂原单作补充证据，不新写；事实不同才走更正。
这组词不随企业变，由本模块统一交给单据目录；各类单据的关键字段、窗口与容差由登记
它的模块声明。
"""

from __future__ import annotations

SUPPLEMENT_WORDS = ("补发", "重发", "再发", "补充")
CORRECTION_WORDS = ("更正", "修正", "改正", "纠正", "订正", "发错")


def document_catalog_contribution():
    from backend.kernel.runtime.public import DocumentCatalogContribution

    from .manifest import MODULE_ID

    return DocumentCatalogContribution(
        module_id=MODULE_ID,
        supplement_words=SUPPLEMENT_WORDS,
        correction_words=CORRECTION_WORDS,
    )


def existing_document_prompt_rule_zh() -> str:
    """One prompt sentence generated from the catalog."""

    return (
        "补发、重发的明细或截图（如写明“"
        + "/".join(SUPPLEMENT_WORDS[:2])
        + "”）照常读出单据事实（编号、重量、运单号等）；服务端按单据类型的关键字段"
        "对照既有正式单据，唯一对上即挂为补充证据、不新增写入，与原单事实不同才转更正。"
    )


__all__ = ["CORRECTION_WORDS", "SUPPLEMENT_WORDS", "document_catalog_contribution", "existing_document_prompt_rule_zh"]
