"""Atomic migration governance for the independent generic-kernel lineage."""

from __future__ import annotations

from backend.kernel.profile_registry import storage_connect

import hashlib
import json
import os
import sqlite3
import uuid
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Iterable, Iterator, Sequence

from backend.modules.master_data.schema import EXTERNAL_IDENTITIES_DDL, standard_schema_sql

from .models import MODEL_TABLES


PROFILE_ID = "generic-kernel-smoke"
LINEAGE_ID = "generic-kernel"


class GenericKernelDatabaseError(RuntimeError):
    def __init__(self, code: str, message: str):
        super().__init__(f"{code}: {message}")
        self.code = code
        self.message = message


def _canonical(payload: object) -> bytes:
    return (json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n").encode()


def _digest(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


@dataclass(frozen=True)
class KernelMigration:
    version: int
    migration_id: str
    dependencies: tuple[str, ...]
    statements: tuple[str, ...]
    owner_ref: str = "generic.kernel_smoke:runtime"
    # SQLite 改不了的列按“建新表 → 搬数据 → 删旧表 → 换名”重建：期间关外键，
    # 整批改完后做全库外键自检再提交。只影响执行方式，不进 checksum。
    rebuilds_tables: bool = False

    @property
    def checksum(self) -> str:
        return _digest(
            _canonical(
                {
                    "lineage_id": LINEAGE_ID,
                    "version": self.version,
                    "migration_id": self.migration_id,
                    "dependencies": list(self.dependencies),
                    "statements": list(self.statements),
                }
            )
        )

    def descriptor(self) -> dict[str, object]:
        return {
            "version": self.version,
            "migration_id": self.migration_id,
            "owner_ref": self.owner_ref,
            "dependencies": list(self.dependencies),
            "checksum": self.checksum,
        }


MIGRATIONS: tuple[KernelMigration, ...] = (
    KernelMigration(
        version=1,
        migration_id="generic-kernel-baseline-v1",
        owner_ref="generic.kernel_smoke:runtime",
        dependencies=(),
        statements=(
            """CREATE TABLE kernel_instance_metadata (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            )""",
            """CREATE TABLE kernel_migration_ledger (
                lineage_id TEXT NOT NULL,
                migration_version INTEGER NOT NULL,
                migration_id TEXT NOT NULL,
                checksum TEXT NOT NULL,
                applied_at TEXT NOT NULL,
                PRIMARY KEY (lineage_id, migration_version),
                UNIQUE (lineage_id, migration_id)
            )""",
            """CREATE TABLE kernel_audit_events (
                event_id TEXT PRIMARY KEY,
                event_type TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                created_at TEXT NOT NULL
            )""",
        ),
    ),
    KernelMigration(
        version=2,
        migration_id="generic-master-data-catalog-v1",
        owner_ref="master_data:catalog-owner",
        dependencies=("generic-kernel-baseline-v1",),
        statements=(
            *standard_schema_sql(),
            """CREATE TABLE location_catalog (
                location_id TEXT PRIMARY KEY,
                canonical_name TEXT NOT NULL,
                normalized_name TEXT NOT NULL UNIQUE,
                status TEXT NOT NULL CHECK(status IN ('active', 'deprecated')),
                attributes_json TEXT NOT NULL
            )""",
            *EXTERNAL_IDENTITIES_DDL,
        ),
    ),
    KernelMigration(
        version=3,
        migration_id="generic-inventory-core-v1",
        owner_ref="inventory:movement-owner",
        dependencies=("generic-master-data-catalog-v1",),
        statements=(
            """CREATE TABLE inventory_movements (
                movement_id TEXT PRIMARY KEY,
                movement_kind TEXT NOT NULL CHECK(movement_kind IN (
                    'inbound', 'outbound', 'transfer', 'stocktake_adjustment', 'reversal', 'correction'
                )),
                product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
                unit_id INTEGER NOT NULL REFERENCES measurement_units(id) ON DELETE RESTRICT,
                quantity NUMERIC NOT NULL CHECK(quantity > 0),
                from_location_id TEXT REFERENCES location_catalog(location_id) ON DELETE RESTRICT,
                to_location_id TEXT REFERENCES location_catalog(location_id) ON DELETE RESTRICT,
                reverses_movement_id TEXT UNIQUE REFERENCES inventory_movements(movement_id) ON DELETE RESTRICT,
                occurred_at TEXT NOT NULL,
                source_ref TEXT NOT NULL,
                reason TEXT NOT NULL,
                CHECK(
                    (from_location_id IS NULL AND to_location_id IS NOT NULL) OR
                    (from_location_id IS NOT NULL AND to_location_id IS NULL) OR
                    (from_location_id IS NOT NULL AND to_location_id IS NOT NULL AND from_location_id <> to_location_id)
                )
            )""",
            """CREATE INDEX ix_inventory_movements_product_unit_time
                ON inventory_movements(product_id, unit_id, occurred_at, movement_id)""",
            """CREATE INDEX ix_inventory_movements_from_location
                ON inventory_movements(from_location_id, product_id, unit_id)""",
            """CREATE INDEX ix_inventory_movements_to_location
                ON inventory_movements(to_location_id, product_id, unit_id)""",
            """CREATE TRIGGER inventory_movements_immutable_update
                BEFORE UPDATE ON inventory_movements
                BEGIN SELECT RAISE(ABORT, 'inventory_movements_immutable'); END""",
            """CREATE TRIGGER inventory_movements_immutable_delete
                BEFORE DELETE ON inventory_movements
                BEGIN SELECT RAISE(ABORT, 'inventory_movements_immutable'); END""",
            """CREATE TABLE inventory_stocktakes (
                stocktake_id TEXT PRIMARY KEY,
                product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
                unit_id INTEGER NOT NULL REFERENCES measurement_units(id) ON DELETE RESTRICT,
                location_id TEXT NOT NULL REFERENCES location_catalog(location_id) ON DELETE RESTRICT,
                actual_quantity NUMERIC NOT NULL CHECK(actual_quantity >= 0),
                projected_quantity NUMERIC NOT NULL,
                occurred_at TEXT NOT NULL,
                source_ref TEXT NOT NULL
            )""",
            """CREATE TABLE inventory_audit_events (
                event_id TEXT PRIMARY KEY,
                event_type TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                created_at TEXT NOT NULL
            )""",
            """CREATE TABLE inventory_action_receipts (
                action_id TEXT PRIMARY KEY,
                idempotency_key TEXT NOT NULL UNIQUE,
                command_digest TEXT NOT NULL,
                preview_digest TEXT NOT NULL,
                movement_ids_json TEXT NOT NULL,
                stocktake_id TEXT REFERENCES inventory_stocktakes(stocktake_id) ON DELETE RESTRICT,
                audit_event_id TEXT NOT NULL REFERENCES inventory_audit_events(event_id) ON DELETE RESTRICT,
                created_at TEXT NOT NULL
            )""",
        ),
    ),
    KernelMigration(
        version=4,
        migration_id="generic-procurement-v1",
        owner_ref="procurement:order-owner",
        dependencies=("generic-inventory-core-v1",),
        statements=(
            """CREATE TABLE procurement_orders (
                order_id TEXT PRIMARY KEY,
                supplier_party_id INTEGER NOT NULL REFERENCES business_parties(id) ON DELETE RESTRICT,
                ordered_at TEXT NOT NULL,
                status TEXT NOT NULL CHECK(status IN ('open', 'partially_received', 'received', 'cancelled')),
                revision INTEGER NOT NULL CHECK(revision >= 1),
                evidence_refs_json TEXT NOT NULL,
                source_ref TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )""",
            """CREATE TABLE procurement_order_lines (
                line_id TEXT PRIMARY KEY,
                order_id TEXT NOT NULL REFERENCES procurement_orders(order_id) ON DELETE RESTRICT,
                product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
                unit_id INTEGER NOT NULL REFERENCES measurement_units(id) ON DELETE RESTRICT,
                quantity NUMERIC NOT NULL CHECK(quantity > 0),
                received_quantity NUMERIC NOT NULL CHECK(received_quantity >= 0 AND received_quantity <= quantity),
                receive_location_id TEXT NOT NULL REFERENCES location_catalog(location_id) ON DELETE RESTRICT
            )""",
            """CREATE INDEX ix_procurement_order_lines_order
                ON procurement_order_lines(order_id, line_id)""",
            """CREATE TABLE procurement_receipts (
                receipt_id TEXT PRIMARY KEY,
                order_id TEXT NOT NULL REFERENCES procurement_orders(order_id) ON DELETE RESTRICT,
                line_id TEXT NOT NULL REFERENCES procurement_order_lines(line_id) ON DELETE RESTRICT,
                quantity NUMERIC NOT NULL CHECK(quantity > 0),
                inventory_action_id TEXT NOT NULL REFERENCES inventory_action_receipts(action_id) ON DELETE RESTRICT,
                inventory_movement_id TEXT NOT NULL REFERENCES inventory_movements(movement_id) ON DELETE RESTRICT,
                occurred_at TEXT NOT NULL,
                evidence_refs_json TEXT NOT NULL
            )""",
            """CREATE TABLE procurement_audit_events (
                event_id TEXT PRIMARY KEY,
                event_type TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                created_at TEXT NOT NULL
            )""",
            """CREATE TABLE procurement_action_receipts (
                action_id TEXT PRIMARY KEY,
                idempotency_key TEXT NOT NULL UNIQUE,
                command_digest TEXT NOT NULL,
                preview_digest TEXT NOT NULL,
                order_id TEXT NOT NULL REFERENCES procurement_orders(order_id) ON DELETE RESTRICT,
                audit_event_id TEXT NOT NULL REFERENCES procurement_audit_events(event_id) ON DELETE RESTRICT,
                inventory_action_id TEXT REFERENCES inventory_action_receipts(action_id) ON DELETE RESTRICT,
                created_at TEXT NOT NULL
            )""",
        ),
    ),
    KernelMigration(
        version=5,
        migration_id="generic-sales-v1",
        owner_ref="sales:order-owner",
        dependencies=("generic-procurement-v1",),
        statements=(
            """CREATE TABLE sales_orders (
                order_id TEXT PRIMARY KEY,
                customer_party_id INTEGER NOT NULL REFERENCES business_parties(id) ON DELETE RESTRICT,
                ordered_at TEXT NOT NULL,
                status TEXT NOT NULL CHECK(status IN ('open', 'partially_fulfilled', 'fulfilled', 'partially_returned', 'returned', 'cancelled')),
                revision INTEGER NOT NULL CHECK(revision >= 1),
                evidence_refs_json TEXT NOT NULL,
                source_ref TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )""",
            """CREATE TABLE sales_order_lines (
                line_id TEXT PRIMARY KEY,
                order_id TEXT NOT NULL REFERENCES sales_orders(order_id) ON DELETE RESTRICT,
                product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
                unit_id INTEGER NOT NULL REFERENCES measurement_units(id) ON DELETE RESTRICT,
                quantity NUMERIC NOT NULL CHECK(quantity > 0),
                fulfilled_quantity NUMERIC NOT NULL CHECK(fulfilled_quantity >= 0 AND fulfilled_quantity <= quantity),
                returned_quantity NUMERIC NOT NULL CHECK(returned_quantity >= 0 AND returned_quantity <= fulfilled_quantity),
                ship_from_location_id TEXT NOT NULL REFERENCES location_catalog(location_id) ON DELETE RESTRICT
            )""",
            """CREATE INDEX ix_sales_order_lines_order
                ON sales_order_lines(order_id, line_id)""",
            """CREATE TABLE sales_fulfillments (
                fulfillment_id TEXT PRIMARY KEY,
                fulfillment_kind TEXT NOT NULL CHECK(fulfillment_kind IN ('shipment', 'return')),
                order_id TEXT NOT NULL REFERENCES sales_orders(order_id) ON DELETE RESTRICT,
                line_id TEXT NOT NULL REFERENCES sales_order_lines(line_id) ON DELETE RESTRICT,
                quantity NUMERIC NOT NULL CHECK(quantity > 0),
                inventory_action_id TEXT NOT NULL REFERENCES inventory_action_receipts(action_id) ON DELETE RESTRICT,
                inventory_movement_id TEXT NOT NULL REFERENCES inventory_movements(movement_id) ON DELETE RESTRICT,
                occurred_at TEXT NOT NULL,
                evidence_refs_json TEXT NOT NULL
            )""",
            """CREATE TABLE sales_audit_events (
                event_id TEXT PRIMARY KEY,
                event_type TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                created_at TEXT NOT NULL
            )""",
            """CREATE TABLE sales_action_receipts (
                action_id TEXT PRIMARY KEY,
                idempotency_key TEXT NOT NULL UNIQUE,
                command_digest TEXT NOT NULL,
                preview_digest TEXT NOT NULL,
                order_id TEXT NOT NULL REFERENCES sales_orders(order_id) ON DELETE RESTRICT,
                audit_event_id TEXT NOT NULL REFERENCES sales_audit_events(event_id) ON DELETE RESTRICT,
                inventory_action_id TEXT REFERENCES inventory_action_receipts(action_id) ON DELETE RESTRICT,
                created_at TEXT NOT NULL
            )""",
        ),
    ),
    KernelMigration(
        version=6,
        migration_id="generic-sales-returns-v1",
        owner_ref="sales:order-owner",
        dependencies=("generic-sales-v1",),
        statements=(
            """CREATE TABLE sales_return_cases (
                case_id TEXT PRIMARY KEY,
                order_id TEXT NOT NULL REFERENCES sales_orders(order_id) ON DELETE RESTRICT,
                status TEXT NOT NULL CHECK(status IN ('registered', 'inspected', 'partially_disposed', 'disposed')),
                occurred_at TEXT NOT NULL,
                source_ref TEXT NOT NULL,
                evidence_refs_json TEXT NOT NULL,
                reason TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )""",
            """CREATE TABLE sales_return_case_items (
                case_id TEXT NOT NULL REFERENCES sales_return_cases(case_id) ON DELETE RESTRICT,
                order_line_id TEXT NOT NULL REFERENCES sales_order_lines(line_id) ON DELETE RESTRICT,
                unit_id INTEGER NOT NULL REFERENCES measurement_units(id) ON DELETE RESTRICT,
                quantity NUMERIC NOT NULL CHECK(quantity > 0),
                received_quantity NUMERIC NOT NULL CHECK(received_quantity >= 0 AND received_quantity <= quantity),
                good_quantity NUMERIC NOT NULL CHECK(good_quantity >= 0 AND good_quantity <= received_quantity),
                scrap_quantity NUMERIC NOT NULL CHECK(scrap_quantity >= 0 AND scrap_quantity <= received_quantity),
                disposed_good_quantity NUMERIC NOT NULL CHECK(disposed_good_quantity >= 0 AND disposed_good_quantity <= good_quantity),
                disposed_scrap_quantity NUMERIC NOT NULL CHECK(disposed_scrap_quantity >= 0 AND disposed_scrap_quantity <= scrap_quantity),
                PRIMARY KEY(case_id, order_line_id)
            )""",
            """CREATE TABLE sales_return_case_events (
                event_id TEXT PRIMARY KEY,
                case_id TEXT NOT NULL REFERENCES sales_return_cases(case_id) ON DELETE RESTRICT,
                action TEXT NOT NULL CHECK(action IN ('register', 'inspect', 'dispose')),
                occurred_at TEXT NOT NULL,
                source_ref TEXT NOT NULL,
                evidence_refs_json TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                created_at TEXT NOT NULL
            )""",
            """CREATE TABLE sales_document_action_receipts (
                action_id TEXT PRIMARY KEY,
                idempotency_key TEXT NOT NULL UNIQUE,
                command_digest TEXT NOT NULL,
                preview_digest TEXT NOT NULL,
                document_kind TEXT NOT NULL,
                document_id TEXT NOT NULL,
                order_id TEXT REFERENCES sales_orders(order_id) ON DELETE RESTRICT,
                audit_event_id TEXT NOT NULL REFERENCES sales_audit_events(event_id) ON DELETE RESTRICT,
                created_at TEXT NOT NULL
            )""",
        ),
    ),
    KernelMigration(
        version=7,
        migration_id="generic-sales-invoices-v1",
        owner_ref="sales:order-owner",
        dependencies=("generic-sales-returns-v1",),
        statements=(
            """CREATE TABLE sales_invoices (
                invoice_id TEXT PRIMARY KEY,
                kind TEXT NOT NULL CHECK(kind IN ('invoice', 'credit_note')),
                document_number TEXT NOT NULL,
                customer_party_id INTEGER NOT NULL REFERENCES business_parties(id) ON DELETE RESTRICT,
                currency TEXT NOT NULL CHECK(currency IN ('CNY', 'USD', 'EUR')),
                business_date TEXT NOT NULL,
                amount TEXT NOT NULL,
                original_invoice_id TEXT REFERENCES sales_invoices(invoice_id) ON DELETE RESTRICT,
                return_case_id TEXT REFERENCES sales_return_cases(case_id) ON DELETE RESTRICT,
                source_ref TEXT NOT NULL,
                evidence_refs_json TEXT NOT NULL,
                created_at TEXT NOT NULL,
                UNIQUE(customer_party_id, document_number),
                CHECK((kind='invoice' AND original_invoice_id IS NULL AND return_case_id IS NULL)
                   OR (kind='credit_note' AND original_invoice_id IS NOT NULL))
            )""",
            """CREATE INDEX ix_sales_invoices_original ON sales_invoices(original_invoice_id)""",
            """CREATE TABLE sales_invoice_lines (
                invoice_id TEXT NOT NULL REFERENCES sales_invoices(invoice_id) ON DELETE RESTRICT,
                line_id TEXT NOT NULL,
                amount TEXT NOT NULL,
                order_id TEXT REFERENCES sales_orders(order_id) ON DELETE RESTRICT,
                order_line_id TEXT REFERENCES sales_order_lines(line_id) ON DELETE RESTRICT,
                tax_rate TEXT,
                tax_amount TEXT,
                PRIMARY KEY(invoice_id, line_id),
                CHECK(order_line_id IS NULL OR order_id IS NOT NULL)
            )""",
        ),
    ),
    KernelMigration(
        version=8,
        migration_id="generic-sales-payments-v1",
        owner_ref="sales:order-owner",
        dependencies=("generic-sales-invoices-v1",),
        statements=(
            """CREATE TABLE sales_payments (
                payment_id TEXT PRIMARY KEY,
                business_identity TEXT NOT NULL UNIQUE,
                customer_party_id INTEGER REFERENCES business_parties(id) ON DELETE RESTRICT,
                currency TEXT NOT NULL CHECK(currency IN ('CNY', 'USD', 'EUR')),
                amount TEXT NOT NULL,
                channel TEXT NOT NULL,
                external_reference TEXT,
                reference_missing INTEGER NOT NULL CHECK(reference_missing IN (0, 1)),
                received_at TEXT NOT NULL,
                received_date TEXT NOT NULL,
                business_at TEXT NOT NULL,
                source_ref TEXT NOT NULL,
                evidence_refs_json TEXT NOT NULL,
                created_at TEXT NOT NULL,
                CHECK((external_reference IS NOT NULL AND reference_missing=0)
                   OR (external_reference IS NULL AND reference_missing=1))
            )""",
            """CREATE TABLE sales_payment_allocations (
                allocation_id TEXT PRIMARY KEY,
                payment_id TEXT NOT NULL REFERENCES sales_payments(payment_id) ON DELETE RESTRICT,
                invoice_id TEXT NOT NULL REFERENCES sales_invoices(invoice_id) ON DELETE RESTRICT,
                amount TEXT NOT NULL,
                active INTEGER NOT NULL CHECK(active IN (0, 1)),
                source_ref TEXT NOT NULL,
                evidence_refs_json TEXT NOT NULL,
                created_at TEXT NOT NULL,
                revoked_at TEXT,
                revoked_action_id TEXT REFERENCES sales_document_action_receipts(action_id) ON DELETE RESTRICT,
                CHECK((active=1 AND revoked_at IS NULL AND revoked_action_id IS NULL)
                   OR (active=0 AND revoked_at IS NOT NULL AND revoked_action_id IS NOT NULL))
            )""",
            "CREATE INDEX ix_sales_payment_allocations_invoice ON sales_payment_allocations(invoice_id, active)",
            "CREATE INDEX ix_sales_payment_allocations_payment ON sales_payment_allocations(payment_id, active)",
        ),
    ),
    KernelMigration(
        version=9,
        migration_id="generic-procurement-receipts-v1",
        owner_ref="procurement:order-owner",
        rebuilds_tables=True,
        dependencies=("generic-procurement-v1",),
        statements=(
            """ALTER TABLE inventory_movements ADD COLUMN quantity_text TEXT""",
            """CREATE TABLE procurement_receipt_documents (
                document_id TEXT PRIMARY KEY,
                supplier_party_id INTEGER NOT NULL REFERENCES business_parties(id) ON DELETE RESTRICT,
                source_identity TEXT NOT NULL,
                occurred_at TEXT NOT NULL,
                source_ref TEXT NOT NULL,
                evidence_refs_json TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                UNIQUE(supplier_party_id, source_identity)
            )""",
            """CREATE TABLE procurement_receipt_lines (
                line_id TEXT PRIMARY KEY,
                document_id TEXT NOT NULL REFERENCES procurement_receipt_documents(document_id) ON DELETE RESTRICT,
                product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
                unit_id INTEGER NOT NULL REFERENCES measurement_units(id) ON DELETE RESTRICT,
                order_line_id TEXT REFERENCES procurement_order_lines(line_id) ON DELETE RESTRICT,
                arrived_quantity TEXT NOT NULL,
                received_quantity TEXT NOT NULL,
                accepted_quantity TEXT NOT NULL DEFAULT '0',
                rejected_quantity TEXT NOT NULL DEFAULT '0',
                inspected_at TEXT,
                inspection_evidence_refs_json TEXT
            )""",
            """CREATE INDEX ix_procurement_receipt_lines_document ON procurement_receipt_lines(document_id, line_id)""",
            """CREATE TABLE procurement_order_lines_v9 (
                line_id TEXT PRIMARY KEY,
                order_id TEXT NOT NULL REFERENCES procurement_orders(order_id) ON DELETE RESTRICT,
                product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
                unit_id INTEGER NOT NULL REFERENCES measurement_units(id) ON DELETE RESTRICT,
                quantity TEXT NOT NULL CHECK(CAST(quantity AS NUMERIC) > 0),
                received_quantity TEXT NOT NULL CHECK(CAST(received_quantity AS NUMERIC) >= 0),
                receive_location_id TEXT NOT NULL REFERENCES location_catalog(location_id) ON DELETE RESTRICT
            )""",
            """INSERT INTO procurement_order_lines_v9 (line_id, order_id, product_id, unit_id, quantity, received_quantity, receive_location_id) SELECT line_id, order_id, product_id, unit_id, generic_decimal_text(quantity), generic_decimal_text(received_quantity), receive_location_id FROM procurement_order_lines""",
            """DROP TABLE procurement_order_lines""",
            """ALTER TABLE procurement_order_lines_v9 RENAME TO procurement_order_lines""",
            """CREATE INDEX ix_procurement_order_lines_order ON procurement_order_lines(order_id, line_id)""",
            """CREATE TABLE procurement_receipts_v9 (
                receipt_id TEXT PRIMARY KEY,
                order_id TEXT NOT NULL REFERENCES procurement_orders(order_id) ON DELETE RESTRICT,
                line_id TEXT NOT NULL REFERENCES procurement_order_lines(line_id) ON DELETE RESTRICT,
                quantity TEXT NOT NULL CHECK(CAST(quantity AS NUMERIC) > 0),
                inventory_action_id TEXT NOT NULL REFERENCES inventory_action_receipts(action_id) ON DELETE RESTRICT,
                inventory_movement_id TEXT NOT NULL REFERENCES inventory_movements(movement_id) ON DELETE RESTRICT,
                occurred_at TEXT NOT NULL,
                evidence_refs_json TEXT NOT NULL,
                receipt_line_id TEXT REFERENCES procurement_receipt_lines(line_id) ON DELETE RESTRICT,
                over_receipt_allowance TEXT NOT NULL DEFAULT '0'
            )""",
            """INSERT INTO procurement_receipts_v9 (receipt_id, order_id, line_id, quantity, inventory_action_id, inventory_movement_id, occurred_at, evidence_refs_json) SELECT receipt_id, order_id, line_id, generic_decimal_text(quantity), inventory_action_id, inventory_movement_id, occurred_at, evidence_refs_json FROM procurement_receipts""",
            """DROP TABLE procurement_receipts""",
            """ALTER TABLE procurement_receipts_v9 RENAME TO procurement_receipts""",
            """CREATE TABLE procurement_action_receipts_v9 (
                action_id TEXT PRIMARY KEY,
                idempotency_key TEXT NOT NULL UNIQUE,
                command_digest TEXT NOT NULL,
                preview_digest TEXT NOT NULL,
                order_id TEXT REFERENCES procurement_orders(order_id) ON DELETE RESTRICT,
                audit_event_id TEXT NOT NULL REFERENCES procurement_audit_events(event_id) ON DELETE RESTRICT,
                inventory_action_id TEXT REFERENCES inventory_action_receipts(action_id) ON DELETE RESTRICT,
                created_at TEXT NOT NULL,
                document_kind TEXT NOT NULL DEFAULT 'order',
                document_id TEXT NOT NULL DEFAULT ''
            )""",
            """INSERT INTO procurement_action_receipts_v9 (action_id, idempotency_key, command_digest, preview_digest, order_id, audit_event_id, inventory_action_id, created_at) SELECT action_id, idempotency_key, command_digest, preview_digest, order_id, audit_event_id, inventory_action_id, created_at FROM procurement_action_receipts""",
            """DROP TABLE procurement_action_receipts""",
            """ALTER TABLE procurement_action_receipts_v9 RENAME TO procurement_action_receipts""",
        ),
    ),
    KernelMigration(
        version=10,
        migration_id="generic-procurement-invoices-v1",
        owner_ref="procurement:order-owner",
        dependencies=("generic-procurement-receipts-v1",),
        statements=(
            """CREATE TABLE procurement_order_line_terms (
                terms_id TEXT PRIMARY KEY,
                order_line_id TEXT NOT NULL REFERENCES procurement_order_lines(line_id) ON DELETE RESTRICT,
                version INTEGER NOT NULL CHECK(version>0),
                active INTEGER NOT NULL CHECK(active IN (0, 1)),
                currency TEXT NOT NULL,
                pricing_quantity TEXT NOT NULL,
                pricing_unit_id INTEGER NOT NULL REFERENCES measurement_units(id) ON DELETE RESTRICT,
                unit_price TEXT,
                agreed_amount TEXT,
                tax_basis TEXT NOT NULL,
                quantity_tolerance TEXT,
                quantity_tolerance_unit_id INTEGER REFERENCES measurement_units(id) ON DELETE RESTRICT,
                amount_tolerance TEXT,
                amount_tolerance_currency TEXT,
                source_kind TEXT NOT NULL,
                source_ref TEXT NOT NULL,
                evidence_refs_json TEXT NOT NULL,
                created_at TEXT NOT NULL,
                superseded_by TEXT REFERENCES procurement_order_line_terms(terms_id) ON DELETE RESTRICT,
                UNIQUE(order_line_id, version),
                CHECK(unit_price IS NOT NULL OR agreed_amount IS NOT NULL)
            )""",
            "CREATE UNIQUE INDEX ux_procurement_current_terms ON procurement_order_line_terms(order_line_id) WHERE active=1",
            """CREATE TABLE procurement_invoices (
                invoice_id TEXT PRIMARY KEY,
                supplier_party_id INTEGER NOT NULL REFERENCES business_parties(id) ON DELETE RESTRICT,
                external_invoice_number TEXT NOT NULL,
                currency TEXT NOT NULL,
                business_date TEXT NOT NULL,
                tax_basis TEXT NOT NULL,
                total_amount TEXT NOT NULL,
                net_amount TEXT,
                tax_amount TEXT,
                tax_rate TEXT,
                source_ref TEXT NOT NULL,
                evidence_refs_json TEXT NOT NULL,
                created_at TEXT NOT NULL,
                UNIQUE(supplier_party_id, external_invoice_number)
            )""",
            """CREATE TABLE procurement_invoice_lines (
                line_id TEXT PRIMARY KEY,
                invoice_id TEXT NOT NULL REFERENCES procurement_invoices(invoice_id) ON DELETE RESTRICT,
                product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
                unit_id INTEGER NOT NULL REFERENCES measurement_units(id) ON DELETE RESTRICT,
                quantity TEXT NOT NULL,
                amount TEXT,
                unit_price TEXT,
                tax_amount TEXT
            )""",
            """CREATE TABLE procurement_invoice_matches (
                match_id TEXT PRIMARY KEY,
                invoice_line_id TEXT NOT NULL REFERENCES procurement_invoice_lines(line_id) ON DELETE RESTRICT,
                order_line_id TEXT NOT NULL REFERENCES procurement_order_lines(line_id) ON DELETE RESTRICT,
                receipt_id TEXT NOT NULL REFERENCES procurement_receipts(receipt_id) ON DELETE RESTRICT,
                terms_id TEXT REFERENCES procurement_order_line_terms(terms_id) ON DELETE RESTRICT,
                quantity TEXT NOT NULL,
                amount TEXT,
                expected_amount TEXT,
                quantity_difference TEXT NOT NULL,
                amount_difference TEXT,
                quantity_tolerance TEXT,
                quantity_tolerance_unit_id INTEGER,
                amount_tolerance TEXT,
                amount_tolerance_currency TEXT,
                quantity_status TEXT NOT NULL,
                amount_status TEXT NOT NULL,
                status TEXT NOT NULL,
                clarification_reason TEXT NOT NULL,
                active INTEGER NOT NULL CHECK(active IN (0, 1)),
                source_ref TEXT NOT NULL,
                evidence_refs_json TEXT NOT NULL,
                created_at TEXT NOT NULL,
                revoked_at TEXT,
                revoked_action_id TEXT REFERENCES procurement_action_receipts(action_id) ON DELETE RESTRICT,
                CHECK((active=1 AND revoked_at IS NULL AND revoked_action_id IS NULL)
                   OR (active=0 AND revoked_at IS NOT NULL AND revoked_action_id IS NOT NULL))
            )""",
            "CREATE UNIQUE INDEX ux_procurement_invoice_line_match ON procurement_invoice_matches(invoice_line_id) WHERE active=1",
            "CREATE INDEX ix_procurement_match_receipt ON procurement_invoice_matches(receipt_id, active)",
            "CREATE INDEX ix_procurement_match_order_line ON procurement_invoice_matches(order_line_id, active)",
        ),
    ),
    KernelMigration(
        version=11,
        migration_id="generic-procurement-payments-v1",
        owner_ref="procurement:order-owner",
        dependencies=("generic-procurement-invoices-v1",),
        statements=(
            """CREATE TABLE procurement_payments (
                payment_id TEXT PRIMARY KEY,
                business_identity TEXT NOT NULL UNIQUE,
                supplier_party_id INTEGER NOT NULL REFERENCES business_parties(id) ON DELETE RESTRICT,
                currency TEXT NOT NULL,
                amount TEXT NOT NULL,
                channel TEXT NOT NULL,
                external_reference TEXT NOT NULL,
                paid_at TEXT NOT NULL,
                paid_date TEXT NOT NULL,
                business_at TEXT NOT NULL,
                source_ref TEXT NOT NULL,
                evidence_refs_json TEXT NOT NULL,
                created_at TEXT NOT NULL,
                UNIQUE(supplier_party_id, external_reference)
            )""",
            """CREATE TABLE procurement_payment_allocations (
                allocation_id TEXT PRIMARY KEY,
                payment_id TEXT NOT NULL REFERENCES procurement_payments(payment_id) ON DELETE RESTRICT,
                invoice_id TEXT NOT NULL REFERENCES procurement_invoices(invoice_id) ON DELETE RESTRICT,
                amount TEXT NOT NULL,
                active INTEGER NOT NULL CHECK(active IN (0, 1)),
                source_ref TEXT NOT NULL,
                evidence_refs_json TEXT NOT NULL,
                created_at TEXT NOT NULL,
                revoked_at TEXT,
                revoked_action_id TEXT REFERENCES procurement_action_receipts(action_id) ON DELETE RESTRICT,
                CHECK((active=1 AND revoked_at IS NULL AND revoked_action_id IS NULL)
                   OR (active=0 AND revoked_at IS NOT NULL AND revoked_action_id IS NOT NULL))
            )""",
            "CREATE INDEX ix_procurement_payment_allocations_invoice ON procurement_payment_allocations(invoice_id, active)",
            "CREATE INDEX ix_procurement_payment_allocations_payment ON procurement_payment_allocations(payment_id, active)",
        ),
    ),
    KernelMigration(
        version=12,
        migration_id="generic-procurement-unit-conversion-v1",
        owner_ref="procurement:order-owner",
        dependencies=("generic-procurement-invoices-v1",),
        statements=(
            "ALTER TABLE procurement_order_line_terms ADD COLUMN conversion_from_unit_id INTEGER REFERENCES measurement_units(id) ON DELETE RESTRICT",
            "ALTER TABLE procurement_order_line_terms ADD COLUMN conversion_to_unit_id INTEGER REFERENCES measurement_units(id) ON DELETE RESTRICT",
            "ALTER TABLE procurement_order_line_terms ADD COLUMN conversion_factor TEXT",
            "ALTER TABLE procurement_order_line_terms ADD COLUMN conversion_source_ref TEXT",
            "ALTER TABLE procurement_invoice_matches ADD COLUMN original_quantity TEXT",
            "ALTER TABLE procurement_invoice_matches ADD COLUMN original_unit_id INTEGER REFERENCES measurement_units(id) ON DELETE RESTRICT",
            "ALTER TABLE procurement_invoice_matches ADD COLUMN converted_quantity TEXT",
        ),
    ),
    KernelMigration(
        version=13,
        migration_id="generic-procurement-post-reference-v1",
        owner_ref="procurement:order-owner",
        dependencies=("generic-procurement-receipts-v1",),
        statements=(
            "ALTER TABLE procurement_action_receipts ADD COLUMN post_reference TEXT",
        ),
    ),
    KernelMigration(
        version=14,
        migration_id="generic-prepared-decisions-v1",
        dependencies=("generic-procurement-post-reference-v1",),
        statements=(
            """CREATE TABLE business_agent_decisions (
                id INTEGER PRIMARY KEY, decision_id VARCHAR(64) NOT NULL UNIQUE,
                source_key VARCHAR(300) NOT NULL, source_kind VARCHAR(40) NOT NULL,
                source_id VARCHAR(120), agent_name VARCHAR(80) NOT NULL, record_type VARCHAR(80) NOT NULL,
                input_hash VARCHAR(64) NOT NULL, observed_facts_hash VARCHAR(64) NOT NULL,
                evidence_snapshot_hash VARCHAR(64) NOT NULL, formal_state_version VARCHAR(64) NOT NULL,
                policy_version VARCHAR(40) NOT NULL, model VARCHAR(120), action VARCHAR(40) NOT NULL,
                decision_json TEXT NOT NULL, state VARCHAR(40) NOT NULL,
                supersedes_decision_id VARCHAR(64), authorized_by TEXT, consumed_by TEXT,
                expires_at DATETIME, created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL,
                apply_started_at DATETIME, consumed_at DATETIME, invalidated_at DATETIME
            )""",
            "CREATE INDEX ix_business_agent_decisions_source_created ON business_agent_decisions (source_key, created_at)",
            "CREATE INDEX ix_business_agent_decisions_state_expires ON business_agent_decisions (state, expires_at)",
            "CREATE UNIQUE INDEX uq_business_agent_decisions_active_source ON business_agent_decisions (source_key) WHERE state IN ('current', 'review_pending', 'applying')",
        ),
    ),
    KernelMigration(
        version=15,
        migration_id="generic-source-clusters-v1",
        owner_ref="generic.kernel_smoke:runtime",
        dependencies=("generic-prepared-decisions-v1",),
        statements=(
            """CREATE TABLE business_agent_source_clusters (
                id INTEGER PRIMARY KEY, execution_key VARCHAR(64) NOT NULL UNIQUE,
                cluster_id VARCHAR(80) NOT NULL, agent_name VARCHAR(80) NOT NULL,
                business_date VARCHAR(10) NOT NULL, source_scope TEXT NOT NULL,
                runtime_version VARCHAR(80) NOT NULL, runtime_fingerprint VARCHAR(64) NOT NULL,
                inference_fingerprint VARCHAR(64) NOT NULL, visual_fingerprint VARCHAR(64) NOT NULL,
                deterministic_fingerprint VARCHAR(64) NOT NULL, code_version VARCHAR(80) NOT NULL,
                claim_generation INTEGER NOT NULL, manifest_hash VARCHAR(64) NOT NULL,
                status VARCHAR(40) NOT NULL, manifest_json TEXT NOT NULL,
                coverage_json TEXT, result_json TEXT,
                expected_source_count INTEGER NOT NULL, expected_part_count INTEGER NOT NULL,
                processed_source_count INTEGER NOT NULL, processed_part_count INTEGER NOT NULL,
                attempt_count INTEGER NOT NULL, model_call_count INTEGER NOT NULL,
                retryable BOOLEAN NOT NULL, failure_category VARCHAR(80), error_fingerprint VARCHAR(64),
                last_error TEXT, next_retry_at DATETIME, claim_token VARCHAR(64),
                lease_expires_at DATETIME, started_at DATETIME, completed_at DATETIME,
                created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL
            )""",
            """CREATE INDEX ix_business_agent_source_cluster_queue ON business_agent_source_clusters
                (agent_name, status, next_retry_at, created_at)""",
            """CREATE INDEX ix_business_agent_source_cluster_business_date ON business_agent_source_clusters
                (business_date, agent_name)""",
            """CREATE TABLE business_agent_source_cluster_members (
                id INTEGER PRIMARY KEY,
                cluster_id INTEGER NOT NULL REFERENCES business_agent_source_clusters(id) ON DELETE CASCADE,
                ordinal INTEGER NOT NULL, source_ref VARCHAR(160) NOT NULL,
                source_kind VARCHAR(40) NOT NULL, source_id VARCHAR(160) NOT NULL,
                source_sha256 VARCHAR(64) NOT NULL, coverage_status VARCHAR(40) NOT NULL,
                candidate_refs_json TEXT, error_fingerprint VARCHAR(64), processed_at DATETIME,
                created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL,
                UNIQUE(cluster_id, source_ref), UNIQUE(cluster_id, ordinal)
            )""",
            """CREATE INDEX ix_business_agent_source_cluster_member_source ON business_agent_source_cluster_members
                (source_kind, source_id)""",
        ),
    ),
)


def validate_catalog(migrations: Sequence[KernelMigration] = MIGRATIONS) -> None:
    versions = [item.version for item in migrations]
    if versions != list(range(1, len(migrations) + 1)):
        raise GenericKernelDatabaseError("generic_migration_version_invalid", "versions must start at 1 and be contiguous")
    by_id = {item.migration_id: item for item in migrations}
    if len(by_id) != len(migrations):
        raise GenericKernelDatabaseError("generic_migration_identity_duplicate", "migration IDs must be unique")
    applied: set[str] = set()
    for migration in migrations:
        unknown = sorted(set(migration.dependencies) - set(by_id))
        if unknown:
            raise GenericKernelDatabaseError("generic_migration_dependency_unknown", str(unknown))
        unmet = sorted(set(migration.dependencies) - applied)
        if unmet:
            raise GenericKernelDatabaseError("generic_migration_dependency_order_invalid", str(unmet))
        applied.add(migration.migration_id)


def migration_set_digest(migrations: Sequence[KernelMigration] = MIGRATIONS) -> str:
    validate_catalog(migrations)
    return _digest(_canonical([item.descriptor() for item in migrations]))


def _connect(path: Path) -> sqlite3.Connection:
    connection = storage_connect(path)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys=ON")
    if connection.execute("PRAGMA foreign_keys").fetchone()[0] != 1:
        connection.close()
        raise GenericKernelDatabaseError("generic_foreign_keys_disabled", "foreign key enforcement is required")
    return connection


def _schema_rows(connection: sqlite3.Connection) -> list[dict[str, str]]:
    rows = connection.execute(
        """SELECT type, name, COALESCE(sql, '') AS sql
           FROM sqlite_master
           WHERE name NOT LIKE 'sqlite_%'
           ORDER BY type, name"""
    ).fetchall()
    return [{"type": str(row["type"]), "name": str(row["name"]), "sql": " ".join(str(row["sql"]).split())} for row in rows]


def schema_fingerprint(connection: sqlite3.Connection) -> str:
    return _digest(_canonical(_schema_rows(connection)))


def expected_schema_fingerprint(
    migrations: Sequence[KernelMigration] = MIGRATIONS,
) -> str:
    connection = storage_connect(":memory:")
    connection.row_factory = sqlite3.Row
    try:
        connection.create_function("generic_decimal_text", 1, str, deterministic=True)
        for migration in migrations:
            for statement in migration.statements:
                connection.execute(statement)
        return schema_fingerprint(connection)
    finally:
        connection.close()


def catalog_payload() -> dict[str, object]:
    return {
        "lineage_id": LINEAGE_ID,
        "current_schema_version": len(MIGRATIONS),
        "migration_set_digest": migration_set_digest(),
        "schema_fingerprint": expected_schema_fingerprint(),
        "items": [item.descriptor() for item in MIGRATIONS],
    }


def _metadata(connection: sqlite3.Connection) -> dict[str, str]:
    exists = connection.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name='kernel_instance_metadata'"
    ).fetchone()
    if not exists:
        return {}
    return {str(row["key"]): str(row["value"]) for row in connection.execute("SELECT key, value FROM kernel_instance_metadata")}


def _ledger(connection: sqlite3.Connection) -> list[dict[str, object]]:
    exists = connection.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name='kernel_migration_ledger'"
    ).fetchone()
    if not exists:
        return []
    rows = connection.execute(
        """SELECT lineage_id, migration_version, migration_id, checksum, applied_at
           FROM kernel_migration_ledger ORDER BY migration_version"""
    ).fetchall()
    return [dict(row) for row in rows]


def _newer_than_program(version: int, known: int) -> GenericKernelDatabaseError:
    # 装回旧版本时库已被新版本升级过：旧程序不认识新改表，不降级、不动库。
    return GenericKernelDatabaseError(
        "generic_database_newer_than_program",
        f"database was upgraded to migration {version} by a newer BizHub version; this program knows "
        f"{known}. Install that newer version again, or restore the pre-upgrade backup.",
    )


def _recorded_migrations(
    connection: sqlite3.Connection,
    migrations: Sequence[KernelMigration],
) -> dict[int, dict[str, object]]:
    catalog = {item.version: item for item in migrations}
    recorded: dict[int, dict[str, object]] = {}
    for row in _ledger(connection):
        if row["lineage_id"] != LINEAGE_ID:
            raise GenericKernelDatabaseError(
                "generic_database_ledger_lineage_drift",
                f"unexpected lineage {row['lineage_id']!r}",
            )
        version = int(row["migration_version"])
        migration = catalog.get(version)
        if version > max(catalog, default=0):
            raise _newer_than_program(version, max(catalog, default=0))
        if migration is None:
            raise GenericKernelDatabaseError(
                "generic_migration_content_drift",
                f"recorded migration version {version} is not in the catalog",
            )
        if row["migration_id"] != migration.migration_id or row["checksum"] != migration.checksum:
            raise GenericKernelDatabaseError(
                "generic_migration_content_drift",
                f"recorded migration {version} differs",
            )
        recorded[version] = row
    versions = sorted(recorded)
    if versions != list(range(1, len(versions) + 1)):
        raise GenericKernelDatabaseError(
            "generic_database_ledger_drift",
            f"recorded versions are not a contiguous prefix: {versions}",
        )
    return recorded


def _expected_table_names(migrations: Sequence[KernelMigration]) -> set[str]:
    active_owners = {item.owner_ref.split(":", 1)[0] for item in migrations}
    highest_version = max((item.version for item in migrations), default=0)
    return {
        table.name for table in MODEL_TABLES
        if table.owner_ref.split(":", 1)[0] in active_owners and table.introduced_version <= highest_version
    }


def migrations_for_modules(module_ids: Iterable[str]) -> tuple[KernelMigration, ...]:
    enabled = set(module_ids)
    if "inventory" in enabled and "master_data" not in enabled:
        raise GenericKernelDatabaseError(
            "generic_migration_dependency_module_missing",
            "inventory requires master_data",
        )
    if "procurement" in enabled and not {"master_data", "inventory"} <= enabled:
        raise GenericKernelDatabaseError(
            "generic_migration_dependency_module_missing",
            "procurement requires master_data and inventory",
        )
    if "sales" in enabled and not {"master_data", "inventory", "procurement"} <= enabled:
        raise GenericKernelDatabaseError(
            "generic_migration_dependency_module_missing",
            "sales requires master_data, inventory, and procurement "
            "for the current linear schema lineage",
        )
    highest_version = 1
    enabled_owner_ids = {"generic.kernel_smoke", *enabled}
    for item in MIGRATIONS:
        if item.migration_id in {"generic-prepared-decisions-v1", "generic-source-clusters-v1"} and not ({"sales", "procurement"} & enabled):
            continue
        if item.owner_ref.split(":", 1)[0] in enabled_owner_ids:
            highest_version = max(highest_version, item.version)
    # A SQLite lineage is a contiguous prefix. Earlier module schema is retained
    # when its Runtime capability is disabled; this does not activate its writer.
    return MIGRATIONS[:highest_version]


def retained_migrations_for_database(
    path: Path,
    active_migrations: Sequence[KernelMigration],
) -> tuple[KernelMigration, ...]:
    """Retain already-applied module schema without activating its runtime."""

    if not path.exists():
        return tuple(active_migrations)
    connection = storage_connect(f"file:{path.resolve()}?mode=ro", uri=True)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA query_only=ON")
    try:
        ledger = _ledger(connection)
    finally:
        connection.close()
    recorded_versions = [int(item["migration_version"]) for item in ledger]
    if recorded_versions and max(recorded_versions) > len(MIGRATIONS):
        raise _newer_than_program(max(recorded_versions), len(MIGRATIONS))
    if any(version < 1 for version in recorded_versions):
        raise GenericKernelDatabaseError(
            "generic_migration_content_drift",
            f"recorded migration version outside catalog: {recorded_versions}",
        )
    active_versions = [item.version for item in active_migrations]
    target_version = max((*recorded_versions, *active_versions), default=0)
    return MIGRATIONS[:target_version]


def _verify_complete_state(
    connection: sqlite3.Connection,
    migrations: Sequence[KernelMigration],
    recorded: dict[int, dict[str, object]],
) -> None:
    expected_fingerprint = expected_schema_fingerprint(migrations)
    actual_fingerprint = schema_fingerprint(connection)
    if actual_fingerprint != expected_fingerprint:
        raise GenericKernelDatabaseError(
            "generic_schema_fingerprint_drift",
            f"expected={expected_fingerprint}, actual={actual_fingerprint}",
        )
    expected_tables = _expected_table_names(migrations)
    actual_tables = {item["name"] for item in _schema_rows(connection) if item["type"] == "table"}
    if actual_tables != expected_tables:
        raise GenericKernelDatabaseError(
            "generic_schema_table_mismatch",
            f"expected={sorted(expected_tables)}, actual={sorted(actual_tables)}",
        )
    expected_metadata = {
        "profile_id": PROFILE_ID,
        "lineage_id": LINEAGE_ID,
        "migration_set_digest": migration_set_digest(migrations),
        "schema_fingerprint": expected_fingerprint,
    }
    metadata = _metadata(connection)
    if metadata != expected_metadata:
        raise GenericKernelDatabaseError(
            "generic_database_metadata_drift",
            f"expected={expected_metadata}, actual={metadata}",
        )
    if sorted(recorded) != [item.version for item in migrations]:
        raise GenericKernelDatabaseError("generic_database_ledger_drift", "migration ledger differs")


def _verify_applied_prefix_state(
    connection: sqlite3.Connection,
    migrations: Sequence[KernelMigration],
    recorded: dict[int, dict[str, object]],
) -> None:
    """Validate the pre-upgrade physical schema against the ledger's applied prefix.

    A database whose declared physical schema drifted (e.g. a lost unique
    index) must fail closed before any pending migration writes; without this
    check the pending branch would upgrade the drifted schema and re-sign it
    as the new trusted baseline (#880).
    """

    applied = migrations[: len(recorded)]
    expected_fingerprint = expected_schema_fingerprint(applied)
    actual_fingerprint = schema_fingerprint(connection)
    if actual_fingerprint != expected_fingerprint:
        raise GenericKernelDatabaseError(
            "generic_schema_pre_upgrade_drift",
            f"expected={expected_fingerprint}, actual={actual_fingerprint}",
        )
    expected_metadata = {
        "profile_id": PROFILE_ID,
        "lineage_id": LINEAGE_ID,
        "migration_set_digest": migration_set_digest(applied),
        "schema_fingerprint": expected_fingerprint,
    }
    metadata = _metadata(connection)
    if metadata != expected_metadata:
        raise GenericKernelDatabaseError(
            "generic_database_pre_upgrade_metadata_drift",
            f"expected={expected_metadata}, actual={metadata}",
        )


def _apply_connection(
    connection: sqlite3.Connection,
    migrations: Sequence[KernelMigration],
    *,
    fail_after_statement: int | None = None,
) -> list[str]:
    validate_catalog(migrations)
    connection.create_function("generic_decimal_text", 1, str, deterministic=True)
    metadata = _metadata(connection)
    if metadata and (
        metadata.get("profile_id") != PROFILE_ID or metadata.get("lineage_id") != LINEAGE_ID
    ):
        raise GenericKernelDatabaseError("generic_database_identity_mismatch", "profile or lineage differs")
    existing = _recorded_migrations(connection, migrations)
    pending = [migration for migration in migrations if migration.version not in existing]
    if not pending:
        _verify_complete_state(connection, migrations, existing)
        return []

    applied_ids: list[str] = []
    statement_count = 0
    rebuild = any(item.rebuilds_tables for item in pending)
    if rebuild:
        connection.execute("PRAGMA foreign_keys=OFF")
    try:
        connection.execute("BEGIN IMMEDIATE")
        metadata = _metadata(connection)
        if metadata and (
            metadata.get("profile_id") != PROFILE_ID or metadata.get("lineage_id") != LINEAGE_ID
        ):
            raise GenericKernelDatabaseError("generic_database_identity_mismatch", "profile or lineage differs")
        existing = _recorded_migrations(connection, migrations)
        if existing:
            _verify_applied_prefix_state(connection, migrations, existing)
        for migration in migrations:
            recorded = existing.get(migration.version)
            if recorded:
                continue
            applied_identities = {item["migration_id"] for item in existing.values()} | set(applied_ids)
            if not set(migration.dependencies).issubset(applied_identities):
                raise GenericKernelDatabaseError(
                    "generic_migration_dependency_unmet",
                    f"migration {migration.migration_id} dependencies are not applied",
                )
            for statement in migration.statements:
                connection.execute(statement)
                statement_count += 1
                if fail_after_statement is not None and statement_count >= fail_after_statement:
                    raise GenericKernelDatabaseError("generic_migration_injected_failure", "test-only failure")
            connection.execute(
                """INSERT INTO kernel_migration_ledger
                   (lineage_id, migration_version, migration_id, checksum, applied_at)
                   VALUES (?, ?, ?, ?, ?)""",
                (LINEAGE_ID, migration.version, migration.migration_id, migration.checksum, datetime.now(UTC).isoformat()),
            )
            applied_ids.append(migration.migration_id)

        expected_digest = migration_set_digest(migrations)
        # Sign the catalog's expected schema, never the just-upgraded actual
        # state, so a drifted database cannot be re-certified by its own
        # current bytes (#880).
        fingerprint = expected_schema_fingerprint(migrations)
        values = {
            "profile_id": PROFILE_ID,
            "lineage_id": LINEAGE_ID,
            "migration_set_digest": expected_digest,
            "schema_fingerprint": fingerprint,
        }
        for key, value in values.items():
            connection.execute(
                "INSERT INTO kernel_instance_metadata(key, value) VALUES (?, ?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (key, value),
            )
        _verify_complete_state(connection, migrations, _recorded_migrations(connection, migrations))
        if applied_ids:
            connection.execute(
                "INSERT INTO kernel_audit_events(event_id, event_type, payload_json, created_at) VALUES (?, ?, ?, ?)",
                (
                    uuid.uuid4().hex,
                    "kernel_migrations_applied",
                    json.dumps({"migration_ids": applied_ids}, sort_keys=True, separators=(",", ":")),
                    datetime.now(UTC).isoformat(),
                ),
            )
        if rebuild and connection.execute("PRAGMA foreign_key_check").fetchone() is not None:
            raise GenericKernelDatabaseError("generic_migration_foreign_key_violation", "rebuilt references differ")
        connection.commit()
        return applied_ids
    except Exception:
        connection.rollback()
        raise
    finally:
        if rebuild:
            connection.execute("PRAGMA foreign_keys=ON")


@contextmanager
def _initialization_lock(path: Path) -> Iterator[None]:
    """Serialize first-publish across processes for one database target path.

    The lock is an exclusive ``flock`` on the database's own directory: no lock
    file is left beside the database (Windows cannot lock a directory, so there it
    is a byte lock on one fixed hidden lock file beside it), and the existence check, temporary build,
    ``os.replace`` publish, and readback all happen inside the same critical
    section. A second process therefore can never observe a missing target
    while a first publish is in flight, nor replace a database the first
    process already published and wrote to (#881).
    """

    if os.name == "nt":
        # Windows 不能打开目录加锁：在库旁的固定锁文件上加独占锁（锁文件只用来排队，留着不删，
        # 删了会让后来者锁到另一个文件上）。桌面运行包在 Windows 上走这条路。
        import msvcrt

        lock_fd = os.open(path.parent / f".{path.name}.init-lock", os.O_RDWR | os.O_CREAT, 0o600)
        try:
            while True:
                try:
                    msvcrt.locking(lock_fd, msvcrt.LK_LOCK, 1)
                    break
                except OSError:
                    continue  # LK_LOCK 约 10 秒拿不到就报错：继续排队，与 flock 阻塞等待同义
            try:
                yield
            finally:
                os.lseek(lock_fd, 0, os.SEEK_SET)
                msvcrt.locking(lock_fd, msvcrt.LK_UNLCK, 1)
        finally:
            os.close(lock_fd)
        return
    import fcntl

    directory_fd = os.open(path.parent, os.O_RDONLY)
    try:
        fcntl.flock(directory_fd, fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(directory_fd, fcntl.LOCK_UN)
    finally:
        os.close(directory_fd)


PRE_UPGRADE_BACKUP_PREFIX = "pre-upgrade-"


def _backup_before_upgrade(
    path: Path,
    migrations: Sequence[KernelMigration],
    backup_dir: Path,
    keep: int,
) -> Path | None:
    """已装的库有待补的改表时，先做一份校验过的备份再升级；没有待补的不备份。"""

    from .backup import create_backup

    connection = storage_connect(f"file:{path}?mode=ro", uri=True)
    connection.row_factory = sqlite3.Row
    try:
        applied = len(_recorded_migrations(connection, migrations))
    finally:
        connection.close()
    if applied >= len(migrations):
        return None
    stamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%S%fZ")
    target = backup_dir.resolve() / f"{PRE_UPGRADE_BACKUP_PREFIX}{stamp}-v{applied}-to-v{len(migrations)}.sqlite"
    create_backup(path, target, migrations=migrations[:applied])
    # 只轮换自动备份，手动备份不碰。
    for stale in sorted(backup_dir.glob(f"{PRE_UPGRADE_BACKUP_PREFIX}*.sqlite"))[:-keep]:
        stale.with_suffix(stale.suffix + ".manifest.json").unlink(missing_ok=True)
        stale.unlink(missing_ok=True)
    return target


def ensure_generic_database(
    path: Path,
    *,
    migrations: Sequence[KernelMigration] = MIGRATIONS,
    fail_after_statement: int | None = None,
    backup_dir: Path | None = None,
    keep_backups: int = 5,
) -> list[str]:
    """Create or verify the generic database without leaving a partial new file.

    With ``backup_dir`` an installed database that has pending migrations is
    backed up (and the backup validated) before any of them run; a failed
    backup leaves the database untouched.
    """

    path = path.resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    with _initialization_lock(path):
        is_new = not path.exists()
        if backup_dir is not None and not is_new:
            _backup_before_upgrade(path, migrations, backup_dir, keep_backups)
        working_path = path
        if is_new:
            working_path = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
        connection = _connect(working_path)
        try:
            applied = _apply_connection(connection, migrations, fail_after_statement=fail_after_statement)
        except Exception:
            connection.close()
            if is_new:
                working_path.unlink(missing_ok=True)
            raise
        connection.close()
        if is_new:
            os.replace(working_path, path)
        readback_database(path, migrations=migrations)
        return applied


def readback_database(
    path: Path,
    *,
    migrations: Sequence[KernelMigration] = MIGRATIONS,
) -> dict[str, object]:
    if not path.exists():
        raise GenericKernelDatabaseError("generic_database_missing", str(path))
    connection = _connect(path)
    try:
        metadata = _metadata(connection)
        ledger = _ledger(connection)
        tables = sorted(item["name"] for item in _schema_rows(connection) if item["type"] == "table")
        fingerprint = schema_fingerprint(connection)
        expected_fingerprint = expected_schema_fingerprint(migrations)
        if fingerprint != expected_fingerprint:
            raise GenericKernelDatabaseError(
                "generic_schema_fingerprint_drift",
                f"expected={expected_fingerprint}, actual={fingerprint}",
            )
        expected_ledger = [item.descriptor() for item in migrations]
        actual_ledger = [
            {
                "version": int(item["migration_version"]),
                "migration_id": str(item["migration_id"]),
                "owner_ref": migrations[int(item["migration_version"]) - 1].owner_ref,
                "dependencies": list(migrations[int(item["migration_version"]) - 1].dependencies),
                "checksum": str(item["checksum"]),
            }
            for item in ledger
        ]
        expected = {
            "profile_id": PROFILE_ID,
            "lineage_id": LINEAGE_ID,
            "migration_set_digest": migration_set_digest(migrations),
            "schema_fingerprint": expected_fingerprint,
        }
        if metadata != expected:
            raise GenericKernelDatabaseError("generic_database_metadata_drift", f"expected={expected}, actual={metadata}")
        if actual_ledger != expected_ledger:
            raise GenericKernelDatabaseError("generic_database_ledger_drift", "migration ledger differs")
        if tables != sorted(_expected_table_names(migrations)):
            raise GenericKernelDatabaseError("generic_schema_table_mismatch", str(tables))
        return {
            **expected,
            "schema_version": len(migrations),
            "tables": tables,
            "migration_ids": [item.migration_id for item in migrations],
        }
    finally:
        connection.close()
