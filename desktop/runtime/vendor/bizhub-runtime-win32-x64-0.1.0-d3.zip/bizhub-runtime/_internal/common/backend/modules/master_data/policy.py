"""主数据标准流程的固定挂钩位置。

通用流程只认这里声明的口子；客户特有的措辞规则（名称归一、本公司名称、错字容忍、
额外的主数据种类、写之前的附加检查）由客户在自己的模块里给出一份策略交进来。
不给时用下面的通用默认。
"""

from __future__ import annotations

import re
import sqlite3
import unicodedata
from dataclasses import dataclass, field
from typing import Any, Callable, Mapping

from .matching import normalize_identity
from .name_types import NAME_TYPES, NameType


def default_normalize_name(domain: str, value: object) -> str:
    """名称比较键：全角半角统一、去空白、不分大小写；往来方再去掉标点。"""

    text = normalize_identity(value)
    if str(domain or "").strip().casefold() == "party":
        return re.sub(r"[\W_]+", "", text)
    return text


def normalize_business_identifier(value: object) -> str:
    """税号、统一信用代码、登记号：只留数字和大写字母。"""

    text = unicodedata.normalize("NFKC", str(value or "")).upper()
    return re.sub(r"[^0-9A-Z]", "", text)


def default_normalize_phone(value: object) -> str:
    """电话只留数字；去不掉的国家区号由客户策略处理。"""

    return "".join(re.findall(r"\d", unicodedata.normalize("NFKC", str(value or ""))))


# 一份候选查找函数：(连接, 策略, 原文, 归一后文字, 来源范围) → 候选列表。
ExtraSearch = Callable[[sqlite3.Connection, "MasterDataPolicy", str, str, str], list[dict[str, Any]]]


@dataclass(frozen=True)
class MasterDataPolicy:
    name_types: Mapping[str, NameType] = field(default_factory=lambda: dict(NAME_TYPES))
    # catalog="provider" 类型的只读目录：类型 → (连接) → [{id, canonical_name, status}]。
    name_catalogs: Mapping[str, Callable[[sqlite3.Connection], list[dict[str, Any]]]] = field(default_factory=dict)
    # 名称比较键（往来方为“核心名”，产品可折叠易混字）。
    normalize_name: Callable[[str, object], str] = default_normalize_name
    # 别名存库的键；默认与名称身份归一相同。
    normalize_alias: Callable[[str, object], str] = lambda _entity_type, value: normalize_identity(value)
    # 本公司的名称：返回本公司正式名表示“这是我方”，任何往来方都不能用它。
    own_company_label: Callable[[str], str | None] = lambda _text: None
    normalize_phone: Callable[[object], str] = default_normalize_phone
    normalize_identifier: Callable[[object], str] = normalize_business_identifier
    # 往来方错字容忍：(核心名最大长度, 允许的编辑距离) 有序表；默认只认核心名完全相同。
    party_fuzzy_distance_by_length: tuple[tuple[int | None, int | None], ...] = ((None, 0),)
    party_fuzzy_min_gap: int = 1
    fuzzy_alias_origin: str = "auto_fuzzy_unique"
    # 往来方名称“包含”匹配的门槛，以及正式名后面可省略的公司类型词。
    party_contains_min_score: float = 0.78
    alias_contains_min_score: float = 0.82
    canonical_legal_suffix_extensions: frozenset[str] = frozenset()
    composite_separator: re.Pattern[str] = re.compile(r"\s*(?:/|／|、|,|，|\|)\s*")
    # 产品候选附带的属性；客户可加上自己的扩展列。
    product_attributes: Callable[[Mapping[str, Any]], dict[str, Any]] = (
        lambda row: {"family": str(row["product_family"] or "")}
    )
    # 客户加在标准表上的扩展列：表名 → 列名；新建、修改时可以随标准列一起写。
    extension_columns: Mapping[str, tuple[str, ...]] = field(default_factory=dict)
    # 客户额外的主数据种类（如规格、物料）：别名可以指向它们；以及它们的候选查找。
    extra_alias_entity_types: frozenset[str] = frozenset()
    # 扩展种类的正式实体读取（含统一的 active/deprecated 状态）。
    extra_entity_rows: Mapping[str, Callable[[sqlite3.Connection, int], dict[str, Any] | None]] = field(default_factory=dict)
    extra_search: Mapping[str, ExtraSearch] = field(default_factory=dict)
    # 查找结果里“归一后文字”怎么写（如规格写成 宽*长*厚）；默认名称身份归一。
    search_normalized_text: Callable[[str, str], str] = lambda _domain, raw_text: normalize_identity(raw_text)
    # 只读展示合组：类型 → 组用途。该用途的在用组，成员标准名或组叫法命中即显示组名；
    # 不改变正式身份或写入解析。
    projection_group_purposes: Mapping[str, str] = field(default_factory=dict)
    # 组变更后在同一事务里维护的只读派生投影（如旧字段）：
    # (连接, 组键, 改前, 改后) → None；改前/改后为 {status, member_type, purpose, members:[(类型, 键)]} 或 None。
    on_group_members_changed: Callable[..., None] | None = None
    # 改往来方资料时补登号码要附的正式证据（如对上发票的税号）：(连接, 全称, 号码列表, 角色) → 证据列表。
    identifier_evidence: Callable[[sqlite3.Connection, str, list[dict[str, str]], str], list[dict[str, Any]]] = (
        lambda _connection, _legal_name, _identifiers, _role: []
    )
    # 主数据处理前后必须不变的业务数字（如各往来方的单据合计）；None 表示不检查。
    protected_projection: Callable[[sqlite3.Connection], Any] | None = None
    # 往来方合并时，各业务模块把自己单据上的往来方改指到合并后的那家：
    # (连接, source_party_id=, target_party_id=, reason=, actor=, dry_run=) → {单据表: 条数}。
    # 演练（dry_run）只数条数并检查会不会撞号，撞号就报错拒收。
    merge_reference_movers: tuple[Callable[..., dict[str, int]], ...] = ()
    # AI 写入请求“新建供应商”：号码要有正式证据才准建（如收到的发票上的税号）。
    # (连接, 全称, 号码列表) → 证据编号列表；require 为 True 时没有证据又没有合同证据就拒收。
    supplier_identifier_evidence: Callable[[sqlite3.Connection, str, list[dict[str, str]]], list[int]] = (
        lambda _connection, _legal_name, _identifiers: []
    )
    require_supplier_identifier_evidence: bool = False
    # 写入请求前后数一数的目录（客户可加上自己的主数据种类）。
    extra_catalog_counts: Callable[[sqlite3.Connection], dict[str, int]] = lambda _connection: {}
    # 客户自有的写入请求动作（如新建物料）：动作名 → (预览, 执行)。
    extra_intent_actions: Mapping[str, tuple[Callable[..., dict[str, Any]], Callable[..., dict[str, Any]]]] = field(
        default_factory=dict
    )


DEFAULT_POLICY = MasterDataPolicy()

__all__ = [
    "DEFAULT_POLICY",
    "ExtraSearch",
    "MasterDataPolicy",
    "default_normalize_name",
    "default_normalize_phone",
    "normalize_business_identifier",
]
