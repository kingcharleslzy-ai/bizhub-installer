"""已启用模块声明名称类型；只描述目录，不携带客户匹配算法。"""

from dataclasses import dataclass
import json
import re
from typing import Mapping


@dataclass(frozen=True)
class NameType:
    owner: str
    table: str = "master_data_name_values"
    key_column: str = "value_key"
    label_column: str = "canonical_name"
    status_column: str = "status"
    numeric_key: bool = False
    scope_dimensions: tuple[str, ...] = ("source", "purpose")
    reference_fields: tuple[str, ...] = ()
    allow_groups: bool = False
    normalization: str = "format"
    confirmation: str = "owner"
    # "table"：目录在库表；"provider"：目录由启用模块经策略 name_catalogs 只读提供（如构建期页面目录）。
    catalog: str = "table"

    def __post_init__(self):
        if self.numeric_key and self.table == "master_data_name_values":
            raise ValueError("numeric name identities require an existing integer-keyed catalog")
        if self.normalization != "format" or self.confirmation != "owner" or not self.owner or self.catalog not in {"table", "provider"} or any(not re.fullmatch(r"[a-z][a-z0-9_]*", value) for value in (
            self.table, self.key_column, self.label_column, self.status_column,
        )):
            raise ValueError("invalid name type declaration")


NAME_TYPES = {
    "location": NameType("inventory", "locations", "key", "display_name", allow_groups=True),
    "name_group": NameType("master_data"),
}


def scope_key(scope: object, declaration: NameType) -> str:
    """新类型范围必须是登记维度组成的对象；旧五域的来源文字不在此改义。"""
    if scope in (None, ""):
        return ""
    if isinstance(scope, str):
        scope = json.loads(scope)
    if not isinstance(scope, Mapping) or set(scope) - set(declaration.scope_dimensions):
        raise ValueError("unregistered name scope dimension")
    if any(not isinstance(v, str) or not v.strip() for v in scope.values()):
        raise ValueError("name scope values must be nonempty strings")
    return json.dumps(dict(scope), ensure_ascii=False, sort_keys=True, separators=(",", ":")) if scope else ""


def scopes_overlap(first: str, second: str) -> bool:
    left, right = json.loads(first or "{}"), json.loads(second or "{}")
    return all(left[key] == right[key] for key in left.keys() & right.keys())


def scope_matches(stored: str, requested: str) -> bool:
    left, right = json.loads(stored or "{}"), json.loads(requested or "{}")
    return all(right.get(key) == value for key, value in left.items())


def target_key(value: object, declaration: NameType) -> int | str:
    if declaration.numeric_key:
        if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
            raise ValueError("name identity must be a positive integer")
    elif not isinstance(value, str) or not value.strip() or value != value.strip() or len(value) > 240:
        raise ValueError("name identity must be a nonempty stable text key")
    return value


def catalog_rows(connection, domain: str, declaration: NameType, providers: Mapping | None = None) -> list[dict]:
    if declaration.catalog == "provider":
        provider = (providers or {}).get(domain)
        if provider is None:
            raise ValueError(f"name catalog provider missing: {domain}")
        return [{"id": row["id"], "canonical_name": str(row["canonical_name"]), "status": row["status"]}
                for row in provider(connection)]
    where, params = (" WHERE domain=?", (domain,)) if declaration.table == "master_data_name_values" else ("", ())
    cursor = connection.execute(
        f"SELECT {declaration.key_column}, {declaration.label_column}, {declaration.status_column} "
        f"FROM {declaration.table}{where}", params,
    )
    return [{"id": row[0], "canonical_name": str(row[1]), "status": row[2]} for row in cursor]
