"""Assemble observation contracts only from the Host's enabled Manifest providers.

This is a projection, not a second list of installed modules or business writers.
It deliberately has no default customer/Profile and imports no private package.
"""

from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict, dataclass, replace, field
from datetime import date, datetime, timezone
from hashlib import sha256
import json
from typing import Any

from .record_contract import RuntimeRecordSpec
from .query_contract import AgentQueryPolicy


@dataclass(frozen=True)
class AgentRuleScope:
    topic: str
    scenes: tuple[str, ...]
    consumers: tuple[str, ...] = ()
    record_types: tuple[str, ...] = ()


@dataclass(frozen=True)
class AgentRuleEntry:
    id: str
    revision: int
    owner: str
    scope: AgentRuleScope
    text_zh: str
    source_refs: tuple[str, ...]
    effective_from: date
    effective_until: date | None = None
    supersedes: tuple[tuple[str, int], ...] = ()
    positive_examples: tuple[str, ...] = ()
    negative_examples: tuple[str, ...] = ()
    schema_version: int = 1


@dataclass(frozen=True)
class RuleValidationIssue:
    code: str
    rule_ids: tuple[tuple[str, int], ...]
    scope: AgentRuleScope


class RuleValidationError(ValueError):
    def __init__(self, issue: RuleValidationIssue):
        self.issues = (issue,)
        super().__init__(f"{issue.code}:{issue.rule_ids}")


@dataclass(frozen=True)
class AgentKnowledgeScope:
    """Host-selected request boundary; no customer selector or clock on reads."""

    scene: str
    consumer: str
    record_types: tuple[str, ...] = ()
    topics: tuple[str, ...] = ()


@dataclass(frozen=True)
class ReviewExperienceReadScope:
    """Exact request identity supplied by the host, never by the model."""

    agent_name: str
    record_type: str
    source_kind: str
    source_refs: tuple[str, ...]
    source_sha256: tuple[tuple[str, str], ...]
    field_paths: tuple[str, ...]


@dataclass(frozen=True)
class ReviewExperienceProjection:
    event_id: str
    agent_name: str
    record_type: str
    source_kind: str
    source_refs: tuple[str, ...]
    field_paths: tuple[str, ...]
    status: str
    reasons: tuple[str, ...]
    confirmed_values_json: str = "{}"


@dataclass(frozen=True)
class AgentKnowledgeProjection:
    """Rule scopes contain the record types still effective for this read."""

    rules: tuple[AgentRuleEntry, ...]
    validation: tuple[RuleValidationIssue, ...]
    digest: str
    experiences: tuple[ReviewExperienceProjection, ...] = ()
    # 带提示重做时这批来源附带的文字澄清：只是本次识别的上下文，不是规则。
    clarifications: tuple[str, ...] = ()


def rule_entry_payload(entry: AgentRuleEntry) -> dict[str, Any]:
    """Complete canonical payload shared by projection and inference identity."""

    payload = asdict(entry)
    payload["effective_from"] = entry.effective_from.isoformat()
    payload["effective_until"] = entry.effective_until.isoformat() if entry.effective_until else None
    return payload


def _rule_issue(code: str, *entries: AgentRuleEntry) -> None:
    raise RuleValidationError(RuleValidationIssue(
        code, tuple((entry.id, entry.revision) for entry in entries), entries[0].scope,
    ))


def _scope_overlap(first: AgentRuleScope, second: AgentRuleScope) -> bool:
    return first.topic == second.topic and all(
        not left or not right or bool(set(left) & set(right))
        for left, right in (
            (first.scenes, second.scenes), (first.consumers, second.consumers),
            (first.record_types, second.record_types),
        )
    )


def _assemble_rule_entries(
    entries: list[AgentRuleEntry], *, as_of: date,
) -> tuple[tuple[AgentRuleEntry, ...], tuple[tuple[tuple[str, int], tuple[tuple[str, int], ...]], ...]]:
    by_key: dict[tuple[str, int], AgentRuleEntry] = {}
    for entry in entries:
        if (entry.schema_version != 1 or not entry.id or entry.revision < 1
                or not entry.scope.topic or not entry.scope.scenes or not entry.text_zh.strip()
                or not entry.source_refs
                or (entry.effective_until is not None and entry.effective_until <= entry.effective_from)):
            _rule_issue("invalid_rule_entry", entry)
        entry = replace(entry, scope=replace(
            entry.scope,
            scenes=tuple(sorted(set(entry.scope.scenes))),
            consumers=tuple(sorted(set(entry.scope.consumers))),
            record_types=tuple(sorted(set(entry.scope.record_types))),
        ), source_refs=tuple(sorted(set(entry.source_refs))),
            supersedes=tuple(sorted(set(entry.supersedes))))
        key = (entry.id, entry.revision)
        previous = by_key.get(key)
        if previous is not None and previous != entry:
            _rule_issue("duplicate_rule_content_conflict", previous, entry)
        by_key[key] = entry

    ancestors: dict[tuple[str, int], set[tuple[str, int]]] = {}

    def visit(key: tuple[str, int], visiting: frozenset[tuple[str, int]]) -> set[tuple[str, int]]:
        if key in visiting:
            _rule_issue("cyclic_rule_supersession", by_key[key])
        if key in ancestors:
            return ancestors[key]
        entry = by_key[key]
        result: set[tuple[str, int]] = set()
        for target in entry.supersedes:
            previous = by_key.get(target)
            if previous is None:
                _rule_issue("dangling_rule_supersession", entry)
            if previous.owner != entry.owner or previous.scope.topic != entry.scope.topic:
                _rule_issue("foreign_rule_supersession", entry, previous)
            if previous.id == entry.id and previous.revision >= entry.revision:
                _rule_issue("invalid_rule_supersession_direction", entry, previous)
            if previous.effective_from > entry.effective_from:
                _rule_issue("invalid_rule_supersession_effective_from", entry, previous)
            result.add(target)
            result.update(visit(target, visiting | {key}))
        ancestors[key] = result
        return result

    for key in by_key:
        visit(key, frozenset())
    ordered = sorted(by_key.items())
    for index, (key, entry) in enumerate(ordered):
        for other_key, other in ordered[index + 1:]:
            time_overlap = max(entry.effective_from, other.effective_from) < min(
                entry.effective_until or date.max, other.effective_until or date.max,
            )
            if (time_overlap and _scope_overlap(entry.scope, other.scope)
                    and entry.text_zh != other.text_zh
                    and other_key not in ancestors[key] and key not in ancestors[other_key]):
                _rule_issue("overlapping_rule_conflict", entry, other)
    active = tuple(entry for _, entry in ordered if entry.effective_from <= as_of
                   and (entry.effective_until is None or as_of < entry.effective_until))
    replacements = tuple(((entry.id, entry.revision), tuple(sorted(ancestors[(entry.id, entry.revision)])))
                         for entry in active if ancestors[(entry.id, entry.revision)])
    return active, replacements


def read_agent_knowledge(
    contracts: AgentContracts, *, scope: AgentKnowledgeScope,
    experiences: tuple[ReviewExperienceProjection, ...] = (),
) -> AgentKnowledgeProjection:
    """Pure read of frozen rules and a host-selected request experience snapshot."""

    if any(not isinstance(item, ReviewExperienceProjection) for item in experiences):
        raise ValueError("invalid_review_experience_projection")
    experiences = tuple(sorted(
        (replace(item, confirmed_values_json="{}") if item.status != "confirmed" else item
         for item in experiences if item.agent_name == scope.consumer
         and item.record_type in scope.record_types), key=lambda item: item.event_id,
    ))
    selected = tuple(entry for entry in contracts.rule_entries
                     if scope.scene in entry.scope.scenes
                     and (not entry.scope.consumers or scope.consumer in entry.scope.consumers)
                     and (not scope.topics or entry.scope.topic in scope.topics))
    # Resolve each record type independently: a narrow replacement cannot hide
    # wording still needed by another record type in the same request.
    replacements = dict(contracts.rule_supersessions)
    retained: dict[tuple[str, int], set[str]] = {}
    for record_type in scope.record_types or (None,):
        applicable = tuple(entry for entry in selected
                           if not entry.scope.record_types or record_type in entry.scope.record_types)
        superseded = {target for entry in applicable
                      for target in replacements.get((entry.id, entry.revision), entry.supersedes)}
        for entry in applicable:
            key = (entry.id, entry.revision)
            if key not in superseded:
                effective_types = retained.setdefault(key, set())
                if record_type is not None:
                    effective_types.add(record_type)
    # Project the resolved scope without changing the frozen Owner entries.
    rules = tuple(replace(entry, scope=replace(
        entry.scope, record_types=tuple(sorted(retained[(entry.id, entry.revision)])),
    )) for entry in selected if (entry.id, entry.revision) in retained)
    payload = [rule_entry_payload(entry) for entry in rules]
    if experiences:
        payload = {"rules": payload, "experiences": [asdict(item) for item in experiences]}
    digest = sha256(json.dumps(payload, ensure_ascii=False, sort_keys=True,
                              separators=(",", ":")).encode()).hexdigest()
    return AgentKnowledgeProjection(rules=rules, validation=(), digest=digest, experiences=experiences)



def with_clarifications(projection: AgentKnowledgeProjection, texts: Any) -> AgentKnowledgeProjection:
    """Attach this request's clarifications; the digest moves so the run is never reused."""
    items = tuple(dict.fromkeys(str(text).strip() for text in texts or () if str(text or "").strip()))
    if not items:
        return projection
    digest = sha256(json.dumps([projection.digest, items], ensure_ascii=False).encode()).hexdigest()
    return replace(projection, clarifications=items, digest=digest)


def render_agent_knowledge(projection: AgentKnowledgeProjection) -> str:
    """Keep historical field evidence separate from rules and current facts."""
    sections = []
    if projection.rules:
        sections.append("【适用规则】\n" + "\n".join(
            (f"仅适用于 record_type={','.join(entry.scope.record_types)}：" if entry.scope.record_types else "")
            + entry.text_zh for entry in projection.rules
        ))
    if projection.experiences:
        sections.append(
            "【历史来源字段经验】仅适用于列出的同一来源与字段；不代表当前库存、余额或新来源事实。\n"
            + json.dumps([asdict(item) for item in projection.experiences], ensure_ascii=False, sort_keys=True)
            + "\n经验摘要：" + projection.digest
        )
    if projection.clarifications:
        sections.append(
            "【这批来源的澄清】看过原图原文的人这次补充的说明，按它理解来源的含义、分批和关系；"
            "与原文冲突时在 uncertainties 写明，不要静默照抄。\n"
            + "\n".join(f"- {text}" for text in projection.clarifications)
        )
    return "\n".join(sections)


@dataclass(frozen=True)
class AgentRole:
    agent_name: str
    purpose: str
    source_contract: str
    master_data_domains: tuple[str, ...]
    relation_types: tuple[str, ...] = ()
    observation_role: bool = True
    source_corrections: bool = False
    context_query_schema: dict[str, Any] = field(default_factory=dict)
    inference_relation_types: tuple[str, ...] | None = None
    prompt_rules_zh: tuple[str, ...] = ()
    domain_rules_zh: tuple[str, ...] = ()
    # Lazy existing role client configuration; credentials never enter contracts.
    review_model_config: Any = None
    # 负责人预览可用的精确锚点字段（crystal_id / sales_order_id / waybill_no）。
    owner_preview_anchors: tuple[str, ...] = ()


@dataclass(frozen=True)
class AgentContribution:
    module_id: str
    roles: tuple[AgentRole, ...] = ()
    records: tuple[RuntimeRecordSpec, ...] = ()
    query_policies: tuple[AgentQueryPolicy, ...] = ()
    deterministic_source_hashes: tuple[tuple[str, str], ...] = ()
    visual_source_hashes: tuple[tuple[str, str], ...] = ()
    # (Owner error code, Review risk, field, savepoint-preview record types).
    owner_shape_errors: tuple[tuple[str, str, str, tuple[str, ...]], ...] = ()
    # ``(review_risk_code, agent_name, human_action_zh)`` wordings that replace
    # the platform's neutral default for this module's own agents only.
    review_risk_human_actions: tuple[tuple[str, str, str], ...] = ()
    # 复核“人话原因”的模块登记：record_type → 字段中文名（单据目录里同名
    # doc_type 的 ``field_labels_zh`` 优先，这里补目录覆盖不到的记录类型）。
    review_field_labels_zh: tuple[tuple[str, dict[str, str]], ...] = ()
    # record_type + 集合名 → 行身份字段（按登记顺序取行内第一个有值的，
    # 用于把“第 N 条”说成“第 N 条 K20-237”）。
    review_row_identity_fields: tuple[tuple[str, str, tuple[str, ...]], ...] = ()
    # record_type + 字段名 → 枚举值的中文标签（today_work=今日工作这类）；
    # 没登记的内部标识符不进人话。
    review_value_labels_zh: tuple[tuple[str, str, tuple[tuple[str, str], ...]], ...] = ()
    # Owner 冲突规则 id → 中文句式渲染器：``(rule_id, renderer)``，
    # renderer(risk, context) -> (主句, 要你做什么) | None。规则的事实必须来自
    # risk 的结构化键（observed_value / audit 的结构化 JSON），不解析散文。
    review_rule_renderers_zh: tuple[tuple[str, Any], ...] = ()
    rule_entries: tuple[AgentRuleEntry, ...] = ()


@dataclass(frozen=True)
class AgentContracts:
    roles: dict[str, AgentRole]
    records: tuple[RuntimeRecordSpec, ...]
    query_policies: dict[str, AgentQueryPolicy] = field(default_factory=dict)
    deterministic_source_hashes: dict[str, dict[str, str]] = field(default_factory=dict)
    visual_source_hashes: dict[str, dict[str, str]] = field(default_factory=dict)
    owner_shape_errors: dict[str, tuple[str, str, tuple[str, ...]]] = field(default_factory=dict)
    review_risk_human_actions: dict[tuple[str, str], str] = field(default_factory=dict)
    review_field_labels_zh: dict[str, dict[str, str]] = field(default_factory=dict)
    review_row_identity_fields: dict[tuple[str, str], tuple[str, ...]] = field(
        default_factory=dict
    )
    review_value_labels_zh: dict[tuple[str, str], dict[str, str]] = field(
        default_factory=dict
    )
    review_rule_renderers_zh: dict[str, Any] = field(default_factory=dict)
    rule_entries: tuple[AgentRuleEntry, ...] = ()
    rule_supersessions: tuple[tuple[tuple[str, int], tuple[tuple[str, int], ...]], ...] = ()


def assemble_agent_contracts(
    registry: Any, *, identifier_grammar: Any = None, rules_as_of: date | None = None,
) -> AgentContracts:
    """Resolve exports through this Registry, rejecting duplicate/foreign owners."""
    if identifier_grammar is None:
        from backend.kernel.runtime.public import resolve_identifier_grammar

        identifier_grammar = resolve_identifier_grammar(registry)
    roles: dict[str, AgentRole] = {}
    rule_entries: list[AgentRuleEntry] = []
    rules_as_of = rules_as_of if rules_as_of is not None else datetime.now(timezone.utc).date()
    records: dict[str, RuntimeRecordSpec] = {}
    query_policies: dict[str, AgentQueryPolicy] = {}
    deterministic_source_hashes: dict[str, dict[str, str]] = {}
    visual_source_hashes: dict[str, dict[str, str]] = {}
    owner_shape_errors: dict[str, tuple[str, str, tuple[str, ...]]] = {}
    review_risk_human_actions: dict[tuple[str, str], str] = {}
    review_field_labels_zh: dict[str, dict[str, str]] = {}
    review_row_identity_fields: dict[tuple[str, str], tuple[str, ...]] = {}
    review_value_labels_zh: dict[tuple[str, str], dict[str, str]] = {}
    review_rule_renderers_zh: dict[str, Any] = {}
    enabled_modules = frozenset(module["module_id"] for module in registry.payload.get("modules", []))
    for module in registry.payload.get("modules", []):
        module_id = module["module_id"]
        capability = f"agent.contracts.{module_id}"
        if capability not in (module.get("capabilities") or {}).get("provides", []):
            continue
        provider = registry.resolve_capability(capability, "agent_contracts")
        contribution = provider(identifier_grammar=identifier_grammar)
        if not isinstance(contribution, AgentContribution) or contribution.module_id != module_id:
            raise ValueError(f"agent_contract_provider_mismatch:{module_id}")
        for entry in contribution.rule_entries:
            if entry.owner != module_id:
                _rule_issue("rule_owner_mismatch", entry)
            rule_entries.append(entry)
        if contribution.deterministic_source_hashes:
            deterministic_source_hashes[module_id] = dict(contribution.deterministic_source_hashes)
        if contribution.visual_source_hashes:
            visual_source_hashes[module_id] = dict(contribution.visual_source_hashes)
        for risk_code, agent_name, human_action_zh in contribution.review_risk_human_actions:
            key = (str(risk_code), str(agent_name))
            if not all(key) or key in review_risk_human_actions:
                raise ValueError(
                    f"agent_review_risk_human_action_duplicate:{key[0]}:{key[1]}"
                )
            review_risk_human_actions[key] = str(human_action_zh)
        for record_type, labels in contribution.review_field_labels_zh:
            record_key = str(record_type or "").strip()
            merged = review_field_labels_zh.setdefault(record_key, {})
            for field, label in dict(labels).items():
                field_key = str(field or "").strip()
                if not field_key or not str(label or "").strip():
                    continue
                merged[field_key] = str(label)
        for record_type, collection, fields in contribution.review_row_identity_fields:
            key = (str(record_type or "").strip(), str(collection or "").strip())
            if not all(key) or not fields or key in review_row_identity_fields:
                raise ValueError(
                    f"agent_review_row_identity_duplicate:{key[0]}:{key[1]}"
                )
            review_row_identity_fields[key] = tuple(
                str(item) for item in fields if str(item or "").strip()
            )
        for record_type, field_name, labels in contribution.review_value_labels_zh:
            key = (
                str(record_type or "").strip(),
                str(field_name or "").strip(),
            )
            if not all(key) or key in review_value_labels_zh:
                raise ValueError(
                    f"agent_review_value_label_duplicate:{key[0]}:{key[1]}"
                )
            review_value_labels_zh[key] = {
                str(value): str(label)
                for value, label in labels
                if str(value or "").strip() and str(label or "").strip()
            }
        for rule_id, renderer in contribution.review_rule_renderers_zh:
            rule_key = str(rule_id or "").strip()
            if not rule_key or not callable(renderer) or rule_key in review_rule_renderers_zh:
                raise ValueError(f"agent_review_rule_renderer_duplicate:{rule_key}")
            review_rule_renderers_zh[rule_key] = renderer
        for role in contribution.roles:
            if not role.agent_name or role.agent_name in roles:
                raise ValueError(f"agent_role_duplicate:{role.agent_name}")
            roles[role.agent_name] = deepcopy(role)
        contributed_roles = {role.agent_name for role in contribution.roles}
        for policy in contribution.query_policies:
            if not isinstance(policy, AgentQueryPolicy) or policy.agent_name not in contributed_roles:
                raise ValueError(f"agent_query_foreign_role:{module_id}")
            if policy.agent_name in query_policies:
                raise ValueError(f"agent_query_duplicate:{policy.agent_name}")
            bound = policy.bind_modules(enabled_modules, registry) if policy.bind_modules else policy
            if not isinstance(bound, AgentQueryPolicy) or bound.agent_name != policy.agent_name:
                raise ValueError(f"agent_query_binding_mismatch:{module_id}")
            query_policies[policy.agent_name] = deepcopy(bound)
        owned = {item["record_type"]: item for item in module.get("ownership", {}).get("record_types", [])}
        for spec in contribution.records:
            if spec.record_type in records:
                raise ValueError(f"agent_record_duplicate:{spec.record_type}")
            if spec.effect == "write" and spec.owner_record_type not in owned:
                raise ValueError(f"agent_record_foreign_owner:{module_id}:{spec.record_type}")
            owner_claim = owned.get(spec.owner_record_type) or {}
            canonical_owner = owner_claim.get("canonical_writer") or owner_claim.get("owner_ref")
            if spec.effect == "write" and not canonical_owner:
                raise ValueError(f"agent_record_owner_missing:{module_id}:{spec.record_type}")
            records[spec.record_type] = replace(deepcopy(spec), canonical_owner=canonical_owner)
        write_types = {spec.record_type for spec in contribution.records if spec.effect == "write"}
        for code, risk, field_name, preview_record_types in contribution.owner_shape_errors:
            if not all(isinstance(value, str) and value.strip() for value in (code, risk, field_name)):
                raise ValueError(f"agent_owner_shape_error_invalid:{module_id}")
            if code in owner_shape_errors:
                raise ValueError(f"agent_owner_shape_error_duplicate:{code}")
            if any(record_type not in write_types for record_type in preview_record_types):
                raise ValueError(f"agent_owner_shape_error_foreign_record:{module_id}:{code}")
            owner_shape_errors[code] = (risk, field_name, tuple(preview_record_types))

    active_roles = {name for name, role in roles.items() if role.observation_role}
    selected = []
    for spec in records.values():
        agents = tuple(name for name in spec.agents if name in active_roles)
        if agents:
            selected.append(replace(
                spec, agents=agents,
                required_context_agents=tuple(name for name in spec.required_context_agents if name in agents),
            ))
    active_rules, rule_supersessions = _assemble_rule_entries(rule_entries, as_of=rules_as_of)
    return AgentContracts(
        roles=roles, records=tuple(sorted(selected, key=lambda item: item.record_type)),
        rule_entries=active_rules, rule_supersessions=rule_supersessions,
        query_policies=query_policies,
        deterministic_source_hashes=deterministic_source_hashes,
        visual_source_hashes=visual_source_hashes,
        owner_shape_errors=owner_shape_errors,
        review_risk_human_actions=review_risk_human_actions,
        review_field_labels_zh=review_field_labels_zh,
        review_row_identity_fields=review_row_identity_fields,
        review_value_labels_zh=review_value_labels_zh,
        review_rule_renderers_zh=review_rule_renderers_zh,
    )
