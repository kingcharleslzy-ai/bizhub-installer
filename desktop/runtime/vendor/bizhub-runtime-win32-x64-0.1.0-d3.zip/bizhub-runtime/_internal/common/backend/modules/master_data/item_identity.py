"""按登记分类解析散装物品；名称定类别，来源属性保留规格和使用状态。"""

from __future__ import annotations

import re
from decimal import Decimal
from typing import Any, Mapping, Sequence


def classify_bulk_item(*, name: str, source_name: str, code: str | None, notes: str,
                       classifications: Sequence[Mapping[str, Any]], category: str | None = None) -> dict[str, Any] | None:
    for rule in classifications:
        if category and category != rule["category"]:
            continue
        if not category and not any(word in name for word in rule["words"]):
            continue
        sources = (source_name, name, notes)
        match = next((match for text in sources if (match := re.search(rule["spec_pattern"], text))), None)
        state = next((key for text in sources for key, words in rule["states"] if any(word in text for word in words)), None)
        label = dict(rule["state_labels"]).get(state, rule["label"])
        spec = match.group(1) if match else None
        return {"category": rule["category"], "category_label": rule["label"],
                "variant": state if rule["state_variant"] else None,
                "variant_label": label if rule["state_variant"] else None,
                "wire_spec": spec, "wire_state": state, "identity_code": code,
                "canonical_name": f"{label}{spec or ''}" if rule["state_variant"] else label}
    return None


def bulk_line_identity(row: Mapping[str, Any], *, classifications, residual_words, residual_label: str,
                       weight_label: str, spec_suffix: str) -> str | None:
    code = re.sub(r"\s+", "", str(row.get("item_code") or row.get("code") or "")).upper().replace("#", "").replace("＃", "")
    name = re.sub(r"\s+", "", str(row.get("item_name") or row.get("name") or ""))
    text = f"{code}{name.upper()}"
    residual = any(word in text for word in residual_words)
    identity = classify_bulk_item(name=text, source_name=name, code=code, notes="", classifications=classifications)
    weight = next((row[field] for field in ("return_weight_g", "weight_g", "outbound_weight_g")
                   if row.get(field) not in (None, "")), None)
    if not code and weight is not None and (residual or identity):
        try:
            amount = format(Decimal(str(weight)), "f")
            if "." in amount:
                amount = amount.rstrip("0").rstrip(".")
        except (ArithmeticError, ValueError):
            amount = str(weight)
        return f"{residual_label if residual else weight_label}{amount}"
    if residual:
        return residual_label
    if identity and identity["wire_spec"]:
        return f"{identity['wire_spec']}{spec_suffix}"
    return code or name or None
