"""库存账标准表 ``stock_moves``：双边流水（从库位 → 到库位），读取与盘点规则见 ``stock_ledger``。

和库位标准表同一套做法（``location_schema``）：这里是唯一定义，取的是首家客户生产库数量台账现在的形状。
客户库里的同名表必须等于“标准表 + 该客户登记的扩展”，由一致性检查逐项核对。

- 对照 Odoo ``stock.move`` / ERPNext Stock Ledger Entry：``from_location``/``to_location`` 是 ``locations.key``；
  ``quantity`` 主数量（可带小数，同 ERPNext ``actual_qty``），``unit_id`` 是它的计量单位（Odoo ``product_uom``；
  空 = 该类别自己的件数），``weight_g`` 第二数量（克重）；``crystal_id`` 是序列号列（Odoo ``lot_id``）。
- ``qty_after_move``：盘点行的盘后数量（ERPNext ``qty_after_transaction``），盘点行数量为 0。
- 来源 ``source_model``/``source_id``/``source_line_key`` 在有效行里唯一；作废只打 ``is_cancelled``，不删行。
"""

from __future__ import annotations

from backend.modules.master_data.schema import Column, ExpressionCheck, ForeignKey, Index, Table, create_table_sql


def _c(name: str, type_: str, *, nullable: bool = False) -> Column:
    return Column(name, type_, nullable)


STOCK_MOVES = Table(
    "stock_moves",
    (
        _c("id", "INTEGER"),
        _c("move_date", "DATE"),
        _c("item_kind", "VARCHAR(40)"),
        _c("product_id", "INTEGER", nullable=True),
        _c("product_spec_id", "INTEGER", nullable=True),
        _c("spec", "VARCHAR(50)"),
        _c("from_location", "VARCHAR(80)"),
        _c("to_location", "VARCHAR(80)"),
        _c("quantity", "NUMERIC"),
        _c("unit_id", "INTEGER", nullable=True),
        _c("weight_g", "NUMERIC", nullable=True),
        _c("qty_after_move", "INTEGER", nullable=True),
        _c("party_id", "INTEGER", nullable=True),
        _c("source_model", "VARCHAR(80)"),
        _c("source_id", "INTEGER"),
        _c("source_line_key", "VARCHAR(120)"),
        _c("crystal_id", "VARCHAR(50)", nullable=True),
        _c("document_id", "INTEGER", nullable=True),
        _c("document_version", "INTEGER", nullable=True),
        Column("is_cancelled", "BOOLEAN", server_default="0", raw_default=True),
        _c("cancelled_at", "DATETIME", nullable=True),
        _c("cancelled_by_version", "INTEGER", nullable=True),
        _c("created_at", "DATETIME"),
    ),
    expression_checks=(
        ExpressionCheck(
            "ck_stock_moves_quantity_positive", "quantity > 0 OR (quantity = 0 AND qty_after_move IS NOT NULL)"
        ),
    ),
    foreign_keys=(
        ForeignKey("product_id", "products", "id", "RESTRICT"),
        ForeignKey("product_spec_id", "product_specs", "id", "RESTRICT"),
        ForeignKey("unit_id", "measurement_units", "id", "RESTRICT"),
        ForeignKey("from_location", "locations", "key", "RESTRICT"),
        ForeignKey("to_location", "locations", "key", "RESTRICT"),
        ForeignKey("document_id", "business_documents", "id", "RESTRICT"),
    ),
    indexes=(
        Index("uq_stock_moves_source_line", ("source_model", "source_id", "source_line_key"), unique=True,
              where="is_cancelled = 0"),
        Index("ix_stock_moves_kind_spec_date", ("item_kind", "spec", "move_date")),
        Index("ix_stock_moves_document_id", ("document_id",)),
    ),
)


def stock_move_schema_sql() -> tuple[str, ...]:
    return create_table_sql(STOCK_MOVES)


__all__ = ["STOCK_MOVES", "stock_move_schema_sql"]
