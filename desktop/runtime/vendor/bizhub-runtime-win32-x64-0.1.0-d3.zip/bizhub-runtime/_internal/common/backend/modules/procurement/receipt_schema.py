"""到货认领标准表：一笔入库流水认领到哪张采购明细、认领多少。

和采购单标准表同一套做法（``order_schema``）：这里是唯一定义，取的是首家客户生产库现在的形状。
一条采购明细和一笔入库流水之间最多一条认领行；认领只进不删，撤销改状态并留下撤销人、撤销时间。
``receipt_event_id`` 指向那笔入库流水；它在哪本库存账里由各库在扩展里绑定（外键）：客户库是通用库存账
``stock_moves``，单独启动的通用应用是它自己的流水表。
"""

from __future__ import annotations

from backend.modules.master_data.schema import Check, Column, ExpressionCheck, ForeignKey, Index, Table, create_table_sql

ALLOCATION_STATUSES = ("confirmed", "reversed")
RECEIPT_ALLOCATIONS = "procurement_receipt_allocations"


def _c(name: str, type_: str, *, nullable: bool = False) -> Column:
    return Column(name, type_, nullable)


PROCUREMENT_RECEIPT_ALLOCATIONS = Table(
    RECEIPT_ALLOCATIONS,
    (
        _c("id", "INTEGER"),
        _c("procurement_id", "INTEGER"),
        _c("receipt_event_id", "INTEGER"),
        _c("allocated_quantity", "NUMERIC"),
        _c("quantity_unit_id", "INTEGER"),
        _c("status", "VARCHAR(30)"),
        _c("source_kind", "VARCHAR(60)"),
        _c("source_ref", "TEXT"),
        _c("notes", "TEXT"),
        _c("confirmed_by", "VARCHAR(120)"),
        _c("confirmed_at", "DATETIME"),
        _c("reversed_by", "VARCHAR(120)"),
        _c("reversed_at", "DATETIME", nullable=True),
        _c("created_at", "DATETIME"),
    ),
    uniques=(("uq_procurement_receipt_allocation_pair", ("procurement_id", "receipt_event_id")),),
    checks=(Check("ck_procurement_receipt_allocation_status", "status", ALLOCATION_STATUSES),),
    expression_checks=(ExpressionCheck("ck_procurement_receipt_allocation_positive", "allocated_quantity > 0"),),
    foreign_keys=(
        ForeignKey("procurement_id", "procurements", "id", "CASCADE"),
        ForeignKey("quantity_unit_id", "measurement_units", "id", "RESTRICT"),
    ),
    indexes=(
        Index("ix_procurement_receipt_allocation_procurement", ("procurement_id", "status")),
        Index("ix_procurement_receipt_allocation_event", ("receipt_event_id", "status")),
    ),
)

RECEIPT_STANDARD_TABLES: tuple[Table, ...] = (PROCUREMENT_RECEIPT_ALLOCATIONS,)


def receipt_schema_sql() -> tuple[str, ...]:
    return tuple(statement for table in RECEIPT_STANDARD_TABLES for statement in create_table_sql(table))


__all__ = [
    "ALLOCATION_STATUSES",
    "PROCUREMENT_RECEIPT_ALLOCATIONS",
    "RECEIPT_ALLOCATIONS",
    "RECEIPT_STANDARD_TABLES",
    "receipt_schema_sql",
]
