"""The only public read facade used by generic business modules."""

from __future__ import annotations

import json
import sqlite3
from typing import Any

from .contracts import (
    MASTER_DATA_REF_FIELDS,
    NUMERIC_RESOURCE_KINDS,
    RESOURCE_KINDS,
    contract_scalar_ok,
    digest_json,
    is_master_data_ref,
)
from .matching import normalize_identity
from .name_types import NAME_TYPES, NameType, scope_key
from .policy import normalize_business_identifier


class MasterDataError(RuntimeError):
    def __init__(self, code: str, message: str):
        super().__init__(f"{code}: {message}")
        self.code = code
        self.message = message


# 标准表：(表名, 显示名所在列, 该种主数据的标准字段)。
_STANDARD = {
    "party": ("business_parties", "canonical_name", ("legal_name",)),
    "product": ("products", "canonical_name", ("product_family",)),
    "unit": ("measurement_units", "display_name", ("canonical_code", "dimension", "factor_to_base")),
}
EXTERNAL_IDENTITIES_TABLE = "master_data_external_identities"


def has_external_identities(connection: sqlite3.Connection) -> bool:
    """外部编号映射是通用可选表：没建这张表的库（如未启用外部导入的客户库）不查它。"""

    return connection.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (EXTERNAL_IDENTITIES_TABLE,)
    ).fetchone() is not None


def _external_resource_key(resource_kind: str, resource_id: object) -> str:
    return str(resource_id)


def _resource_from_row(resource_kind: str, row: sqlite3.Row) -> dict[str, Any]:
    payload = dict(row)
    if resource_kind == "location":
        payload.pop("normalized_name", None)
        payload["attributes"] = json.loads(str(payload.pop("attributes_json") or "{}"))
        payload["canonical_name"] = str(payload["display_name"])
        payload["resource_id"] = str(payload["key"])
    else:
        _, label_column, fields = _STANDARD[resource_kind]
        payload["resource_id"] = int(payload["id"])
        payload["canonical_name"] = str(payload[label_column])
        if resource_kind == "unit":
            payload["code"] = str(payload["canonical_code"])
            if payload.get("factor_to_base") is not None:
                payload["factor_to_base"] = str(payload["factor_to_base"])
        payload = {key: value for key, value in payload.items() if key in {
            "id", "resource_id", "canonical_name", "status", "code", *fields,
        }}
    payload["resource_kind"] = resource_kind
    return payload


def get_resource(
    connection: sqlite3.Connection,
    resource_kind: str,
    resource_id: object,
    *,
    require_active: bool = True,
) -> dict[str, Any]:
    if resource_kind not in RESOURCE_KINDS:
        raise MasterDataError("master_data_resource_kind_invalid", resource_kind)
    if resource_kind in NUMERIC_RESOURCE_KINDS:
        if not is_master_data_ref(resource_id):
            raise MasterDataError("master_data_reference_invalid", f"{resource_kind}:{resource_id!r}")
        row = connection.execute(
            f"SELECT * FROM {_STANDARD[resource_kind][0]} WHERE id=?", (resource_id,)
        ).fetchone()
    else:
        row = connection.execute(
            "SELECT * FROM locations WHERE key=?", (str(resource_id),)
        ).fetchone()
    if row is None:
        raise MasterDataError(
            "master_data_resource_missing", f"{resource_kind}:{resource_id}"
        )
    payload = _resource_from_row(resource_kind, row)
    if require_active and payload.get("status") != "active":
        raise MasterDataError(
            "master_data_resource_inactive", f"{resource_kind}:{resource_id}"
        )
    return payload


def _resource_ref(resource_kind: str, value: str) -> object:
    return int(value) if resource_kind in NUMERIC_RESOURCE_KINDS else value


def resolve_external_identity(
    connection: sqlite3.Connection,
    *,
    resource_kind: str,
    source_id: str,
    external_id: str,
) -> dict[str, Any]:
    row = None
    if has_external_identities(connection):
        row = connection.execute(
            f"""SELECT resource_id, alias, status
               FROM {EXTERNAL_IDENTITIES_TABLE}
               WHERE resource_kind=? AND source_id=? AND external_id=?""",
            (resource_kind, source_id, external_id),
        ).fetchone()
    if row is None or str(row["status"]) != "active":
        raise MasterDataError(
            "master_data_external_identity_missing",
            f"{resource_kind}:{source_id}:{external_id}",
        )
    resource = get_resource(connection, resource_kind, _resource_ref(resource_kind, str(row["resource_id"])))
    resource["external_identity"] = {
        "source_id": source_id,
        "external_id": external_id,
        "alias": str(row["alias"] or ""),
    }
    return resource


def resolve_alias(
    connection: sqlite3.Connection,
    *,
    resource_kind: str,
    source_id: str,
    alias: str,
) -> dict[str, Any]:
    normalized = normalize_identity(alias)
    rows = []
    if has_external_identities(connection):
        rows = connection.execute(
            f"""SELECT resource_id FROM {EXTERNAL_IDENTITIES_TABLE}
               WHERE resource_kind=? AND source_id=? AND normalized_alias=? AND status='active'""",
            (resource_kind, source_id, normalized),
        ).fetchall()
    if len(rows) != 1:
        code = (
            "master_data_alias_missing"
            if not rows
            else "master_data_alias_ambiguous"
        )
        raise MasterDataError(code, f"{resource_kind}:{source_id}:{alias}")
    return get_resource(connection, resource_kind, _resource_ref(resource_kind, str(rows[0]["resource_id"])))


def _active_rows(connection: sqlite3.Connection, resource_kind: str) -> list[dict[str, Any]]:
    if resource_kind == "location":
        rows = connection.execute(
            "SELECT * FROM locations WHERE status='active' ORDER BY display_name, key"
        ).fetchall()
    else:
        table, label_column, _ = _STANDARD[resource_kind]
        rows = connection.execute(
            f"SELECT * FROM {table} WHERE status='active' ORDER BY {label_column}, id"
        ).fetchall()
    return [_resource_from_row(resource_kind, row) for row in rows]


def search_catalog(
    connection: sqlite3.Connection,
    resource_kind: str,
    query: str = "",
    *,
    limit: int = 20,
    offset: int = 0,
) -> list[dict[str, Any]]:
    """Read-only catalog search for callers that must resolve identities first.

    Besides canonical names and ids, confirmed aliases, active external ids and
    external aliases are searched as candidates; a query that matches several
    resources keeps every match so the caller can clarify instead of guessing
    a unique owner.
    """

    if resource_kind not in RESOURCE_KINDS:
        raise MasterDataError("master_data_resource_kind_invalid", resource_kind)
    raw = str(query or "").strip()
    normalized = normalize_identity(query)
    rows = _active_rows(connection, resource_kind)
    aliases: dict[str, list[str]] = {}
    if resource_kind in NUMERIC_RESOURCE_KINDS:
        for row in connection.execute(
            """SELECT entity_id, normalized_alias FROM master_data_aliases
               WHERE entity_type=? AND alias_status='confirmed'""",
            (resource_kind,),
        ):
            aliases.setdefault(str(row["entity_id"]), []).append(str(row["normalized_alias"]))
    identities: dict[str, list[dict[str, str]]] = {}
    if has_external_identities(connection):
        for row in connection.execute(
            f"""SELECT source_id, external_id, alias, normalized_alias, resource_id
               FROM {EXTERNAL_IDENTITIES_TABLE}
               WHERE resource_kind=? AND status='active'
               ORDER BY resource_id, source_id, external_id""",
            (resource_kind,),
        ):
            identities.setdefault(str(row["resource_id"]), []).append(dict(row))
    matched: list[dict[str, Any]] = []
    for item in rows:
        key = _external_resource_key(resource_kind, item["resource_id"])
        own = identities.get(key, [])
        hits = [
            identity for identity in own
            if normalized and (identity["external_id"] == raw or normalized in str(identity["normalized_alias"]))
        ]
        if normalized and not (
            normalized in normalize_identity(item["canonical_name"])
            or key == raw
            or any(normalized in alias for alias in aliases.get(key, ()))
            or hits
        ):
            continue
        result = {name: value for name, value in item.items() if name not in {"id", "location_id"}}
        if hits:
            result["external_identities"] = [
                {"source_id": str(hit["source_id"]), "external_id": str(hit["external_id"]), "alias": str(hit["alias"] or "")}
                for hit in hits
            ]
        matched.append(result)
    start = max(0, int(offset))
    return matched[start:start + max(1, min(int(limit), 101))]


def list_locations(connection: sqlite3.Connection) -> list[dict[str, Any]]:
    return [
        {**item, "location_id": item["resource_id"]}
        for item in _active_rows(connection, "location")
    ]


__all__ = [
    "NAME_TYPES",
    "NameType",
    "scope_key",
    "read_resource_names",
    "read_party",
    "MASTER_DATA_REF_FIELDS",
    "MasterDataError",
    "contract_scalar_ok",
    "is_master_data_ref",
    "get_resource",
    "digest_json",
    "has_external_identities",
    "list_locations",
    "normalize_business_identifier",
    "normalize_identity",
    "resolve_alias",
    "resolve_external_identity",
    "search_catalog",
]


# 客户模块调用通用主数据写入、查找、人工处理时只走这个公开入口（放在末尾：这些模块
# 导入本模块已定义好的 MasterDataError 等名称）。
from . import commands, intents, lookup, resolution, writes  # noqa: E402
from .item_identity import bulk_line_identity, classify_bulk_item

from .name_snapshots import NameAliasSnapshot, ProvidedNameAliases  # noqa: E402

__all__ += ["commands", "intents", "lookup", "resolution", "writes", "NameAliasSnapshot", "ProvidedNameAliases"]
__all__ += ["bulk_line_identity", "classify_bulk_item", "project_item_names", "project_names"]
from .document_hints import (  # noqa: E402
    CORRECTION_WORDS,
    SUPPLEMENT_WORDS,
    document_catalog_contribution,
    existing_document_prompt_rule_zh,
)

__all__ += ["CORRECTION_WORDS", "SUPPLEMENT_WORDS", "document_catalog_contribution", "existing_document_prompt_rule_zh"]


def project_item_names(connection, names, *, policy=None) -> dict[str, str]:
    """散装单据读写共用正式名称；未登记的历史原名仍交领域分类。"""
    from .policy import DEFAULT_POLICY

    return {
        name: lookup.project_name(connection, "product", name, policy=policy or DEFAULT_POLICY)
        for name in dict.fromkeys(str(value or "").strip() for value in names)
    }


def project_names(connection, domain, references, *, policy=None) -> dict[tuple, str]:
    """Batch read-only labels keyed by (formal identity, original wording)."""
    from .policy import DEFAULT_POLICY

    return {
        (entity_id, name): lookup.project_name(
            connection, domain, name, entity_id=entity_id, policy=policy or DEFAULT_POLICY,
        )
        for entity_id, name in dict.fromkeys(references)
    }


async def read_resource_names(db, *, resource_kind: str, resource_ids) -> dict[int, str]:
    """Read standard labels without loading a customer's extended ORM row."""
    from sqlalchemy import column, select, table

    if resource_kind not in _STANDARD:
        raise MasterDataError("master_data_resource_kind_invalid", resource_kind)
    ids = tuple(resource_ids)
    if not ids:
        return {}
    name, label, _ = _STANDARD[resource_kind]
    resource = table(name, column("id"), column(label))
    return dict((await db.execute(select(resource.c.id, resource.c[label])
                                 .where(resource.c.id.in_(ids)))).all())


async def read_party(db, *, party_id: int | None = None, canonical_name: str | None = None):
    """一个正式往来方的标准字段（编号、正式名称、法定名称、状态），按编号或正式名称精确取；没有返回空。

    只读标准列，不加载企业扩展的整行。"""
    from sqlalchemy import column, select, table

    if (party_id is None) == (canonical_name is None):
        raise MasterDataError("master_data_party_read_requires_one_key", "party_id or canonical_name")
    parties = table("business_parties", column("id"), column("canonical_name"), column("legal_name"),
                    column("status"))
    key = parties.c.id == int(party_id) if party_id is not None else parties.c.canonical_name == canonical_name
    return (await db.execute(select(parties).where(key))).first()


# 业务会话（AsyncSession）入口和本企业已装的规则：按需加载，独立通用产品不带业务会话时不受影响。
_SESSION_ENTRY_EXPORTS = frozenset({
    "ALL_MODELS",
    "confirm_alias_candidate",
    "count_alias_candidates",
    "ensure_party_role",
    "is_safe_unique_party_containment_candidate",
    "list_alias_candidates",
    "party_formal_names_with_role",
    "party_roles_for_wording",
    "preview_resolution",
    "record_governance",
    "reject_alias_candidate",
    "remember_resolutions",
    "resolve",
    "run_standard_read",
    "run_standard_write",
    "search_master_data",
    "unique_party_label_with_role",
})
_INSTALLED_EXPORTS = frozenset({"assemble_master_data_policy", "installed_master_data_policy"})


def __getattr__(name: str):
    if name in _SESSION_ENTRY_EXPORTS:
        from . import session_entry

        return getattr(session_entry, name)
    if name in _INSTALLED_EXPORTS:
        from . import installed

        return getattr(installed, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ += sorted(_SESSION_ENTRY_EXPORTS | _INSTALLED_EXPORTS)
