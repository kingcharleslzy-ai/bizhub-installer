"""Single writer for customer-neutral procurement orders and receipts."""

from __future__ import annotations

from backend.kernel.profile_registry import StorageTarget, read_storage, storage_connect, write_storage

import json
import sqlite3
import unicodedata
import uuid
from collections import Counter
from datetime import UTC, date, datetime
from decimal import Context, Decimal, Inexact, localcontext
from pathlib import Path
from typing import Any, Iterable
from zoneinfo import ZoneInfo

from backend.modules.inventory.public import (
    InventoryCommand,
    InventoryPreview,
    apply_preview_in_transaction as apply_inventory_in_transaction,
    preview_action_in_transaction as preview_inventory_in_transaction,
    read_action_in_transaction as read_inventory_in_transaction,
)
from backend.modules.master_data.public import MasterDataError, get_resource, is_master_data_ref
from backend.modules.trade_core.public import (
    BUSINESS_TIMEZONE,
    business_datetime,
    TradeRuleError,
    aggregate_order_progress,
    check_decimal_range,
    decimal_sum,
    digest_json,
    normalized_evidence_refs,
    quantity_decimal,
    strict_money,
)

from . import settlement_writes as settlement
from .settlement_reads import read_settlement_records

from .contracts import (ProcurementCommand, ProcurementPreview, ProcurementReceiptCommand, ProcurementReceiptPreview,
                        ProcurementTermsCommand, ProcurementInvoiceCommand, ProcurementDocumentPreview,
                        ProcurementPaymentCommand, ProcurementPaymentPreview)

from backend.kernel.runtime.quantity_parser import canonical_decimal_text, finite_decimal


# Reversal state and physical writes remain under this original transaction Owner.
from backend.modules.trade_core.public import (
    TradeReversalCommand, TradeReversalPreview, apply_reversal as _apply_trade_reversal,
    preview_reversal as _preview_trade_reversal, reversal_documents as _reversal_documents,
    reversed_movement, target_voided,
)


MODULE_ID = "procurement"
OWNER_REF = f"{MODULE_ID}:order-owner"
REQUIRED_MODULES = {MODULE_ID, "trade_core", "master_data", "inventory"}


class ProcurementOwnerError(RuntimeError):
    def __init__(self, code: str, message: str):
        super().__init__(f"{code}: {message}")
        self.code = code
        self.message = message


def _identity_text(value: str | None) -> str:
    return unicodedata.normalize("NFKC", value or "").strip().casefold()


def _arrival_facts(document: dict[str, Any], lines: Iterable[dict[str, Any]]) -> tuple[Any, ...]:
    details = [(line["product_id"], line["unit_id"], line.get("order_line_id") or None,
                _quantity(line["arrived_quantity"])) for line in lines]
    return document["supplier_party_id"], document["occurred_at"], Counter(details)


def _post_facts(command: ProcurementReceiptCommand) -> tuple[Any, ...]:
    allocations = [(item.receipt_line_id, item.order_line_id, item.location_id,
                    _quantity(item.quantity), _quantity(item.over_receipt_allowance, allow_zero=True))
                   for item in command.allocations]
    return command.document_id, command.occurred_at, Counter(allocations)


def _check_receipt_identity(connection: sqlite3.Connection, command: ProcurementReceiptCommand) -> None:
    if command.action == "register":
        identity = _identity_text(command.source_identity)
        for row in connection.execute("SELECT * FROM procurement_receipt_documents"):
            same_identity = (row["supplier_party_id"] == command.supplier_party_id
                             and _identity_text(row["source_identity"]) == identity)
            if not same_identity and row["document_id"] != command.document_id:
                continue
            same = same_identity and _arrival_facts(dict(row), _receipt_lines(connection, row["document_id"])) == _arrival_facts(
                command.to_dict(), [item.to_dict() for item in command.lines])
            code = "procurement_arrival_duplicate" if same else "procurement_arrival_identity_conflict"
            raise ProcurementOwnerError(code, f"existing document_id={row['document_id']}")
    elif command.action == "post" and command.post_reference is not None:
        reference = _identity_text(command.post_reference)
        if not reference:
            raise ProcurementOwnerError("procurement_post_identity_required", "post_reference")
        for row in connection.execute("""SELECT r.action_id, r.post_reference, a.payload_json
            FROM procurement_action_receipts r JOIN procurement_audit_events a ON a.event_id=r.audit_event_id
            WHERE r.document_kind='receipt' AND r.post_reference IS NOT NULL"""):
            if _identity_text(row["post_reference"]) != reference:
                continue
            previous = ProcurementReceiptCommand.from_dict(json.loads(row["payload_json"])["command"])
            same = _post_facts(previous) == _post_facts(command)
            code = "procurement_post_duplicate" if same else "procurement_post_identity_conflict"
            raise ProcurementOwnerError(code, f"existing action_id={row['action_id']}")


def _invoice_facts(document: dict[str, Any], lines: Iterable[dict[str, Any]]) -> tuple[Any, ...]:
    header = tuple(document.get(key) for key in ("supplier_party_id", "currency", "business_date", "tax_basis"))
    amounts = tuple((_quantity(document[key], allow_zero=True) if key == "tax_rate" else _money(document[key]))
                    if document.get(key) is not None else None
                    for key in ("total_amount", "net_amount", "tax_amount", "tax_rate"))
    details = [(line["product_id"], line["unit_id"], _quantity(line["quantity"]),
                *((_quantity(line[key], allow_zero=True) if key == "unit_price" else _money(line[key]))
                  if line.get(key) is not None else None for key in ("amount", "unit_price", "tax_amount")))
               for line in lines]
    return *header, *amounts, Counter(details)


def _check_invoice_identity(connection: sqlite3.Connection, command: ProcurementInvoiceCommand) -> None:
    if command.action != "register":
        return
    identity = _identity_text(command.external_invoice_number)
    for stored in connection.execute("SELECT * FROM procurement_invoices"):
        row = _invoice_view(stored)
        same_identity = (row["supplier_party_id"] == command.supplier_party_id
                         and _identity_text(row["external_invoice_number"]) == identity)
        if not same_identity and row["source_key"] != command.source_key:
            continue
        lines = [dict(item) for item in connection.execute("SELECT * FROM procurement_invoice_lines WHERE invoice_id=?", (row["invoice_id"],))]
        same = same_identity and _invoice_facts(dict(row), lines) == _invoice_facts(command.to_dict(), [item.to_dict() for item in command.lines])
        code = "procurement_invoice_duplicate" if same else "procurement_invoice_identity_conflict"
        raise ProcurementOwnerError(code, f"existing invoice_id={row['invoice_id']}")


def _check_payment_identity(connection: sqlite3.Connection, command: ProcurementPaymentCommand) -> None:
    if command.action != "register":
        return
    reference = _identity_text(command.external_reference)
    for stored in connection.execute("SELECT * FROM procurement_payments WHERE supplier_party_id=? AND status='confirmed'", (command.supplier_party_id,)):
        row = _payment_view(stored)
        if _identity_text(row["external_reference"]) != reference:
            continue
        same = (row["channel"] is not None and row["paid_at"] is not None
                and Decimal(row["amount"]) == _money(command.amount, allow_zero=False)
                and row["currency"] == _currency(command.currency) and row["channel"].strip() == command.channel.strip()
                and datetime.fromisoformat(row["paid_at"]) == datetime.fromisoformat(command.paid_at)
                and row["business_at"] == command.business_at)
        code = "procurement_payment_duplicate" if same else "procurement_payment_identity_conflict"
        raise ProcurementOwnerError(code, f"existing payment_id={row['payment_id']}")


def _require_module_enabled(enabled_module_ids: Iterable[str] | None) -> set[str]:
    if enabled_module_ids is None:
        from backend.generic_kernel.profile import get_generic_registry

        enabled_module_ids = [
            str(item["module_id"])
            for item in get_generic_registry().payload.get("modules", [])
        ]
    enabled = set(enabled_module_ids)
    missing = sorted(REQUIRED_MODULES - enabled)
    if MODULE_ID not in enabled:
        raise ProcurementOwnerError("procurement_module_disabled", f"{MODULE_ID} is not enabled")
    if missing:
        raise ProcurementOwnerError("procurement_dependency_missing", ",".join(missing))
    return enabled


def _connect(path: Path, *, readonly: bool) -> sqlite3.Connection:
    connection = storage_connect(f"file:{path}?mode=ro" if readonly else path, uri=readonly)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys=ON")
    connection.execute("PRAGMA busy_timeout=10000")
    if readonly:
        connection.execute("PRAGMA query_only=ON")
        # One deferred read transaction keeps composite readbacks (details,
        # balances, projections, generation) on a single committed snapshot.
        connection.execute("BEGIN")
    return connection


def _reading(storage: StorageTarget):
    return read_storage(storage, lambda path: _connect(path, readonly=True))


def _writing(storage: StorageTarget):
    return write_storage(storage, lambda path: _connect(path, readonly=False))


def _document_row(row: sqlite3.Row) -> dict[str, Any]:
    # NULL appended columns on v11 rows preserve the historical readback/generation.
    appended = {"conversion_from_unit_id", "conversion_to_unit_id", "conversion_factor", "conversion_source_ref",
                "original_quantity", "original_unit_id", "converted_quantity", "post_reference"}
    return {key: value for key, value in dict(row).items() if key not in appended or value is not None}


def _table_rows(connection: sqlite3.Connection, table: str, key: str) -> list[dict[str, Any]]:
    rows = connection.execute(f"SELECT * FROM {table} ORDER BY {key}")
    if table == "procurement_order_lines":
        # Step 7 replaces the order shape; until then the new allocation handle
        # does not change the existing line_id-based order/receipt state contract.
        return [{name: value for name, value in dict(row).items() if name != "id"} for row in rows]
    return [(_document_row(row) if table in {"procurement_order_line_terms", "procurement_invoice_matches", "procurement_action_receipts"} else dict(row)) for row in rows]


def _state_generation(connection: sqlite3.Connection) -> str:
    # Schema-only v9 upgrades retain the v1 digest's numeric representation
    # and column set. New receipt previews bind the exact text state separately.
    lines = _table_rows(connection, "procurement_order_lines", "line_id")
    for row in lines:
        for key in ("quantity", "received_quantity"):
            row[key] = connection.execute("SELECT CAST(? AS NUMERIC)", (row[key],)).fetchone()[0]
    receipts = _table_rows(connection, "procurement_receipts", "receipt_id")
    for row in receipts:
        row["quantity"] = connection.execute("SELECT CAST(? AS NUMERIC)", (row["quantity"],)).fetchone()[0]
        row.pop("receipt_line_id", None)
        row.pop("over_receipt_allowance", None)
    actions = _table_rows(connection, "procurement_action_receipts", "action_id")
    for row in actions:
        row.pop("document_kind", None)
        row.pop("document_id", None)
        row.pop("post_reference", None)
    return digest_json({"orders": _table_rows(connection, "procurement_orders", "order_id"),
                        "lines": lines, "receipts": receipts, "actions": actions})


def _quantity(value: object, *, allow_zero: bool = False) -> Decimal:
    try:
        return check_decimal_range(quantity_decimal(value, allow_zero=allow_zero), "procurement_quantity_out_of_range")
    except TradeRuleError as exc:
        raise ProcurementOwnerError(str(exc), str(value)) from exc


def _cumulative_quantity(value: object) -> Decimal:
    # Historical received quantities keep their stored digits: v8 SQL-float
    # remainders (0.1+0.2) and legal high-precision values are not new input
    # and must not re-enter the four-decimal input limit. Only finiteness,
    # sign and the integer-digit range still apply to the accumulated total.
    try:
        parsed = quantity_decimal(value, allow_zero=True)
        if parsed.adjusted() >= 18:
            raise TradeRuleError("procurement_quantity_out_of_range")
        return parsed
    except TradeRuleError as exc:
        raise ProcurementOwnerError(str(exc), str(value)) from exc


def _linked_arrival(connection: sqlite3.Connection, order_id: str) -> bool:
    if not connection.execute("SELECT 1 FROM sqlite_master WHERE name='procurement_receipt_lines'").fetchone():
        return False
    return connection.execute(
        """SELECT 1 FROM procurement_receipt_lines r JOIN procurement_order_lines l
           ON r.order_line_id=l.line_id WHERE l.order_id=? LIMIT 1""", (order_id,)
    ).fetchone() is not None


def _linked_terms(connection: sqlite3.Connection, order_id: str) -> bool:
    if not connection.execute("SELECT 1 FROM sqlite_master WHERE name='procurement_order_line_terms'").fetchone():
        return False
    return connection.execute("""SELECT 1 FROM procurement_order_line_terms t
        JOIN procurement_order_lines l ON l.line_id=t.order_line_id WHERE l.order_id=? LIMIT 1""",
        (order_id,)).fetchone() is not None


def _order(connection: sqlite3.Connection, order_id: str) -> dict[str, Any] | None:
    row = connection.execute(
        "SELECT * FROM procurement_orders WHERE order_id=?", (order_id,)
    ).fetchone()
    return dict(row) if row else None


def _lines(connection: sqlite3.Connection, order_id: str) -> list[dict[str, Any]]:
    return [
        dict(row)
        for row in connection.execute(
            "SELECT * FROM procurement_order_lines WHERE order_id=? ORDER BY line_id",
            (order_id,),
        )
    ]


def _validate_command(command: ProcurementCommand) -> tuple[str, ...]:
    if command.action not in {"create", "receive", "cancel", "revise"}:
        raise ProcurementOwnerError("procurement_action_invalid", command.action)
    if not isinstance(command.idempotency_key, str):
        raise ProcurementOwnerError("procurement_idempotency_key_invalid", "use a string")
    if not command.idempotency_key.strip():
        raise ProcurementOwnerError("procurement_idempotency_key_required", "idempotency key is required")
    for field in ("ordered_at", "occurred_at"):
        value = getattr(command, field)
        if value:
            try:
                business_datetime(value)
            except TradeRuleError as exc:
                raise ProcurementOwnerError("procurement_" + field + "_invalid", "use an ISO date or timestamp with timezone") from exc
    if not command.order_id.strip():
        raise ProcurementOwnerError("procurement_order_id_required", "order id is required")
    if not command.source_ref.strip():
        raise ProcurementOwnerError("procurement_source_ref_required", "source ref is required")
    try:
        return normalized_evidence_refs(command.evidence_refs)
    except TradeRuleError as exc:
        raise ProcurementOwnerError(str(exc), "evidence refs are invalid") from exc


def _validated_lines(
    connection: sqlite3.Connection,
    command: ProcurementCommand,
) -> tuple[dict[str, Any], ...]:
    if not command.lines:
        raise ProcurementOwnerError("procurement_lines_required", "at least one line is required")
    if len({item.line_id for item in command.lines}) != len(command.lines):
        raise ProcurementOwnerError("procurement_line_id_duplicate", command.order_id)
    planned: list[dict[str, Any]] = []
    for item in command.lines:
        if not all((item.line_id.strip(), is_master_data_ref(item.product_id), is_master_data_ref(item.unit_id), item.receive_location_id.strip())):
            raise ProcurementOwnerError("procurement_line_identity_required", item.line_id)
        try:
            get_resource(connection, "product", item.product_id)
            get_resource(connection, "unit", item.unit_id)
            get_resource(connection, "location", item.receive_location_id)
            quantity = _quantity(item.quantity)
        except (MasterDataError, TradeRuleError) as exc:
            raise ProcurementOwnerError(getattr(exc, "code", str(exc)), item.line_id) from exc
        planned.append({
            "line_id": item.line_id,
            "product_id": item.product_id,
            "unit_id": item.unit_id,
            "quantity": format(quantity, "f"),
            "received_quantity": "0",
            "receive_location_id": item.receive_location_id,
        })
    return tuple(planned)


def _receipt_id(command: ProcurementCommand) -> str:
    return f"prc-{digest_json(command.to_dict())[:24]}"


def _project_order_status(lines: list[dict[str, Any]]) -> str:
    states = ["completed" if Decimal(str(item["received_quantity"])) >= Decimal(str(item["quantity"]))
              else "partial" if Decimal(str(item["received_quantity"])) > 0 else "open" for item in lines]
    value = aggregate_order_progress(states)
    return {"completed": "received", "partial": "partially_received"}.get(value, value)


def _apply_receiving_effect(connection: sqlite3.Connection, receipt: dict[str, Any],
                            inventory: InventoryPreview, *, enabled: set[str], now: str,
                            refresh_inventory: bool = False) -> dict[str, Any]:
    if refresh_inventory:
        inventory = preview_inventory_in_transaction(connection, inventory.command, enabled_module_ids=enabled)
    result = apply_inventory_in_transaction(connection, inventory, enabled_module_ids=enabled)
    columns = ["receipt_id", "order_id", "line_id", "quantity", "inventory_action_id", "inventory_movement_id",
               "occurred_at", "evidence_refs_json"]
    values = [receipt[key] for key in ("receipt_id", "order_id", "line_id", "quantity")]
    values += [result["action_id"], result["movements"][0]["movement_id"], receipt["occurred_at"], receipt["evidence_refs_json"]]
    if "receipt_line_id" in receipt:
        columns += ["receipt_line_id", "over_receipt_allowance"]
        values += [receipt["receipt_line_id"], receipt["over_receipt_allowance"]]
    connection.execute(f"INSERT INTO procurement_receipts ({', '.join(columns)}) VALUES ({', '.join('?' for _ in columns)})", values)
    current = connection.execute("SELECT received_quantity FROM procurement_order_lines WHERE line_id=?", (receipt["line_id"],)).fetchone()
    received = _cumulative_quantity(decimal_sum((Decimal(str(current[0])), Decimal(receipt["quantity"]))))
    connection.execute("UPDATE procurement_order_lines SET received_quantity=? WHERE line_id=?", (format(received, "f"), receipt["line_id"]))
    status = _project_order_status(_lines(connection, receipt["order_id"]))
    connection.execute("UPDATE procurement_orders SET status=?, updated_at=? WHERE order_id=?", (status, now, receipt["order_id"]))
    return result


def _preview_on_connection(
    connection: sqlite3.Connection,
    command: ProcurementCommand,
    *,
    enabled_module_ids: Iterable[str] | None,
) -> ProcurementPreview:
    enabled = _require_module_enabled(enabled_module_ids)
    evidence_refs = _validate_command(command)
    generation = _state_generation(connection)
    existing = _order(connection, command.order_id)
    planned_lines: tuple[dict[str, Any], ...] = ()
    planned_receipt: dict[str, Any] | None = None
    inventory_preview: dict[str, Any] | None = None

    if command.action == "create":
        if existing is not None:
            raise ProcurementOwnerError("procurement_order_already_exists", command.order_id)
        if not is_master_data_ref(command.supplier_party_id) or not command.ordered_at.strip():
            raise ProcurementOwnerError("procurement_order_identity_required", command.order_id)
        try:
            get_resource(connection, "party", command.supplier_party_id)
        except MasterDataError as exc:
            raise ProcurementOwnerError(exc.code, exc.message) from exc
        planned_lines = _validated_lines(connection, command)
        planned_order = {
            "order_id": command.order_id,
            "supplier_party_id": command.supplier_party_id,
            "ordered_at": command.ordered_at,
            "status": "open",
            "revision": 1,
            "evidence_refs_json": json.dumps(evidence_refs, ensure_ascii=False),
            "source_ref": command.source_ref,
        }
    else:
        if existing is None:
            raise ProcurementOwnerError("procurement_order_not_found", command.order_id)
        current_lines = _lines(connection, command.order_id)
        if command.action in {"revise", "cancel"} and _linked_arrival(connection, command.order_id):
            raise ProcurementOwnerError("procurement_arrival_linked_order_locked", command.order_id)
        if command.action in {"revise", "cancel"} and _linked_terms(connection, command.order_id):
            raise ProcurementOwnerError("procurement_terms_linked_order_locked", command.order_id)
        planned_order = dict(existing)
        if command.action == "receive":
            if existing["status"] == "cancelled":
                raise ProcurementOwnerError("procurement_order_cancelled", command.order_id)
            target = next((item for item in current_lines if item["line_id"] == command.target_line_id), None)
            if target is None:
                raise ProcurementOwnerError("procurement_line_not_found", command.target_line_id)
            try:
                quantity = _quantity(command.quantity)
            except TradeRuleError as exc:
                raise ProcurementOwnerError(str(exc), command.quantity) from exc
            remaining = decimal_sum((Decimal(str(target["quantity"])), Decimal(str(target["received_quantity"])).copy_negate()))
            if quantity > remaining:
                raise ProcurementOwnerError("procurement_receipt_exceeds_remaining", command.target_line_id)
            if not command.occurred_at.strip():
                raise ProcurementOwnerError("procurement_occurred_at_required", command.order_id)
            inventory = preview_inventory_in_transaction(
                connection,
                InventoryCommand(
                    action="inbound",
                    idempotency_key=f"procurement:{command.idempotency_key}",
                    product_id=int(target["product_id"]),
                    unit_id=int(target["unit_id"]),
                    quantity=format(quantity, "f"),
                    to_location_id=str(target["receive_location_id"]),
                    occurred_at=command.occurred_at,
                    source_ref=command.source_ref,
                    reason=command.reason,
                ),
                enabled_module_ids=enabled,
            )
            inventory_preview = inventory.to_dict()
            planned_receipt = {
                "receipt_id": _receipt_id(command),
                "order_id": command.order_id,
                "line_id": command.target_line_id,
                "quantity": format(quantity, "f"),
                "occurred_at": command.occurred_at,
                "evidence_refs_json": json.dumps(evidence_refs, ensure_ascii=False),
            }
            updated_lines = [dict(item) for item in current_lines]
            for item in updated_lines:
                if item["line_id"] == command.target_line_id:
                    item["received_quantity"] = format(
                        decimal_sum((Decimal(str(item["received_quantity"])), quantity)),
                        "f",
                    )
            planned_order["status"] = _project_order_status(updated_lines)
        elif command.action == "cancel":
            if existing["status"] == "cancelled":
                raise ProcurementOwnerError("procurement_order_already_cancelled", command.order_id)
            if any(Decimal(str(item["received_quantity"])) > 0 for item in current_lines):
                raise ProcurementOwnerError(
                    "procurement_received_order_not_cancellable",
                    command.order_id,
                )
            if not command.reason.strip():
                raise ProcurementOwnerError("procurement_cancellation_reason_required", command.order_id)
            planned_order["status"] = "cancelled"
        else:
            if any(Decimal(str(item["received_quantity"])) > 0 for item in current_lines):
                raise ProcurementOwnerError("procurement_received_order_not_revisable", command.order_id + "；请先通过 /api/procurement/reversals preview→apply 冲销收货；已核对发票或付款须人工处理")
            if not command.reason.strip() or not is_master_data_ref(command.supplier_party_id) or not command.ordered_at.strip():
                raise ProcurementOwnerError("procurement_revision_fields_required", command.order_id)
            try:
                get_resource(connection, "party", command.supplier_party_id)
            except MasterDataError as exc:
                raise ProcurementOwnerError(exc.code, exc.message) from exc
            planned_lines = _validated_lines(connection, command)
            planned_order.update({
                "supplier_party_id": command.supplier_party_id,
                "ordered_at": command.ordered_at,
                "status": "open",
                "revision": int(existing["revision"]) + 1,
                "evidence_refs_json": json.dumps(evidence_refs, ensure_ascii=False),
                "source_ref": command.source_ref,
            })
    content = {
        "command": command.to_dict(),
        "state_generation": generation,
        "planned_order": planned_order,
        "planned_lines": list(planned_lines),
        "planned_receipt": planned_receipt,
        "inventory_preview": inventory_preview,
    }
    return ProcurementPreview(
        command=command,
        state_generation=generation,
        planned_order=planned_order,
        planned_lines=planned_lines,
        planned_receipt=planned_receipt,
        inventory_preview=inventory_preview,
        preview_digest=digest_json(content),
    )


def preview_action(
    storage: StorageTarget,
    command: ProcurementCommand,
    *,
    enabled_module_ids: Iterable[str] | None = None,
) -> ProcurementPreview:
    _require_module_enabled(enabled_module_ids)
    with _reading(storage) as connection:
        return _preview_on_connection(
            connection,
            command,
            enabled_module_ids=enabled_module_ids,
        )


def _legacy_quantity_row(connection: sqlite3.Connection, row: sqlite3.Row | dict[str, Any]) -> dict[str, Any]:
    result = {name: value for name, value in dict(row).items() if name != "id"}
    for key in ("quantity", "received_quantity"):
        if key in result:
            numeric = connection.execute("SELECT CAST(? AS NUMERIC)", (result[key],)).fetchone()[0]
            if Decimal(str(numeric)) == Decimal(str(result[key])):
                result[key] = numeric
    return result


def _readback(connection: sqlite3.Connection, action_id: str) -> dict[str, Any]:
    receipt = connection.execute(
        "SELECT * FROM procurement_action_receipts WHERE action_id=?", (action_id,)
    ).fetchone()
    if receipt is None:
        raise ProcurementOwnerError("procurement_readback_missing", action_id)
    if "document_kind" in receipt.keys() and receipt["document_kind"] == "reversal":
        return json.loads(connection.execute("SELECT payload_json FROM procurement_audit_events WHERE event_id=?", (receipt["audit_event_id"],)).fetchone()[0])["readback"]
    if "document_kind" in receipt.keys() and receipt["document_kind"] == "receipt":
        return _receipt_readback(connection, receipt)
    if "document_kind" in receipt.keys() and receipt["document_kind"] in {"terms", "invoice", "payment"}:
        return _document_readback(connection, receipt)
    order_id = str(receipt["order_id"])
    order = _order(connection, order_id)
    inventory = None
    if receipt["inventory_action_id"]:
        inventory = read_inventory_in_transaction(connection, str(receipt["inventory_action_id"]))
    audit = connection.execute(
        "SELECT * FROM procurement_audit_events WHERE event_id=?",
        (receipt["audit_event_id"],),
    ).fetchone()
    return {
        "schema_version": "bizhub.procurement-readback.v1",
        "owner_ref": OWNER_REF,
        "action_id": action_id,
        "idempotency_key": str(receipt["idempotency_key"]),
        "command_digest": str(receipt["command_digest"]),
        "preview_digest": str(receipt["preview_digest"]),
        "order": order,
        "lines": [_legacy_quantity_row(connection, row) for row in _lines(connection, order_id)],
        "receipts": [
            {key: value for key, value in _legacy_quantity_row(connection, row).items() if key not in {"receipt_line_id", "over_receipt_allowance"}}
            for row in connection.execute(
                "SELECT * FROM procurement_receipts WHERE order_id=? ORDER BY receipt_id",
                (order_id,),
            )
        ],
        "inventory": inventory,
        "audit_event": dict(audit) if audit else None,
        "state_generation": _state_generation(connection),
    }


def apply_preview_in_transaction(connection: sqlite3.Connection, preview: ProcurementPreview, *, enabled_module_ids: Iterable[str] | None = None) -> dict[str, Any]:
    if not connection.in_transaction:
        raise ProcurementOwnerError("procurement_transaction_required", "an outer transaction is required")
    enabled = _require_module_enabled(enabled_module_ids)
    if digest_json(preview.content()) != preview.preview_digest:
        raise ProcurementOwnerError("procurement_preview_content_drift", "preview digest differs")
    try:
        existing = connection.execute(
            "SELECT action_id, command_digest FROM procurement_action_receipts WHERE idempotency_key=?",
            (preview.command.idempotency_key,),
        ).fetchone()
        if existing is not None:
            if str(existing["command_digest"]) != preview.command.command_digest:
                raise ProcurementOwnerError("procurement_idempotency_conflict", preview.command.idempotency_key)
            result = _readback(connection, str(existing["action_id"]))
            result["disposition"] = "idempotent_noop"
            return result
        if _state_generation(connection) != preview.state_generation:
            raise ProcurementOwnerError("procurement_state_generation_drift", "procurement changed")
        authoritative = _preview_on_connection(
            connection,
            preview.command,
            enabled_module_ids=enabled,
        )
        if authoritative.preview_digest != preview.preview_digest:
            raise ProcurementOwnerError("procurement_preview_content_drift", "authoritative plan differs")
        inventory_result = None
        now = datetime.now(UTC).isoformat()
        order = authoritative.planned_order
        if preview.command.action == "create":
            connection.execute(
                """INSERT INTO procurement_orders
                   (order_id, supplier_party_id, ordered_at, status, revision,
                    evidence_refs_json, source_ref, created_at, updated_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    order["order_id"], order["supplier_party_id"], order["ordered_at"],
                    order["status"], order["revision"], order["evidence_refs_json"],
                    order["source_ref"], now, now,
                ),
            )
            for line in authoritative.planned_lines:
                connection.execute(
                    """INSERT INTO procurement_order_lines
                       (line_id, order_id, product_id, unit_id, quantity,
                        received_quantity, receive_location_id)
                       VALUES (?, ?, ?, ?, ?, ?, ?)""",
                    (
                        line["line_id"], preview.command.order_id, line["product_id"],
                        line["unit_id"], line["quantity"], line["received_quantity"],
                        line["receive_location_id"],
                    ),
                )
        elif preview.command.action == "receive":
            inventory_result = _apply_receiving_effect(
                connection, authoritative.planned_receipt or {},
                InventoryPreview.from_dict(authoritative.inventory_preview or {}), enabled=enabled, now=now,
            )
        elif preview.command.action == "cancel":
            connection.execute(
                "UPDATE procurement_orders SET status='cancelled', updated_at=? WHERE order_id=?",
                (now, preview.command.order_id),
            )
        else:
            connection.execute(
                """UPDATE procurement_orders SET supplier_party_id=?, ordered_at=?, status=?,
                   revision=?, evidence_refs_json=?, source_ref=?, updated_at=? WHERE order_id=?""",
                (
                    order["supplier_party_id"], order["ordered_at"], order["status"],
                    order["revision"], order["evidence_refs_json"], order["source_ref"],
                    now, preview.command.order_id,
                ),
            )
            connection.execute("DELETE FROM procurement_order_lines WHERE order_id=?", (preview.command.order_id,))
            for line in authoritative.planned_lines:
                connection.execute(
                    """INSERT INTO procurement_order_lines
                       (line_id, order_id, product_id, unit_id, quantity,
                        received_quantity, receive_location_id)
                       VALUES (?, ?, ?, ?, ?, ?, ?)""",
                    (
                        line["line_id"], preview.command.order_id, line["product_id"],
                        line["unit_id"], line["quantity"], line["received_quantity"],
                        line["receive_location_id"],
                    ),
                )
        action_id = uuid.uuid4().hex
        audit_event_id = uuid.uuid4().hex
        connection.execute(
            "INSERT INTO procurement_audit_events(event_id, event_type, payload_json, created_at) VALUES (?, ?, ?, ?)",
            (
                audit_event_id,
                f"procurement_{preview.command.action}_applied",
                json.dumps(authoritative.to_dict(), ensure_ascii=False, sort_keys=True, separators=(",", ":")),
                now,
            ),
        )
        connection.execute(
            """INSERT INTO procurement_action_receipts
               (action_id, idempotency_key, command_digest, preview_digest, order_id,
                audit_event_id, inventory_action_id, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                action_id, preview.command.idempotency_key, preview.command.command_digest,
                preview.preview_digest, preview.command.order_id, audit_event_id,
                (inventory_result or {}).get("action_id"), now,
            ),
        )
        result = _readback(connection, action_id)
    except settlement.SettlementWriteError as exc:
        raise ProcurementOwnerError(exc.code, exc.message) from exc
    except sqlite3.IntegrityError as exc:
        raise ProcurementOwnerError("procurement_write_conflict", str(exc)) from exc
    result["disposition"] = "applied"
    return result


def apply_preview(storage: StorageTarget, preview: ProcurementPreview, *, enabled_module_ids: Iterable[str] | None = None) -> dict[str, Any]:
    _require_module_enabled(enabled_module_ids)
    with _writing(storage) as connection:
        return apply_preview_in_transaction(connection, preview, enabled_module_ids=enabled_module_ids)


def _receipt_generation(connection: sqlite3.Connection) -> str:
    return digest_json({table: _table_rows(connection, table, key) for table, key in (
        ("procurement_orders", "order_id"), ("procurement_order_lines", "line_id"),
        ("procurement_receipts", "receipt_id"), ("procurement_action_receipts", "action_id"),
        ("procurement_receipt_documents", "document_id"), ("procurement_receipt_lines", "line_id"),
    )})


def _receipt_document(connection: sqlite3.Connection, document_id: str) -> dict[str, Any]:
    row = connection.execute("SELECT * FROM procurement_receipt_documents WHERE document_id=?", (document_id,)).fetchone()
    if row is None:
        raise ProcurementOwnerError("procurement_receipt_document_not_found", document_id)
    return dict(row)


def _receipt_lines(connection: sqlite3.Connection, document_id: str) -> list[dict[str, Any]]:
    return [dict(row) for row in connection.execute(
        "SELECT * FROM procurement_receipt_lines WHERE document_id=? ORDER BY line_id", (document_id,))]


def _posted_quantity(connection: sqlite3.Connection, line_id: str) -> Decimal:
    return decimal_sum(Decimal(row[0]) for row in connection.execute(
        "SELECT r.quantity FROM procurement_receipts r WHERE receipt_line_id=? AND NOT EXISTS (SELECT 1 FROM inventory_movements m WHERE m.reverses_movement_id=r.inventory_movement_id)", (line_id,)))


def _target_line(connection: sqlite3.Connection, line_id: str, *, supplier: str,
                 product: str, unit: str) -> dict[str, Any]:
    row = connection.execute(
        """SELECT l.*, o.supplier_party_id, o.status FROM procurement_order_lines l
           JOIN procurement_orders o ON o.order_id=l.order_id WHERE l.line_id=?""", (line_id,)).fetchone()
    if row is None:
        raise ProcurementOwnerError("procurement_line_not_found", line_id)
    if row["status"] == "cancelled":
        raise ProcurementOwnerError("procurement_order_cancelled", row["order_id"])
    for key, expected in (("supplier_party_id", supplier), ("product_id", product), ("unit_id", unit)):
        if row[key] != expected:
            raise ProcurementOwnerError("procurement_receipt_identity_mismatch", key)
    return dict(row)


def _preview_receipt_on_connection(connection: sqlite3.Connection, command: ProcurementReceiptCommand,
                                   *, enabled_module_ids: Iterable[str] | None) -> ProcurementReceiptPreview:
    enabled = _require_module_enabled(enabled_module_ids)
    if command.action not in {"register", "inspect", "post"}:
        raise ProcurementOwnerError("procurement_receipt_action_invalid", command.action)
    if not all(value.strip() for value in (command.idempotency_key, command.document_id, command.source_ref, command.occurred_at)):
        raise ProcurementOwnerError("procurement_receipt_identity_required", command.document_id)
    try:
        business_datetime(command.occurred_at)
    except TradeRuleError as exc:
        raise ProcurementOwnerError("procurement_occurred_at_invalid", "use an ISO date or timestamp with timezone") from exc
    if command.post_reference is not None and command.action != "post":
        raise ProcurementOwnerError("procurement_receipt_fields_invalid", "post_reference is only allowed for post")
    try:
        evidence = normalized_evidence_refs(command.evidence_refs)
    except TradeRuleError as exc:
        raise ProcurementOwnerError(str(exc), "evidence refs are required") from exc
    generation = _receipt_generation(connection)
    planned_lines: list[dict[str, Any]] = []
    allocations: list[dict[str, Any]] = []
    inventory_previews: list[dict[str, Any]] = []
    if command.action == "register":
        if not is_master_data_ref(command.supplier_party_id) or not command.source_identity.strip():
            raise ProcurementOwnerError("procurement_arrival_identity_required", command.document_id)
        if command.allocations or not command.lines or len({item.line_id for item in command.lines}) != len(command.lines):
            raise ProcurementOwnerError("procurement_receipt_lines_invalid", command.document_id)
        _check_receipt_identity(connection, command)
        try:
            get_resource(connection, "party", command.supplier_party_id)
            for item in command.lines:
                if not item.line_id.strip() or any((item.received_quantity, item.accepted_quantity, item.rejected_quantity)):
                    raise ProcurementOwnerError("procurement_registration_inspection_forbidden", item.line_id)
                get_resource(connection, "product", item.product_id)
                get_resource(connection, "unit", item.unit_id)
                quantity = _quantity(item.arrived_quantity)
                if item.order_line_id:
                    _target_line(connection, item.order_line_id, supplier=command.supplier_party_id, product=item.product_id, unit=item.unit_id)
                planned_lines.append({"line_id": item.line_id, "document_id": command.document_id,
                    "product_id": item.product_id, "unit_id": item.unit_id, "order_line_id": item.order_line_id or None,
                    "arrived_quantity": format(quantity, "f"), "received_quantity": format(quantity, "f"),
                    "accepted_quantity": "0", "rejected_quantity": "0", "inspected_at": None, "inspection_evidence_refs_json": None})
        except MasterDataError as exc:
            raise ProcurementOwnerError(exc.code, exc.message) from exc
        document = {"document_id": command.document_id, "supplier_party_id": command.supplier_party_id,
                    "source_identity": command.source_identity, "occurred_at": command.occurred_at,
                    "source_ref": command.source_ref, "evidence_refs_json": json.dumps(evidence, ensure_ascii=False)}
    else:
        document = _receipt_document(connection, command.document_id)
        if target_voided(connection, MODULE_ID, "receipt_document", command.document_id):
            raise ProcurementOwnerError("procurement_receipt_voided", "该收货单已作废，请重新登记收货单")
        current = {item["line_id"]: item for item in _receipt_lines(connection, command.document_id)}
        if command.supplier_party_id or command.source_identity:
            raise ProcurementOwnerError("procurement_receipt_identity_immutable", command.document_id)
        if command.action == "inspect":
            if command.allocations or not command.lines or len({item.line_id for item in command.lines}) != len(command.lines):
                raise ProcurementOwnerError("procurement_inspection_lines_invalid", command.document_id)
            for item in command.lines:
                if item.line_id not in current:
                    raise ProcurementOwnerError("procurement_receipt_line_not_found", item.line_id)
                if any((item.product_id, item.unit_id, item.arrived_quantity, item.order_line_id)):
                    raise ProcurementOwnerError("procurement_receipt_identity_immutable", item.line_id)
                row = dict(current[item.line_id])
                received = _quantity(item.received_quantity, allow_zero=True)
                accepted = _quantity(item.accepted_quantity, allow_zero=True)
                rejected = _quantity(item.rejected_quantity, allow_zero=True)
                if received > Decimal(row["arrived_quantity"]) or decimal_sum((accepted, rejected)) > received:
                    raise ProcurementOwnerError("procurement_inspection_exceeds_arrival", item.line_id)
                if accepted < _posted_quantity(connection, item.line_id):
                    raise ProcurementOwnerError("procurement_inspection_below_posted", item.line_id)
                row.update(received_quantity=format(received, "f"), accepted_quantity=format(accepted, "f"),
                           rejected_quantity=format(rejected, "f"), inspected_at=command.occurred_at,
                           inspection_evidence_refs_json=json.dumps(evidence, ensure_ascii=False))
                planned_lines.append(row)
        else:
            if command.lines or not command.allocations:
                raise ProcurementOwnerError("procurement_allocations_required", command.document_id)
            _check_receipt_identity(connection, command)
            source_totals: dict[str, Decimal] = {}
            target_totals: dict[str, Decimal] = {}
            allowances: dict[str, Decimal] = {}
            for index, allocation in enumerate(command.allocations):
                row = current.get(allocation.receipt_line_id)
                if row is None:
                    raise ProcurementOwnerError("procurement_receipt_line_not_found", allocation.receipt_line_id)
                if row["inspected_at"] is None:
                    raise ProcurementOwnerError("procurement_receipt_not_inspected", allocation.receipt_line_id)
                target = _target_line(connection, allocation.order_line_id, supplier=document["supplier_party_id"],
                                      product=row["product_id"], unit=row["unit_id"])
                quantity = _quantity(allocation.quantity)
                allowance = _quantity(allocation.over_receipt_allowance, allow_zero=True)
                if allocation.order_line_id in allowances and allowances[allocation.order_line_id] != allowance:
                    raise ProcurementOwnerError("procurement_over_receipt_allowance_conflict", allocation.order_line_id)
                allowances[allocation.order_line_id] = allowance
                source_total = decimal_sum((source_totals.get(row["line_id"], _posted_quantity(connection, row["line_id"])), quantity))
                target_total = _cumulative_quantity(decimal_sum((target_totals.get(target["line_id"], Decimal(str(target["received_quantity"]))), quantity)))
                if source_total > Decimal(row["accepted_quantity"]):
                    raise ProcurementOwnerError("procurement_post_exceeds_accepted", row["line_id"])
                if target_total > decimal_sum((Decimal(str(target["quantity"])), allowance)):
                    raise ProcurementOwnerError("procurement_receipt_exceeds_remaining", target["line_id"])
                source_totals[row["line_id"]] = source_total
                target_totals[target["line_id"]] = target_total
                receipt = {"receipt_id": f"prc-{command.command_digest[:24]}-{index}", "receipt_line_id": row["line_id"],
                           "order_id": target["order_id"], "line_id": target["line_id"], "quantity": format(quantity, "f"),
                           "over_receipt_allowance": format(allowance, "f"), "occurred_at": command.occurred_at,
                           "evidence_refs_json": json.dumps(evidence, ensure_ascii=False)}
                inventory = preview_inventory_in_transaction(connection, InventoryCommand(
                    action="inbound", idempotency_key=f"procurement-receipt:{command.idempotency_key}:{index}",
                    product_id=row["product_id"], unit_id=row["unit_id"], quantity=receipt["quantity"],
                    to_location_id=allocation.location_id, occurred_at=command.occurred_at,
                    source_ref=command.source_ref, reason=command.reason), enabled_module_ids=enabled)
                allocations.append(receipt)
                inventory_previews.append(inventory.to_dict())
    content = {"command": command.to_dict(), "state_generation": generation, "planned_document": document,
               "planned_lines": planned_lines, "planned_allocations": allocations, "inventory_previews": inventory_previews}
    return ProcurementReceiptPreview(command, generation, document, tuple(planned_lines), tuple(allocations),
                                     tuple(inventory_previews), digest_json(content))


def preview_receipt_action(storage: StorageTarget, command: ProcurementReceiptCommand, *,
                           enabled_module_ids: Iterable[str] | None = None) -> ProcurementReceiptPreview:
    _require_module_enabled(enabled_module_ids)
    with _reading(storage) as connection:
        return _preview_receipt_on_connection(connection, command, enabled_module_ids=enabled_module_ids)


def _receipt_detail(connection: sqlite3.Connection, document_id: str) -> dict[str, Any]:
    document = _receipt_document(connection, document_id)
    voided = target_voided(connection, MODULE_ID, "receipt_document", document_id)
    if voided:
        document["status"] = "voided"
    lines = _receipt_lines(connection, document_id)
    for line in lines:
        posted = _posted_quantity(connection, line["line_id"])
        line["posted_quantity"] = format(posted, "f")
        line["unposted_accepted_quantity"] = "0" if voided else format(decimal_sum((Decimal(line["accepted_quantity"]), posted.copy_negate())), "f")
    allocations = [dict(row) for row in connection.execute(
        """SELECT r.* FROM procurement_receipts r JOIN procurement_receipt_lines l ON l.line_id=r.receipt_line_id
           WHERE l.document_id=? ORDER BY r.receipt_id""", (document_id,))]
    return {"document": document, "lines": lines, "allocations": allocations}


def _receipt_readback(connection: sqlite3.Connection, action: sqlite3.Row) -> dict[str, Any]:
    detail = _receipt_detail(connection, action["document_id"])
    audit = dict(connection.execute("SELECT * FROM procurement_audit_events WHERE event_id=?", (action["audit_event_id"],)).fetchone())
    planned = json.loads(audit["payload_json"])
    ids = [row["receipt_id"] for row in planned["planned_allocations"]]
    effects = [row for row in detail["allocations"] if row["receipt_id"] in ids]
    return {"schema_version": "bizhub.procurement-receipt-readback.v1", "owner_ref": OWNER_REF,
            "action_id": action["action_id"], "idempotency_key": action["idempotency_key"],
            "command_digest": action["command_digest"], "preview_digest": action["preview_digest"], **detail,
            "inventory": [read_inventory_in_transaction(connection, row["inventory_action_id"]) for row in effects],
            "audit_event": audit, "state_generation": _receipt_generation(connection)}


def read_receipt_document(storage: StorageTarget, document_id: str) -> dict[str, Any]:
    with _reading(storage) as connection:
        return _receipt_detail(connection, document_id)


def read_action(storage: StorageTarget, action_id: str) -> dict[str, Any]:
    with _reading(storage) as connection:
        return _readback(connection, action_id)


def apply_receipt_preview_in_transaction(connection: sqlite3.Connection, preview: ProcurementReceiptPreview, *, enabled_module_ids: Iterable[str] | None = None) -> dict[str, Any]:
    if not connection.in_transaction:
        raise ProcurementOwnerError("procurement_transaction_required", "an outer transaction is required")
    enabled = _require_module_enabled(enabled_module_ids)
    if digest_json(preview.content()) != preview.preview_digest:
        raise ProcurementOwnerError("procurement_preview_content_drift", "preview digest differs")
    try:
        existing = connection.execute("SELECT * FROM procurement_action_receipts WHERE idempotency_key=?", (preview.command.idempotency_key,)).fetchone()
        if existing is not None:
            if existing["command_digest"] != preview.command.command_digest:
                raise ProcurementOwnerError("procurement_idempotency_conflict", preview.command.idempotency_key)
            result = _readback(connection, existing["action_id"])
            return {**result, "disposition": "idempotent_noop"}
        _check_receipt_identity(connection, preview.command)
        if _receipt_generation(connection) != preview.state_generation:
            raise ProcurementOwnerError("procurement_state_generation_drift", "procurement changed")
        authoritative = _preview_receipt_on_connection(connection, preview.command, enabled_module_ids=enabled)
        if authoritative.preview_digest != preview.preview_digest:
            raise ProcurementOwnerError("procurement_preview_content_drift", "authoritative plan differs")
        command = authoritative.command
        now = datetime.now(UTC).isoformat()
        if command.action == "register":
            document = authoritative.planned_document
            connection.execute("""INSERT INTO procurement_receipt_documents
                (document_id, supplier_party_id, source_identity, occurred_at, source_ref, evidence_refs_json, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)""", tuple(document[key] for key in (
                    "document_id", "supplier_party_id", "source_identity", "occurred_at", "source_ref", "evidence_refs_json")) + (now, now))
            for line in authoritative.planned_lines:
                columns = list(line)
                connection.execute(f"INSERT INTO procurement_receipt_lines ({', '.join(columns)}) VALUES ({', '.join('?' for _ in columns)})", tuple(line.values()))
        elif command.action == "inspect":
            for line in authoritative.planned_lines:
                connection.execute("""UPDATE procurement_receipt_lines SET received_quantity=?, accepted_quantity=?,
                    rejected_quantity=?, inspected_at=?, inspection_evidence_refs_json=? WHERE line_id=?""",
                    tuple(line[key] for key in ("received_quantity", "accepted_quantity", "rejected_quantity", "inspected_at", "inspection_evidence_refs_json", "line_id")))
        else:
            for receipt, inventory in zip(authoritative.planned_allocations, authoritative.inventory_previews, strict=True):
                _apply_receiving_effect(connection, receipt, InventoryPreview.from_dict(inventory), enabled=enabled, now=now, refresh_inventory=True)
        connection.execute("UPDATE procurement_receipt_documents SET updated_at=? WHERE document_id=?", (now, command.document_id))
        action_id, audit_id = uuid.uuid4().hex, uuid.uuid4().hex
        connection.execute("INSERT INTO procurement_audit_events(event_id, event_type, payload_json, created_at) VALUES (?, ?, ?, ?)",
                           (audit_id, f"procurement_receipt_{command.action}_applied", json.dumps(authoritative.to_dict(), ensure_ascii=False, sort_keys=True, separators=(",", ":")), now))
        receipt = {"action_id": action_id, "idempotency_key": command.idempotency_key,
                   "command_digest": command.command_digest, "preview_digest": preview.preview_digest,
                   "order_id": None, "audit_event_id": audit_id, "inventory_action_id": None,
                   "created_at": now, "document_kind": "receipt", "document_id": command.document_id}
        if command.post_reference is not None:
            receipt["post_reference"] = command.post_reference
        connection.execute(f"INSERT INTO procurement_action_receipts ({', '.join(receipt)}) VALUES ({', '.join('?' for _ in receipt)})",
                           tuple(receipt.values()))
        result = _readback(connection, action_id)
        return {**result, "disposition": "applied"}
    except settlement.SettlementWriteError as exc:
        raise ProcurementOwnerError(exc.code, exc.message) from exc
    except sqlite3.IntegrityError as exc:
        raise ProcurementOwnerError("procurement_write_conflict", str(exc)) from exc


def apply_receipt_preview(storage: StorageTarget, preview: ProcurementReceiptPreview, *, enabled_module_ids: Iterable[str] | None = None) -> dict[str, Any]:
    _require_module_enabled(enabled_module_ids)
    with _writing(storage) as connection:
        return apply_receipt_preview_in_transaction(connection, preview, enabled_module_ids=enabled_module_ids)


def _money(value: object, *, allow_zero: bool = True) -> Decimal:
    try:
        return strict_money(value, allow_zero=allow_zero, invalid_code="procurement_amount_invalid",
                            range_code="procurement_amount_out_of_range", precision_code="procurement_amount_precision_invalid")
    except TradeRuleError as exc:
        raise ProcurementOwnerError(str(exc), str(value)) from exc


def _optional_decimal(value: str | None, *, money: bool = False) -> str | None:
    if value is None:
        return None
    return format(_money(value) if money else _quantity(value, allow_zero=True), "f")


def _currency(value: str) -> str:
    try:
        return settlement.currency_code(value)
    except settlement.SettlementWriteError as exc:
        raise ProcurementOwnerError(exc.code, str(value)) from exc


def _tax_basis(value: str) -> str:
    if value not in {"tax_inclusive", "tax_exclusive", "unspecified"}:
        raise ProcurementOwnerError("procurement_tax_basis_invalid", value)
    return value


def _document_generation(connection: sqlite3.Connection) -> str:
    return digest_json({"receiving": _receipt_generation(connection), **{
        table: _table_rows(connection, table, key) for table, key in (
            ("procurement_order_line_terms", "terms_id"), ("procurement_invoices", "id"),
            ("procurement_invoice_allocations", "id"),
            ("procurement_invoice_lines", "line_id"), ("procurement_invoice_matches", "match_id"))}})


def _order_line(connection: sqlite3.Connection, line_id: str) -> dict[str, Any]:
    row = connection.execute("""SELECT l.*, o.supplier_party_id, o.status AS order_status
        FROM procurement_order_lines l JOIN procurement_orders o ON o.order_id=l.order_id WHERE l.line_id=?""",
        (line_id,)).fetchone()
    if row is None:
        raise ProcurementOwnerError("procurement_line_not_found", line_id)
    return dict(row)


def _current_terms(connection: sqlite3.Connection, line_id: str) -> dict[str, Any] | None:
    row = connection.execute("SELECT * FROM procurement_order_line_terms WHERE order_line_id=? AND active=1", (line_id,)).fetchone()
    return _document_row(row) if row else None


def _priced_amount(terms: dict[str, Any], quantity: Decimal) -> str | None:
    # No rounding, tax conversion or inferred price. Non-cent proportional
    # amounts require clarification instead of manufacturing an agreed value.
    with localcontext(Context(prec=64)) as context:
        context.traps[Inexact] = True
        try:
            if terms["unit_price"] is not None:
                amount = quantity * Decimal(terms["unit_price"])
            else:
                amount = Decimal(terms["agreed_amount"]) * quantity / Decimal(terms["pricing_quantity"])
            return format(_money(amount), "f")
        except Inexact:
            return None
        except ProcurementOwnerError as exc:
            if exc.code == "procurement_amount_precision_invalid":
                return None
            raise


def _plan_terms(connection: sqlite3.Connection, command: ProcurementTermsCommand, refs: tuple[str, ...]) -> dict[str, Any]:
    if command.action != "set":
        raise ProcurementOwnerError("procurement_terms_action_invalid", command.action)
    line = _order_line(connection, command.order_line_id)
    if line["order_status"] == "cancelled":
        raise ProcurementOwnerError("procurement_order_cancelled", line["order_id"])
    if command.source_kind not in {"quotation", "order_memo", "wechat_quote", "reconciliation_basis"}:
        raise ProcurementOwnerError("procurement_terms_source_invalid", command.source_kind)
    if command.pricing_unit_id != line["unit_id"]:
        raise ProcurementOwnerError("procurement_terms_unit_mismatch", command.pricing_unit_id)
    currency = _currency(command.currency)
    if command.quantity_tolerance is None:
        if command.quantity_tolerance_unit_id is not None:
            raise ProcurementOwnerError("procurement_tolerance_unit_without_value", command.order_line_id)
    elif command.quantity_tolerance_unit_id != command.pricing_unit_id:
        raise ProcurementOwnerError("procurement_tolerance_unit_mismatch", command.order_line_id)
    if command.amount_tolerance is None:
        if command.amount_tolerance_currency is not None:
            raise ProcurementOwnerError("procurement_tolerance_currency_without_value", command.order_line_id)
    elif command.amount_tolerance_currency != currency:
        raise ProcurementOwnerError("procurement_tolerance_currency_mismatch", command.order_line_id)
    conversion = {key: getattr(command, key) for key in (
        "conversion_from_unit_id", "conversion_to_unit_id", "conversion_factor", "conversion_source_ref")}
    if any(value is not None for value in conversion.values()):
        if any(not value or (isinstance(value, str) and not value.strip()) for value in conversion.values()):
            raise ProcurementOwnerError("procurement_unit_conversion_incomplete", "units, factor and source are required")
        if command.conversion_to_unit_id != line["unit_id"] or command.conversion_from_unit_id == command.conversion_to_unit_id:
            raise ProcurementOwnerError("procurement_unit_conversion_invalid", "convert invoice unit to order unit")
        try:
            get_resource(connection, "unit", command.conversion_from_unit_id)
        except MasterDataError as exc:
            raise ProcurementOwnerError(exc.code, exc.message) from exc
        conversion["conversion_factor"] = format(_quantity(command.conversion_factor), "f")
    planned = {"terms_id": f"pt-{command.command_digest[:24]}", "order_line_id": command.order_line_id,
               "version": connection.execute("SELECT COALESCE(MAX(version), 0)+1 FROM procurement_order_line_terms WHERE order_line_id=?",
                                             (command.order_line_id,)).fetchone()[0],
               "active": 1, "currency": currency, "pricing_quantity": format(_quantity(command.pricing_quantity), "f"),
               "pricing_unit_id": command.pricing_unit_id, "unit_price": _optional_decimal(command.unit_price),
               "agreed_amount": _optional_decimal(command.agreed_amount, money=True), "tax_basis": _tax_basis(command.tax_basis),
               "quantity_tolerance": _optional_decimal(command.quantity_tolerance),
               "quantity_tolerance_unit_id": command.quantity_tolerance_unit_id,
               "amount_tolerance": _optional_decimal(command.amount_tolerance, money=True),
               "amount_tolerance_currency": command.amount_tolerance_currency, "source_kind": command.source_kind,
               "source_ref": command.source_ref, "evidence_refs_json": json.dumps(refs, ensure_ascii=False), "superseded_by": None}
    if any(value is not None for value in conversion.values()):
        # The planned row mirrors the command identity: no conversion means the
        # pre-v12 column set, matching how _document_row reads history back.
        planned.update(conversion)
    if planned["unit_price"] is None and planned["agreed_amount"] is None:
        raise ProcurementOwnerError("procurement_terms_price_required", command.order_line_id)
    if planned["unit_price"] is not None and planned["agreed_amount"] is not None:
        if _priced_amount(planned, Decimal(planned["pricing_quantity"])) != planned["agreed_amount"]:
            raise ProcurementOwnerError("procurement_terms_amount_inconsistent", command.order_line_id)
    return planned


def _invoice_view(row) -> dict[str, Any]:
    document = dict(row)
    for name in ("total_amount", "net_amount", "tax_amount"):
        if document.get(name) is not None:
            document[name] = format(Decimal(str(document[name])), ".2f")
    if document.get("tax_rate") is not None:
        document["tax_rate"] = format(Decimal(str(document["tax_rate"])), "f")
    return {**document, "invoice_id": document["id"],
            "external_invoice_number": document["invoice_number"], "business_date": document["invoice_date"]}


def _invoice(connection: sqlite3.Connection, invoice_id: int) -> dict[str, Any]:
    row = connection.execute("SELECT * FROM procurement_invoices WHERE id=?", (invoice_id,)).fetchone()
    if row is None:
        raise ProcurementOwnerError("procurement_invoice_not_found", str(invoice_id))
    return _invoice_view(row)


def _next_record_id(connection, table):
    return int(connection.execute(f"SELECT COALESCE(MAX(id),0)+1 FROM {table}").fetchone()[0])


def _procurement_line_facts(connection, procurement_id):
    row = connection.execute("SELECT l.*,o.supplier_party_id FROM procurement_order_lines l JOIN procurement_orders o ON o.order_id=l.order_id WHERE l.id=?", (procurement_id,)).fetchone()
    if row is None:
        return None
    # Before purchase-order step 7 this physical line has no authoritative total_amount.
    return settlement.LineFacts(int(row["id"]), int(row["supplier_party_id"]), None)


def _plan_invoice_registration(connection: sqlite3.Connection, command: ProcurementInvoiceCommand,
                               refs: tuple[str, ...]) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    number = command.external_invoice_number.strip()
    if not number or not command.source_key.strip() or command.invoice_id is not None or not is_master_data_ref(command.supplier_party_id):
        raise ProcurementOwnerError("procurement_invoice_identity_required", command.invoice_id)
    _check_invoice_identity(connection, command)
    try:
        get_resource(connection, "party", command.supplier_party_id)
    except MasterDataError as exc:
        raise ProcurementOwnerError(exc.code, exc.message) from exc
    try:
        day = date.fromisoformat(command.business_date)
        if day.isoformat() != command.business_date:
            raise ValueError("business_date must be YYYY-MM-DD")
    except ValueError as exc:
        raise ProcurementOwnerError("procurement_business_date_invalid", command.business_date) from exc
    invoice_id = _next_record_id(connection, "procurement_invoices")
    document = {"id": invoice_id, "source_key": command.source_key, "source_kind": "generic_document", "confirmed_by": OWNER_REF,
                "supplier_party_id": command.supplier_party_id,
                "invoice_number": number, "normalized_invoice_number": unicodedata.normalize("NFKC", number).strip().upper(),
                "currency": _currency(command.currency), "invoice_date": day.isoformat(),
                "tax_basis": _tax_basis(command.tax_basis), "total_amount": format(_money(command.total_amount, allow_zero=False), "f"),
                "net_amount": _optional_decimal(command.net_amount, money=True), "tax_amount": _optional_decimal(command.tax_amount, money=True),
                "tax_rate": _optional_decimal(command.tax_rate), "source_ref": command.source_ref,
                "evidence_refs_json": json.dumps(refs, ensure_ascii=False)}
    if document["net_amount"] is not None and document["tax_amount"] is not None and document["tax_basis"] == "tax_inclusive":
        if decimal_sum((Decimal(document["net_amount"]), Decimal(document["tax_amount"]))) != Decimal(document["total_amount"]):
            raise ProcurementOwnerError("procurement_invoice_total_inconsistent", command.invoice_id)
    if not command.lines or len({item.line_id for item in command.lines}) != len(command.lines):
        raise ProcurementOwnerError("procurement_invoice_lines_invalid", command.invoice_id)
    lines = []
    for item in command.lines:
        if not item.line_id.strip() or connection.execute("SELECT 1 FROM procurement_invoice_lines WHERE line_id=?", (item.line_id,)).fetchone():
            raise ProcurementOwnerError("procurement_invoice_line_identity_invalid", item.line_id)
        try:
            get_resource(connection, "product", item.product_id)
            get_resource(connection, "unit", item.unit_id)
        except MasterDataError as exc:
            raise ProcurementOwnerError(exc.code, exc.message) from exc
        lines.append({"line_id": item.line_id, "invoice_id": invoice_id, "product_id": item.product_id,
                      "unit_id": item.unit_id, "quantity": format(_quantity(item.quantity), "f"),
                      "amount": _optional_decimal(item.amount, money=True), "unit_price": _optional_decimal(item.unit_price),
                      "tax_amount": _optional_decimal(item.tax_amount, money=True)})
    known_total = decimal_sum(Decimal(item["amount"]) for item in lines if item["amount"] is not None)
    total = Decimal(document["total_amount"])
    if known_total > total or (all(item["amount"] is not None for item in lines) and known_total != total):
        raise ProcurementOwnerError("procurement_invoice_line_total_inconsistent", command.invoice_id)
    return document, lines


def _billed_quantity(converted_quantity: str | None, invoice_line_quantity: str) -> Decimal:
    # v11 matches have no conversion columns; their invoice lines are in order units.
    return Decimal(converted_quantity if converted_quantity is not None else invoice_line_quantity)


def _plan_matches(connection: sqlite3.Connection, command: ProcurementInvoiceCommand, document: dict[str, Any],
                  lines: list[dict[str, Any]], refs: tuple[str, ...]) -> list[dict[str, Any]]:
    if command.action == "match" and document["status"] != "confirmed":
        raise ProcurementOwnerError("invoice_not_confirmed", str(document["id"]))
    planned = []
    seen_lines: set[str] = set()
    occupied: dict[str, Decimal] = {}
    billed: dict[str, Decimal] = {}
    for index, item in enumerate(command.matches):
        invoice_line = next((row for row in lines if row["line_id"] == item.invoice_line_id), None)
        if invoice_line is None:
            raise ProcurementOwnerError("procurement_invoice_line_not_found", item.invoice_line_id)
        if item.invoice_line_id in seen_lines or connection.execute(
                "SELECT 1 FROM procurement_invoice_matches WHERE invoice_line_id=? AND active=1", (item.invoice_line_id,)).fetchone():
            raise ProcurementOwnerError("procurement_invoice_line_already_matched", item.invoice_line_id)
        seen_lines.add(item.invoice_line_id)
        line = _order_line(connection, item.order_line_id)
        receipt = connection.execute("SELECT * FROM procurement_receipts WHERE receipt_id=?", (item.receipt_id,)).fetchone()
        if receipt is None or receipt["line_id"] != item.order_line_id or reversed_movement(connection, receipt["inventory_movement_id"]):
            raise ProcurementOwnerError("procurement_match_receipt_invalid", item.receipt_id)
        if receipt["receipt_line_id"] is None:
            raise ProcurementOwnerError("procurement_match_inspection_missing", item.receipt_id)
        if line["supplier_party_id"] != document["supplier_party_id"] or line["product_id"] != invoice_line["product_id"]:
            raise ProcurementOwnerError("procurement_match_identity_mismatch", item.invoice_line_id)
        terms = _current_terms(connection, item.order_line_id)
        invoice_quantity = Decimal(invoice_line["quantity"])
        cross_unit = line["unit_id"] != invoice_line["unit_id"]
        if cross_unit:
            if (not terms or terms.get("conversion_from_unit_id") != invoice_line["unit_id"]
                    or terms.get("conversion_to_unit_id") != line["unit_id"] or not terms.get("conversion_source_ref")):
                raise ProcurementOwnerError("unit_conversion_missing", "set a sourced invoice-to-order conversion in current terms")
            with localcontext(Context(prec=64)) as context:
                context.traps[Inexact] = True
                invoice_quantity = _quantity(finite_decimal(canonical_decimal_text(invoice_quantity * Decimal(terms["conversion_factor"]), notation="normalized", signed_zero=True)))
        quantity = _quantity(item.quantity)
        if item.receipt_id not in occupied:
            active_matches = connection.execute(
                """SELECT m.quantity, m.converted_quantity, l.quantity AS invoice_quantity
                    FROM procurement_invoice_matches m JOIN procurement_invoice_lines l ON l.line_id=m.invoice_line_id
                    WHERE m.receipt_id=? AND m.active=1""", (item.receipt_id,)).fetchall()
            occupied[item.receipt_id] = decimal_sum(Decimal(row["quantity"]) for row in active_matches)
            billed[item.receipt_id] = decimal_sum(_billed_quantity(row["converted_quantity"], row["invoice_quantity"])
                                                 for row in active_matches)
        occupied[item.receipt_id] = decimal_sum((occupied[item.receipt_id], quantity))
        billed[item.receipt_id] = decimal_sum((billed[item.receipt_id], _billed_quantity(format(invoice_quantity, "f"), invoice_line["quantity"])))
        if (occupied[item.receipt_id] > Decimal(receipt["quantity"])
                or billed[item.receipt_id] > Decimal(receipt["quantity"])):
            raise ProcurementOwnerError("procurement_match_exceeds_receipt", item.receipt_id)
        if terms and terms["currency"] != document["currency"]:
            raise ProcurementOwnerError("procurement_match_currency_mismatch", item.invoice_line_id)
        quantity_difference = decimal_sum((invoice_quantity, quantity.copy_negate()))
        missing_terms = terms is None or terms["quantity_tolerance"] is None or terms["amount_tolerance"] is None
        quantity_status = "missing_terms" if terms is None or terms["quantity_tolerance"] is None else (
            "within_tolerance" if abs(quantity_difference) <= Decimal(terms["quantity_tolerance"]) else "outside_tolerance")
        expected = _priced_amount(terms, quantity) if terms else None
        difference = None if expected is None or invoice_line["amount"] is None else format(
            decimal_sum((Decimal(invoice_line["amount"]), Decimal(expected).copy_negate())), "f")
        clarification = ""
        if terms is None or terms["amount_tolerance"] is None:
            amount_status = "missing_terms"
        elif invoice_line["amount"] is None:
            amount_status, clarification = "needs_clarification", "invoice_line_amount_missing"
        elif terms["tax_basis"] == "unspecified" or terms["tax_basis"] != document["tax_basis"]:
            amount_status, clarification = "needs_clarification", "tax_basis_not_comparable"
        elif expected is None:
            amount_status, clarification = "needs_clarification", "agreed_amount_requires_rounding"
        else:
            amount_status = "within_tolerance" if abs(Decimal(difference)) <= Decimal(terms["amount_tolerance"]) else "outside_tolerance"
        status = ("unmatched_missing_terms" if missing_terms else "needs_clarification" if amount_status == "needs_clarification"
                  else "matched" if quantity_status == amount_status == "within_tolerance" else "unmatched")
        planned.append({"match_id": f"pm-{command.command_digest[:24]}-{index}", "invoice_id": document["id"], "invoice_line_id": item.invoice_line_id,
                        "order_line_id": item.order_line_id, "receipt_id": item.receipt_id,
                        "terms_id": terms["terms_id"] if terms else None, "quantity": format(quantity, "f"), "amount": invoice_line["amount"],
                        "original_quantity": invoice_line["quantity"], "original_unit_id": invoice_line["unit_id"],
                        "converted_quantity": format(invoice_quantity, "f"),
                        "expected_amount": expected, "quantity_difference": format(quantity_difference, "f"), "amount_difference": difference,
                        **{key: terms[key] if terms else None for key in ("quantity_tolerance", "quantity_tolerance_unit_id", "amount_tolerance", "amount_tolerance_currency")},
                        "quantity_status": quantity_status, "amount_status": amount_status, "status": status,
                        "clarification_reason": clarification, "active": 1, "source_ref": command.source_ref,
                        "evidence_refs_json": json.dumps(refs, ensure_ascii=False), "revoked_at": None, "revoked_action_id": None})
    return planned


def _preview_document_on_connection(connection: sqlite3.Connection, command: ProcurementTermsCommand | ProcurementInvoiceCommand) -> ProcurementDocumentPreview:
    if not command.idempotency_key.strip() or not command.source_ref.strip():
        raise ProcurementOwnerError("procurement_document_source_required", "idempotency_key and source_ref are required")
    try:
        refs = normalized_evidence_refs(command.evidence_refs)
    except TradeRuleError as exc:
        raise ProcurementOwnerError(str(exc), "evidence refs are invalid") from exc
    lines: list[dict[str, Any]] = []
    matches: list[dict[str, Any]] = []
    if isinstance(command, ProcurementTermsCommand):
        document = _plan_terms(connection, command, refs)
    else:
        if command.action not in {"register", "match", "unmatch"}:
            raise ProcurementOwnerError("procurement_invoice_action_invalid", command.action)
        if command.action != "register" and command.lines:
            raise ProcurementOwnerError("procurement_invoice_lines_not_allowed", command.action)
        if (command.action != "unmatch" and command.match_ids) or (command.action == "unmatch" and command.matches):
            raise ProcurementOwnerError("procurement_invoice_match_fields_invalid", command.action)
        if command.action == "register":
            document, lines = _plan_invoice_registration(connection, command, refs)
        else:
            document = _invoice(connection, command.invoice_id)
            lines = [dict(row) for row in connection.execute("SELECT * FROM procurement_invoice_lines WHERE invoice_id=? ORDER BY line_id", (command.invoice_id,))]
        if command.action == "unmatch":
            if not command.reason.strip() or not command.match_ids or len(set(command.match_ids)) != len(command.match_ids):
                raise ProcurementOwnerError("procurement_unmatch_reason_and_ids_required", command.invoice_id)
            for match_id in command.match_ids:
                row = connection.execute("""SELECT m.* FROM procurement_invoice_matches m
                    JOIN procurement_invoice_lines l ON l.line_id=m.invoice_line_id WHERE m.match_id=? AND l.invoice_id=? AND m.active=1""",
                    (match_id, command.invoice_id)).fetchone()
                if row is None:
                    raise ProcurementOwnerError("procurement_active_match_not_found", match_id)
                matches.append(dict(row))
        else:
            if command.action == "match" and not command.matches:
                raise ProcurementOwnerError("procurement_matches_required", command.invoice_id)
            matches = _plan_matches(connection, command, document, lines, refs)
    content = {"command": command.to_dict(), "state_generation": _document_generation(connection), "planned_document": document,
               "planned_lines": lines, "planned_matches": matches}
    return ProcurementDocumentPreview(command, content["state_generation"], document, tuple(lines), tuple(matches), digest_json(content))


def preview_document_action(storage: StorageTarget, command: ProcurementTermsCommand | ProcurementInvoiceCommand, *,
                            enabled_module_ids: Iterable[str] | None = None) -> ProcurementDocumentPreview:
    _require_module_enabled(enabled_module_ids)
    with _reading(storage) as connection:
        return _preview_document_on_connection(connection, command)


def _project_match_statuses(connection: sqlite3.Connection, matches: list[dict[str, Any]]) -> None:
    for match in matches:
        if match["active"]:
            terms = _current_terms(connection, match["order_line_id"])
            if match["terms_id"] != (terms["terms_id"] if terms else None):
                match["status"] = "rematch_required"


def _invoice_detail(connection: sqlite3.Connection, invoice_id: str) -> dict[str, Any]:
    document = _invoice(connection, invoice_id)
    lines = [dict(row) for row in connection.execute("SELECT * FROM procurement_invoice_lines WHERE invoice_id=? ORDER BY line_id", (invoice_id,))]
    matches = [_document_row(row) for row in connection.execute("""SELECT m.* FROM procurement_invoice_matches m
        JOIN procurement_invoice_lines l ON l.line_id=m.invoice_line_id WHERE l.invoice_id=? ORDER BY m.created_at, m.match_id""", (invoice_id,))]
    _project_match_statuses(connection, matches)
    for line in lines:
        active = next((row for row in matches if row["invoice_line_id"] == line["line_id"] and row["active"]), None)
        line["match_status"] = active["status"] if active else "needs_clarification" if line["amount"] is None else "unmatched"
    return {"document": document, "lines": lines, "matches": matches,
            "match_status": "rematch_required" if any(line["match_status"] == "rematch_required" for line in lines)
                else "matched" if all(line["match_status"] == "matched" for line in lines) else "unmatched"}


def _terms_detail(connection: sqlite3.Connection, order_line_id: str) -> dict[str, Any]:
    _order_line(connection, order_line_id)
    return {"current_terms": _current_terms(connection, order_line_id), "versions": [_document_row(row) for row in connection.execute(
        "SELECT * FROM procurement_order_line_terms WHERE order_line_id=? ORDER BY version", (order_line_id,))]}


def _document_readback(connection: sqlite3.Connection, action: sqlite3.Row) -> dict[str, Any]:
    kind = action["document_kind"]
    detail = (_payment_detail(connection, action["document_id"]) if kind == "payment" else
              _terms_detail(connection, action["document_id"]) if kind == "terms" else _invoice_detail(connection, action["document_id"]))
    return {"schema_version": "bizhub.procurement-document-readback.v1", "owner_ref": OWNER_REF,
            "action_id": action["action_id"], "idempotency_key": action["idempotency_key"], "document_kind": kind,
            "command_digest": action["command_digest"], "preview_digest": action["preview_digest"], **detail,
            "audit_event": dict(connection.execute("SELECT * FROM procurement_audit_events WHERE event_id=?", (action["audit_event_id"],)).fetchone()),
            "state_generation": _payment_generation(connection) if kind == "payment" else _document_generation(connection)}


def _insert_document_row(connection: sqlite3.Connection, table: str, row: dict[str, Any], now: str) -> None:
    values = {**row, "created_at": now}
    connection.execute(f"INSERT INTO {table} ({', '.join(values)}) VALUES ({', '.join('?' for _ in values)})", tuple(values.values()))


def apply_document_preview_in_transaction(connection: sqlite3.Connection, preview: ProcurementDocumentPreview, *, enabled_module_ids: Iterable[str] | None = None) -> dict[str, Any]:
    if not connection.in_transaction:
        raise ProcurementOwnerError("procurement_transaction_required", "an outer transaction is required")
    _require_module_enabled(enabled_module_ids)
    if preview.preview_digest not in preview.content_digests():
        raise ProcurementOwnerError("procurement_preview_content_drift", "preview digest differs")
    try:
        existing = connection.execute("SELECT * FROM procurement_action_receipts WHERE idempotency_key=?", (preview.command.idempotency_key,)).fetchone()
        if existing is not None:
            accepted = (preview.command.command_digests if isinstance(preview.command, ProcurementTermsCommand)
                        else (preview.command.command_digest,))
            if str(existing["command_digest"]) not in accepted:
                raise ProcurementOwnerError("procurement_idempotency_conflict", preview.command.idempotency_key)
            result = _readback(connection, existing["action_id"])
            return {**result, "disposition": "idempotent_noop"}
        if isinstance(preview.command, ProcurementInvoiceCommand):
            _check_invoice_identity(connection, preview.command)
        if _document_generation(connection) != preview.state_generation:
            raise ProcurementOwnerError("procurement_state_generation_drift", "procurement changed")
        authoritative = _preview_document_on_connection(connection, preview.command)
        if authoritative.preview_digest != preview.preview_digest:
            raise ProcurementOwnerError("procurement_preview_content_drift", "authoritative plan differs")
        command, now = authoritative.command, datetime.now(UTC).isoformat()
        kind = "terms" if isinstance(command, ProcurementTermsCommand) else "invoice"
        document_id = command.order_line_id if kind == "terms" else authoritative.planned_document["id"]
        action_id, audit_id = uuid.uuid4().hex, uuid.uuid4().hex
        connection.execute("INSERT INTO procurement_audit_events(event_id, event_type, payload_json, created_at) VALUES (?, ?, ?, ?)",
            (audit_id, f"procurement_{kind}_{command.action}_applied", json.dumps(authoritative.to_dict(), ensure_ascii=False, sort_keys=True, separators=(",", ":")), now))
        connection.execute("""INSERT INTO procurement_action_receipts
            (action_id, idempotency_key, command_digest, preview_digest, order_id, audit_event_id, inventory_action_id,
             created_at, document_kind, document_id) VALUES (?, ?, ?, ?, NULL, ?, NULL, ?, ?, ?)""",
            (action_id, command.idempotency_key, command.command_digest, preview.preview_digest, audit_id, now, kind, document_id))
        if kind == "terms":
            old = _current_terms(connection, command.order_line_id)
            if old:
                connection.execute("UPDATE procurement_order_line_terms SET active=0 WHERE terms_id=?", (old["terms_id"],))
            _insert_document_row(connection, "procurement_order_line_terms", authoritative.planned_document, now)
            if old:
                connection.execute("UPDATE procurement_order_line_terms SET superseded_by=? WHERE terms_id=?", (authoritative.planned_document["terms_id"], old["terms_id"]))
        else:
            if command.action == "register":
                values = {key: value for key, value in authoritative.planned_document.items() if key != "id"}
                invoice_id = settlement.SettlementRecordWriter("invoice").materialize(connection, None, values)
                if invoice_id != authoritative.planned_document["id"]:
                    raise ProcurementOwnerError("procurement_state_generation_drift", "invoice id changed")
                for row in authoritative.planned_lines:
                    connection.execute("""INSERT INTO procurement_invoice_lines
                        (line_id, invoice_id, product_id, unit_id, quantity, amount, unit_price, tax_amount) VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                        tuple(row[key] for key in ("line_id", "invoice_id", "product_id", "unit_id", "quantity", "amount", "unit_price", "tax_amount")))
            if command.action == "unmatch":
                for row in authoritative.planned_matches:
                    connection.execute("UPDATE procurement_invoice_matches SET active=0, revoked_at=?, revoked_action_id=? WHERE match_id=?", (now, action_id, row["match_id"]))
                    allocation = connection.execute("SELECT id FROM procurement_invoice_allocations WHERE invoice_id=? AND invoice_line_key=? AND status='confirmed'", (row["invoice_id"], row["invoice_line_id"])).fetchone()
                    if allocation:
                        settlement.reverse_allocation(connection, "invoice", owner_id=row["invoice_id"], allocation_id=allocation[0], reversed_by=action_id, now=now)
            else:
                for row in authoritative.planned_matches:
                    _insert_document_row(connection, "procurement_invoice_matches", row, now)
                    if row["amount"] is not None and Decimal(row["amount"]) != 0:
                        procurement_id = _order_line(connection, row["order_line_id"])["id"]
                        settlement.allocate_invoice(connection, invoice_id=row["invoice_id"], procurement_id=procurement_id,
                            amount=Decimal(row["amount"]), read_line=_procurement_line_facts,
                            invoice_line_key=row["invoice_line_id"], provenance=settlement.Provenance(source_ref=row["source_ref"], actor=action_id), now=now)
        result = _readback(connection, action_id)
        return {**result, "disposition": "applied"}
    except settlement.SettlementWriteError as exc:
        raise ProcurementOwnerError(exc.code, exc.message) from exc
    except sqlite3.IntegrityError as exc:
        raise ProcurementOwnerError("procurement_write_conflict", str(exc)) from exc


def apply_document_preview(storage: StorageTarget, preview: ProcurementDocumentPreview, *, enabled_module_ids: Iterable[str] | None = None) -> dict[str, Any]:
    _require_module_enabled(enabled_module_ids)
    with _writing(storage) as connection:
        return apply_document_preview_in_transaction(connection, preview, enabled_module_ids=enabled_module_ids)


def read_invoice(storage: StorageTarget, invoice_id: int) -> dict[str, Any]:
    with _reading(storage) as connection:
        return _invoice_detail(connection, invoice_id)


def read_terms(storage: StorageTarget, order_line_id: str) -> dict[str, Any]:
    with _reading(storage) as connection:
        return _terms_detail(connection, order_line_id)


def read_three_way(storage: StorageTarget, order_line_id: str) -> dict[str, Any]:
    with _reading(storage) as connection:
        line = _order_line(connection, order_line_id)
        receipts = [dict(row) for row in connection.execute("SELECT * FROM procurement_receipts WHERE line_id=? ORDER BY receipt_id", (order_line_id,))]
        matches = [_document_row(row) for row in connection.execute("""SELECT m.*, i.currency, i.tax_basis, l.quantity AS invoice_line_quantity
            FROM procurement_invoice_matches m JOIN procurement_invoice_lines l ON l.line_id=m.invoice_line_id
            JOIN procurement_invoices i ON i.id=l.invoice_id
            WHERE m.order_line_id=? ORDER BY m.created_at, m.match_id""", (order_line_id,))]
        _project_match_statuses(connection, matches)
        invoice_quantity = decimal_sum(_billed_quantity(row.get("converted_quantity"), row["invoice_line_quantity"])
                                       for row in matches if row["active"])
        for row in matches:
            row.pop("invoice_line_quantity")
        active = [row for row in matches if row["active"]]
        qualified = decimal_sum(Decimal(row["quantity"]) for row in receipts if row["receipt_line_id"] is not None and not reversed_movement(connection, row["inventory_movement_id"]))
        occupied = decimal_sum(Decimal(row["quantity"]) for row in active)
        amounts_by_currency = []
        for currency in sorted({row["currency"] for row in active}):
            group = [row for row in active if row["currency"] == currency]
            amounts_by_currency.append({"currency": currency,
                "invoice_amount": None if any(row["amount"] is None for row in group) else format(decimal_sum(Decimal(row["amount"]) for row in group), "f"),
                "amount_difference": None if any(row["amount_difference"] is None or row["amount_status"] == "needs_clarification" for row in group)
                    else format(decimal_sum(Decimal(row["amount_difference"]) for row in group), "f")})
        for row in receipts:
            used = decimal_sum(Decimal(match["quantity"]) for match in active if match["receipt_id"] == row["receipt_id"])
            row["occupied_quantity"] = format(used, "f")
            row["unmatched_qualified_quantity"] = format(decimal_sum((Decimal(row["quantity"]), used.copy_negate())), "f") if row["receipt_line_id"] is not None else None
        return {"order_line": line, **_terms_detail(connection, order_line_id), "receipts": receipts, "matches": matches,
                "qualified_received_quantity": format(qualified, "f"), "occupied_quantity": format(occupied, "f"),
                "qualified_minus_ordered_quantity": format(decimal_sum((qualified, Decimal(line["quantity"]).copy_negate())), "f"),
                "invoice_minus_occupied_quantity": format(decimal_sum(Decimal(row["quantity_difference"]) for row in active), "f"),
                "amounts_by_currency": amounts_by_currency,
                "unmatched_qualified_quantity": format(decimal_sum((qualified, occupied.copy_negate())), "f"),
                "invoice_quantity": format(invoice_quantity, "f"),
                "match_status": "rematch_required" if any(row["status"] == "rematch_required" for row in active)
                    else "matched" if active and all(row["status"] == "matched" for row in active) and occupied == qualified else "unmatched"}


__all__ = ["preview_payment_action", "apply_payment_preview", "read_payment", "read_payables", "read_payment_balances", "ProcurementOwnerError", "apply_preview", "preview_action", "preview_receipt_action",
           "apply_receipt_preview", "read_receipt_document", "read_action", "preview_document_action",
           "apply_document_preview", "read_invoice", "read_terms", "read_three_way"]


def _payment_view(row) -> dict[str, Any]:
    payment = dict(row)
    payment["amount"] = format(Decimal(str(payment["amount"])), ".2f")
    try:
        legacy = json.loads(payment.get("notes") or "{}")
    except (ValueError, TypeError):
        legacy = {}
    if not isinstance(legacy, dict):
        legacy = {}
    paid_at = str(payment.get("paid_at") or "")
    paid_date = datetime.fromisoformat(paid_at).astimezone(ZoneInfo(BUSINESS_TIMEZONE)).date().isoformat() if paid_at else payment["business_date"]
    return {**payment, "payment_id": payment["id"], "external_reference": payment["reference_no"],
            "paid_date": paid_date, "business_at": legacy.get("business_at", payment["business_date"])}


def _payment(connection: sqlite3.Connection, payment_id: int) -> dict[str, Any]:
    row = connection.execute("SELECT * FROM procurement_payments WHERE id=?", (payment_id,)).fetchone()
    if row is None:
        raise ProcurementOwnerError("procurement_payment_not_found", str(payment_id))
    return _payment_view(row)


def _allocated_amount(connection: sqlite3.Connection, *, payment_id: int) -> Decimal:
    return settlement.payment_allocated(connection, payment_id)


def _payment_generation(connection: sqlite3.Connection) -> str:
    return digest_json({"invoices": _document_generation(connection),
                        "payments": _table_rows(connection, "procurement_payments", "id"),
                        "allocations": _table_rows(connection, "procurement_payment_allocations", "id")})


def _payment_target(connection, procurement_id, payment):
    if not is_master_data_ref(procurement_id):
        raise ProcurementOwnerError("procurement_payment_target_invalid", str(procurement_id))
    facts = _procurement_line_facts(connection, procurement_id)
    if facts is None:
        raise ProcurementOwnerError("procurement_line_not_found", str(procurement_id))
    if facts.supplier_party_id != payment["supplier_party_id"]:
        raise ProcurementOwnerError("procurement_payment_supplier_mismatch", str(procurement_id))
    line = connection.execute("SELECT line_id FROM procurement_order_lines WHERE id=?", (procurement_id,)).fetchone()
    terms = _current_terms(connection, line["line_id"])
    # A line without a currency-bearing agreement cannot silently absorb any currency.
    if terms is None:
        raise ProcurementOwnerError("procurement_payment_currency_missing", str(procurement_id))
    if terms["currency"] != payment["currency"]:
        raise ProcurementOwnerError("procurement_payment_currency_mismatch", str(procurement_id))
    return facts


def _preview_payment_on_connection(connection: sqlite3.Connection, command: ProcurementPaymentCommand) -> ProcurementPaymentPreview:
    if command.action not in {"register", "allocate", "unallocate"}:
        raise ProcurementOwnerError("procurement_payment_action_invalid", command.action)
    if not command.idempotency_key.strip() or not command.source_ref.strip():
        raise ProcurementOwnerError("procurement_payment_identity_required", "idempotency_key and source_ref required")
    try:
        refs = normalized_evidence_refs(command.evidence_refs)
    except TradeRuleError as exc:
        raise ProcurementOwnerError(str(exc), "payment evidence invalid") from exc
    if command.action == "register":
        if command.payment_id is not None or command.allocation_ids:
            raise ProcurementOwnerError("procurement_payment_fields_invalid", "register cannot reference existing payment/allocation")
        currency, amount = _currency(command.currency), _money(command.amount, allow_zero=False)
        reference = command.external_reference.strip()
        if not reference or not is_master_data_ref(command.supplier_party_id):
            raise ProcurementOwnerError("procurement_payment_identity_required", "supplier and external_reference required")
        try:
            get_resource(connection, "party", command.supplier_party_id)
        except MasterDataError as exc:
            raise ProcurementOwnerError(exc.code, str(exc)) from exc
        try:
            business_datetime(command.paid_at)
            paid = datetime.fromisoformat(command.paid_at)
            if paid.tzinfo is None:
                raise ValueError("paid_at needs an explicit timezone")
            business_day = business_datetime(command.business_at).date().isoformat()
        except ValueError as exc:
            raise ProcurementOwnerError("procurement_payment_date_invalid", str(exc)) from exc
        _check_payment_identity(connection, command)
        payment = {"id": _next_record_id(connection, "procurement_payments"), "source_kind": "generic_document", "confirmed_by": OWNER_REF,
                   "source_key": f"pay-{command.command_digest[:24]}",
                   "supplier_party_id": command.supplier_party_id, "currency": currency, "amount": format(amount, ".2f"),
                   "payment_method": command.channel if command.channel in {"bank_transfer", "bank_acceptance", "cash", "other", "unknown"} else "unknown",
                   "channel": command.channel.strip(), "reference_no": reference, "paid_at": command.paid_at,
                   "business_date": business_day, "source_ref": command.source_ref,
                   "notes": json.dumps({"business_at": command.business_at, "evidence_refs_json": json.dumps(refs, ensure_ascii=False)}, ensure_ascii=False)}
        available = amount
    else:
        if not is_master_data_ref(command.payment_id) or any((command.supplier_party_id, command.currency, command.amount, command.channel,
                                          command.external_reference, command.paid_at, command.business_at)):
            raise ProcurementOwnerError("procurement_payment_fields_invalid", "allocation actions only reference registered payment")
        payment = dict(connection.execute("SELECT * FROM procurement_payments WHERE id=?", (command.payment_id,)).fetchone() or {})
        if not payment or payment["status"] != "confirmed":
            raise ProcurementOwnerError("procurement_payment_not_found", str(command.payment_id))
        available = decimal_sum((Decimal(str(payment["amount"])), _allocated_amount(connection, payment_id=command.payment_id).copy_negate()))
    planned = []
    if command.action == "unallocate":
        if command.allocations or not command.allocation_ids or len(set(command.allocation_ids)) != len(command.allocation_ids):
            raise ProcurementOwnerError("procurement_payment_allocations_invalid", "distinct allocation_ids required")
        for allocation_id in command.allocation_ids:
            row = connection.execute("SELECT * FROM procurement_payment_allocations WHERE id=?", (allocation_id,)).fetchone()
            if row is None or row["payment_id"] != payment["id"] or row["status"] != "confirmed":
                raise ProcurementOwnerError("procurement_payment_allocation_not_active", str(allocation_id))
            planned.append(dict(row))
    else:
        if command.allocation_ids or (command.action == "allocate" and not command.allocations):
            raise ProcurementOwnerError("procurement_payment_allocations_invalid", "allocate requires allocations")
        if len({item.procurement_id for item in command.allocations}) != len(command.allocations):
            raise ProcurementOwnerError("procurement_payment_allocations_invalid", "one amount per purchase line required")
        for item in command.allocations:
            amount = _money(item.amount, allow_zero=False)
            _payment_target(connection, item.procurement_id, payment)
            existing = connection.execute("SELECT id FROM procurement_payment_allocations WHERE payment_id=? AND procurement_id=? AND status='confirmed'", (payment["id"], item.procurement_id)).fetchone()
            if existing:
                raise ProcurementOwnerError("procurement_payment_allocation_already_exists", str(existing[0]))
            planned.append({"payment_id": payment["id"], "procurement_id": item.procurement_id,
                            "allocated_amount": format(amount, ".2f"), "source_ref": command.source_ref})
        if decimal_sum(Decimal(item["allocated_amount"]) for item in planned) > available:
            raise ProcurementOwnerError("procurement_payment_exceeds_available", str(payment["id"]))
    content = {"command": command.to_dict(), "state_generation": _payment_generation(connection),
               "planned_payment": payment, "planned_allocations": planned}
    return ProcurementPaymentPreview(command, content["state_generation"], payment, tuple(planned), digest_json(content))


def preview_payment_action(storage: StorageTarget, command: ProcurementPaymentCommand, *, enabled_module_ids: Iterable[str] | None = None) -> ProcurementPaymentPreview:
    _require_module_enabled(enabled_module_ids)
    with _reading(storage) as connection:
        return _preview_payment_on_connection(connection, command)


def _payable_item(connection: sqlite3.Connection, procurement_id: int, *, currency: str | None = None) -> dict[str, Any]:
    row = connection.execute("SELECT line_id FROM procurement_order_lines WHERE id=?", (procurement_id,)).fetchone()
    line = _order_line(connection, row["line_id"])
    terms = _current_terms(connection, row["line_id"])
    currency = currency or (terms["currency"] if terms else None)
    expected = _priced_amount(terms, Decimal(line["quantity"])) if terms and terms["currency"] == currency else None
    facts = read_settlement_records(connection, procurement_ids=(procurement_id,),
        expected_amounts={(procurement_id, currency): Decimal(expected) if expected is not None else None})["lines"][(procurement_id, currency)]
    return {"procurement_id": procurement_id, "order_line_id": row["line_id"],
            "supplier_party_id": line["supplier_party_id"], "currency": currency,
            "payable_amount": expected, "paid_amount": format(facts["paid_amount"], ".2f"),
            "unpaid_amount": format(facts["remaining_payable"], ".2f") if facts["remaining_payable"] is not None else None,
            "prepaid_amount": format(facts["prepaid_amount"], ".2f") if facts["prepaid_amount"] is not None else None,
            "invoiced_amount": format(facts["invoiced_amount"], ".2f")}



def _payment_detail(connection: sqlite3.Connection, payment_id: int) -> dict[str, Any]:
    payment = _payment(connection, payment_id)
    allocations = [dict(row) for row in connection.execute(
        "SELECT * FROM procurement_payment_allocations WHERE payment_id=? ORDER BY id", (payment_id,))]
    allocated = _allocated_amount(connection, payment_id=payment_id)
    targets = sorted({row["procurement_id"] for row in allocations})
    return {"schema_version": "bizhub.procurement-payment-read.v1", "owner_ref": OWNER_REF, "payment": payment,
            "allocations": allocations, "procurements": [_payable_item(connection, target, currency=payment["currency"]) for target in targets],
            "balance": {"currency": payment["currency"], "payment_amount": format(Decimal(str(payment["amount"])), ".2f"), "allocated_amount": format(allocated, ".2f"),
                        "unallocated_amount": format(decimal_sum((Decimal(str(payment["amount"])), allocated.copy_negate())), ".2f")}}


def read_payment(storage: StorageTarget, payment_id: int, *, enabled_module_ids: Iterable[str] | None = None) -> dict[str, Any]:
    _require_module_enabled(enabled_module_ids)
    with _reading(storage) as connection:
        return _payment_detail(connection, payment_id)


def read_payables(storage: StorageTarget, *, enabled_module_ids: Iterable[str] | None = None) -> dict[str, Any]:
    _require_module_enabled(enabled_module_ids)
    with _reading(storage) as connection:
        items = []
        rows = list(connection.execute("SELECT id,line_id FROM procurement_order_lines ORDER BY id"))
        settlements = read_settlement_records(connection, procurement_ids=(row["id"] for row in rows))["lines"]
        for row in rows:
            terms = _current_terms(connection, row["line_id"])
            currencies = {terms["currency"] if terms else None}
            currencies.update(currency for (identity, currency) in settlements if identity == row["id"])
            items.extend(_payable_item(connection, row["id"], currency=currency)
                         for currency in sorted(currencies, key=lambda value: value or ""))
        return {"schema_version": "bizhub.procurement-payables-read.v1", "owner_ref": OWNER_REF, "items": items}


def read_payment_balances(storage: StorageTarget, *, enabled_module_ids: Iterable[str] | None = None) -> dict[str, Any]:
    _require_module_enabled(enabled_module_ids)
    with _reading(storage) as connection:
        items = []
        for row in connection.execute("SELECT * FROM procurement_payments WHERE status='confirmed' ORDER BY id"):
            allocated = _allocated_amount(connection, payment_id=row["id"])
            items.append({"payment_id": row["id"], "supplier_party_id": row["supplier_party_id"], "currency": row["currency"],
                          "payment_amount": format(Decimal(str(row["amount"])), ".2f"), "allocated_amount": format(allocated, ".2f"),
                          "unallocated_amount": format(decimal_sum((Decimal(str(row["amount"])), allocated.copy_negate())), ".2f")})
        return {"schema_version": "bizhub.procurement-payment-balances-read.v1", "owner_ref": OWNER_REF, "items": items}


def apply_payment_preview_in_transaction(connection: sqlite3.Connection, preview: ProcurementPaymentPreview, *, enabled_module_ids: Iterable[str] | None = None) -> dict[str, Any]:
    if not connection.in_transaction:
        raise ProcurementOwnerError("procurement_transaction_required", "an outer transaction is required")
    _require_module_enabled(enabled_module_ids)
    if digest_json(preview.content()) != preview.preview_digest:
        raise ProcurementOwnerError("procurement_preview_content_drift", "preview digest differs")
    try:
        existing = connection.execute("SELECT * FROM procurement_action_receipts WHERE idempotency_key=?", (preview.command.idempotency_key,)).fetchone()
        if existing is not None:
            if existing["command_digest"] != preview.command.command_digest:
                raise ProcurementOwnerError("procurement_idempotency_conflict", preview.command.idempotency_key)
            result = _readback(connection, existing["action_id"])
            return {**result, "disposition": "idempotent_noop"}
        _check_payment_identity(connection, preview.command)
        if _payment_generation(connection) != preview.state_generation:
            raise ProcurementOwnerError("procurement_state_generation_drift", "payment/invoice state changed")
        authoritative = _preview_payment_on_connection(connection, preview.command)
        if authoritative.preview_digest != preview.preview_digest:
            raise ProcurementOwnerError("procurement_preview_content_drift", "authoritative plan differs")
        now = datetime.now(UTC).isoformat()
        if preview.command.action == "register":
            values = {key: value for key, value in authoritative.planned_payment.items() if key != "id"}
            payment_id = settlement.SettlementRecordWriter("payment").materialize(connection, None, values)
            if payment_id != authoritative.planned_payment["id"]:
                raise ProcurementOwnerError("procurement_state_generation_drift", "payment id changed")
        action_id, audit_id = uuid.uuid4().hex, uuid.uuid4().hex
        connection.execute("INSERT INTO procurement_audit_events(event_id, event_type, payload_json, created_at) VALUES (?, ?, ?, ?)",
                           (audit_id, f"procurement_payment_{preview.command.action}_applied", json.dumps(authoritative.to_dict(), ensure_ascii=False, sort_keys=True), now))
        connection.execute("""INSERT INTO procurement_action_receipts(action_id, idempotency_key, command_digest, preview_digest,
            order_id, audit_event_id, inventory_action_id, created_at, document_kind, document_id)
            VALUES (?, ?, ?, ?, NULL, ?, NULL, ?, 'payment', ?)""",
            (action_id, preview.command.idempotency_key, preview.command.command_digest, preview.preview_digest, audit_id, now, authoritative.planned_payment["id"]))
        for allocation in authoritative.planned_allocations:
            if preview.command.action == "unallocate":
                settlement.reverse_allocation(connection, "payment", owner_id=authoritative.planned_payment["id"],
                    allocation_id=allocation["id"], reversed_by=action_id, notes=preview.command.source_ref, now=now)
            else:
                settlement.allocate_payment(connection, payment_id=authoritative.planned_payment["id"],
                    procurement_id=allocation["procurement_id"], amount=Decimal(allocation["allocated_amount"]),
                    read_line=_procurement_line_facts,
                    provenance=settlement.Provenance(source_ref=allocation["source_ref"], actor=action_id), now=now)
        result = _readback(connection, action_id)
        return {**result, "disposition": "applied"}
    except settlement.SettlementWriteError as exc:
        raise ProcurementOwnerError(exc.code, exc.message) from exc
    except sqlite3.IntegrityError as exc:
        raise ProcurementOwnerError("procurement_write_conflict", str(exc)) from exc


def apply_payment_preview(storage: StorageTarget, preview: ProcurementPaymentPreview, *, enabled_module_ids: Iterable[str] | None = None) -> dict[str, Any]:
    _require_module_enabled(enabled_module_ids)
    with _writing(storage) as connection:
        return apply_payment_preview_in_transaction(connection, preview, enabled_module_ids=enabled_module_ids)


def preview_action_in_transaction(connection: sqlite3.Connection, command, *, enabled_module_ids: Iterable[str] | None = None):
    enabled = _require_module_enabled(enabled_module_ids)
    return _preview_on_connection(connection, command, enabled_module_ids=enabled)


def preview_receipt_action_in_transaction(connection: sqlite3.Connection, command, *, enabled_module_ids: Iterable[str] | None = None):
    enabled = _require_module_enabled(enabled_module_ids)
    return _preview_receipt_on_connection(connection, command, enabled_module_ids=enabled)


def preview_document_action_in_transaction(connection: sqlite3.Connection, command, *, enabled_module_ids: Iterable[str] | None = None):
    enabled = _require_module_enabled(enabled_module_ids)
    return _preview_document_on_connection(connection, command)


def preview_payment_action_in_transaction(connection: sqlite3.Connection, command, *, enabled_module_ids: Iterable[str] | None = None):
    enabled = _require_module_enabled(enabled_module_ids)
    return _preview_payment_on_connection(connection, command)


def read_action_in_transaction(connection: sqlite3.Connection, action_id: str, *, enabled_module_ids: Iterable[str] | None = None) -> dict[str, Any]:
    _require_module_enabled(enabled_module_ids)
    return _readback(connection, action_id)




def preview_reversal_action(storage: StorageTarget, command: TradeReversalCommand, *, numeric_tools, enabled_module_ids=None) -> TradeReversalPreview:
    enabled = _require_module_enabled(enabled_module_ids)
    with _reading(storage) as connection:
        try:
            return _preview_trade_reversal(connection, MODULE_ID, command, inventory_preview=preview_inventory_in_transaction, inventory_command=InventoryCommand, enabled=enabled, numeric_tools=numeric_tools)
        except TradeRuleError as exc:
            raise ProcurementOwnerError(str(exc), "冲销无法执行：" + str(exc)) from exc


def apply_reversal_preview(storage: StorageTarget, preview: TradeReversalPreview, *, numeric_tools, enabled_module_ids=None) -> dict[str, Any]:
    enabled = _require_module_enabled(enabled_module_ids)
    try:
        with _writing(storage) as connection:
            return _apply_trade_reversal(connection, MODULE_ID, preview, inventory_preview=preview_inventory_in_transaction,
                inventory_apply=apply_inventory_in_transaction, inventory_command=InventoryCommand, enabled=enabled, project_status=_project_order_status, persist=_persist_reversal, numeric_tools=numeric_tools)
    except TradeRuleError as exc:
        raise ProcurementOwnerError(str(exc), "冲销无法执行：" + str(exc)) from exc


def list_reversals(storage: StorageTarget, *, status: str = "", enabled_module_ids=None) -> dict[str, Any]:
    _require_module_enabled(enabled_module_ids)
    with _reading(storage) as connection:
        return {"items": [row for row in _reversal_documents(connection, MODULE_ID) if not status or row["status"] == status]}


def read_reversal(storage: StorageTarget, reversal_id: str, *, enabled_module_ids=None) -> dict[str, Any]:
    for row in list_reversals(storage, enabled_module_ids=enabled_module_ids)["items"]:
        if row["reversal_id"] == reversal_id:
            return row
    raise ProcurementOwnerError("trade_reversal_not_found", reversal_id)



def _persist_reversal(connection, preview, result, receipt, line_changes, order_changes):
    """The original Owner is the only physical writer of its transaction facts."""
    now = result["created_at"]
    for line_id, quantity in line_changes.items():
        connection.execute("UPDATE procurement_order_lines SET received_quantity=? WHERE line_id=?", (quantity, line_id))
    for order_id, status in order_changes.items():
        connection.execute("UPDATE procurement_orders SET status=?, updated_at=? WHERE order_id=?", (status, now, order_id))
    connection.execute("INSERT INTO procurement_audit_events(event_id,event_type,payload_json,created_at) VALUES (?,?,?,?)",
        (result["reversal_id"], "trade_reversal_recorded", json.dumps({"preview": preview.to_dict(), "readback": result}, ensure_ascii=False), now))
    connection.execute(f"INSERT INTO procurement_action_receipts ({','.join(receipt)}) VALUES ({','.join('?' for _ in receipt)})", tuple(receipt.values()))



def party_reference_counts(connection: sqlite3.Connection, party_id: int) -> dict[str, int]:
    """只读：本模块有多少张单据指向这个往来方（往来方合并前用来拦）。"""

    return {
        table: int(connection.execute(f"SELECT COUNT(*) FROM {table} WHERE supplier_party_id=?", (int(party_id),)).fetchone()[0])
        for table in ("procurement_orders", "procurement_receipt_documents", "procurement_invoices", "procurement_payments")
    }
