"""Single writer for customer-neutral procurement orders and receipts."""

from __future__ import annotations

from backend.kernel.profile_registry import StorageTarget, read_storage, storage_connect, write_storage

import json
import sqlite3
import unicodedata
import uuid
from collections import Counter
from datetime import UTC, date, datetime
from decimal import Decimal
from pathlib import Path
from typing import Any, Iterable

from backend.modules.inventory.public import (
    InventoryCommand,
    InventoryPreview,
    apply_preview_in_transaction as apply_inventory_in_transaction,
    preview_action_in_transaction as preview_inventory_in_transaction,
    read_action_in_transaction as read_inventory_in_transaction,
)
from backend.modules.master_data.public import MasterDataError, get_resource, is_master_data_ref
from backend.modules.trade_core.public import (
    BUSINESS_TIMEZONE,
    business_datetime,
    TradeRuleError,
    aggregate_order_progress,
    check_decimal_range,
    decimal_sum,
    digest_json,
    normalized_evidence_refs,
    quantity_decimal,
)

from . import receipt_writes, settlement_writes as settlement

from .contracts import ProcurementCommand, ProcurementPreview, ProcurementReceiptCommand, ProcurementReceiptPreview



# Reversal state and physical writes remain under this original transaction Owner.
from backend.modules.trade_core.public import (
    TradeReversalCommand, TradeReversalPreview, apply_reversal as _apply_trade_reversal,
    preview_reversal as _preview_trade_reversal, reversal_documents as _reversal_documents,
    reversed_movement, target_voided,
)


MODULE_ID = "procurement"
OWNER_REF = f"{MODULE_ID}:order-owner"
REQUIRED_MODULES = {MODULE_ID, "trade_core", "master_data", "inventory"}

# From v21 the order, line and receipt tables are the procurement standard tables plus this database's extension
# columns (generic_kernel.migrations). These projections keep the text-keyed row shape its commands, previews,
# readbacks and generations are built on; writes go to the physical tables.
ORDER_ROWS = ("(SELECT order_id, supplier_party_id, ordered_at, status, revision, evidence_refs_json, source_ref, created_at,"
              " updated_at FROM procurement_batches)")
LINE_ROWS = ("(SELECT p.id, p.line_id, b.order_id, p.product_id, p.quantity_unit_id AS unit_id, p.quantity_text AS quantity,"
             " p.received_quantity, p.receive_location_id FROM procurements p JOIN procurement_batches b ON b.id=p.batch_id)")
RECEIPT_ROWS = ("(SELECT a.receipt_id, a.order_id, p.line_id, a.quantity_text AS quantity, a.inventory_action_id,"
                " a.inventory_movement_id, a.occurred_at, a.evidence_refs_json, a.receipt_line_id, a.over_receipt_allowance"
                " FROM procurement_receipt_allocations a JOIN procurements p ON p.id=a.procurement_id)")
_ROWS = {"procurement_orders": ORDER_ROWS, "procurement_order_lines": LINE_ROWS, "procurement_receipts": RECEIPT_ROWS}


class ProcurementOwnerError(RuntimeError):
    def __init__(self, code: str, message: str):
        super().__init__(f"{code}: {message}")
        self.code = code
        self.message = message


def _identity_text(value: str | None) -> str:
    return unicodedata.normalize("NFKC", value or "").strip().casefold()


def _arrival_facts(document: dict[str, Any], lines: Iterable[dict[str, Any]]) -> tuple[Any, ...]:
    details = [(line["product_id"], line["unit_id"], line.get("order_line_id") or None,
                _quantity(line["arrived_quantity"])) for line in lines]
    return document["supplier_party_id"], document["occurred_at"], Counter(details)


def _post_facts(command: ProcurementReceiptCommand) -> tuple[Any, ...]:
    allocations = [(item.receipt_line_id, item.order_line_id, item.location_id,
                    _quantity(item.quantity), _quantity(item.over_receipt_allowance, allow_zero=True))
                   for item in command.allocations]
    return command.document_id, command.occurred_at, Counter(allocations)


def _check_receipt_identity(connection: sqlite3.Connection, command: ProcurementReceiptCommand) -> None:
    if command.action == "register":
        identity = _identity_text(command.source_identity)
        for row in connection.execute("SELECT * FROM procurement_receipt_documents"):
            same_identity = (row["supplier_party_id"] == command.supplier_party_id
                             and _identity_text(row["source_identity"]) == identity)
            if not same_identity and row["document_id"] != command.document_id:
                continue
            same = same_identity and _arrival_facts(dict(row), _receipt_lines(connection, row["document_id"])) == _arrival_facts(
                command.to_dict(), [item.to_dict() for item in command.lines])
            code = "procurement_arrival_duplicate" if same else "procurement_arrival_identity_conflict"
            raise ProcurementOwnerError(code, f"existing document_id={row['document_id']}")
    elif command.action == "post" and command.post_reference is not None:
        reference = _identity_text(command.post_reference)
        if not reference:
            raise ProcurementOwnerError("procurement_post_identity_required", "post_reference")
        for row in connection.execute("""SELECT r.action_id, r.post_reference, a.payload_json
            FROM procurement_action_receipts r JOIN procurement_audit_events a ON a.event_id=r.audit_event_id
            WHERE r.document_kind='receipt' AND r.post_reference IS NOT NULL"""):
            if _identity_text(row["post_reference"]) != reference:
                continue
            previous = ProcurementReceiptCommand.from_dict(json.loads(row["payload_json"])["command"])
            same = _post_facts(previous) == _post_facts(command)
            code = "procurement_post_duplicate" if same else "procurement_post_identity_conflict"
            raise ProcurementOwnerError(code, f"existing action_id={row['action_id']}")


def _require_module_enabled(enabled_module_ids: Iterable[str] | None) -> set[str]:
    if enabled_module_ids is None:
        from backend.generic_kernel.profile import get_generic_registry

        enabled_module_ids = [
            str(item["module_id"])
            for item in get_generic_registry().payload.get("modules", [])
        ]
    enabled = set(enabled_module_ids)
    missing = sorted(REQUIRED_MODULES - enabled)
    if MODULE_ID not in enabled:
        raise ProcurementOwnerError("procurement_module_disabled", f"{MODULE_ID} is not enabled")
    if missing:
        raise ProcurementOwnerError("procurement_dependency_missing", ",".join(missing))
    return enabled


def _connect(path: Path, *, readonly: bool) -> sqlite3.Connection:
    connection = storage_connect(f"file:{path}?mode=ro" if readonly else path, uri=readonly)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys=ON")
    connection.execute("PRAGMA busy_timeout=10000")
    if readonly:
        connection.execute("PRAGMA query_only=ON")
        # One deferred read transaction keeps composite readbacks (details,
        # balances, projections, generation) on a single committed snapshot.
        connection.execute("BEGIN")
    return connection


def _reading(storage: StorageTarget):
    return read_storage(storage, lambda path: _connect(path, readonly=True))


def _writing(storage: StorageTarget):
    return write_storage(storage, lambda path: _connect(path, readonly=False))


def _document_row(row: sqlite3.Row) -> dict[str, Any]:
    # NULL appended columns on v11 rows preserve the historical readback/generation.
    appended = {"conversion_from_unit_id", "conversion_to_unit_id", "conversion_factor", "conversion_source_ref",
                "original_quantity", "original_unit_id", "converted_quantity", "post_reference"}
    return {key: value for key, value in dict(row).items() if key not in appended or value is not None}


def _table_rows(connection: sqlite3.Connection, table: str, key: str) -> list[dict[str, Any]]:
    rows = connection.execute(f"SELECT * FROM {_ROWS.get(table, table)} ORDER BY {key}")
    return [(_document_row(row) if table in {"procurement_order_line_terms", "procurement_invoice_matches", "procurement_action_receipts"} else dict(row)) for row in rows]


def _state_generation(connection: sqlite3.Connection) -> str:
    # Schema-only v9 upgrades retain the v1 digest's numeric representation
    # and column set. New receipt previews bind the exact text state separately.
    lines = _table_rows(connection, "procurement_order_lines", "line_id")
    for row in lines:
        for key in ("quantity", "received_quantity"):
            row[key] = connection.execute("SELECT CAST(? AS NUMERIC)", (row[key],)).fetchone()[0]
    receipts = _table_rows(connection, "procurement_receipts", "receipt_id")
    for row in receipts:
        row["quantity"] = connection.execute("SELECT CAST(? AS NUMERIC)", (row["quantity"],)).fetchone()[0]
        row.pop("receipt_line_id", None)
        row.pop("over_receipt_allowance", None)
    actions = _table_rows(connection, "procurement_action_receipts", "action_id")
    for row in actions:
        row.pop("document_kind", None)
        row.pop("document_id", None)
        row.pop("post_reference", None)
    return digest_json({"orders": _table_rows(connection, "procurement_orders", "order_id"),
                        "lines": lines, "receipts": receipts, "actions": actions})


def _quantity(value: object, *, allow_zero: bool = False) -> Decimal:
    try:
        return check_decimal_range(quantity_decimal(value, allow_zero=allow_zero), "procurement_quantity_out_of_range")
    except TradeRuleError as exc:
        raise ProcurementOwnerError(str(exc), str(value)) from exc


def _cumulative_quantity(value: object) -> Decimal:
    # Historical received quantities keep their stored digits: v8 SQL-float
    # remainders (0.1+0.2) and legal high-precision values are not new input
    # and must not re-enter the four-decimal input limit. Only finiteness,
    # sign and the integer-digit range still apply to the accumulated total.
    try:
        parsed = quantity_decimal(value, allow_zero=True)
        if parsed.adjusted() >= 18:
            raise TradeRuleError("procurement_quantity_out_of_range")
        return parsed
    except TradeRuleError as exc:
        raise ProcurementOwnerError(str(exc), str(value)) from exc


def _linked_arrival(connection: sqlite3.Connection, order_id: str) -> bool:
    if not connection.execute("SELECT 1 FROM sqlite_master WHERE name='procurement_receipt_lines'").fetchone():
        return False
    return connection.execute(
        f"""SELECT 1 FROM procurement_receipt_lines r JOIN {LINE_ROWS} l
           ON r.order_line_id=l.line_id WHERE l.order_id=? LIMIT 1""", (order_id,)
    ).fetchone() is not None


def _linked_receipts(connection: sqlite3.Connection, order_id: str) -> bool:
    return connection.execute("SELECT 1 FROM procurement_receipt_allocations WHERE order_id=? LIMIT 1", (order_id,)).fetchone() is not None


def _order(connection: sqlite3.Connection, order_id: str) -> dict[str, Any] | None:
    row = connection.execute(
        f"SELECT * FROM {ORDER_ROWS} WHERE order_id=?", (order_id,)
    ).fetchone()
    return dict(row) if row else None


def _lines(connection: sqlite3.Connection, order_id: str) -> list[dict[str, Any]]:
    return [
        dict(row)
        for row in connection.execute(
            f"SELECT * FROM {LINE_ROWS} WHERE order_id=? ORDER BY line_id",
            (order_id,),
        )
    ]


def _validate_command(command: ProcurementCommand) -> tuple[str, ...]:
    if command.action not in {"create", "receive", "cancel", "revise"}:
        raise ProcurementOwnerError("procurement_action_invalid", command.action)
    if not isinstance(command.idempotency_key, str):
        raise ProcurementOwnerError("procurement_idempotency_key_invalid", "use a string")
    if not command.idempotency_key.strip():
        raise ProcurementOwnerError("procurement_idempotency_key_required", "idempotency key is required")
    for field in ("ordered_at", "occurred_at"):
        value = getattr(command, field)
        if value:
            try:
                business_datetime(value)
            except TradeRuleError as exc:
                raise ProcurementOwnerError("procurement_" + field + "_invalid", "use an ISO date or timestamp with timezone") from exc
    if not command.order_id.strip():
        raise ProcurementOwnerError("procurement_order_id_required", "order id is required")
    if not command.source_ref.strip():
        raise ProcurementOwnerError("procurement_source_ref_required", "source ref is required")
    try:
        return normalized_evidence_refs(command.evidence_refs)
    except TradeRuleError as exc:
        raise ProcurementOwnerError(str(exc), "evidence refs are invalid") from exc


def _validated_lines(
    connection: sqlite3.Connection,
    command: ProcurementCommand,
) -> tuple[dict[str, Any], ...]:
    if not command.lines:
        raise ProcurementOwnerError("procurement_lines_required", "at least one line is required")
    if len({item.line_id for item in command.lines}) != len(command.lines):
        raise ProcurementOwnerError("procurement_line_id_duplicate", command.order_id)
    planned: list[dict[str, Any]] = []
    for item in command.lines:
        if not all((item.line_id.strip(), is_master_data_ref(item.product_id), is_master_data_ref(item.unit_id), item.receive_location_id.strip())):
            raise ProcurementOwnerError("procurement_line_identity_required", item.line_id)
        try:
            get_resource(connection, "product", item.product_id)
            get_resource(connection, "unit", item.unit_id)
            get_resource(connection, "location", item.receive_location_id)
            quantity = _quantity(item.quantity)
        except (MasterDataError, TradeRuleError) as exc:
            raise ProcurementOwnerError(getattr(exc, "code", str(exc)), item.line_id) from exc
        planned.append({
            "line_id": item.line_id,
            "product_id": item.product_id,
            "unit_id": item.unit_id,
            "quantity": format(quantity, "f"),
            "received_quantity": "0",
            "receive_location_id": item.receive_location_id,
        })
    return tuple(planned)


def _receipt_id(command: ProcurementCommand) -> str:
    return f"prc-{digest_json(command.to_dict())[:24]}"


def _project_order_status(lines: list[dict[str, Any]]) -> str:
    states = ["completed" if Decimal(str(item["received_quantity"])) >= Decimal(str(item["quantity"]))
              else "partial" if Decimal(str(item["received_quantity"])) > 0 else "open" for item in lines]
    value = aggregate_order_progress(states)
    return {"completed": "received", "partial": "partially_received"}.get(value, value)


def _apply_receiving_effect(connection: sqlite3.Connection, receipt: dict[str, Any],
                            inventory: InventoryPreview, *, enabled: set[str], now: str,
                            refresh_inventory: bool = False) -> dict[str, Any]:
    if refresh_inventory:
        inventory = preview_inventory_in_transaction(connection, inventory.command, enabled_module_ids=enabled)
    result = apply_inventory_in_transaction(connection, inventory, enabled_module_ids=enabled)
    movement = connection.execute(
        "SELECT id, product_id, quantity_unit_id, quantity, quantity_text FROM material_inventory_events WHERE movement_id=?",
        (result["movements"][0]["movement_id"],)).fetchone()
    line = connection.execute("SELECT id, product_id, quantity_unit_id, quantity_text FROM procurements WHERE line_id=?",
                              (receipt["line_id"],)).fetchone()
    extension = {
        "receipt_id": receipt["receipt_id"], "order_id": receipt["order_id"], "inventory_action_id": result["action_id"],
        "inventory_movement_id": result["movements"][0]["movement_id"], "occurred_at": receipt["occurred_at"],
        "evidence_refs_json": receipt["evidence_refs_json"], "receipt_line_id": receipt.get("receipt_line_id"),
        "over_receipt_allowance": receipt.get("over_receipt_allowance", "0"), "quantity_text": receipt["quantity"],
    }
    try:
        receipt_writes.allocate(
            connection,
            line=receipt_writes.LineFacts(int(line["id"]), int(line["product_id"]), int(line["quantity_unit_id"]),
                                          Decimal(line["quantity_text"]), tolerance=Decimal(extension["over_receipt_allowance"])),
            receipt=receipt_writes.ReceiptFacts(int(movement["id"]), movement["product_id"], movement["quantity_unit_id"],
                                                Decimal(movement["quantity_text"] or str(movement["quantity"]))),
            quantity=receipt["quantity"], quantity_unit_id=int(line["quantity_unit_id"]),
            provenance=receipt_writes.Provenance("generic_receipt", result["action_id"], "", "generic"), extra=extension)
    except receipt_writes.ReceiptWriteError as exc:
        raise ProcurementOwnerError(_receipt_write_code(exc.code), exc.message) from exc
    _refresh_received_quantity(connection, int(line["id"]))
    materialize(connection, receipt["order_id"], now=now, status=_project_order_status(_lines(connection, receipt["order_id"])))
    return result


def materialize(connection: sqlite3.Connection, order_id: str, *, now: str, **columns: Any) -> None:
    """The one place this Owner writes an existing order header's columns (status, revision, header facts)."""
    assignments = ", ".join(f"{name}=?" for name in (*columns, "updated_at"))
    connection.execute(f"UPDATE procurement_batches SET {assignments} WHERE order_id=?", (*columns.values(), now, order_id))


def _receipt_write_code(code: str) -> str:
    return code if code.startswith("procurement_") else f"procurement_{code}"


def _refresh_received_quantity(connection: sqlite3.Connection, procurement_id: int) -> None:
    # The line's received total is the exact text sum of its confirmed allocations (SQLite's numeric SUM would add
    # float remainders to a text total).
    received = _cumulative_quantity(decimal_sum(Decimal(row[0]) for row in connection.execute(
        "SELECT quantity_text FROM procurement_receipt_allocations WHERE procurement_id=? AND status='confirmed'", (procurement_id,))))
    connection.execute("UPDATE procurements SET received_quantity=? WHERE id=?", (format(received, "f"), procurement_id))


def _preview_on_connection(
    connection: sqlite3.Connection,
    command: ProcurementCommand,
    *,
    enabled_module_ids: Iterable[str] | None,
) -> ProcurementPreview:
    enabled = _require_module_enabled(enabled_module_ids)
    evidence_refs = _validate_command(command)
    generation = _state_generation(connection)
    existing = _order(connection, command.order_id)
    planned_lines: tuple[dict[str, Any], ...] = ()
    planned_receipt: dict[str, Any] | None = None
    inventory_preview: dict[str, Any] | None = None

    if command.action == "create":
        if existing is not None:
            raise ProcurementOwnerError("procurement_order_already_exists", command.order_id)
        if not is_master_data_ref(command.supplier_party_id) or not command.ordered_at.strip():
            raise ProcurementOwnerError("procurement_order_identity_required", command.order_id)
        try:
            get_resource(connection, "party", command.supplier_party_id)
        except MasterDataError as exc:
            raise ProcurementOwnerError(exc.code, exc.message) from exc
        planned_lines = _validated_lines(connection, command)
        planned_order = {
            "order_id": command.order_id,
            "supplier_party_id": command.supplier_party_id,
            "ordered_at": command.ordered_at,
            "status": "open",
            "revision": 1,
            "evidence_refs_json": json.dumps(evidence_refs, ensure_ascii=False),
            "source_ref": command.source_ref,
        }
    else:
        if existing is None:
            raise ProcurementOwnerError("procurement_order_not_found", command.order_id)
        current_lines = _lines(connection, command.order_id)
        if command.action in {"revise", "cancel"} and _linked_arrival(connection, command.order_id):
            raise ProcurementOwnerError("procurement_arrival_linked_order_locked", command.order_id)
        planned_order = dict(existing)
        if command.action == "receive":
            if existing["status"] == "cancelled":
                raise ProcurementOwnerError("procurement_order_cancelled", command.order_id)
            target = next((item for item in current_lines if item["line_id"] == command.target_line_id), None)
            if target is None:
                raise ProcurementOwnerError("procurement_line_not_found", command.target_line_id)
            try:
                quantity = _quantity(command.quantity)
            except TradeRuleError as exc:
                raise ProcurementOwnerError(str(exc), command.quantity) from exc
            remaining = decimal_sum((Decimal(str(target["quantity"])), Decimal(str(target["received_quantity"])).copy_negate()))
            if quantity > remaining:
                raise ProcurementOwnerError("procurement_receipt_exceeds_remaining", command.target_line_id)
            if not command.occurred_at.strip():
                raise ProcurementOwnerError("procurement_occurred_at_required", command.order_id)
            inventory = preview_inventory_in_transaction(
                connection,
                InventoryCommand(
                    action="inbound",
                    idempotency_key=f"procurement:{command.idempotency_key}",
                    product_id=int(target["product_id"]),
                    unit_id=int(target["unit_id"]),
                    quantity=format(quantity, "f"),
                    to_location_id=str(target["receive_location_id"]),
                    occurred_at=command.occurred_at,
                    source_ref=command.source_ref,
                    reason=command.reason,
                ),
                enabled_module_ids=enabled,
            )
            inventory_preview = inventory.to_dict()
            planned_receipt = {
                "receipt_id": _receipt_id(command),
                "order_id": command.order_id,
                "line_id": command.target_line_id,
                "quantity": format(quantity, "f"),
                "occurred_at": command.occurred_at,
                "evidence_refs_json": json.dumps(evidence_refs, ensure_ascii=False),
            }
            updated_lines = [dict(item) for item in current_lines]
            for item in updated_lines:
                if item["line_id"] == command.target_line_id:
                    item["received_quantity"] = format(
                        decimal_sum((Decimal(str(item["received_quantity"])), quantity)),
                        "f",
                    )
            planned_order["status"] = _project_order_status(updated_lines)
        elif command.action == "cancel":
            if existing["status"] == "cancelled":
                raise ProcurementOwnerError("procurement_order_already_cancelled", command.order_id)
            if any(Decimal(str(item["received_quantity"])) > 0 for item in current_lines):
                raise ProcurementOwnerError(
                    "procurement_received_order_not_cancellable",
                    command.order_id,
                )
            if not command.reason.strip():
                raise ProcurementOwnerError("procurement_cancellation_reason_required", command.order_id)
            planned_order["status"] = "cancelled"
        else:
            if any(Decimal(str(item["received_quantity"])) > 0 for item in current_lines) or _linked_receipts(connection, command.order_id):
                raise ProcurementOwnerError("procurement_received_order_not_revisable", command.order_id + "；请先通过 /api/procurement/reversals preview→apply 冲销收货；已核对发票或付款须人工处理")
            if not command.reason.strip() or not is_master_data_ref(command.supplier_party_id) or not command.ordered_at.strip():
                raise ProcurementOwnerError("procurement_revision_fields_required", command.order_id)
            try:
                get_resource(connection, "party", command.supplier_party_id)
            except MasterDataError as exc:
                raise ProcurementOwnerError(exc.code, exc.message) from exc
            planned_lines = _validated_lines(connection, command)
            planned_order.update({
                "supplier_party_id": command.supplier_party_id,
                "ordered_at": command.ordered_at,
                "status": "open",
                "revision": int(existing["revision"]) + 1,
                "evidence_refs_json": json.dumps(evidence_refs, ensure_ascii=False),
                "source_ref": command.source_ref,
            })
    content = {
        "command": command.to_dict(),
        "state_generation": generation,
        "planned_order": planned_order,
        "planned_lines": list(planned_lines),
        "planned_receipt": planned_receipt,
        "inventory_preview": inventory_preview,
    }
    return ProcurementPreview(
        command=command,
        state_generation=generation,
        planned_order=planned_order,
        planned_lines=planned_lines,
        planned_receipt=planned_receipt,
        inventory_preview=inventory_preview,
        preview_digest=digest_json(content),
    )


def preview_action(
    storage: StorageTarget,
    command: ProcurementCommand,
    *,
    enabled_module_ids: Iterable[str] | None = None,
) -> ProcurementPreview:
    _require_module_enabled(enabled_module_ids)
    with _reading(storage) as connection:
        return _preview_on_connection(
            connection,
            command,
            enabled_module_ids=enabled_module_ids,
        )


def _legacy_quantity_row(connection: sqlite3.Connection, row: sqlite3.Row | dict[str, Any]) -> dict[str, Any]:
    result = {name: value for name, value in dict(row).items() if name != "id"}
    for key in ("quantity", "received_quantity"):
        if key in result:
            numeric = connection.execute("SELECT CAST(? AS NUMERIC)", (result[key],)).fetchone()[0]
            if Decimal(str(numeric)) == Decimal(str(result[key])):
                result[key] = numeric
    return result


def _readback(connection: sqlite3.Connection, action_id: str) -> dict[str, Any]:
    receipt = connection.execute(
        "SELECT * FROM procurement_action_receipts WHERE action_id=?", (action_id,)
    ).fetchone()
    if receipt is None:
        raise ProcurementOwnerError("procurement_readback_missing", action_id)
    if "document_kind" in receipt.keys() and receipt["document_kind"] == "reversal":
        return json.loads(connection.execute("SELECT payload_json FROM procurement_audit_events WHERE event_id=?", (receipt["audit_event_id"],)).fetchone()[0])["readback"]
    if "document_kind" in receipt.keys() and receipt["document_kind"] == "receipt":
        return _receipt_readback(connection, receipt)
    order_id = str(receipt["order_id"])
    order = _order(connection, order_id)
    inventory = None
    if receipt["inventory_action_id"]:
        inventory = read_inventory_in_transaction(connection, str(receipt["inventory_action_id"]))
    audit = connection.execute(
        "SELECT * FROM procurement_audit_events WHERE event_id=?",
        (receipt["audit_event_id"],),
    ).fetchone()
    return {
        "schema_version": "bizhub.procurement-readback.v1",
        "owner_ref": OWNER_REF,
        "action_id": action_id,
        "idempotency_key": str(receipt["idempotency_key"]),
        "command_digest": str(receipt["command_digest"]),
        "preview_digest": str(receipt["preview_digest"]),
        "order": order,
        "lines": [_legacy_quantity_row(connection, row) for row in _lines(connection, order_id)],
        "receipts": [
            {key: value for key, value in _legacy_quantity_row(connection, row).items() if key not in {"receipt_line_id", "over_receipt_allowance"}}
            for row in connection.execute(
                f"SELECT * FROM {RECEIPT_ROWS} WHERE order_id=? ORDER BY receipt_id",
                (order_id,),
            )
        ],
        "inventory": inventory,
        "audit_event": dict(audit) if audit else None,
        "state_generation": _state_generation(connection),
    }


def apply_preview_in_transaction(connection: sqlite3.Connection, preview: ProcurementPreview, *, enabled_module_ids: Iterable[str] | None = None) -> dict[str, Any]:
    if not connection.in_transaction:
        raise ProcurementOwnerError("procurement_transaction_required", "an outer transaction is required")
    enabled = _require_module_enabled(enabled_module_ids)
    if digest_json(preview.content()) != preview.preview_digest:
        raise ProcurementOwnerError("procurement_preview_content_drift", "preview digest differs")
    try:
        existing = connection.execute(
            "SELECT action_id, command_digest FROM procurement_action_receipts WHERE idempotency_key=?",
            (preview.command.idempotency_key,),
        ).fetchone()
        if existing is not None:
            if str(existing["command_digest"]) != preview.command.command_digest:
                raise ProcurementOwnerError("procurement_idempotency_conflict", preview.command.idempotency_key)
            result = _readback(connection, str(existing["action_id"]))
            result["disposition"] = "idempotent_noop"
            return result
        if _state_generation(connection) != preview.state_generation:
            raise ProcurementOwnerError("procurement_state_generation_drift", "procurement changed")
        authoritative = _preview_on_connection(
            connection,
            preview.command,
            enabled_module_ids=enabled,
        )
        if authoritative.preview_digest != preview.preview_digest:
            raise ProcurementOwnerError("procurement_preview_content_drift", "authoritative plan differs")
        inventory_result = None
        now = datetime.now(UTC).isoformat()
        order = authoritative.planned_order
        if preview.command.action == "create":
            connection.execute(
                """INSERT INTO procurement_batches
                   (order_id, supplier_party_id, ordered_at, business_date, status, revision,
                    evidence_refs_json, source_ref, created_at, updated_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    order["order_id"], order["supplier_party_id"], order["ordered_at"], _business_date(order["ordered_at"]),
                    order["status"], order["revision"], order["evidence_refs_json"],
                    order["source_ref"], now, now,
                ),
            )
            _insert_lines(connection, preview.command.order_id, authoritative.planned_lines, now)
        elif preview.command.action == "receive":
            inventory_result = _apply_receiving_effect(
                connection, authoritative.planned_receipt or {},
                InventoryPreview.from_dict(authoritative.inventory_preview or {}), enabled=enabled, now=now,
            )
        elif preview.command.action == "cancel":
            materialize(connection, preview.command.order_id, now=now, status="cancelled")
        else:
            materialize(connection, preview.command.order_id, now=now, business_date=_business_date(order["ordered_at"]),
                        **{key: order[key] for key in ("supplier_party_id", "ordered_at", "status", "revision", "evidence_refs_json", "source_ref")})
            connection.execute("DELETE FROM procurements WHERE batch_id=(SELECT id FROM procurement_batches WHERE order_id=?)",
                               (preview.command.order_id,))
            _insert_lines(connection, preview.command.order_id, authoritative.planned_lines, now)
        action_id = uuid.uuid4().hex
        audit_event_id = uuid.uuid4().hex
        connection.execute(
            "INSERT INTO procurement_audit_events(event_id, event_type, payload_json, created_at) VALUES (?, ?, ?, ?)",
            (
                audit_event_id,
                f"procurement_{preview.command.action}_applied",
                json.dumps(authoritative.to_dict(), ensure_ascii=False, sort_keys=True, separators=(",", ":")),
                now,
            ),
        )
        connection.execute(
            """INSERT INTO procurement_action_receipts
               (action_id, idempotency_key, command_digest, preview_digest, order_id,
                audit_event_id, inventory_action_id, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                action_id, preview.command.idempotency_key, preview.command.command_digest,
                preview.preview_digest, preview.command.order_id, audit_event_id,
                (inventory_result or {}).get("action_id"), now,
            ),
        )
        result = _readback(connection, action_id)
    except settlement.SettlementWriteError as exc:
        raise ProcurementOwnerError(exc.code, exc.message) from exc
    except sqlite3.IntegrityError as exc:
        raise ProcurementOwnerError("procurement_write_conflict", str(exc)) from exc
    result["disposition"] = "applied"
    return result


def _business_date(ordered_at: str) -> str:
    return business_datetime(ordered_at).date().isoformat()


def _insert_lines(connection: sqlite3.Connection, order_id: str, lines: Iterable[dict[str, Any]], now: str) -> None:
    # Standard columns the generic order does not carry get their neutral values; the item name is the product's.
    batch_id = connection.execute("SELECT id FROM procurement_batches WHERE order_id=?", (order_id,)).fetchone()[0]
    for line in lines:
        connection.execute(
            """INSERT INTO procurements
               (batch_id, product_id, item_name, quantity, quantity_unit_id, is_taxed, invoice_expectation,
                invoice_expectation_note, created_at, line_id, received_quantity, receive_location_id, quantity_text)
               VALUES (?, ?, (SELECT canonical_name FROM products WHERE id=?), CAST(? AS NUMERIC), ?, 0, 'unknown', '', ?, ?, ?, ?, ?)""",
            (batch_id, line["product_id"], line["product_id"], line["quantity"], line["unit_id"], now,
             line["line_id"], line["received_quantity"], line["receive_location_id"], line["quantity"]),
        )


def apply_preview(storage: StorageTarget, preview: ProcurementPreview, *, enabled_module_ids: Iterable[str] | None = None) -> dict[str, Any]:
    _require_module_enabled(enabled_module_ids)
    with _writing(storage) as connection:
        return apply_preview_in_transaction(connection, preview, enabled_module_ids=enabled_module_ids)


def _receipt_generation(connection: sqlite3.Connection) -> str:
    return digest_json({table: _table_rows(connection, table, key) for table, key in (
        ("procurement_orders", "order_id"), ("procurement_order_lines", "line_id"),
        ("procurement_receipts", "receipt_id"), ("procurement_action_receipts", "action_id"),
        ("procurement_receipt_documents", "document_id"), ("procurement_receipt_lines", "line_id"),
    )})


def _receipt_document(connection: sqlite3.Connection, document_id: str) -> dict[str, Any]:
    row = connection.execute("SELECT * FROM procurement_receipt_documents WHERE document_id=?", (document_id,)).fetchone()
    if row is None:
        raise ProcurementOwnerError("procurement_receipt_document_not_found", document_id)
    return dict(row)


def _receipt_lines(connection: sqlite3.Connection, document_id: str) -> list[dict[str, Any]]:
    return [dict(row) for row in connection.execute(
        "SELECT * FROM procurement_receipt_lines WHERE document_id=? ORDER BY line_id", (document_id,))]


def _posted_quantity(connection: sqlite3.Connection, line_id: str) -> Decimal:
    return decimal_sum(Decimal(row[0]) for row in connection.execute(
        f"SELECT r.quantity FROM {RECEIPT_ROWS} r WHERE receipt_line_id=? AND NOT EXISTS (SELECT 1 FROM material_inventory_events m WHERE m.movement_id=r.inventory_movement_id AND m.status='reversed')", (line_id,)))


def _target_line(connection: sqlite3.Connection, line_id: str, *, supplier: str,
                 product: str, unit: str) -> dict[str, Any]:
    row = connection.execute(
        f"""SELECT l.*, o.supplier_party_id, o.status FROM {LINE_ROWS} l
           JOIN {ORDER_ROWS} o ON o.order_id=l.order_id WHERE l.line_id=?""", (line_id,)).fetchone()
    if row is None:
        raise ProcurementOwnerError("procurement_line_not_found", line_id)
    if row["status"] == "cancelled":
        raise ProcurementOwnerError("procurement_order_cancelled", row["order_id"])
    for key, expected in (("supplier_party_id", supplier), ("product_id", product), ("unit_id", unit)):
        if row[key] != expected:
            raise ProcurementOwnerError("procurement_receipt_identity_mismatch", key)
    return dict(row)


def _preview_receipt_on_connection(connection: sqlite3.Connection, command: ProcurementReceiptCommand,
                                   *, enabled_module_ids: Iterable[str] | None) -> ProcurementReceiptPreview:
    enabled = _require_module_enabled(enabled_module_ids)
    if command.action not in {"register", "inspect", "post"}:
        raise ProcurementOwnerError("procurement_receipt_action_invalid", command.action)
    if not all(value.strip() for value in (command.idempotency_key, command.document_id, command.source_ref, command.occurred_at)):
        raise ProcurementOwnerError("procurement_receipt_identity_required", command.document_id)
    try:
        business_datetime(command.occurred_at)
    except TradeRuleError as exc:
        raise ProcurementOwnerError("procurement_occurred_at_invalid", "use an ISO date or timestamp with timezone") from exc
    if command.post_reference is not None and command.action != "post":
        raise ProcurementOwnerError("procurement_receipt_fields_invalid", "post_reference is only allowed for post")
    try:
        evidence = normalized_evidence_refs(command.evidence_refs)
    except TradeRuleError as exc:
        raise ProcurementOwnerError(str(exc), "evidence refs are required") from exc
    generation = _receipt_generation(connection)
    planned_lines: list[dict[str, Any]] = []
    allocations: list[dict[str, Any]] = []
    inventory_previews: list[dict[str, Any]] = []
    if command.action == "register":
        if not is_master_data_ref(command.supplier_party_id) or not command.source_identity.strip():
            raise ProcurementOwnerError("procurement_arrival_identity_required", command.document_id)
        if command.allocations or not command.lines or len({item.line_id for item in command.lines}) != len(command.lines):
            raise ProcurementOwnerError("procurement_receipt_lines_invalid", command.document_id)
        _check_receipt_identity(connection, command)
        try:
            get_resource(connection, "party", command.supplier_party_id)
            for item in command.lines:
                if not item.line_id.strip() or any((item.received_quantity, item.accepted_quantity, item.rejected_quantity)):
                    raise ProcurementOwnerError("procurement_registration_inspection_forbidden", item.line_id)
                get_resource(connection, "product", item.product_id)
                get_resource(connection, "unit", item.unit_id)
                quantity = _quantity(item.arrived_quantity)
                if item.order_line_id:
                    _target_line(connection, item.order_line_id, supplier=command.supplier_party_id, product=item.product_id, unit=item.unit_id)
                planned_lines.append({"line_id": item.line_id, "document_id": command.document_id,
                    "product_id": item.product_id, "unit_id": item.unit_id, "order_line_id": item.order_line_id or None,
                    "arrived_quantity": format(quantity, "f"), "received_quantity": format(quantity, "f"),
                    "accepted_quantity": "0", "rejected_quantity": "0", "inspected_at": None, "inspection_evidence_refs_json": None})
        except MasterDataError as exc:
            raise ProcurementOwnerError(exc.code, exc.message) from exc
        document = {"document_id": command.document_id, "supplier_party_id": command.supplier_party_id,
                    "source_identity": command.source_identity, "occurred_at": command.occurred_at,
                    "source_ref": command.source_ref, "evidence_refs_json": json.dumps(evidence, ensure_ascii=False)}
    else:
        document = _receipt_document(connection, command.document_id)
        if target_voided(connection, MODULE_ID, "receipt_document", command.document_id):
            raise ProcurementOwnerError("procurement_receipt_voided", "该收货单已作废，请重新登记收货单")
        current = {item["line_id"]: item for item in _receipt_lines(connection, command.document_id)}
        if command.supplier_party_id or command.source_identity:
            raise ProcurementOwnerError("procurement_receipt_identity_immutable", command.document_id)
        if command.action == "inspect":
            if command.allocations or not command.lines or len({item.line_id for item in command.lines}) != len(command.lines):
                raise ProcurementOwnerError("procurement_inspection_lines_invalid", command.document_id)
            for item in command.lines:
                if item.line_id not in current:
                    raise ProcurementOwnerError("procurement_receipt_line_not_found", item.line_id)
                if any((item.product_id, item.unit_id, item.arrived_quantity, item.order_line_id)):
                    raise ProcurementOwnerError("procurement_receipt_identity_immutable", item.line_id)
                row = dict(current[item.line_id])
                received = _quantity(item.received_quantity, allow_zero=True)
                accepted = _quantity(item.accepted_quantity, allow_zero=True)
                rejected = _quantity(item.rejected_quantity, allow_zero=True)
                if received > Decimal(row["arrived_quantity"]) or decimal_sum((accepted, rejected)) > received:
                    raise ProcurementOwnerError("procurement_inspection_exceeds_arrival", item.line_id)
                if accepted < _posted_quantity(connection, item.line_id):
                    raise ProcurementOwnerError("procurement_inspection_below_posted", item.line_id)
                row.update(received_quantity=format(received, "f"), accepted_quantity=format(accepted, "f"),
                           rejected_quantity=format(rejected, "f"), inspected_at=command.occurred_at,
                           inspection_evidence_refs_json=json.dumps(evidence, ensure_ascii=False))
                planned_lines.append(row)
        else:
            if command.lines or not command.allocations:
                raise ProcurementOwnerError("procurement_allocations_required", command.document_id)
            _check_receipt_identity(connection, command)
            source_totals: dict[str, Decimal] = {}
            target_totals: dict[str, Decimal] = {}
            allowances: dict[str, Decimal] = {}
            for index, allocation in enumerate(command.allocations):
                row = current.get(allocation.receipt_line_id)
                if row is None:
                    raise ProcurementOwnerError("procurement_receipt_line_not_found", allocation.receipt_line_id)
                if row["inspected_at"] is None:
                    raise ProcurementOwnerError("procurement_receipt_not_inspected", allocation.receipt_line_id)
                target = _target_line(connection, allocation.order_line_id, supplier=document["supplier_party_id"],
                                      product=row["product_id"], unit=row["unit_id"])
                quantity = _quantity(allocation.quantity)
                allowance = _quantity(allocation.over_receipt_allowance, allow_zero=True)
                if allocation.order_line_id in allowances and allowances[allocation.order_line_id] != allowance:
                    raise ProcurementOwnerError("procurement_over_receipt_allowance_conflict", allocation.order_line_id)
                allowances[allocation.order_line_id] = allowance
                source_total = decimal_sum((source_totals.get(row["line_id"], _posted_quantity(connection, row["line_id"])), quantity))
                target_total = _cumulative_quantity(decimal_sum((target_totals.get(target["line_id"], Decimal(str(target["received_quantity"]))), quantity)))
                if source_total > Decimal(row["accepted_quantity"]):
                    raise ProcurementOwnerError("procurement_post_exceeds_accepted", row["line_id"])
                if target_total > decimal_sum((Decimal(str(target["quantity"])), allowance)):
                    raise ProcurementOwnerError("procurement_receipt_exceeds_remaining", target["line_id"])
                source_totals[row["line_id"]] = source_total
                target_totals[target["line_id"]] = target_total
                receipt = {"receipt_id": f"prc-{command.command_digest[:24]}-{index}", "receipt_line_id": row["line_id"],
                           "order_id": target["order_id"], "line_id": target["line_id"], "quantity": format(quantity, "f"),
                           "over_receipt_allowance": format(allowance, "f"), "occurred_at": command.occurred_at,
                           "evidence_refs_json": json.dumps(evidence, ensure_ascii=False)}
                inventory = preview_inventory_in_transaction(connection, InventoryCommand(
                    action="inbound", idempotency_key=f"procurement-receipt:{command.idempotency_key}:{index}",
                    product_id=row["product_id"], unit_id=row["unit_id"], quantity=receipt["quantity"],
                    to_location_id=allocation.location_id, occurred_at=command.occurred_at,
                    source_ref=command.source_ref, reason=command.reason), enabled_module_ids=enabled)
                allocations.append(receipt)
                inventory_previews.append(inventory.to_dict())
    content = {"command": command.to_dict(), "state_generation": generation, "planned_document": document,
               "planned_lines": planned_lines, "planned_allocations": allocations, "inventory_previews": inventory_previews}
    return ProcurementReceiptPreview(command, generation, document, tuple(planned_lines), tuple(allocations),
                                     tuple(inventory_previews), digest_json(content))


def preview_receipt_action(storage: StorageTarget, command: ProcurementReceiptCommand, *,
                           enabled_module_ids: Iterable[str] | None = None) -> ProcurementReceiptPreview:
    _require_module_enabled(enabled_module_ids)
    with _reading(storage) as connection:
        return _preview_receipt_on_connection(connection, command, enabled_module_ids=enabled_module_ids)


def _receipt_detail(connection: sqlite3.Connection, document_id: str) -> dict[str, Any]:
    document = _receipt_document(connection, document_id)
    voided = target_voided(connection, MODULE_ID, "receipt_document", document_id)
    if voided:
        document["status"] = "voided"
    lines = _receipt_lines(connection, document_id)
    for line in lines:
        posted = _posted_quantity(connection, line["line_id"])
        line["posted_quantity"] = format(posted, "f")
        line["unposted_accepted_quantity"] = "0" if voided else format(decimal_sum((Decimal(line["accepted_quantity"]), posted.copy_negate())), "f")
    allocations = [dict(row) for row in connection.execute(
        f"""SELECT r.* FROM {RECEIPT_ROWS} r JOIN procurement_receipt_lines l ON l.line_id=r.receipt_line_id
           WHERE l.document_id=? ORDER BY r.receipt_id""", (document_id,))]
    return {"document": document, "lines": lines, "allocations": allocations}


def _receipt_readback(connection: sqlite3.Connection, action: sqlite3.Row) -> dict[str, Any]:
    detail = _receipt_detail(connection, action["document_id"])
    audit = dict(connection.execute("SELECT * FROM procurement_audit_events WHERE event_id=?", (action["audit_event_id"],)).fetchone())
    planned = json.loads(audit["payload_json"])
    ids = [row["receipt_id"] for row in planned["planned_allocations"]]
    effects = [row for row in detail["allocations"] if row["receipt_id"] in ids]
    return {"schema_version": "bizhub.procurement-receipt-readback.v1", "owner_ref": OWNER_REF,
            "action_id": action["action_id"], "idempotency_key": action["idempotency_key"],
            "command_digest": action["command_digest"], "preview_digest": action["preview_digest"], **detail,
            "inventory": [read_inventory_in_transaction(connection, row["inventory_action_id"]) for row in effects],
            "audit_event": audit, "state_generation": _receipt_generation(connection)}


def read_receipt_document(storage: StorageTarget, document_id: str) -> dict[str, Any]:
    with _reading(storage) as connection:
        return _receipt_detail(connection, document_id)


def read_action(storage: StorageTarget, action_id: str) -> dict[str, Any]:
    with _reading(storage) as connection:
        return _readback(connection, action_id)


def apply_receipt_preview_in_transaction(connection: sqlite3.Connection, preview: ProcurementReceiptPreview, *, enabled_module_ids: Iterable[str] | None = None) -> dict[str, Any]:
    if not connection.in_transaction:
        raise ProcurementOwnerError("procurement_transaction_required", "an outer transaction is required")
    enabled = _require_module_enabled(enabled_module_ids)
    if digest_json(preview.content()) != preview.preview_digest:
        raise ProcurementOwnerError("procurement_preview_content_drift", "preview digest differs")
    try:
        existing = connection.execute("SELECT * FROM procurement_action_receipts WHERE idempotency_key=?", (preview.command.idempotency_key,)).fetchone()
        if existing is not None:
            if existing["command_digest"] != preview.command.command_digest:
                raise ProcurementOwnerError("procurement_idempotency_conflict", preview.command.idempotency_key)
            result = _readback(connection, existing["action_id"])
            return {**result, "disposition": "idempotent_noop"}
        _check_receipt_identity(connection, preview.command)
        if _receipt_generation(connection) != preview.state_generation:
            raise ProcurementOwnerError("procurement_state_generation_drift", "procurement changed")
        authoritative = _preview_receipt_on_connection(connection, preview.command, enabled_module_ids=enabled)
        if authoritative.preview_digest != preview.preview_digest:
            raise ProcurementOwnerError("procurement_preview_content_drift", "authoritative plan differs")
        command = authoritative.command
        now = datetime.now(UTC).isoformat()
        if command.action == "register":
            document = authoritative.planned_document
            connection.execute("""INSERT INTO procurement_receipt_documents
                (document_id, supplier_party_id, source_identity, occurred_at, source_ref, evidence_refs_json, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)""", tuple(document[key] for key in (
                    "document_id", "supplier_party_id", "source_identity", "occurred_at", "source_ref", "evidence_refs_json")) + (now, now))
            for line in authoritative.planned_lines:
                columns = list(line)
                connection.execute(f"INSERT INTO procurement_receipt_lines ({', '.join(columns)}) VALUES ({', '.join('?' for _ in columns)})", tuple(line.values()))
        elif command.action == "inspect":
            for line in authoritative.planned_lines:
                connection.execute("""UPDATE procurement_receipt_lines SET received_quantity=?, accepted_quantity=?,
                    rejected_quantity=?, inspected_at=?, inspection_evidence_refs_json=? WHERE line_id=?""",
                    tuple(line[key] for key in ("received_quantity", "accepted_quantity", "rejected_quantity", "inspected_at", "inspection_evidence_refs_json", "line_id")))
        else:
            for receipt, inventory in zip(authoritative.planned_allocations, authoritative.inventory_previews, strict=True):
                _apply_receiving_effect(connection, receipt, InventoryPreview.from_dict(inventory), enabled=enabled, now=now, refresh_inventory=True)
        connection.execute("UPDATE procurement_receipt_documents SET updated_at=? WHERE document_id=?", (now, command.document_id))
        action_id, audit_id = uuid.uuid4().hex, uuid.uuid4().hex
        connection.execute("INSERT INTO procurement_audit_events(event_id, event_type, payload_json, created_at) VALUES (?, ?, ?, ?)",
                           (audit_id, f"procurement_receipt_{command.action}_applied", json.dumps(authoritative.to_dict(), ensure_ascii=False, sort_keys=True, separators=(",", ":")), now))
        receipt = {"action_id": action_id, "idempotency_key": command.idempotency_key,
                   "command_digest": command.command_digest, "preview_digest": preview.preview_digest,
                   "order_id": None, "audit_event_id": audit_id, "inventory_action_id": None,
                   "created_at": now, "document_kind": "receipt", "document_id": command.document_id}
        if command.post_reference is not None:
            receipt["post_reference"] = command.post_reference
        connection.execute(f"INSERT INTO procurement_action_receipts ({', '.join(receipt)}) VALUES ({', '.join('?' for _ in receipt)})",
                           tuple(receipt.values()))
        result = _readback(connection, action_id)
        return {**result, "disposition": "applied"}
    except settlement.SettlementWriteError as exc:
        raise ProcurementOwnerError(exc.code, exc.message) from exc
    except sqlite3.IntegrityError as exc:
        raise ProcurementOwnerError("procurement_write_conflict", str(exc)) from exc


def apply_receipt_preview(storage: StorageTarget, preview: ProcurementReceiptPreview, *, enabled_module_ids: Iterable[str] | None = None) -> dict[str, Any]:
    _require_module_enabled(enabled_module_ids)
    with _writing(storage) as connection:
        return apply_receipt_preview_in_transaction(connection, preview, enabled_module_ids=enabled_module_ids)


__all__ = ["ProcurementOwnerError", "apply_preview", "preview_action", "preview_receipt_action",
           "apply_receipt_preview", "read_receipt_document", "read_action"]


def preview_action_in_transaction(connection: sqlite3.Connection, command, *, enabled_module_ids: Iterable[str] | None = None):
    enabled = _require_module_enabled(enabled_module_ids)
    return _preview_on_connection(connection, command, enabled_module_ids=enabled)


def preview_receipt_action_in_transaction(connection: sqlite3.Connection, command, *, enabled_module_ids: Iterable[str] | None = None):
    enabled = _require_module_enabled(enabled_module_ids)
    return _preview_receipt_on_connection(connection, command, enabled_module_ids=enabled)


def read_action_in_transaction(connection: sqlite3.Connection, action_id: str, *, enabled_module_ids: Iterable[str] | None = None) -> dict[str, Any]:
    _require_module_enabled(enabled_module_ids)
    return _readback(connection, action_id)


def preview_reversal_action(storage: StorageTarget, command: TradeReversalCommand, *, numeric_tools, enabled_module_ids=None) -> TradeReversalPreview:
    enabled = _require_module_enabled(enabled_module_ids)
    with _reading(storage) as connection:
        try:
            return _preview_trade_reversal(connection, MODULE_ID, command, inventory_preview=preview_inventory_in_transaction, inventory_command=InventoryCommand, enabled=enabled, numeric_tools=numeric_tools)
        except TradeRuleError as exc:
            raise ProcurementOwnerError(str(exc), "冲销无法执行：" + str(exc)) from exc


def apply_reversal_preview(storage: StorageTarget, preview: TradeReversalPreview, *, numeric_tools, enabled_module_ids=None) -> dict[str, Any]:
    enabled = _require_module_enabled(enabled_module_ids)
    try:
        with _writing(storage) as connection:
            return _apply_trade_reversal(connection, MODULE_ID, preview, inventory_preview=preview_inventory_in_transaction,
                inventory_apply=apply_inventory_in_transaction, inventory_command=InventoryCommand, enabled=enabled, project_status=_project_order_status, persist=_persist_reversal, numeric_tools=numeric_tools)
    except TradeRuleError as exc:
        raise ProcurementOwnerError(str(exc), "冲销无法执行：" + str(exc)) from exc


def list_reversals(storage: StorageTarget, *, status: str = "", enabled_module_ids=None) -> dict[str, Any]:
    _require_module_enabled(enabled_module_ids)
    with _reading(storage) as connection:
        return {"items": [row for row in _reversal_documents(connection, MODULE_ID) if not status or row["status"] == status]}


def read_reversal(storage: StorageTarget, reversal_id: str, *, enabled_module_ids=None) -> dict[str, Any]:
    for row in list_reversals(storage, enabled_module_ids=enabled_module_ids)["items"]:
        if row["reversal_id"] == reversal_id:
            return row
    raise ProcurementOwnerError("trade_reversal_not_found", reversal_id)


def _persist_reversal(connection, preview, result, receipt, line_changes, order_changes):
    """The original Owner is the only physical writer of its transaction facts."""
    now = result["created_at"]
    if not preview.blockers:
        # Each reversed receipt is a reversed allocation; the line's received total is recomputed from what stays confirmed.
        for target in preview.targets:
            allocation = connection.execute("SELECT id, procurement_id FROM procurement_receipt_allocations WHERE receipt_id=?",
                                            (target["receipt_id"],)).fetchone()
            try:
                receipt_writes.reverse(connection, int(allocation["id"]), line_id=int(allocation["procurement_id"]),
                                       reversed_by="generic", notes=preview.command.reason)
            except receipt_writes.ReceiptWriteError as exc:
                raise ProcurementOwnerError(_receipt_write_code(exc.code), exc.message) from exc
            _refresh_received_quantity(connection, int(allocation["procurement_id"]))
    for order_id, status in order_changes.items():
        materialize(connection, order_id, now=now, status=status)
    connection.execute("INSERT INTO procurement_audit_events(event_id,event_type,payload_json,created_at) VALUES (?,?,?,?)",
        (result["reversal_id"], "trade_reversal_recorded", json.dumps({"preview": preview.to_dict(), "readback": result}, ensure_ascii=False), now))
    connection.execute(f"INSERT INTO procurement_action_receipts ({','.join(receipt)}) VALUES ({','.join('?' for _ in receipt)})", tuple(receipt.values()))


def party_reference_counts(connection: sqlite3.Connection, party_id: int) -> dict[str, int]:
    """只读：本模块有多少张单据指向这个往来方（往来方合并前用来拦）。"""

    return {
        table: int(connection.execute(f"SELECT COUNT(*) FROM {table} WHERE supplier_party_id=?", (int(party_id),)).fetchone()[0])
        for table in ("procurement_batches", "procurement_receipt_documents", "procurement_invoices", "procurement_payments")
    }
