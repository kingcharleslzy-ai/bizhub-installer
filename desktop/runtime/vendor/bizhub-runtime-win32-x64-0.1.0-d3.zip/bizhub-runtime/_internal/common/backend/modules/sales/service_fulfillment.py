"""Non-stock service contracts and acceptance evidence under the sales order owner."""

from __future__ import annotations

import json
import re
import sqlite3
import uuid
from datetime import UTC, datetime
from decimal import Decimal, localcontext

from backend.modules.master_data.public import MasterDataError, get_resource, is_master_data_ref
from backend.modules.trade_core.public import TradeRuleError, business_datetime, decimal_context, decimal_sum, digest_json, strict_money

from . import owner


def service_schema_sql() -> tuple[str, ...]:
    return (
        """CREATE TABLE sales_service_contracts (
            order_id TEXT PRIMARY KEY NOT NULL REFERENCES sales_batches(order_id) ON DELETE RESTRICT,
            currency TEXT NOT NULL)""",
        """CREATE TABLE sales_service_lines (
            sales_order_id INTEGER PRIMARY KEY REFERENCES sales_orders(id) ON DELETE RESTRICT,
            service_name TEXT NOT NULL,
            unit_price TEXT NOT NULL)""",
        """CREATE TABLE sales_service_acceptances (
            acceptance_id TEXT PRIMARY KEY NOT NULL,
            sales_order_id INTEGER NOT NULL REFERENCES sales_service_lines(sales_order_id) ON DELETE RESTRICT,
            quantity INTEGER NOT NULL CHECK(quantity > 0), source_ref TEXT NOT NULL,
            accepted_by TEXT NOT NULL, occurred_at TEXT NOT NULL,
            UNIQUE(sales_order_id, source_ref))""",
    )


def _text(obj, field):
    value = obj.get(field)
    if not isinstance(value, str) or not value.strip():
        raise owner.SalesOwnerError("sales_service_text_required", field)
    return value.strip()


def _quantity(obj):
    quantity = obj.get("quantity")
    if type(quantity) is not int or not 0 < quantity < 10**18:
        raise owner.SalesOwnerError("sales_service_count_invalid", "quantity")
    return quantity


def _command(payload):
    if not isinstance(payload, dict):
        raise owner.SalesOwnerError("sales_service_command_invalid", "expected an object")
    result = {k: _text(payload, k) for k in ("action", "order_id", "idempotency_key", "occurred_at", "source_ref")}
    try:
        business_datetime(result["occurred_at"])
        if result["action"] == "create":
            party = payload.get("customer_party_id")
            currency = _text(payload, "currency")
            if not is_master_data_ref(party) or party > 2**63 - 1 or not re.fullmatch("[A-Z]{3}", currency):
                raise owner.SalesOwnerError("sales_service_contract_identity_invalid", "customer_party_id/currency")
            lines = payload.get("lines")
            if not isinstance(lines, list) or not lines:
                raise owner.SalesOwnerError("sales_service_lines_required", "lines")
            result.update(customer_party_id=party, currency=currency, lines=[])
            for line in lines:
                if not isinstance(line, dict) or set(line) != {"line_id", "service_name", "quantity", "unit_price"}:
                    raise owner.SalesOwnerError("sales_service_line_invalid", "line fields")
                price = strict_money(line["unit_price"], allow_zero=True, invalid_code="sales_service_price_invalid",
                                     range_code="sales_service_price_range", precision_code="sales_service_price_precision")
                result["lines"].append({"line_id": _text(line, "line_id"), "service_name": _text(line, "service_name"),
                                        "quantity": _quantity(line), "unit_price": format(price, ".2f")})
            if len({line["line_id"] for line in result["lines"]}) != len(lines):
                raise owner.SalesOwnerError("sales_service_duplicate_line", result["order_id"])
        elif result["action"] == "accept":
            result.update({k: _text(payload, k) for k in ("line_id", "acceptance_id", "accepted_by")})
            result["quantity"] = _quantity(payload)
        else:
            raise owner.SalesOwnerError("sales_service_action_invalid", result["action"])
    except TradeRuleError as exc:
        raise owner.SalesOwnerError(str(exc), "occurred_at/unit_price") from exc
    if set(payload) != set(result):
        raise owner.SalesOwnerError("sales_service_command_invalid", "unexpected fields")
    return result


def _line_amount(line):
    count, price = Decimal(line["quantity"]), Decimal(line["unit_price"])
    with localcontext(decimal_context((count, price))) as ctx:
        ctx.prec = max(ctx.prec, len(count.as_tuple().digits) + len(price.as_tuple().digits))
        return count * price


def _contract(db, order_id):
    header = db.execute("""SELECT b.order_id, c.currency, b.source_ref, b.ordered_at AS occurred_at, b.status,
                           (SELECT l.customer_party_id FROM sales_orders l WHERE l.batch_id=b.id LIMIT 1) AS customer_party_id
                           FROM sales_service_contracts c JOIN sales_batches b ON b.order_id=c.order_id WHERE c.order_id=?""",
                        (order_id,)).fetchone()
    if header is None:
        raise owner.SalesOwnerError("sales_service_contract_not_found", order_id)
    lines = db.execute("""SELECT l.line_id, s.sales_order_id, s.service_name, s.unit_price, l.quantity_num AS quantity,
                            l.fulfilled_quantity AS accepted_quantity, l.quantity_num-l.fulfilled_quantity AS remaining_quantity
                          FROM sales_service_lines s JOIN sales_orders l ON l.id=s.sales_order_id
                          JOIN sales_batches b ON b.id=l.batch_id WHERE b.order_id=? ORDER BY l.seq_no""", (order_id,))
    acceptances = db.execute("""SELECT a.*, l.line_id FROM sales_service_acceptances a
                                JOIN sales_orders l ON l.id=a.sales_order_id JOIN sales_batches b ON b.id=l.batch_id
                                WHERE b.order_id=? ORDER BY a.occurred_at, a.acceptance_id""", (order_id,))
    items = [{**dict(row), "amount": format(_line_amount(row), ".2f")} for row in lines]
    total = decimal_sum(Decimal(line["amount"]) for line in items)
    return {**dict(header), "lines": items, "total_amount": format(total, ".2f"),
            "acceptances": [dict(row) for row in acceptances]}


def _existing(db, command):
    receipt = db.execute("""SELECT action_id, command_digest, document_kind FROM sales_document_action_receipts
                            WHERE idempotency_key=?""", (command["idempotency_key"],)).fetchone()
    if receipt and (receipt["document_kind"] != "service" or receipt["command_digest"] != digest_json(command)):
        raise owner.SalesOwnerError("sales_idempotency_conflict", command["idempotency_key"])
    return receipt


def _plan(db, command):
    if command["action"] == "create":
        if owner._order(db, command["order_id"]):
            raise owner.SalesOwnerError("sales_order_already_exists", command["order_id"])
        try:
            get_resource(db, "party", command["customer_party_id"])
        except MasterDataError as exc:
            raise owner.SalesOwnerError(exc.code, exc.message) from exc
        for line in command["lines"]:
            if db.execute("SELECT 1 FROM sales_orders WHERE line_id=?", (line["line_id"],)).fetchone():
                raise owner.SalesOwnerError("sales_service_duplicate_line", line["line_id"])
        return {"contract": command["order_id"], "lines": command["lines"]}
    contract = _contract(db, command["order_id"])
    line = next((row for row in contract["lines"] if row["line_id"] == command["line_id"]), None)
    if line is None:
        raise owner.SalesOwnerError("sales_service_line_not_found", command["line_id"])
    if db.execute("""SELECT 1 FROM sales_service_acceptances
                     WHERE acceptance_id=? OR (sales_order_id=? AND source_ref=?)""",
                  (command["acceptance_id"], line["sales_order_id"], command["source_ref"])).fetchone():
        raise owner.SalesOwnerError("sales_service_acceptance_conflict", command["acceptance_id"])
    remaining = line["remaining_quantity"] - command["quantity"]
    if remaining < 0:
        raise owner.SalesOwnerError("sales_service_count_exceeds_remaining", line["line_id"])
    return {"sales_order_id": line["sales_order_id"], "accepted_quantity": line["accepted_quantity"] + command["quantity"],
            "remaining_quantity": remaining, "currency": contract["currency"], "unit_price": line["unit_price"]}


def _preview(db, command):
    receipt = _existing(db, command)
    if receipt:
        row = db.execute("""SELECT a.payload_json FROM sales_audit_events a JOIN sales_document_action_receipts r
                            ON r.audit_event_id=a.event_id WHERE r.action_id=?""", (receipt["action_id"],)).fetchone()
        return json.loads(row[0])["preview"]
    content = {"command": command, "plan": _plan(db, command)}
    return {**content, "preview_digest": digest_json(content)}


def preview_service_action(storage, command, *, enabled_module_ids=None):
    owner._require_module_enabled(enabled_module_ids)
    with owner._reading(storage) as db:
        return _preview(db, _command(command))


def _create(db, cmd, now):
    day = owner._business_date(cmd["occurred_at"])
    batch_id = owner._HEADER_WRITER.materialize(db, None, {
        "order_id": cmd["order_id"], "ordered_at": cmd["occurred_at"], "business_date": day,
        "status": "open", "revision": 1, "evidence_refs_json": json.dumps([cmd["source_ref"]]),
        "source_ref": cmd["source_ref"], "created_at": now, "updated_at": now,
    })
    db.execute("INSERT INTO sales_service_contracts(order_id,currency) VALUES (?,?)", (cmd["order_id"], cmd["currency"]))
    for seq, line in enumerate(cmd["lines"], 1):
        pk = owner._LINE_WRITER.materialize(db, None, {
            "batch_id": batch_id, "seq_no": seq, "line_id": line["line_id"], "customer_party_id": cmd["customer_party_id"],
            "quantity_num": line["quantity"], "business_date": day,
            "fulfilled_quantity": 0, "returned_quantity": 0, "created_at": now,
        })
        db.execute("INSERT INTO sales_service_lines(sales_order_id,service_name,unit_price) VALUES (?,?,?)",
                   (pk, line["service_name"], line["unit_price"]))


def _accept(db, cmd, plan, now):
    db.execute("""INSERT INTO sales_service_acceptances(acceptance_id,sales_order_id,quantity,source_ref,accepted_by,occurred_at)
                  VALUES (?,?,?,?,?,?)""", (cmd["acceptance_id"], plan["sales_order_id"], cmd["quantity"],
                                            cmd["source_ref"], cmd["accepted_by"], cmd["occurred_at"]))
    owner.fulfillment_writes.set_line_quantity(db, line_where=("line_id", cmd["line_id"]), field="fulfilled_quantity",
                                               quantity=plan["accepted_quantity"])
    header = owner._order(db, cmd["order_id"])
    owner.materialize(db, cmd["order_id"], now=now, status=owner._project_order_status(owner._lines(db, cmd["order_id"])),
                      revision=header["revision"] + 1)


def apply_service_preview(storage, preview, *, enabled_module_ids=None):
    owner._require_module_enabled(enabled_module_ids)
    if not isinstance(preview, dict) or set(preview) != {"command", "plan", "preview_digest"}:
        raise owner.SalesOwnerError("sales_preview_content_drift", "complete preview required")
    command = _command(preview["command"])
    with owner._writing(storage) as db:
        authoritative = _preview(db, command)
        if digest_json(preview) != digest_json(authoritative):
            raise owner.SalesOwnerError("sales_preview_content_drift", "service plan differs")
        receipt = _existing(db, command)
        if receipt:
            result = owner._document_readback(db, receipt["action_id"])
            return {**result, "disposition": "idempotent_noop"}
        now = datetime.now(UTC).isoformat()
        if command["action"] == "create":
            _create(db, command, now)
        else:
            _accept(db, command, authoritative["plan"], now)
        action_id, audit_id = uuid.uuid4().hex, uuid.uuid4().hex
        result = {"contract": _contract(db, command["order_id"]), "action_id": action_id, "disposition": "applied"}
        owner.record_audit_event(db, audit_id, "sales_service_" + command["action"],
                                json.dumps({"preview": authoritative, "readback": result}), now)
        owner.record_document_receipt(db, action_id=action_id, idempotency_key=command["idempotency_key"],
                                      command_digest=digest_json(command), preview_digest=authoritative["preview_digest"],
                                      document_kind="service", document_id=command.get("acceptance_id", command["order_id"]),
                                      order_id=command["order_id"], audit_event_id=audit_id, created_at=now)
        return result


def list_services(storage, *, enabled_module_ids=None):
    owner._require_module_enabled(enabled_module_ids)
    with owner._reading(storage) as db:
        ids = db.execute("SELECT order_id FROM sales_service_contracts ORDER BY order_id")
        return {"contracts": [_contract(db, row["order_id"]) for row in ids]}
