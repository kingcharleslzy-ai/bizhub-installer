"""销售正式关系候选的通用读取：只读销售明细、退货单的标准列，企业扩展由企业登记。

读单上下文按记录类型找正式关系候选时调这里；参数由调用方先做有界校验，这里只按标准规则查：

- 销售明细候选：按往来方、产品、规格、业务日（或截至业务日的活跃窗口）收窄，按编号倒序最多 ``limit`` 条；
  企业登记的扩展筛选（规格编号、来源消息、客户 PO、运单、收件人等）一起收窄。
- 退货追溯最近一次销售：同客户、同规格、在退货日或之前、剩余可退数量够这次退货的最近一张销售明细；同一天
  有两张一样新的不猜。已退数量用 :func:`return_origin.returned_quantity` 同一份规则。
- 退货单候选：本来源登记过的退货单优先；没有就按调用方给的来源线程，或原运单对应的销售找。

企业差异只走 :class:`SalesRelationExtension`（同一张物理表上的扩展列、正式可关联范围、扩展筛选和字段）。
没登记扩展的企业只读标准列；扩展参数明确拒绝，不当作没有这项筛选。
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, timedelta
from typing import TYPE_CHECKING, Any, Awaitable, Callable, Mapping

from backend.modules.trade_core.public import TradeRuleError

from .order_schema import SALES_ORDERS
from .return_origin import returned_quantity
from .return_schema import SALES_RETURN_CASES, SALES_RETURN_CASE_ITEMS

if TYPE_CHECKING:
    from sqlalchemy.ext.asyncio import AsyncSession

_STANDARD_ORDER_FILTERS = frozenset({
    "customer_party_id", "product_id", "target_spec", "business_date", "activity_window_days",
    "source_wechat_message_ids",
})

# 各类候选的字段与顺序（标准字段 + 企业登记的扩展字段，取其中有的）。
_ORDER_CANDIDATE = (
    "sales_order_id", "po_number", "shipment_num", "business_date", "customer_party_id", "customer_name",
    "product_id", "product_name", "product_spec_id", "spec", "quantity", "weight_g", "logistics_requirement",
    "own_waybill_nos", "tracking_no", "unit_price", "pricing_input_unit_price", "pricing_unit_price_basis",
    "pricing_invoice_mode", "pricing_tax_rate", "return_cases",
)
_LATEST_CANDIDATE = (
    "relation_subtype", "sales_order_id", "business_date", "sales_business_date", "ship_date",
    "customer_party_id", "customer_name", "product_id", "product_name", "product_spec_id", "spec", "quantity",
    "sold_quantity", "returned_quantity_before", "remaining_quantity_before", "selection_basis",
)
_ORDER_PREVIEW = (
    "id", "business_date", "ship_date", "customer_party_id", "customer_name", "product_id", "product_name",
    "product_spec_id", "spec", "quantity", "logistics_requirement",
)
_CASE_CANDIDATE = (
    "sales_return_case_id", "po_number", "shipment_num", "lifecycle_status", "claimed_weight_g",
    "actual_received_weight_g", "inventory_resolution_status", "financial_adjustment_status",
    "source_relations", "items", "sales_items",
)
_CASE_ITEM = ("item_id", "crystal_id", "item_name", "spec", "quantity", "unit", "claimed_weight_g", "actual_weight_g")


@dataclass(frozen=True)
class SalesRelationExtension:
    """一家企业在标准销售明细、退货单上登记的扩展（列都在同一张物理表上）。

    ``order_columns`` / ``case_columns`` / ``case_item_columns`` 是要多读的扩展列（退货单两类按原列名输出）；
    ``order_scope(filters)`` 给正式可关联范围（如只认正式销售、排除当前来源自己写的）；``order_filter_keys``
    是企业认的扩展参数，``order_filters(filters)`` 把它们变成筛选条件；``order_fields(row)`` 是一条明细的扩展字段；``annotate_orders(db, rows, filters)``
    返回 ``(结果附加, {明细编号: 附加字段})``；``capacity_unit`` 是退货按哪种单位算已退；
    ``external_item_candidates`` 按企业自己的外部物品编号找销售；``cases_by_tracking(tracking_no)`` 给原运单对应
    的退货单编号子查询；``case_sales_items(db, case_ids, external_id, limit)`` 给每张退货单挂的销售物品。
    """

    order_columns: tuple[str, ...] = ()
    order_scope: Callable[[Mapping[str, Any]], list[Any]] | None = None
    order_filter_keys: frozenset[str] = frozenset()
    order_filters: Callable[[Mapping[str, Any]], list[Any]] | None = None
    order_fields: Callable[[Any], Mapping[str, Any]] | None = None
    annotate_orders: Callable[..., Awaitable[tuple[dict[str, Any], dict[int, dict[str, Any]]]]] | None = None
    capacity_unit: str = ""
    external_item_candidates: Callable[..., Awaitable[list[dict[str, Any]]]] | None = None
    case_columns: tuple[str, ...] = ()
    case_item_columns: tuple[str, ...] = ()
    cases_by_tracking: Callable[[str], Any] | None = None
    case_sales_items: Callable[..., Awaitable[dict[int, list[dict[str, Any]]]]] | None = None


_NONE = SalesRelationExtension()


def _ordered(keys: tuple[str, ...], values: Mapping[str, Any]) -> dict[str, Any]:
    return {key: values[key] for key in keys if key in values}


def _missing(feature: str) -> TradeRuleError:
    return TradeRuleError(f"sales_relation_extension_not_registered:{feature}")


def _physical(name: str, standard: Any, extra: tuple[str, ...]) -> list[Any]:
    """物理表上这些列：标准列 + 企业登记的扩展列（类型与物理表定义一致）。"""

    from backend.models.sales import SalesOrder  # noqa: F401  (表定义所在的模型目录)
    from backend.models.sales_return_case import SalesReturnCase, SalesReturnCaseItem  # noqa: F401
    from backend.database import Base

    physical = Base.metadata.tables[name]
    return [physical.c[column.name] for column in standard.columns] + [physical.c[column] for column in extra]


def _order_columns(extension: SalesRelationExtension) -> list[Any]:
    return _physical(SALES_ORDERS.name, SALES_ORDERS, extension.order_columns)


def _order_values(row: Any, extension: SalesRelationExtension) -> dict[str, Any]:
    values = {
        "id": row.id, "sales_order_id": row.id, "business_date": row.business_date, "ship_date": row.ship_date,
        "customer_party_id": row.customer_party_id, "product_id": row.product_id,
        "product_name": row.product_name, "spec": row.spec, "quantity": row.quantity_num,
        "unit_price": row.unit_price,
    }
    return {**values, **(extension.order_fields(row) if extension.order_fields else {})}


def _scoped(query: Any, filters: Mapping[str, Any], extension: SalesRelationExtension) -> Any:
    return query.where(*extension.order_scope(filters)) if extension.order_scope else query


async def read_order_relation_candidates(
    db: AsyncSession, *, filters: Mapping[str, Any], extension: SalesRelationExtension | None = None,
    limit: int,
) -> dict[str, Any]:
    """按已校验的筛选找销售明细候选（见模块说明）；没有任何收窄条件时拒绝。"""

    from sqlalchemy import select

    extension = extension or _NONE
    unknown = sorted(set(filters) - _STANDARD_ORDER_FILTERS - extension.order_filter_keys)
    if unknown:
        raise _missing(unknown[0])
    columns = _order_columns(extension)
    by_name = {column.name: column for column in columns}
    query = _scoped(select(*columns), filters, extension)
    for key in ("customer_party_id", "product_id"):
        if key in filters:
            query = query.where(by_name[key] == filters[key])
    if extension.order_filters:
        query = query.where(*extension.order_filters(filters))
    if "target_spec" in filters:
        query = query.where(by_name["spec"] == filters["target_spec"])
    if "business_date" in filters:
        business_date = filters["business_date"]
        if filters.get("activity_window_days") is not None:
            query = query.where(
                by_name["business_date"] >= business_date - timedelta(days=int(filters["activity_window_days"])),
                by_name["business_date"] <= business_date,
            )
        else:
            query = query.where(by_name["business_date"] == business_date)
    rows = (await db.execute(query.order_by(by_name["id"].desc()).limit(limit))).all()
    if filters.get("source_wechat_message_ids") and "source_wechat_message_id" in by_name:
        # 这一批来源消息已经入过的正式销售明细也摆进候选（不论单号对不对得上），是不是同一笔由模型判断。
        seen = {int(row.id) for row in rows}
        rows = [*rows, *(row for row in (await db.execute(
            _scoped(select(*columns), filters, extension)
            .where(by_name["source_wechat_message_id"].in_(list(filters["source_wechat_message_ids"])))
            .order_by(by_name["id"].desc()).limit(limit))).all() if int(row.id) not in seen)]
    extra, per_row = (
        await extension.annotate_orders(db, rows, filters) if extension.annotate_orders else ({}, {})
    )
    # 每条明细挂着的退货单和它的钱怎么处理的（补货/换货按原发货认退货、定价时用）。
    return_cases: dict[int, list[dict[str, Any]]] = {}
    if rows:
        from backend.models.sales_return_case import SalesReturnCase, SalesReturnCaseOrderLink

        for order_id, case_id, financial in (await db.execute(
            select(SalesReturnCaseOrderLink.sales_order_id, SalesReturnCase.id,
                   SalesReturnCase.financial_adjustment_status)
            .join(SalesReturnCase, SalesReturnCase.id == SalesReturnCaseOrderLink.sales_return_case_id)
            .where(SalesReturnCaseOrderLink.sales_order_id.in_([int(row.id) for row in rows]))
            .order_by(SalesReturnCase.id)
        )).all():
            return_cases.setdefault(int(order_id), []).append(
                {"sales_return_case_id": int(case_id), "financial_adjustment_status": financial})
    return {
        "relation_type": "sales_order",
        **extra,
        "candidates": [
            _ordered(_ORDER_CANDIDATE, {**_order_values(row, extension), **per_row.get(int(row.id), {}),
                                        "return_cases": return_cases.get(int(row.id), [])})
            for row in rows
        ],
    }


async def read_latest_capacity_sale(
    db: AsyncSession, *, customer_party_id: int, spec: str, on_or_before: date, returned_quantity_now: int,
    filters: Mapping[str, Any], extension: SalesRelationExtension | None = None,
) -> dict[str, Any]:
    """退货追溯的最近一次销售（同客户同规格、退货日或之前、剩余可退够这次退货）；同一天两张一样新的不猜。"""

    from sqlalchemy import func, select

    extension = extension or _NONE
    if not extension.capacity_unit:
        raise _missing("capacity_unit")
    columns = _order_columns(extension)
    by_name = {column.name: column for column in columns}
    unit = extension.capacity_unit
    effective = func.coalesce(by_name["ship_date"], by_name["business_date"])
    already = returned_quantity(by_name["id"], unit=unit).correlate(by_name["id"].table)
    query = _scoped(select(*columns), filters, extension).where(
        by_name["customer_party_id"] == customer_party_id,
        by_name["spec"] == spec,
        effective <= on_or_before,
        by_name["quantity_num"].is_not(None),
        by_name["quantity_num"] >= already + returned_quantity_now,
    )
    rows = (await db.execute(query.order_by(effective.desc(), by_name["id"].desc()).limit(2))).all()
    result: dict[str, Any] = {"relation_type": "sales_order", "relation_subtype": "latest_customer_spec_sale"}
    if not rows:
        return {**result, "candidates": [], "empty_reason": "latest_capacity_valid_sale_not_found"}
    if len(rows) > 1 and (rows[1].ship_date or rows[1].business_date) == (rows[0].ship_date or rows[0].business_date):
        return {**result, "candidates": [], "empty_reason": "latest_capacity_valid_sale_not_unique"}
    order = rows[0]
    returned_before = int(await db.scalar(select(returned_quantity(int(order.id), unit=unit))) or 0)
    sold = int(order.quantity_num or 0)
    values = {
        **_order_values(order, extension),
        "relation_subtype": "latest_customer_spec_sale",
        "business_date": order.ship_date or order.business_date,
        "sales_business_date": order.business_date,
        "sold_quantity": sold,
        "returned_quantity_before": returned_before,
        "remaining_quantity_before": sold - returned_before,
        "selection_basis": "latest_customer_spec_sale_on_or_before_return",
    }
    return {**result, "candidates": [_ordered(_LATEST_CANDIDATE, values)]}


async def read_order_by_external_item(
    db: AsyncSession, *, filters: Mapping[str, Any], extension: SalesRelationExtension | None = None, limit: int,
) -> dict[str, Any]:
    """按企业自己的外部物品编号（如客户发货编号）找销售；没登记这项扩展明确拒绝。"""

    extension = extension or _NONE
    if extension.external_item_candidates is None:
        raise _missing("external_crystal_id")
    return {
        "relation_type": "sales_order",
        "relation_subtype": "customer_external_crystal_id",
        "candidates": await extension.external_item_candidates(db, filters=filters, limit=limit),
    }


async def read_order_preview(
    db: AsyncSession, *, order_id: int, extension: SalesRelationExtension | None = None,
) -> dict[str, Any] | None:
    """负责人预览用的一条销售明细（标准字段 + 登记的扩展字段）；没有返回空。"""

    from sqlalchemy import select

    extension = extension or _NONE
    columns = _order_columns(extension)
    row = (await db.execute(select(*columns).where(columns[0] == int(order_id)))).first()
    return _ordered(_ORDER_PREVIEW, _order_values(row, extension)) if row is not None else None


def plan_settled(due_date: date | None, settled_before: date | None) -> bool:
    """计划交期早于计划结清日的算已结清：不再出少发、逾期提醒。结清日是企业配置，没配就都不结清。"""

    return due_date is not None and settled_before is not None and due_date < settled_before


async def read_return_case_candidates(
    db: AsyncSession, *, source_channel: str, source_id: str, thread_source_ids: list[str],
    tracking_no: str | None, po_number: str | None, external_id: str | None,
    extension: SalesRelationExtension | None = None, limit: int,
) -> dict[str, Any]:
    """一条来源能挂的退货单候选（见模块说明），按更新时间倒序最多 ``limit`` 张。"""

    from sqlalchemy import select

    from backend.database import Base

    extension = extension or _NONE
    sources = Base.metadata.tables["sales_return_case_sources"]
    exact_ids = list(dict.fromkeys(int(value) for value in (await db.execute(
        select(sources.c.sales_return_case_id)
        .where(sources.c.source_channel == source_channel, sources.c.source_id == source_id)
        .distinct().order_by(sources.c.sales_return_case_id).limit(limit + 1)
    )).scalars()))
    case_columns = _physical(SALES_RETURN_CASES.name, SALES_RETURN_CASES, extension.case_columns)
    case_by_name = {column.name: column for column in case_columns}
    if exact_ids:
        scope, subtype = case_by_name["id"].in_(exact_ids), "exact_registered_source"
    else:
        subtype = "mail_thread_source"
        scope = case_by_name["id"].in_(select(sources.c.sales_return_case_id).where(
            sources.c.source_channel == source_channel, sources.c.source_id.in_(thread_source_ids)))
        if tracking_no is not None:
            if extension.cases_by_tracking is None:
                raise _missing("tracking_no")
            scope, subtype = case_by_name["id"].in_(extension.cases_by_tracking(tracking_no)), "original_waybill_sales_batch"
    query = select(*case_columns).where(scope)
    if po_number and not exact_ids:
        query = query.where(case_by_name["po_number"] == po_number)
    cases = (await db.execute(
        query.order_by(case_by_name["updated_at"].desc(), case_by_name["id"].desc()).limit(limit)
    )).all()
    case_ids = [int(row.id) for row in cases]
    sources_by_case: dict[int, list[Any]] = {case_id: [] for case_id in case_ids}
    items_by_case: dict[int, list[Any]] = {case_id: [] for case_id in case_ids}
    sales_items: dict[int, list[dict[str, Any]]] = {case_id: [] for case_id in case_ids}
    if case_ids:
        for row in (await db.execute(select(sources).where(
                sources.c.sales_return_case_id.in_(case_ids)).order_by(sources.c.id))).all():
            sources_by_case[int(row.sales_return_case_id)].append(row)
        item_columns = _physical(SALES_RETURN_CASE_ITEMS.name, SALES_RETURN_CASE_ITEMS, extension.case_item_columns)
        for row in (await db.execute(select(*item_columns).where(
                item_columns[1].in_(case_ids)).order_by(item_columns[0]))).all():
            items_by_case[int(row.sales_return_case_id)].append(row)
        if extension.case_sales_items is not None:
            sales_items.update(await extension.case_sales_items(
                db, case_ids=case_ids, external_id=external_id, limit=limit))
    return {
        "relation_type": "sales_return_case",
        "relation_subtype": subtype,
        "candidates": [
            _ordered(_CASE_CANDIDATE, {
                **{name: getattr(row, name) for name in extension.case_columns},
                "sales_return_case_id": row.id, "po_number": row.po_number, "shipment_num": row.shipment_num,
                "lifecycle_status": row.lifecycle_status,
                "inventory_resolution_status": row.inventory_resolution_status,
                "financial_adjustment_status": row.financial_adjustment_status,
                "source_relations": [
                    {
                        "source_channel": source.source_channel, "source_id": source.source_id,
                        "source_role": source.source_role,
                        "matches_current_source": (
                            source.source_channel == source_channel and source.source_id == source_id
                        ),
                    }
                    for source in sources_by_case[int(row.id)][:limit]
                ],
                "items": [
                    _ordered(_CASE_ITEM, {
                        **{name: getattr(item, name) for name in extension.case_item_columns},
                        "item_id": item.id, "item_name": item.item_name, "spec": item.spec,
                        "quantity": item.claimed_quantity, "unit": item.claimed_unit,
                    })
                    for item in items_by_case[int(row.id)][:limit]
                ],
                "sales_items": sales_items.get(int(row.id), []),
            })
            for row in cases
        ],
    }


__all__ = [
    "SalesRelationExtension",
    "read_latest_capacity_sale",
    "read_order_by_external_item",
    "read_order_preview",
    "read_order_relation_candidates",
    "read_return_case_candidates",
    "plan_settled",
]
