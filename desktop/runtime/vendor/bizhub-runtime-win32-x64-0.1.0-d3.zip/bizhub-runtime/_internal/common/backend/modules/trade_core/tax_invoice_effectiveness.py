"""Shared eligibility contract for current, effective tax-office invoices."""

from __future__ import annotations

from decimal import Decimal, InvalidOperation
from typing import Any


INEFFECTIVE_TAX_INVOICE_STATUS_TOKENS = ("作废", "红冲", "异常", "失控", "CHARGE_OFF")
INEFFECTIVE_TAX_INVOICE_RISK_TOKENS = ("异常", "风险", "失控")


def tax_invoice_is_effective(invoice: Any, *, direction: str | None = None) -> bool:
    """Return whether a tax-office invoice can participate in formal matching."""

    try:
        total_amount = Decimal(str(invoice.total_amount or 0))
    except (InvalidOperation, TypeError, ValueError):
        return False
    status = str(invoice.invoice_status or "").upper()
    risk = str(invoice.risk_level or "")
    return (
        (direction is None or str(invoice.direction or "") == direction)
        and str(invoice.positive_flag or "") == "positive"
        and total_amount > 0
        and not any(
            token in status for token in INEFFECTIVE_TAX_INVOICE_STATUS_TOKENS
        )
        and not any(token in risk for token in INEFFECTIVE_TAX_INVOICE_RISK_TOKENS)
    )
