"""Single writer for the generic master-data catalog (standard tables)."""

from __future__ import annotations

from backend.kernel.profile_registry import StorageTarget, read_storage, storage_connect, write_storage

import json
import sqlite3
from pathlib import Path
from typing import Any, Iterable

from .contracts import (
    DRAFT_ATTRIBUTES,
    RESOURCE_KINDS,
    CatalogDraft,
    CatalogPreview,
    digest_json,
    storage_timestamp,
)
from .matching import normalize_identity
from .public import (
    EXTERNAL_IDENTITIES_TABLE,
    MasterDataError,
    get_resource,
    has_external_identities,
    resolve_external_identity,
)


MODULE_ID = "master_data"
OWNER_REF = f"{MODULE_ID}:catalog-owner"
_STATE_TABLES = ("business_parties", "products", "measurement_units", "locations")


def _require_module_enabled(enabled_module_ids: Iterable[str] | None) -> None:
    if enabled_module_ids is None:
        from backend.generic_kernel.profile import get_generic_registry

        enabled_module_ids = [
            str(item["module_id"])
            for item in get_generic_registry().payload.get("modules", [])
        ]
    if MODULE_ID not in set(enabled_module_ids):
        raise MasterDataError("master_data_module_disabled", f"{MODULE_ID} is not enabled")


def _connect(path: Path, *, readonly: bool) -> sqlite3.Connection:
    connection = storage_connect(f"file:{path}?mode=ro" if readonly else path, uri=readonly)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys=ON")
    connection.execute("PRAGMA busy_timeout=10000")
    if readonly:
        connection.execute("PRAGMA query_only=ON")
    return connection


def _reading(storage: StorageTarget):
    return read_storage(storage, lambda path: _connect(path, readonly=True))


def _writing(storage: StorageTarget):
    return write_storage(storage, lambda path: _connect(path, readonly=False))


def _state_generation(connection: sqlite3.Connection) -> str:
    tables = (*_STATE_TABLES, *((EXTERNAL_IDENTITIES_TABLE,) if has_external_identities(connection) else ()))
    payload = {
        table: [dict(row) for row in connection.execute(f"SELECT * FROM {table} ORDER BY 1")]
        for table in tables
    }
    return digest_json(payload)


def _validate_drafts(items: tuple[CatalogDraft, ...]) -> None:
    names: set[tuple[str, str]] = set()
    codes: set[str] = set()
    locations: set[str] = set()
    externals: set[tuple[str, str, str]] = set()
    for item in items:
        if item.resource_kind not in RESOURCE_KINDS:
            raise MasterDataError("master_data_resource_kind_invalid", item.resource_kind)
        if not item.canonical_name.strip():
            raise MasterDataError("master_data_identity_invalid", item.resource_kind)
        attributes = dict(item.attributes or {})
        if item.resource_kind == "location":
            if not item.location_id.strip():
                raise MasterDataError("master_data_identity_invalid", "location requires location_id")
            if item.location_id in locations:
                raise MasterDataError("master_data_identity_duplicate", item.location_id)
            locations.add(item.location_id)
        else:
            if item.location_id:
                raise MasterDataError("master_data_identity_invalid", f"{item.resource_kind} id is assigned by storage")
            unknown = sorted(set(attributes) - DRAFT_ATTRIBUTES[item.resource_kind])
            if unknown:
                raise MasterDataError("master_data_attribute_unknown", f"{item.resource_kind}:{unknown}")
            if item.resource_kind == "unit":
                code = str(attributes.get("code") or "").strip()
                if not code:
                    raise MasterDataError("master_data_identity_invalid", "unit requires attributes.code")
                if code in codes:
                    raise MasterDataError("master_data_identity_duplicate", f"unit:{code}")
                codes.add(code)
        name = (item.resource_kind, normalize_identity(item.canonical_name))
        if name in names:
            raise MasterDataError("master_data_name_conflict", repr(name))
        names.add(name)
        if bool(item.source_id) != bool(item.external_id):
            raise MasterDataError("master_data_external_identity_incomplete", item.canonical_name)
        if item.alias and not item.source_id:
            raise MasterDataError("master_data_alias_identity_required", "alias requires source_id and external_id")
        if item.source_id:
            external = (item.resource_kind, item.source_id, item.external_id)
            if external in externals:
                raise MasterDataError("master_data_external_identity_duplicate", repr(external))
            externals.add(external)


def preview_catalog(
    storage: StorageTarget,
    drafts: Iterable[CatalogDraft],
    *,
    enabled_module_ids: Iterable[str] | None = None,
) -> CatalogPreview:
    _require_module_enabled(enabled_module_ids)
    items = tuple(drafts)
    _validate_drafts(items)
    with _reading(storage) as connection:
        if any(item.source_id for item in items) and not has_external_identities(connection):
            raise MasterDataError(
                "master_data_external_identity_unsupported",
                "this storage has no external identity mapping",
            )
        generation = _state_generation(connection)
    body = {"state_generation": generation, "drafts": [item.to_dict() for item in items]}
    return CatalogPreview(generation, items, digest_json(body))


def _find(connection: sqlite3.Connection, item: CatalogDraft) -> dict[str, Any] | None:
    """按身份找已有的一条：往来方、产品按正式名称，单位按编码，库位按编号。"""

    if item.resource_kind == "location":
        row = connection.execute(
            "SELECT key FROM locations WHERE key=?", (item.location_id,)
        ).fetchone()
        return None if row is None else get_resource(connection, "location", item.location_id, require_active=False)
    if item.resource_kind == "unit":
        row = connection.execute(
            "SELECT id FROM measurement_units WHERE canonical_code=?",
            (str((item.attributes or {}).get("code") or "").strip(),),
        ).fetchone()
    else:
        table = "business_parties" if item.resource_kind == "party" else "products"
        row = connection.execute(f"SELECT id FROM {table} WHERE canonical_name=?", (item.canonical_name,)).fetchone()
    return None if row is None else get_resource(connection, item.resource_kind, int(row["id"]), require_active=False)


def _same_as_draft(resource: dict[str, Any], item: CatalogDraft) -> bool:
    if resource["canonical_name"] != item.canonical_name or resource["status"] != "active":
        return False
    attributes = dict(item.attributes or {})
    if item.resource_kind == "location":
        return resource["attributes"] == attributes
    expected = {
        "party": {"legal_name": str(attributes.get("legal_name") or "")},
        "product": {"product_family": str(attributes.get("product_family") or "")},
        "unit": {
            "code": str(attributes.get("code") or "").strip(),
            "dimension": str(attributes.get("dimension") or ""),
            "factor_to_base": None if attributes.get("factor_to_base") is None else str(attributes["factor_to_base"]),
        },
    }[item.resource_kind]
    return all(resource.get(key) == value for key, value in expected.items())


def _present(connection: sqlite3.Connection, items: tuple[CatalogDraft, ...]) -> bool:
    """这一批是否已原样存在（同一份新建做第二次时零变化）。"""

    for item in items:
        resource = _find(connection, item)
        if resource is None or not _same_as_draft(resource, item):
            return False
        if item.source_id:
            try:
                resolved = resolve_external_identity(
                    connection,
                    resource_kind=item.resource_kind,
                    source_id=item.source_id,
                    external_id=item.external_id,
                )
            except MasterDataError:
                return False
            if resolved["resource_id"] != resource["resource_id"] or resolved["external_identity"]["alias"] != item.alias:
                return False
    return True


def _readback_catalog(connection: sqlite3.Connection, preview: CatalogPreview) -> dict[str, object]:
    resources: list[dict[str, object]] = []
    external_mappings: list[dict[str, object]] = []
    for item in preview.drafts:
        resource = _find(connection, item)
        if resource is None or not _same_as_draft(resource, item):
            raise MasterDataError("master_data_readback_drift", f"{item.resource_kind}:{item.canonical_name}")
        resources.append(
            {
                "resource_kind": item.resource_kind,
                "resource_id": resource["resource_id"],
                "canonical_name": str(resource["canonical_name"]),
            }
        )
        if item.source_id:
            resolved = resolve_external_identity(
                connection,
                resource_kind=item.resource_kind,
                source_id=item.source_id,
                external_id=item.external_id,
            )
            if resolved["resource_id"] != resource["resource_id"]:
                raise MasterDataError(
                    "master_data_readback_drift",
                    f"{item.resource_kind}:{item.source_id}:{item.external_id}",
                )
            external_mappings.append(
                {
                    "resource_kind": item.resource_kind,
                    "source_id": item.source_id,
                    "external_id": item.external_id,
                    "resource_id": resource["resource_id"],
                    "alias": item.alias,
                }
            )
    return {
        "schema_version": "bizhub.master-data-catalog-readback.v2",
        "owner_ref": OWNER_REF,
        "preview_digest": preview.preview_digest,
        "resources": resources,
        "external_mappings": external_mappings,
        "state_generation": _state_generation(connection),
    }


def _conflict(connection: sqlite3.Connection, item: CatalogDraft) -> str | None:
    """名称归一后撞名（如只差大小写、空格），或编码 / 编号已被占用。"""

    if _find(connection, item) is not None:
        return f"{item.resource_kind}:{item.canonical_name}"
    normalized = normalize_identity(item.canonical_name)
    if item.resource_kind == "location":
        rows = connection.execute("SELECT normalized_name AS name FROM locations").fetchall()
        taken = {str(row["name"]) for row in rows}
    else:
        table, column = {
            "party": ("business_parties", "canonical_name"),
            "product": ("products", "canonical_name"),
            "unit": ("measurement_units", "display_name"),
        }[item.resource_kind]
        taken = {normalize_identity(row[0]) for row in connection.execute(f"SELECT {column} FROM {table}")}
    return f"{item.resource_kind}:{item.canonical_name}" if normalized in taken else None


def _insert(connection: sqlite3.Connection, item: CatalogDraft, now: str) -> object:
    attributes = dict(item.attributes or {})
    if item.resource_kind == "location":
        connection.execute(
            """INSERT INTO locations
               (key, display_name, item_kind, usage, counts_in_total, available_for_sale, sort_order, status,
                normalized_name, attributes_json)
               VALUES (?, ?, 'product', 'internal', 1, 1, 0, 'active', ?, ?)""",
            (
                item.location_id,
                item.canonical_name,
                normalize_identity(item.canonical_name),
                json.dumps(attributes, ensure_ascii=False, sort_keys=True, separators=(",", ":")),
            ),
        )
        return item.location_id
    if item.resource_kind == "party":
        cursor = connection.execute(
            """INSERT INTO business_parties
               (canonical_name, legal_name, status, successor_party_id, created_at, updated_at)
               VALUES (?, ?, 'active', NULL, ?, ?)""",
            (item.canonical_name, str(attributes.get("legal_name") or ""), now, now),
        )
    elif item.resource_kind == "product":
        cursor = connection.execute(
            """INSERT INTO products
               (canonical_name, product_family, status, successor_product_id, created_at, updated_at)
               VALUES (?, ?, 'active', NULL, ?, ?)""",
            (item.canonical_name, str(attributes.get("product_family") or ""), now, now),
        )
    else:
        factor = attributes.get("factor_to_base")
        cursor = connection.execute(
            """INSERT INTO measurement_units
               (canonical_code, display_name, dimension, factor_to_base, status, created_at, updated_at)
               VALUES (?, ?, ?, ?, 'active', ?, ?)""",
            (
                str(attributes["code"]).strip(),
                item.canonical_name,
                str(attributes.get("dimension") or ""),
                None if factor is None else str(factor),
                now,
                now,
            ),
        )
    return int(cursor.lastrowid)


def apply_catalog(
    storage: StorageTarget,
    preview: CatalogPreview,
    *,
    enabled_module_ids: Iterable[str] | None = None,
) -> dict[str, object]:
    _require_module_enabled(enabled_module_ids)
    expected = digest_json({
        "state_generation": preview.state_generation,
        "drafts": [item.to_dict() for item in preview.drafts],
    })
    if expected != preview.preview_digest:
        raise MasterDataError("master_data_preview_content_drift", "preview digest differs")
    with _reading(storage) as read_connection:
        if _present(read_connection, preview.drafts):
            result = _readback_catalog(read_connection, preview)
            result["disposition"] = "idempotent_noop"
            return result
    authoritative = preview_catalog(
        storage,
        preview.drafts,
        enabled_module_ids=enabled_module_ids,
    )
    if authoritative.preview_digest != preview.preview_digest:
        raise MasterDataError(
            "master_data_state_generation_drift",
            "catalog changed since preview",
        )
    preview = authoritative

    def write(connection: sqlite3.Connection) -> tuple[dict[str, object], list[dict[str, object]]] | None:
        if _present(connection, preview.drafts):
            return None
        if _state_generation(connection) != preview.state_generation:
            raise MasterDataError("master_data_state_generation_drift", "catalog changed")
        now = storage_timestamp()
        created: list[dict[str, object]] = []
        for item in preview.drafts:
            conflict = _conflict(connection, item)
            if conflict is not None:
                raise MasterDataError("master_data_catalog_conflict", conflict)
            resource_id = _insert(connection, item, now)
            if item.source_id:
                connection.execute(
                    """INSERT INTO master_data_external_identities
                       (resource_kind, source_id, external_id, resource_id, alias, normalized_alias, status)
                       VALUES (?, ?, ?, ?, ?, ?, 'active')""",
                    (
                        item.resource_kind,
                        item.source_id,
                        item.external_id,
                        str(resource_id),
                        item.alias,
                        normalize_identity(item.alias),
                    ),
                )
            created.append({"resource_kind": item.resource_kind, "resource_id": resource_id})
        return _readback_catalog(connection, preview), created

    try:
        with _writing(storage) as connection:
            applied = write(connection)
    except sqlite3.IntegrityError as exc:
        raise MasterDataError("master_data_catalog_conflict", str(exc)) from exc
    if applied is None:
        with _reading(storage) as read_connection:
            result = _readback_catalog(read_connection, preview)
            result["disposition"] = "idempotent_noop"
            return result
    result, created = applied
    result["created"] = created
    result["disposition"] = "applied"
    return result


__all__ = ["apply_catalog", "preview_catalog"]
