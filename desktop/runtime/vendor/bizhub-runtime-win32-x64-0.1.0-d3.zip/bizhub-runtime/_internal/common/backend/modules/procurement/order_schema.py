"""采购单标准表：一张单头 + 多行明细。

和库存标准表同一套做法（``inventory.location_schema``）：这里是唯一定义，取的是首家客户生产库现在的形状
（表名沿用它的 ``procurement_batches`` / ``procurements``）。客户库里的同名表必须等于“标准表 + 该客户登记的
扩展”，由一致性检查逐项核对。

- 单头：业务日期、供应方、状态（open 未到货 / partially_received 部分到货 / received 已到货 / cancelled 作废）、备注。
- 明细：货品（产品主数据可空；首家客户的物料另有品目表，用它自己的扩展列引用）、品名、数量与单位、
  单价与金额、是否含税、各日期、开票预期（unknown / expected / not_available）。
- 明细的单头引用在迁移第 7.1 步先允许为空（历史明细补上单头后再收紧为必填）。
"""

from __future__ import annotations

from backend.modules.master_data.schema import Check, Column, ForeignKey, Index, Table, create_table_sql

ORDER_STATUSES = ("open", "partially_received", "received", "cancelled")
INVOICE_EXPECTATIONS = ("unknown", "expected", "not_available")
BATCHES = "procurement_batches"
LINES = "procurements"


def _c(name: str, type_: str, *, nullable: bool = False, default: str | None = None) -> Column:
    return Column(name, type_, nullable, default)


PROCUREMENT_BATCHES = Table(
    BATCHES,
    (
        _c("id", "INTEGER"),
        _c("business_date", "DATE", nullable=True),
        _c("supplier_party_id", "INTEGER", nullable=True),
        _c("status", "VARCHAR(30)", default="open"),
        _c("notes", "TEXT", nullable=True),
        _c("created_at", "DATETIME"),
    ),
    checks=(Check("ck_procurement_batches_status", "status", ORDER_STATUSES),),
    foreign_keys=(ForeignKey("supplier_party_id", "business_parties", "id", "SET NULL"),),
)

PROCUREMENTS = Table(
    LINES,
    (
        _c("id", "INTEGER"),
        _c("batch_id", "INTEGER"),
        _c("product_id", "INTEGER", nullable=True),
        _c("item_name", "VARCHAR(200)"),
        _c("quantity", "NUMERIC", nullable=True),
        _c("quantity_unit_id", "INTEGER", nullable=True),
        _c("unit_price", "NUMERIC", nullable=True),
        _c("total_amount", "NUMERIC", nullable=True),
        _c("is_taxed", "BOOLEAN"),
        _c("business_date", "DATE", nullable=True),
        _c("purchase_date", "DATE", nullable=True),
        _c("goods_received_date", "DATE", nullable=True),
        _c("invoice_date", "DATE", nullable=True),
        _c("invoice_expectation", "VARCHAR(30)", default="unknown"),
        _c("invoice_expectation_note", "TEXT", default=""),
        _c("notes", "TEXT", nullable=True),
        _c("created_at", "DATETIME"),
    ),
    checks=(Check("ck_procurements_invoice_expectation", "invoice_expectation", INVOICE_EXPECTATIONS),),
    foreign_keys=(
        ForeignKey("batch_id", BATCHES, "id", "NO ACTION"),
        ForeignKey("product_id", "products", "id", "RESTRICT"),
        ForeignKey("quantity_unit_id", "measurement_units", "id", "SET NULL"),
    ),
    indexes=(Index("ix_procurements_invoice_expectation", ("invoice_expectation",)),),
)

ORDER_STANDARD_TABLES: tuple[Table, ...] = (PROCUREMENT_BATCHES, PROCUREMENTS)


def order_schema_sql() -> tuple[str, ...]:
    return tuple(statement for table in ORDER_STANDARD_TABLES for statement in create_table_sql(table))


__all__ = [
    "BATCHES",
    "INVOICE_EXPECTATIONS",
    "LINES",
    "ORDER_STANDARD_TABLES",
    "ORDER_STATUSES",
    "PROCUREMENTS",
    "PROCUREMENT_BATCHES",
    "order_schema_sql",
]
