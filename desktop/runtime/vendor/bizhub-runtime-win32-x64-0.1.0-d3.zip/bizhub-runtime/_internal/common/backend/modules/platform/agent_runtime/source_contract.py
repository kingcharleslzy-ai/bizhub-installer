"""Pure, hash-stable source contracts shared by installed runtimes."""
from __future__ import annotations
from copy import deepcopy
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
from typing import Any, Iterable

SOURCE_MANIFEST_VERSION = "business_agent_source_manifest.v1"


SOURCE_IDENTITY_HASH_VERSION = "business_agent_source_identity_hash.v2"


SEMANTIC_CLUSTER_VERSION = "business_agent_semantic_cluster.v1"


SOURCE_WINDOW_VERSION = "business_agent_source_window.v1"


PRIOR_CONTEXT_VERSION = "business_agent_prior_context.v1"


DEFAULT_TEXT_PART_CHARS = 6_000


DEFAULT_WINDOW_TEXT_CHARS = 12_000


DEFAULT_WINDOW_IMAGES = 5


DEFAULT_WINDOW_SOURCES = 32


BUSINESS_BURST_WINDOW_TEXT_CHARS = 48_000


SEMANTIC_EPISODE_GAP_SECONDS = 5 * 60


class SourceManifestError(ValueError):
    """A missing/duplicated source part is a technical failure, not Review."""


def persisted_manifest_source_hashes_v2(
    payload: dict[str, Any],
    *,
    source_refs: Iterable[str] | None = None,
) -> dict[str, str]:
    """Recompute v2 source identities from an immutable persisted manifest.

    This is intentionally read-only: old SourceCluster/member rows remain
    immutable provenance.  The complete persisted manifest already contains
    ordered source metadata, part hashes and text, so a newer truth gate can
    derive the current identity contract without replaying a model or reading
    mutable live files.
    """

    sources = [item for item in payload.get("sources") or [] if isinstance(item, dict)]
    parts = [item for item in payload.get("parts") or [] if isinstance(item, dict)]
    requested = (
        {str(item) for item in source_refs}
        if source_refs is not None
        else {str(item.get("source_ref") or "") for item in sources}
    )
    source_index = {
        str(item.get("source_ref") or ""): item
        for item in sources
        if str(item.get("source_ref") or "")
    }
    if not requested or not requested.issubset(source_index):
        raise SourceManifestError("persisted_manifest_source_coverage_missing")
    part_index = {
        str(item.get("part_ref") or ""): item
        for item in parts
        if str(item.get("part_ref") or "")
    }
    output: dict[str, str] = {}
    for source_ref in sorted(requested):
        raw_source = source_index[source_ref]
        source = {
            key: value
            for key, value in raw_source.items()
            if key != "ordinal"
        }
        identity_parts: list[dict[str, Any]] = []
        for part_ref in raw_source.get("part_refs") or []:
            raw_part = part_index.get(str(part_ref))
            if raw_part is None or str(raw_part.get("source_ref") or "") != source_ref:
                raise SourceManifestError("persisted_manifest_part_coverage_missing")
            metadata = raw_part.get("metadata") or {}
            identity_parts.append(
                {
                    **{
                        key: value
                        for key, value in raw_part.items()
                        if key not in {"local_path", "text", "metadata"}
                    },
                    "metadata": {
                        key: value
                        for key, value in metadata.items()
                        if not _location_only_metadata_key(key)
                    },
                    "text": raw_part.get("text"),
                }
            )
        output[source_ref] = _digest(
            {
                "hash_version": SOURCE_IDENTITY_HASH_VERSION,
                "source": source,
                "parts": identity_parts,
            }
        )
    return output


def stable_json(value: Any) -> str:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )


def _digest(value: Any) -> str:
    return hashlib.sha256(stable_json(value).encode("utf-8")).hexdigest()


def _clean_text(value: Any) -> str:
    return str(value or "").replace("\x00", "").strip()


def _chunk_text(text: str, *, max_chars: int) -> list[str]:
    value = _clean_text(text)
    if not value:
        return []
    limit = max(500, int(max_chars))
    chunks: list[str] = []
    cursor = 0
    while cursor < len(value):
        end = min(len(value), cursor + limit)
        if end < len(value):
            candidates = [
                value.rfind("\n", cursor, end),
                value.rfind("。", cursor, end),
                value.rfind(";", cursor, end),
                value.rfind("；", cursor, end),
            ]
            boundary = max(candidates)
            if boundary >= cursor + limit // 2:
                end = boundary + 1
        chunk = value[cursor:end].strip()
        if chunk:
            chunks.append(chunk)
        cursor = end
    return chunks


@dataclass(frozen=True)
class SourcePartV1:
    part_ref: str
    source_ref: str
    ordinal: int
    kind: str
    role: str
    text: str | None
    local_path: str | None
    sha256: str
    size_bytes: int
    mime_type: str | None
    status: str
    metadata: dict[str, Any]

    @property
    def is_image(self) -> bool:
        return self.kind == "image" and self.status == "available"

    @property
    def prompt_text(self) -> str | None:
        if self.metadata.get("prompt_visible") is False:
            return None
        return self.text

    def to_manifest_payload(self) -> dict[str, Any]:
        return {
            "part_ref": self.part_ref,
            "source_ref": self.source_ref,
            "ordinal": self.ordinal,
            "kind": self.kind,
            "role": self.role,
            "sha256": self.sha256,
            "size_bytes": self.size_bytes,
            "mime_type": self.mime_type,
            "status": self.status,
            "metadata": self.metadata,
        }

    def to_identity_payload(self) -> dict[str, Any]:
        """Return content identity without host- or bundle-local locations."""

        payload = self.to_manifest_payload()
        payload["metadata"] = {
            key: value
            for key, value in self.metadata.items()
            if not _location_only_metadata_key(key)
        }
        return payload

    def to_prompt_payload(self, *, image_order: int | None = None) -> dict[str, Any]:
        payload = self.to_manifest_payload()
        if self.prompt_text is not None:
            payload["text"] = self.prompt_text
        if image_order is not None:
            payload["image_ref"] = f"input_image_{image_order}"
            payload["image_order"] = image_order
        return payload


@dataclass(frozen=True)
class SourceEventV1:
    source_ref: str
    source_kind: str
    ordinal: int
    sender: str | None
    occurred_at: str | None
    context: dict[str, Any]
    part_refs: tuple[str, ...]

    def to_payload(self) -> dict[str, Any]:
        return {
            "source_ref": self.source_ref,
            "source_kind": self.source_kind,
            "ordinal": self.ordinal,
            "sender": self.sender,
            "occurred_at": self.occurred_at,
            "context": self.context,
            "part_refs": list(self.part_refs),
        }

    def to_identity_payload(self) -> dict[str, Any]:
        """Return source identity without its position inside one cluster.

        ``ordinal`` belongs to the ordered SourceCluster manifest and is also
        persisted independently on the member row.  Including it in a source
        digest made unchanged sources appear different when a replay regrouped
        them with different siblings.  Source-local ``part_refs`` and each
        part's own ordinal remain part of the identity below.
        """

        payload = self.to_payload()
        payload.pop("ordinal", None)
        return payload


@dataclass(frozen=True)
class SourceManifestV1:
    agent_name: str
    business_date: str
    cluster_id: str
    scope: str
    sources: tuple[SourceEventV1, ...]
    parts: tuple[SourcePartV1, ...]
    manifest_hash: str

    @property
    def source_refs(self) -> tuple[str, ...]:
        return tuple(item.source_ref for item in self.sources)

    @property
    def part_refs(self) -> tuple[str, ...]:
        return tuple(item.part_ref for item in self.parts)

    @property
    def unavailable_part_refs(self) -> tuple[str, ...]:
        return tuple(
            item.part_ref for item in self.parts if item.status != "available"
        )

    def to_payload(self) -> dict[str, Any]:
        return {
            "schema_version": SOURCE_MANIFEST_VERSION,
            "source_identity_hash_version": SOURCE_IDENTITY_HASH_VERSION,
            "cluster_version": SEMANTIC_CLUSTER_VERSION,
            "agent_name": self.agent_name,
            "business_date": self.business_date,
            "cluster_id": self.cluster_id,
            "scope": self.scope,
            "sources": [item.to_payload() for item in self.sources],
            "parts": [item.to_manifest_payload() for item in self.parts],
            "coverage": {
                "source_count": len(self.sources),
                "part_count": len(self.parts),
                "text_part_count": sum(item.kind == "text" for item in self.parts),
                "image_part_count": sum(item.kind == "image" for item in self.parts),
                "attachment_part_count": sum(
                    item.kind == "attachment" for item in self.parts
                ),
                "unavailable_part_refs": list(self.unavailable_part_refs),
            },
            "manifest_hash": self.manifest_hash,
        }

    def to_persisted_payload(self) -> dict[str, Any]:
        """Return the complete durable queue snapshot.

        ``to_payload`` is safe for logs and model bookkeeping, so it omits
        source text and host-local media paths.  The persistent SourceCluster
        needs those values to prove full ordered coverage and to distinguish a
        source change from a code-only retry.
        """

        payload = self.to_payload()
        payload["parts"] = [
            {
                **part.to_manifest_payload(),
                "text": part.text,
                "local_path": part.local_path,
            }
            for part in self.parts
        ]
        payload["source_hashes"] = {
            source.source_ref: self.source_sha256(source.source_ref)
            for source in self.sources
        }
        return payload

    def source_sha256(self, source_ref: str) -> str:
        source = next(
            (item for item in self.sources if item.source_ref == source_ref),
            None,
        )
        if source is None:
            raise SourceManifestError(f"manifest_source_missing:{source_ref}")
        parts = {
            item.part_ref: item
            for item in self.parts
            if item.source_ref == source_ref
        }
        return _digest(
            {
                # v1 implicitly included ``source.ordinal``.  v2 deliberately
                # changes every newly emitted digest so old and new identity
                # semantics cannot be silently mixed.  Existing persisted
                # cluster/member rows remain immutable provenance and must not
                # be backfilled in place.
                "hash_version": SOURCE_IDENTITY_HASH_VERSION,
                "source": source.to_identity_payload(),
                "parts": [
                    {
                        **parts[part_ref].to_identity_payload(),
                        "text": parts[part_ref].text,
                    }
                    for part_ref in source.part_refs
                ],
            }
        )


@dataclass(frozen=True)
class SourceWindowV1:
    window_ref: str
    cluster_id: str
    ordinal: int
    source_refs: tuple[str, ...]
    part_refs: tuple[str, ...]
    prompt_payload: dict[str, Any]
    image_paths: tuple[Path, ...]
    text_chars: int

    def to_payload(self) -> dict[str, Any]:
        return {
            "schema_version": SOURCE_WINDOW_VERSION,
            "window_ref": self.window_ref,
            "cluster_id": self.cluster_id,
            "ordinal": self.ordinal,
            "source_refs": list(self.source_refs),
            "part_refs": list(self.part_refs),
            "prompt_payload": self.prompt_payload,
            "image_paths": [str(path) for path in self.image_paths],
            "text_chars": self.text_chars,
        }


@dataclass(frozen=True)
class PriorContextV1:
    """Hash-audited sources visible for interpretation, never ownership.

    These sources are deliberately outside the current SourceCluster manifest.
    They may help the primary model interpret an otherwise elliptical current
    message and may be named by the separate context-relation result, but they
    can never enter current source coverage, candidates, evidence, compiler or
    Owner commands.
    """

    context_hash: str
    source_refs: tuple[str, ...]
    sources: tuple[dict[str, Any], ...]
    image_paths: tuple[Path, ...]

    def with_image_limit(self, max_images: int) -> "PriorContextV1":
        limit = max(0, int(max_images))
        if limit >= len(self.image_paths):
            return self
        rows = deepcopy(list(self.sources))
        for source in rows:
            kept_images: list[dict[str, Any]] = []
            omitted = int(source.get("omitted_available_image_count") or 0)
            for image in source.get("images") or []:
                if int(image.get("context_image_order") or 0) <= limit:
                    kept_images.append(image)
                else:
                    omitted += 1
            source["images"] = kept_images
            source["omitted_available_image_count"] = omitted
        return PriorContextV1(
            context_hash=self.context_hash,
            source_refs=self.source_refs,
            sources=tuple(rows),
            image_paths=self.image_paths[:limit],
        )

    def prompt_payload(self, *, image_offset: int = 0) -> dict[str, Any]:
        rows = deepcopy(list(self.sources))
        for source in rows:
            for image in source.get("images") or []:
                image_order = int(image.pop("context_image_order", 0) or 0)
                if image_order > 0:
                    image["image_ref"] = (
                        f"input_image_{max(0, int(image_offset)) + image_order}"
                    )
        return {
            "contract": PRIOR_CONTEXT_VERSION,
            "authority": "interpretation_and_relation_only",
            "context_hash": self.context_hash,
            "ordered_source_refs": list(self.source_refs),
            "sources": rows,
        }

    def audit_payload(self) -> dict[str, Any]:
        return {
            "contract": PRIOR_CONTEXT_VERSION,
            "context_hash": self.context_hash,
            "source_refs": list(self.source_refs),
            "source_hashes": {
                str(source.get("source_ref") or ""): str(
                    source.get("source_sha256") or ""
                )
                for source in self.sources
                if str(source.get("source_ref") or "")
            },
            "image_count": len(self.image_paths),
            # Preserve the exact parts seen by inference for later case reads.
            "sources": deepcopy(list(self.sources)),
        }


def _part_ref(source_ref: str, *, kind: str, ordinal: int) -> str:
    safe_source = source_ref.replace(":", "_").replace("/", "_")
    return f"{safe_source}:{kind}:{ordinal:03d}"


def _location_only_metadata_key(value: Any) -> bool:
    key = str(value or "").strip().casefold()
    return key in {
        "path",
        "local_path",
        "source_path",
        "source_path_aliases",
    } or key.endswith(
        ("_path", "_dir", "_directory")
    )


def assert_manifest_window_coverage(
    manifest: SourceManifestV1,
    windows: Iterable[SourceWindowV1],
) -> None:
    assert_manifest_window_partition(
        manifest,
        windows,
        unavailable_source_refs=(),
    )


def assert_manifest_window_partition(
    manifest: SourceManifestV1,
    windows: Iterable[SourceWindowV1],
    *,
    unavailable_source_refs: Iterable[str],
) -> None:
    unavailable = {
        str(source_ref)
        for source_ref in unavailable_source_refs
        if str(source_ref)
    }
    unknown_sources = unavailable - set(manifest.source_refs)
    if unknown_sources:
        raise SourceManifestError(
            "source_manifest_window_unavailable_source_unknown:"
            + ",".join(sorted(unknown_sources))
        )
    expected = [
        part.part_ref
        for part in manifest.parts
        if part.source_ref not in unavailable
    ]
    _assert_window_part_refs(expected=expected, windows=windows)


def _assert_window_part_refs(
    *,
    expected: list[str],
    windows: Iterable[SourceWindowV1],
) -> None:
    seen: list[str] = [
        part_ref
        for window in windows
        for part_ref in window.part_refs
    ]
    duplicates = sorted(
        part_ref for part_ref in set(seen) if seen.count(part_ref) > 1
    )
    missing = sorted(set(expected) - set(seen))
    extra = sorted(set(seen) - set(expected))
    if duplicates or missing or extra or len(seen) != len(expected):
        raise SourceManifestError(
            "source_manifest_window_coverage_failed:"
            f"missing={','.join(missing)};extra={','.join(extra)};"
            f"duplicates={','.join(duplicates)}"
        )
    if seen != expected:
        raise SourceManifestError("source_manifest_window_order_changed")


def source_catalog_from_manifest(
    manifest: SourceManifestV1,
) -> dict[str, dict[str, Any]]:
    parts_by_source: dict[str, list[SourcePartV1]] = {
        source_ref: [] for source_ref in manifest.source_refs
    }
    for part in manifest.parts:
        parts_by_source[part.source_ref].append(part)
    source_index = {item.source_ref: item for item in manifest.sources}
    return {
        source_ref: {
            **source_index[source_ref].to_payload(),
            **source_index[source_ref].context,
            "message_id": source_index[source_ref].context.get("message_id"),
            "source_message_id": source_index[source_ref].context.get(
                "source_message_id"
            ),
            "msg_type": source_index[source_ref].source_kind,
            "source_sha256": manifest.source_sha256(source_ref),
            "source_identity_hash_version": SOURCE_IDENTITY_HASH_VERSION,
            "media_sha256s": sorted({
                part.sha256 for part in parts_by_source[source_ref]
                if part.is_image and part.role == "source_image" and part.sha256
            }),
            "image_local_path": next(
                (
                    part.local_path
                    for part in parts_by_source[source_ref]
                    if part.is_image and part.local_path
                ),
                None,
            ),
            "image_paths": [
                part.local_path
                for part in parts_by_source[source_ref]
                if part.is_image and part.local_path
            ],
            "image_views": [
                {
                    "path": part.local_path,
                    "view_kind": part.metadata.get("view_kind")
                    or part.role,
                    "position_hint": part.metadata.get("position_hint"),
                    "crop_box_normalized": part.metadata.get(
                        "crop_box_normalized"
                    ),
                }
                for part in parts_by_source[source_ref]
                if part.is_image and part.local_path
            ],
            "content": "\n".join(
                part.prompt_text or ""
                for part in parts_by_source[source_ref]
                if part.kind == "text" and part.prompt_text
            ),
            "current_content": "\n".join(
                part.text or ""
                for part in parts_by_source[source_ref]
                if part.kind == "text"
                and (
                    part.role in {"current_subject", "current_direction"}
                    or part.role.startswith("current:")
                    or part.role.startswith("attachment_preview:")
                )
                and part.text
            ),
            "attachment_refs": [
                part.part_ref
                for part in parts_by_source[source_ref]
                if part.kind == "attachment"
            ],
            "part_refs": [part.part_ref for part in parts_by_source[source_ref]],
            "source_files": [
                {"path": str(part.local_path), "sha256": part.sha256,
                 "filename": part.metadata.get("filename") or Path(part.local_path).name}
                for part in parts_by_source[source_ref]
                if part.kind == "attachment" and part.local_path and part.sha256
            ],
            "manifest_hash": manifest.manifest_hash,
        }
        for source_ref in manifest.source_refs
    }


def _text_parts(
    *,
    source_ref: str,
    text_blocks: list[dict[str, Any]],
    start_ordinal: int,
    max_chars: int,
) -> list[SourcePartV1]:
    parts: list[SourcePartV1] = []
    ordinal = start_ordinal
    for block_index, block in enumerate(text_blocks):
        role = _clean_text(block.get("role")) or "message_text"
        prompt_visible = block.get("prompt_visible") is not False
        block_metadata = {
            str(key): value
            for key, value in block.items()
            if key not in {"role", "text", "prompt_visible"}
        }
        raw_text = str(block.get("text") or "")
        # Audit-only text must remain complete in the persistent manifest, but
        # it must not be split into hundreds of metadata-only prompt entries.
        # Visible text is still bounded normally before model transport.
        chunks = (
            [raw_text.strip()]
            if not prompt_visible and raw_text.strip()
            else _chunk_text(raw_text, max_chars=max_chars)
        )
        for chunk_index, chunk in enumerate(chunks):
            encoded = chunk.encode("utf-8")
            parts.append(
                SourcePartV1(
                    part_ref=_part_ref(source_ref, kind="text", ordinal=ordinal),
                    source_ref=source_ref,
                    ordinal=ordinal,
                    kind="text",
                    role=role,
                    text=chunk,
                    local_path=None,
                    sha256=hashlib.sha256(encoded).hexdigest(),
                    size_bytes=len(encoded),
                    mime_type="text/plain; charset=utf-8",
                    status="available",
                    metadata={
                        "block_index": block_index,
                        "chunk_index": chunk_index,
                        "chunk_count": len(chunks),
                        "prompt_visible": prompt_visible,
                        **block_metadata,
                    },
                )
            )
            ordinal += 1
    return parts
