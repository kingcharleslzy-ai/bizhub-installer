"""Read-only statement comparison against formal sales and receipt projections."""
from __future__ import annotations

from collections import defaultdict
from datetime import date
from decimal import Decimal, InvalidOperation
from backend.modules.master_data.public import normalize_identity


def _text(value):
    return "" if value is None else str(value).strip()


def parse_statement_number(value, *, compound=False):
    if value is None or isinstance(value, bool) or _text(value) == "":
        return None
    text = str(value).strip().replace(",", "").replace("￥", "").replace("元", "")
    if compound and text.startswith("*"):
        text = text[1:]
    if not compound and "+" in text:
        return None
    try:
        result = sum((Decimal(part) for part in text.split("+")), Decimal(0))
        return result if result.is_finite() else None
    except InvalidOperation:
        return None



def _spec(value):
    return normalize_identity(value).replace("×", "*").replace("x", "*")



def _close(left, right, tolerance):
    return left is not None and right is not None and abs(left - right) <= Decimal(tolerance)


def _formal_amount(order):
    return parse_statement_number(order.get("net_receivable" if "net_receivable" in order else "receivable"))


def _swapped(fact, order, quantity_tolerance, amount_tolerance):
    """数量、单价两列写反而金额相同（原表笔误）。"""

    return (_close(parse_statement_number(fact.get("amount")), _formal_amount(order), amount_tolerance)
            and _close(parse_statement_number(fact.get("quantity")), parse_statement_number(order.get("unit_price")), amount_tolerance)
            and _close(parse_statement_number(fact.get("unit_price")), parse_statement_number(order.get("quantity_num")), quantity_tolerance))


def _twin(fact, order, quantity_tolerance, amount_tolerance):
    """数量、金额都和这一行相同（单价写了也要相同）的正式单，或两列写反的同一张单。"""

    price = parse_statement_number(fact.get("unit_price"))
    return (_close(parse_statement_number(fact.get("amount")), _formal_amount(order), amount_tolerance)
            and _close(parse_statement_number(fact.get("quantity")), parse_statement_number(order.get("quantity_num")), quantity_tolerance)
            and (price is None or _close(price, parse_statement_number(order.get("unit_price")), amount_tolerance))
            ) or _swapped(fact, order, quantity_tolerance, amount_tolerance)


def _order_date(order):
    day = order.get("ship_date") or order.get("business_date")
    return date.fromisoformat(str(day)) if day else None


def compare_statement_sheet(statement, *, indexes, amount_tolerance="0.01", quantity_tolerance="0.01", weight_tolerance="0.5",
                            spec_key=_spec, date_tolerance_days=0, twin_date_tolerance_days=0):
    """Identity chooses candidates; amounts compare them and only break ties between identity candidates.

    同一身份（客户、规格、日期窗口）有几张正式单时，数量、金额都相同的“同一笔”优先：
    从同一天起逐天放宽到 ``twin_date_tolerance_days``，相同的几行恰好对上同样多张才认，多了仍算拿不准。
    剩下对不上的行按同规格同单价合计：几行合起来和它们的候选单合起来数量、金额都相等，认作分批记账。
    """
    from .public import unique_match

    customer = statement["customer"]
    names = indexes.get("party_id_by_name", {})
    party_id = names.get(normalize_identity(customer))
    orders = list(indexes.get("sales_orders", {}).values())
    facts = statement["rows"]

    def identity_candidates(fact):
        candidates = [order for order in orders if (order.get("customer_party_id") == party_id if party_id is not None
            else normalize_identity(order.get("customer_name")) == normalize_identity(customer))
            ]
        return [order for order in candidates if fact["spec"] and (
            spec_key(fact.get("identity_spec", fact["spec"])) == spec_key(order.get("spec") or order.get("product_spec_family_key") or order.get("product_name"))
            or not order.get("spec") and not order.get("product_spec_family_key")
            and _spec(fact["spec"]) in _spec(order.get("product_name")))]

    def within(fact, candidates, days):
        return list(unique_match(candidates, key=lambda _: True, on_date=date.fromisoformat(fact["date"]),
            before_days=days, after_days=days, quantity_of=lambda _: None, date_of=_order_date,
        ).candidates) if fact["date"] else []

    identities = [identity_candidates(fact) for fact in facts]
    chosen, claimed, blocks = {}, set(), defaultdict(list)
    for index, fact in enumerate(facts):
        if fact["date"] and identities[index]:
            blocks[tuple(str(fact.get(key)) for key in ("date", "identity_spec", "spec", "quantity", "unit_price", "amount"))].append(index)
    settled = set()
    for days in range(max(int(date_tolerance_days or 0), int(twin_date_tolerance_days or 0)) + 1):
        for key, members in blocks.items():
            if key in settled:
                continue
            fact = facts[members[0]]
            twins = [order for order in within(fact, identities[members[0]], days)
                     if order["id"] not in claimed and _twin(fact, order, quantity_tolerance, amount_tolerance)]
            if len(twins) < len(members):
                continue
            settled.add(key)
            if len(twins) == len(members):
                for index, order in zip(members, sorted(twins, key=lambda order: (_order_date(order), order["id"]))):
                    chosen[index] = order
                    claimed.add(order["id"])
    result = []
    for index, fact in enumerate(facts):
        differences = []
        candidates = [chosen[index]] if index in chosen else [
            order for order in within(fact, identities[index], date_tolerance_days) if order["id"] not in claimed]
        unresolved_party = party_id is None and indexes.get("party_catalog_complete", False)
        if unresolved_party:
            differences.append({"type": "not_comparable", "field": "customer", "reason": "customer_identity_unresolved"})
        if not customer or not fact["date"] or not fact["spec"]:
            differences.append({"type": "not_comparable", "reason": "statement_identity_incomplete"})
        if "amount" not in fact["reported_fields"]:
            differences.append({"type": "not_comparable", "field": "amount", "reason": "source_amount_missing"})
        if not unresolved_party and customer and fact["date"] and fact["spec"] and len(candidates) != 1:
            differences.append({"type": "ambiguous_target" if candidates else "missing_in_formal",
                                "formal_value": [str(order["id"]) for order in candidates]})
        formal = candidates[0] if len(candidates) == 1 else None
        if formal is not None:
            if fact.get("treatment_state") and fact["treatment_state"] != formal.get("treatment_state"):
                differences.append({"type": "treatment_mismatch" if formal.get("treatment_state") not in {None, "unknown"} else "not_comparable",
                                    "field": "treatment_state", "workbook_value": fact["treatment_state"],
                                    "formal_value": formal.get("treatment_state")})
            fields = (("quantity", "quantity_num", quantity_tolerance), ("weight", "rough_detail_weight_g", weight_tolerance),
                      ("unit_price", "unit_price", amount_tolerance),
                      ("amount", "net_receivable" if "net_receivable" in formal else "receivable", amount_tolerance),
                      ("balance", "remaining_receivable", amount_tolerance))
            for field, target, tolerance in fields:
                left, right = parse_statement_number(fact.get(field)), parse_statement_number(formal.get(target))
                if left is None and field not in fact["reported_fields"]:
                    continue
                if left is None or right is None:
                    differences.append({"type": "not_comparable", "field": field, "reason": "formal_or_source_value_missing"})
                elif abs(left - right) > Decimal(tolerance):
                    differences.append({"type": "amount_mismatch" if field in {"amount", "balance"} else field + "_mismatch",
                                        "field": field, "workbook_value": str(left), "formal_value": str(right)})
            if index in chosen and _swapped(fact, formal, quantity_tolerance, amount_tolerance):
                differences = [item for item in differences if item.get("field") not in {"quantity", "unit_price"}]
                fact = {**fact, "match_note": "数量、单价两列写反，金额相同"}
            if "received" in fact["reported_fields"]:
                allocations = formal.get("payment_allocations")
                if allocations is None or not fact["payment_date"]:
                    differences.append({"type": "not_comparable", "field": "received", "reason": "formal_receipt_or_date_missing"})
                else:
                    matches = [a for a in allocations if str(a.get("business_date") or "") == fact["payment_date"]]
                    if len(matches) != 1:
                        differences.append({"type": "ambiguous_target" if matches else "missing_in_formal", "field": "received"})
                    elif parse_statement_number(fact["received"]) != parse_statement_number(matches[0].get("allocated_amount")):
                        differences.append({"type": "amount_mismatch", "field": "received", "workbook_value": fact["received"],
                                            "formal_value": str(matches[0].get("allocated_amount"))})
        result.append({**fact, "customer_party_id": party_id, "formal_order_id": str(formal["id"]) if formal else None,
                       "candidate_order_ids": [str(o["id"]) for o in candidates],
                       "status": "needs_review" if differences else "matched_existing", "differences": differences})
    claims = defaultdict(list)
    for row in result:
        if row["formal_order_id"]:
            claims[row["formal_order_id"]].append(row)
    for rows in claims.values():
        if len(rows) > 1:
            for row in rows:
                row["differences"].append({"type": "ambiguous_target", "reason": "formal_sale_reused_by_statement_rows"})
                row["status"] = "needs_review"
    _match_batch_totals(result, [within(fact, identities[index], date_tolerance_days) for index, fact in enumerate(facts)],
                        quantity_tolerance=quantity_tolerance, amount_tolerance=amount_tolerance)
    total = sum((parse_statement_number(row["amount"]) for row in result), Decimal(0)) if all(parse_statement_number(row["amount"]) is not None for row in result) else None
    summaries = [{**row, "status": "source_sum_only" if total is not None and row["amounts"] and
        all(abs(Decimal(amount) - total) <= Decimal(amount_tolerance) for amount in row["amounts"]) else "needs_review",
        "detail_amount_sum": str(total) if total is not None else None} for row in statement["summaries"]]
    return {**statement, "rows": result, "summaries": summaries,
            "summary_difference_count": sum(row["status"] == "needs_review" for row in summaries),
            "matched_count": sum(not r["differences"] for r in result),
            "difference_count": sum(bool(r["differences"]) for r in result)}


_BATCH_DIFFERENCES = {"quantity_mismatch", "amount_mismatch", "ambiguous_target", "missing_in_formal"}


def _batch_balances(rows, pool, price, *, quantity_tolerance, amount_tolerance):
    # 单价为 0 的赠送单数量算进合计、金额为 0；单价未知或不同的单仍不认。
    if len(rows) + len(pool) < 3 or any(
            not (_close(order_price := parse_statement_number(order.get("unit_price")), price, amount_tolerance)
                 or order_price == 0) for order in pool.values()):
        return False
    formal_amounts = [_formal_amount(order) for order in pool.values()]
    formal_quantities = [parse_statement_number(order.get("quantity_num")) for order in pool.values()]
    if any(value is None for value in (*formal_amounts, *formal_quantities)):
        return False  # 正式单缺数或缺价不当零，不认合计
    return (_close(sum(parse_statement_number(row["quantity"]) for row in rows), sum(formal_quantities), quantity_tolerance)
            and _close(sum(parse_statement_number(row["amount"]) for row in rows), sum(formal_amounts), amount_tolerance))


def _match_batch_totals(result, window_candidates, *, quantity_tolerance, amount_tolerance):
    """同规格同单价还对不上的行，按日期连续的几行与它们窗口内没被别行认走的正式单比合计。

    从一行起逐步加长，最短的一段先认；数量、金额都相等才认作分批记账，一张单只认给一段。
    """

    taken = {row["formal_order_id"] for row in result if row["formal_order_id"] and not row["differences"]}
    groups = defaultdict(list)
    for index, row in enumerate(result):
        price = parse_statement_number(row.get("unit_price"))
        if (row["differences"] and price is not None and "received" not in row["reported_fields"]
                and {item["type"] for item in row["differences"]} <= _BATCH_DIFFERENCES
                and parse_statement_number(row.get("quantity")) is not None and parse_statement_number(row.get("amount")) is not None):
            groups[(row.get("identity_spec") or row.get("spec"), price)].append(index)
    for (_spec_key, price), members in groups.items():
        members = sorted(members, key=lambda index: (result[index]["date"] or "", result[index]["row"]))
        matched = set()
        for length in range(1, len(members) + 1):
            for start in range(len(members) - length + 1):
                run = members[start:start + length]
                if matched & set(run):
                    continue
                pool = {str(order["id"]): order for index in run for order in window_candidates[index]
                        if str(order["id"]) not in taken}
                if not _batch_balances([result[index] for index in run], pool, price,
                                       quantity_tolerance=quantity_tolerance, amount_tolerance=amount_tolerance):
                    continue
                matched.update(run)
                taken.update(pool)
                for index in run:
                    result[index].update({"status": "matched_existing", "differences": [], "formal_order_id": None,
                                          "candidate_order_ids": sorted(pool, key=int), "match_basis": "batch_total",
                                          "match_note": "分批记账：同规格同单价（含 0 元赠送）几行合计与这几张单合计的数量、金额都相同"})
