"""Customer-neutral build-time Profile Registry resolver.

The kernel only understands explicit file bindings and the shared Registry
contract. Customer profiles provide their own paths in adapters outside this
package, so a generic artifact does not need to carry customer configuration.
"""

from __future__ import annotations

import hashlib
import importlib
import json
import re
from copy import deepcopy
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping


REGISTRY_SCHEMA_VERSION = "bizhub.runtime-registry.v1"
PROFILE_SCHEMA_VERSION = "bizhub.profile-lock.v1"
COMPATIBILITY_SCHEMA_VERSION = "bizhub.legacy-compat-inventory.v1"
SHA256_RE = re.compile(r"^[0-9a-f]{64}$")


class RuntimeRegistryError(RuntimeError):
    """Fail-closed Profile Registry error with a stable machine code."""

    def __init__(self, code: str, message: str):
        super().__init__(f"{code}: {message}")
        self.code = code
        self.message = message


@dataclass(frozen=True)
class RegistryFiles:
    profile_id: str
    registry: str
    registry_digest: str
    profile_lock: str
    compatibility_inventory: str | None = None


def canonical_json(payload: Any) -> bytes:
    return (json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n").encode()


def digest_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def digest_json(payload: Any) -> str:
    return digest_bytes(canonical_json(payload))


def _load_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeRegistryError("runtime_registry_file_invalid", f"cannot read {path}: {exc}") from exc


def _claim(
    claims: dict[tuple[str, ...], str],
    identity: tuple[str, ...],
    module_id: str,
    conflicts: list[str],
) -> None:
    existing = claims.get(identity)
    if existing is not None:
        conflicts.append(f"{identity!r} is declared by both {existing!r} and {module_id!r}")
        return
    claims[identity] = module_id


def validate_module_graph(modules: Iterable[Mapping[str, Any]]) -> None:
    """Validate the deliberately small v1 dependency and surface contract."""

    rows = [dict(item) for item in modules]
    by_id: dict[str, dict[str, Any]] = {}
    conflicts: list[str] = []
    for module in rows:
        module_id = str(module.get("module_id") or "")
        if not module_id:
            conflicts.append("module_id is required")
            continue
        if module_id in by_id:
            conflicts.append(f"duplicate module_id {module_id!r}")
            continue
        by_id[module_id] = module

    for module_id, module in by_id.items():
        dependencies = module.get("dependencies") or []
        if not isinstance(dependencies, list) or any(not isinstance(item, str) for item in dependencies):
            conflicts.append(f"module {module_id!r} has invalid required dependencies")
            continue
        for dependency in dependencies:
            if dependency not in by_id:
                conflicts.append(f"module {module_id!r} requires unknown module {dependency!r}")
                continue
            source_kind = str((module.get("source") or {}).get("kind") or "")
            dependency_kind = str((by_id[dependency].get("source") or {}).get("kind") or "")
            if source_kind == "generic" and dependency_kind == "customer-private":
                conflicts.append(
                    f"generic module {module_id!r} cannot depend on customer-private module {dependency!r}"
                )

    visiting: set[str] = set()
    visited: set[str] = set()

    def visit(module_id: str, path: tuple[str, ...]) -> None:
        if module_id in visiting:
            cycle_start = path.index(module_id) if module_id in path else 0
            conflicts.append("dependency cycle: " + " -> ".join((*path[cycle_start:], module_id)))
            return
        if module_id in visited:
            return
        visiting.add(module_id)
        for dependency in by_id[module_id].get("dependencies") or []:
            if dependency in by_id:
                visit(dependency, (*path, module_id))
        visiting.remove(module_id)
        visited.add(module_id)

    for module_id in sorted(by_id):
        visit(module_id, ())

    claims: dict[tuple[str, ...], str] = {}
    for module_id, module in sorted(by_id.items()):
        capabilities = module.get("capabilities") or {}
        for capability in capabilities.get("provides") or []:
            _claim(claims, ("capability", str(capability)), module_id, conflicts)
        surfaces = module.get("surfaces") or {}
        for route in surfaces.get("routes") or []:
            _claim(
                claims,
                ("route", str(route.get("surface_id")), str(route.get("method")), str(route.get("path"))),
                module_id,
                conflicts,
            )
        for route in surfaces.get("ui_routes") or []:
            surface_id = str(route.get("surface_id"))
            _claim(claims, ("ui_route", surface_id, str(route.get("path"))), module_id, conflicts)
            navigation_key = route.get("navigation_key")
            if navigation_key is not None:
                _claim(claims, ("navigation", surface_id, str(navigation_key)), module_id, conflicts)
        for job in surfaces.get("jobs") or []:
            _claim(claims, ("job", str(job.get("job_id"))), module_id, conflicts)
        for tool in surfaces.get("mcp_tools") or []:
            _claim(claims, ("mcp_tool", str(tool.get("tool_id"))), module_id, conflicts)
        for action in surfaces.get("actions") or []:
            _claim(claims, ("action", str(action.get("action_id"))), module_id, conflicts)
        ownership = module.get("ownership") or {}
        for owner in ownership.get("record_types") or []:
            _claim(claims, ("record_type_owner", str(owner.get("record_type"))), module_id, conflicts)
        for owner in ownership.get("tables") or []:
            _claim(claims, ("table_owner", str(owner.get("table"))), module_id, conflicts)

    if conflicts:
        raise RuntimeRegistryError("runtime_registry_conflict", "; ".join(sorted(set(conflicts))))


def _validate_compatibility_inventory(inventory: Mapping[str, Any]) -> None:
    if inventory.get("schema_version") != COMPATIBILITY_SCHEMA_VERSION:
        raise RuntimeRegistryError("compatibility_inventory_schema_mismatch", "unsupported inventory schema")
    allowed_top = {"schema_version", "inventory_id", "source_commit", "entries"}
    forbidden_top = sorted(set(inventory) - allowed_top)
    if forbidden_top:
        raise RuntimeRegistryError(
            "compatibility_inventory_forbidden_claim",
            f"forbidden top-level keys: {forbidden_top}",
        )
    allowed_entry = {"kind", "ref", "source", "reason"}
    for index, entry in enumerate(inventory.get("entries") or []):
        forbidden = sorted(set(entry) - allowed_entry)
        if forbidden:
            raise RuntimeRegistryError(
                "compatibility_inventory_forbidden_claim",
                f"entry {index} has forbidden keys: {forbidden}",
            )


def _validate_generated_assembly(payload: Mapping[str, Any]) -> None:
    assembly = payload.get("assembly") or {}
    conflicts: list[str] = []
    route_claims: set[tuple[str, str, str]] = set()
    for binding in assembly.get("backend_router_bindings") or []:
        for mode in binding.get("modes") or []:
            identity = (str(mode), str(binding.get("module")), str(binding.get("symbol")))
            if identity in route_claims:
                conflicts.append(f"duplicate backend router binding {identity!r}")
            route_claims.add(identity)
    job_claims: set[tuple[str, str]] = set()
    for binding in assembly.get("jobs") or []:
        identity = (str(binding.get("surface")), str(binding.get("job_id")))
        if identity in job_claims:
            conflicts.append(f"duplicate job binding {identity!r}")
        job_claims.add(identity)
    hook_claims: set[str] = set()
    for binding in assembly.get("startup_hooks") or []:
        hook_id = str(binding.get("hook_id") or "")
        if not hook_id or hook_id in hook_claims:
            conflicts.append(f"duplicate or empty startup hook {hook_id!r}")
        hook_claims.add(hook_id)
    profile_id = str(payload.get("profile_id") or "")
    assembly_hooks = sorted(
        f"{profile_id}|{item.get('hook_id')}|{item.get('factory')}|profile_scope={item.get('profile_scope')}"
        for item in assembly.get("startup_hooks") or []
    )
    effective_hooks = sorted(
        str(item) for item in (payload.get("effective_system_map") or {}).get("startup_hooks") or []
    )
    if assembly_hooks != effective_hooks:
        conflicts.append("startup hook assembly and effective map differ")
    model_imports = [str(item) for item in assembly.get("model_imports") or []]
    if not model_imports or len(model_imports) != len(set(model_imports)):
        conflicts.append("model import catalog must be non-empty and unique")
    mcp_tools = [str(item) for item in assembly.get("mcp_tool_ids") or []]
    if len(mcp_tools) != len(set(mcp_tools)):
        conflicts.append("MCP tool catalog contains duplicate IDs")
    effective_mcp = [str(item) for item in (payload.get("effective_system_map") or {}).get("mcp_tools") or []]
    if set(mcp_tools) != set(effective_mcp):
        conflicts.append("MCP assembly and effective map differ")
    migration_catalog = assembly.get("migration_catalog") or {}
    migrations = migration_catalog.get("items") or []
    versions = [int(item.get("version")) for item in migrations]
    current = int(migration_catalog.get("current_schema_version") or 0)
    if versions != list(range(1, current + 1)):
        conflicts.append("migration catalog must retain contiguous lineage versions")
    if conflicts:
        raise RuntimeRegistryError("runtime_registry_assembly_conflict", "; ".join(conflicts))


@dataclass(frozen=True)
class RuntimeRegistry:
    repo_root: Path
    profile_lock: Mapping[str, Any]
    compatibility_inventory: Mapping[str, Any] | None
    payload: Mapping[str, Any]

    @classmethod
    def load(
        cls,
        repo_root: Path | None = None,
        *,
        files: RegistryFiles,
    ) -> "RuntimeRegistry":
        root = (repo_root or Path(__file__).resolve().parents[2]).resolve()
        registry_path = root / files.registry
        digest_path = root / files.registry_digest
        profile_path = root / files.profile_lock
        inventory_path = root / files.compatibility_inventory if files.compatibility_inventory else None

        try:
            expected_registry_digest = digest_path.read_text(encoding="utf-8").strip()
        except OSError as exc:
            raise RuntimeRegistryError("runtime_registry_digest_missing", str(exc)) from exc
        if not SHA256_RE.fullmatch(expected_registry_digest):
            raise RuntimeRegistryError("runtime_registry_digest_invalid", "registry digest sidecar is malformed")
        try:
            registry_bytes = registry_path.read_bytes()
        except OSError as exc:
            raise RuntimeRegistryError("runtime_registry_file_invalid", str(exc)) from exc
        actual_registry_digest = digest_bytes(registry_bytes)
        if actual_registry_digest != expected_registry_digest:
            raise RuntimeRegistryError(
                "runtime_registry_content_drift",
                f"expected {expected_registry_digest}, got {actual_registry_digest}",
            )

        payload = _load_json(registry_path)
        profile = _load_json(profile_path)
        inventory = _load_json(inventory_path) if inventory_path else None
        if payload.get("schema_version") != REGISTRY_SCHEMA_VERSION:
            raise RuntimeRegistryError("runtime_registry_schema_mismatch", "unsupported registry schema")
        if profile.get("schema_version") != PROFILE_SCHEMA_VERSION:
            raise RuntimeRegistryError("profile_lock_schema_mismatch", "unsupported Profile Lock schema")
        if profile.get("profile_id") != files.profile_id or payload.get("profile_id") != files.profile_id:
            raise RuntimeRegistryError("profile_id_mismatch", f"expected build profile {files.profile_id!r}")

        if digest_bytes(profile_path.read_bytes()) != payload.get("profile_lock_sha256"):
            raise RuntimeRegistryError("profile_lock_content_drift", "Profile Lock digest does not match registry")
        if inventory_path is None:
            if profile.get("compatibility_inventory_ref") is not None:
                raise RuntimeRegistryError("compatibility_inventory_ref_mismatch", "profile must not reference inventory")
            if payload.get("compatibility_inventory_sha256") is not None:
                raise RuntimeRegistryError("compatibility_inventory_content_drift", "registry must not bind inventory")
        else:
            if inventory is None:
                raise RuntimeRegistryError("compatibility_inventory_file_invalid", "inventory is required")
            _validate_compatibility_inventory(inventory)
            if digest_bytes(inventory_path.read_bytes()) != payload.get("compatibility_inventory_sha256"):
                raise RuntimeRegistryError(
                    "compatibility_inventory_content_drift",
                    "compatibility inventory digest does not match registry",
                )
            if profile.get("compatibility_inventory_ref") != inventory.get("inventory_id"):
                raise RuntimeRegistryError("compatibility_inventory_ref_mismatch", "Profile Lock reference is not exact")
            if inventory.get("source_commit") != payload.get("source_commit"):
                raise RuntimeRegistryError("inventory_source_commit_mismatch", "inventory and registry source commits differ")

        if profile.get("source_commit") != payload.get("source_commit"):
            raise RuntimeRegistryError("profile_source_commit_mismatch", "Profile and registry source commits differ")
        modules = payload.get("modules") or []
        validate_module_graph(modules)
        _validate_generated_assembly(payload)
        locked_modules = {item.get("module_id"): item for item in profile.get("modules") or []}
        manifest_modules = {item.get("module_id"): item for item in modules}
        if set(locked_modules) != set(manifest_modules):
            raise RuntimeRegistryError("profile_module_set_mismatch", "Profile Lock and registry modules differ")
        for module_id, lock in locked_modules.items():
            manifest = manifest_modules[module_id]
            if lock.get("module_version") != manifest.get("module_version"):
                raise RuntimeRegistryError("profile_module_version_mismatch", f"module {module_id!r} version differs")
            if lock.get("source_commit") != manifest.get("source", {}).get("commit"):
                raise RuntimeRegistryError("profile_module_commit_mismatch", f"module {module_id!r} commit differs")
            if lock.get("module_manifest_sha256") != digest_json(manifest):
                raise RuntimeRegistryError(
                    "profile_module_manifest_digest_mismatch",
                    f"module {module_id!r} manifest differs",
                )

        expected = profile.get("expected") or {}
        if expected.get("shared_kernel_source_digest") != payload.get("shared_kernel_source_digest"):
            raise RuntimeRegistryError(
                "shared_kernel_source_digest_mismatch",
                "Profile Lock shared kernel digest differs",
            )
        if expected.get("profile_source_digest") != payload.get("profile_source_digest"):
            raise RuntimeRegistryError(
                "profile_source_digest_mismatch",
                "Profile Lock profile source digest differs",
            )
        effective_digest = digest_json(payload.get("effective_system_map") or {})
        if effective_digest != payload.get("effective_system_map_digest"):
            raise RuntimeRegistryError("effective_system_map_content_drift", "generated effective map digest differs")
        if expected.get("effective_system_map_digest") != effective_digest:
            raise RuntimeRegistryError("profile_effective_map_digest_mismatch", "Profile Lock map digest differs")
        return cls(root, profile, inventory, payload)

    def router_bindings(self, mode: str) -> list[dict[str, Any]]:
        if mode not in {"live", "read_mirror"}:
            raise RuntimeRegistryError("runtime_mode_invalid", f"unsupported backend mode {mode!r}")
        return [
            deepcopy(item)
            for item in self.payload.get("assembly", {}).get("backend_router_bindings", [])
            if mode in (item.get("modes") or [])
        ]

    def job_bindings(self, surface: str) -> list[dict[str, Any]]:
        if surface not in {"api", "worker"}:
            raise RuntimeRegistryError("job_surface_invalid", f"unsupported job surface {surface!r}")
        return [
            deepcopy(item)
            for item in self.payload.get("assembly", {}).get("jobs", [])
            if item.get("surface") == surface
        ]

    def startup_hook_bindings(self) -> list[dict[str, Any]]:
        return deepcopy(list(self.payload.get("assembly", {}).get("startup_hooks") or []))

    def resolve_symbol(self, reference: str) -> Any:
        module_name, separator, symbol_name = str(reference).partition(":")
        if not separator or not module_name or not symbol_name:
            raise RuntimeRegistryError("runtime_symbol_invalid", f"invalid symbol reference {reference!r}")
        try:
            module = importlib.import_module(module_name)
            return getattr(module, symbol_name)
        except (ImportError, AttributeError) as exc:
            raise RuntimeRegistryError("runtime_symbol_unresolved", f"cannot resolve {reference!r}: {exc}") from exc

    def activate_model_catalog(self) -> None:
        for module_name in self.payload.get("assembly", {}).get("model_imports", []):
            try:
                importlib.import_module(str(module_name))
            except ImportError as exc:
                raise RuntimeRegistryError("model_catalog_import_failed", str(exc)) from exc

    def migration_runner(self) -> Callable[..., Any]:
        reference = str(self.migration_catalog().get("runner") or "")
        runner = self.resolve_symbol(reference)
        if not callable(runner):
            raise RuntimeRegistryError("migration_runner_invalid", f"{reference!r} is not callable")
        return runner

    def migration_catalog(self) -> dict[str, Any]:
        return deepcopy(dict(self.payload.get("assembly", {}).get("migration_catalog") or {}))

    def resolve_mcp_tools(self, tools: Mapping[str, Any]) -> dict[str, Any]:
        expected = list(self.payload.get("assembly", {}).get("mcp_tool_ids", []))
        actual = list(tools)
        if len(actual) != len(expected) or set(actual) != set(expected):
            missing = sorted(set(expected) - set(actual))
            unexpected = sorted(set(actual) - set(expected))
            raise RuntimeRegistryError(
                "mcp_tool_catalog_drift",
                f"missing={missing}, unexpected={unexpected}",
            )
        return dict(tools)

    def effective_system_map(self) -> dict[str, Any]:
        return deepcopy(dict(self.payload.get("effective_system_map") or {}))
