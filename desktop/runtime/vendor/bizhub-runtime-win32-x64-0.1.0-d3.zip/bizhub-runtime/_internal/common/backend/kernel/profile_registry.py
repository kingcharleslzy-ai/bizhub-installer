"""Customer-neutral build-time Profile Registry resolver.

The kernel only understands explicit file bindings and the shared Registry
contract. Customer profiles provide their own paths in adapters outside this
package, so a generic artifact does not need to carry customer configuration.
"""

from __future__ import annotations

import hashlib
import importlib
import json
from copy import deepcopy
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping

# ``kernel.profile_registry`` declares this module as its public surface, so the
# module-contract projection consumed by other modules is re-exported here
# instead of reaching into ``backend.kernel.module_contract`` directly.
from .module_contract import module_contract_payload
# Storage mechanism consumers share this same declared kernel public facade.
from .sqlite_storage import (
    STORAGE_BUDGET, BoundStorage, StorageBudget, StorageBusy, StorageTarget,
    StorageTransactionRequired, connect as storage_connect, read_storage,
    wait_for_storage_retry, write_storage,
)


REGISTRY_SCHEMA_VERSION = "bizhub.runtime-registry.v1"
PROFILE_SCHEMA_VERSION = "bizhub.profile-lock.v1"


def registered_business_facts(payload: Mapping[str, Any]) -> list[dict[str, Any]]:
    """Registered business facts (``agent_context.business_facts[]``) of the enabled modules.

    ``module`` is the fact's business module (first of ``requires_modules``),
    ``declared_by`` the manifest that registers its reader. A fact whose
    ``requires_modules`` are not all enabled is not offered; one fact id or
    reader tool has one owner.
    """
    enabled = {str(module["module_id"]) for module in payload.get("modules", [])}
    facts: list[dict[str, Any]] = []
    owners: dict[str, str] = {}
    for module in payload.get("modules", []):
        module_id = str(module["module_id"])
        for fact in (module.get("agent_context") or {}).get("business_facts") or []:
            for key in (f"fact:{fact['fact_id']}", f"tool:{fact['tool']}"):
                if key in owners:
                    raise RuntimeRegistryError(
                        "business_fact_conflict", f"{key} is declared by both {owners[key]!r} and {module_id!r}"
                    )
                owners[key] = module_id
            if set(fact.get("requires_modules") or []) <= enabled:
                facts.append({**deepcopy(dict(fact)), "module": fact["requires_modules"][0], "declared_by": module_id})
    return facts


class RuntimeRegistryError(RuntimeError):
    """Fail-closed Profile Registry error with a stable machine code."""

    def __init__(self, code: str, message: str):
        super().__init__(f"{code}: {message}")
        self.code = code
        self.message = message


@dataclass(frozen=True)
class RegistryFiles:
    profile_id: str
    registry: str
    profile_lock: str


def canonical_json(payload: Any) -> bytes:
    return (json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n").encode()


def digest_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def digest_json(payload: Any) -> str:
    return digest_bytes(canonical_json(payload))


def _load_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeRegistryError("runtime_registry_file_invalid", f"cannot read {path}: {exc}") from exc


def _claim(
    claims: dict[tuple[str, ...], str],
    identity: tuple[str, ...],
    module_id: str,
    conflicts: list[str],
) -> None:
    existing = claims.get(identity)
    if existing is not None:
        conflicts.append(f"{identity!r} is declared by both {existing!r} and {module_id!r}")
        return
    claims[identity] = module_id


def module_stores_in_lineage(module: Mapping[str, Any], lineage_id: str) -> bool:
    """Whether a module's owned tables live in this Profile's own database.

    A module whose every table declares another migration lineage is enabled
    but not wired into this Profile yet: it contributes no effective record
    owner or action here. Table-less modules belong to every Profile.
    """

    tables = (module.get("ownership") or {}).get("tables") or []
    return not tables or any(str(item.get("lineage_id") or lineage_id) == lineage_id for item in tables)


def validate_module_graph(modules: Iterable[Mapping[str, Any]]) -> None:
    """Validate the deliberately small v1 dependency and surface contract."""

    rows = [dict(item) for item in modules]
    by_id: dict[str, dict[str, Any]] = {}
    conflicts: list[str] = []
    for module in rows:
        module_id = str(module.get("module_id") or "")
        if not module_id:
            conflicts.append("module_id is required")
            continue
        if module_id in by_id:
            conflicts.append(f"duplicate module_id {module_id!r}")
            continue
        by_id[module_id] = module

    for module_id, module in by_id.items():
        dependencies = module.get("dependencies") or []
        if not isinstance(dependencies, list) or any(not isinstance(item, str) for item in dependencies):
            conflicts.append(f"module {module_id!r} has invalid required dependencies")
            continue
        for dependency in dependencies:
            if dependency not in by_id:
                conflicts.append(f"module {module_id!r} requires unknown module {dependency!r}")
                continue
            source_kind = str((module.get("source") or {}).get("kind") or "")
            dependency_kind = str((by_id[dependency].get("source") or {}).get("kind") or "")
            if source_kind == "generic" and dependency_kind == "customer-private":
                conflicts.append(
                    f"generic module {module_id!r} cannot depend on customer-private module {dependency!r}"
                )

    visiting: set[str] = set()
    visited: set[str] = set()

    def visit(module_id: str, path: tuple[str, ...]) -> None:
        if module_id in visiting:
            cycle_start = path.index(module_id) if module_id in path else 0
            conflicts.append("dependency cycle: " + " -> ".join((*path[cycle_start:], module_id)))
            return
        if module_id in visited:
            return
        visiting.add(module_id)
        for dependency in by_id[module_id].get("dependencies") or []:
            if dependency in by_id:
                visit(dependency, (*path, module_id))
        visiting.remove(module_id)
        visited.add(module_id)

    for module_id in sorted(by_id):
        visit(module_id, ())

    claims: dict[tuple[str, ...], str] = {}
    for module_id, module in sorted(by_id.items()):
        capabilities = module.get("capabilities") or {}
        for capability in capabilities.get("provides") or []:
            _claim(claims, ("capability", str(capability)), module_id, conflicts)
        surfaces = module.get("surfaces") or {}
        for route in surfaces.get("routes") or []:
            _claim(
                claims,
                ("route", str(route.get("surface_id")), str(route.get("method")), str(route.get("path"))),
                module_id,
                conflicts,
            )
        for route in surfaces.get("ui_routes") or []:
            surface_id = str(route.get("surface_id"))
            _claim(claims, ("ui_route", surface_id, str(route.get("path"))), module_id, conflicts)
            navigation_key = route.get("navigation_key")
            if navigation_key is not None:
                _claim(claims, ("navigation", surface_id, str(navigation_key)), module_id, conflicts)
        for job in surfaces.get("jobs") or []:
            _claim(claims, ("job", str(job.get("job_id"))), module_id, conflicts)
        for hook in surfaces.get("startup_hooks") or []:
            _claim(
                claims,
                (
                    "startup_hook",
                    str(hook.get("profile_scope")),
                    str(hook.get("hook_id")),
                ),
                module_id,
                conflicts,
            )
        for tool in surfaces.get("mcp_tools") or []:
            _claim(claims, ("mcp_tool", str(tool.get("tool_id"))), module_id, conflicts)
        for tool in surfaces.get("agent_tools") or []:
            _claim(claims, ("agent_tool", str(tool.get("tool_id"))), module_id, conflicts)
            if str(tool.get("module_id") or "") != module_id:
                conflicts.append(
                    f"agent tool {tool.get('tool_id')!r} declares a different module_id"
                )
        for action in surfaces.get("actions") or []:
            _claim(claims, ("action", str(action.get("action_id"))), module_id, conflicts)
        ownership = module.get("ownership") or {}
        for owner in ownership.get("models") or []:
            _claim(claims, ("model", str(owner.get("model"))), module_id, conflicts)
        for owner in ownership.get("record_types") or []:
            _claim(claims, ("record_type_owner", str(owner.get("record_type"))), module_id, conflicts)
        for owner in ownership.get("tables") or []:
            # Same-named tables in different migration lineages are different
            # physical tables; no lineage means the Profile's own database.
            _claim(
                claims,
                ("table_owner", str(owner.get("lineage_id") or ""), str(owner.get("table"))),
                module_id,
                conflicts,
            )

    if conflicts:
        raise RuntimeRegistryError("runtime_registry_conflict", "; ".join(sorted(set(conflicts))))


def _validate_generated_assembly(payload: Mapping[str, Any]) -> None:
    assembly = payload.get("assembly") or {}
    conflicts: list[str] = []
    module_ids = {
        str(item.get("module_id"))
        for item in payload.get("modules") or []
    }
    route_claims: set[tuple[str, str, str]] = set()
    for binding in assembly.get("backend_router_bindings") or []:
        binding_module_id = binding.get("module_id")
        if binding_module_id is not None and str(binding_module_id) not in module_ids:
            conflicts.append(
                f"backend router binding references inactive module {binding_module_id!r}"
            )
        for mode in binding.get("modes") or []:
            identity = (str(mode), str(binding.get("module")), str(binding.get("symbol")))
            if identity in route_claims:
                conflicts.append(f"duplicate backend router binding {identity!r}")
            route_claims.add(identity)
    job_claims: set[tuple[str, str]] = set()
    for binding in assembly.get("jobs") or []:
        binding_module_id = binding.get("module_id")
        if binding_module_id is not None and str(binding_module_id) not in module_ids:
            conflicts.append(f"job binding references inactive module {binding_module_id!r}")
        identity = (str(binding.get("surface")), str(binding.get("job_id")))
        if identity in job_claims:
            conflicts.append(f"duplicate job binding {identity!r}")
        job_claims.add(identity)
    hook_claims: set[str] = set()
    for binding in assembly.get("startup_hooks") or []:
        binding_module_id = binding.get("module_id")
        if binding_module_id is not None and str(binding_module_id) not in module_ids:
            conflicts.append(
                f"startup hook references inactive module {binding_module_id!r}"
            )
        hook_id = str(binding.get("hook_id") or "")
        if not hook_id or hook_id in hook_claims:
            conflicts.append(f"duplicate or empty startup hook {hook_id!r}")
        hook_claims.add(hook_id)
    profile_id = str(payload.get("profile_id") or "")
    assembly_hooks = sorted(
        f"{profile_id}|{item.get('hook_id')}|{item.get('factory')}|profile_scope={item.get('profile_scope')}"
        for item in assembly.get("startup_hooks") or []
    )
    effective_hooks = sorted(
        str(item) for item in (payload.get("effective_system_map") or {}).get("startup_hooks") or []
    )
    if assembly_hooks != effective_hooks:
        conflicts.append("startup hook assembly and effective map differ")
    model_imports = [str(item) for item in assembly.get("model_imports") or []]
    if not model_imports or len(model_imports) != len(set(model_imports)):
        conflicts.append("model import catalog must be non-empty and unique")
    mcp_tools = [str(item) for item in assembly.get("mcp_tool_ids") or []]
    if len(mcp_tools) != len(set(mcp_tools)):
        conflicts.append("MCP tool catalog contains duplicate IDs")
    effective_mcp = [str(item) for item in (payload.get("effective_system_map") or {}).get("mcp_tools") or []]
    if set(mcp_tools) != set(effective_mcp):
        conflicts.append("MCP assembly and effective map differ")
    migration_catalog = assembly.get("migration_catalog") or {}
    migrations = migration_catalog.get("items") or []
    versions = [int(item.get("version")) for item in migrations]
    current = int(migration_catalog.get("current_schema_version") or 0)
    if versions != list(range(1, current + 1)):
        conflicts.append("migration catalog must retain contiguous lineage versions")
    if conflicts:
        raise RuntimeRegistryError("runtime_registry_assembly_conflict", "; ".join(conflicts))


def verify_profile_lock(profile: Mapping[str, Any], modules: list[Mapping[str, Any]]) -> None:
    """The Profile Lock pins every module's version, revision and manifest bytes.

    Both files hold per-module rows only (no aggregate digests or profile
    revision), so independent module changes merge without touching shared
    lines; release bytes stay pinned by the CP-5 artifact digests.
    """
    locked_modules = {item.get("module_id"): item for item in profile.get("modules") or []}
    manifest_modules = {item.get("module_id"): item for item in modules}
    if set(locked_modules) != set(manifest_modules):
        raise RuntimeRegistryError("profile_module_set_mismatch", "Profile Lock and registry modules differ")
    for module_id, lock in locked_modules.items():
        manifest = manifest_modules[module_id]
        if lock.get("module_version") != manifest.get("module_version"):
            raise RuntimeRegistryError("profile_module_version_mismatch", f"module {module_id!r} version differs")
        if lock.get("source_commit") != manifest.get("source", {}).get("commit"):
            raise RuntimeRegistryError("profile_module_commit_mismatch", f"module {module_id!r} commit differs")
        if lock.get("module_manifest_sha256") != digest_json(manifest):
            raise RuntimeRegistryError(
                "profile_module_manifest_digest_mismatch",
                f"module {module_id!r} manifest differs",
            )


@dataclass(frozen=True)
class RuntimeRegistry:
    repo_root: Path
    profile_lock: Mapping[str, Any]
    payload: Mapping[str, Any]

    @classmethod
    def load(
        cls,
        repo_root: Path | None = None,
        *,
        files: RegistryFiles,
    ) -> "RuntimeRegistry":
        root = (repo_root or Path(__file__).resolve().parents[2]).resolve()
        payload = _load_json(root / files.registry)
        profile = _load_json(root / files.profile_lock)
        if payload.get("schema_version") != REGISTRY_SCHEMA_VERSION:
            raise RuntimeRegistryError("runtime_registry_schema_mismatch", "unsupported registry schema")
        if profile.get("schema_version") != PROFILE_SCHEMA_VERSION:
            raise RuntimeRegistryError("profile_lock_schema_mismatch", "unsupported Profile Lock schema")
        if profile.get("profile_id") != files.profile_id or payload.get("profile_id") != files.profile_id:
            raise RuntimeRegistryError("profile_id_mismatch", f"expected build profile {files.profile_id!r}")
        modules = payload.get("modules") or []
        validate_module_graph(modules)
        _validate_generated_assembly(payload)
        verify_profile_lock(profile, modules)
        return cls(root, profile, payload)

    def router_bindings(self, mode: str) -> list[dict[str, Any]]:
        if mode not in {"live", "read_mirror"}:
            raise RuntimeRegistryError("runtime_mode_invalid", f"unsupported backend mode {mode!r}")
        return [
            deepcopy(item)
            for item in self.payload.get("assembly", {}).get("backend_router_bindings", [])
            if mode in (item.get("modes") or [])
        ]

    def job_bindings(self, surface: str) -> list[dict[str, Any]]:
        if surface not in {"api", "worker"}:
            raise RuntimeRegistryError("job_surface_invalid", f"unsupported job surface {surface!r}")
        return [
            deepcopy(item)
            for item in self.payload.get("assembly", {}).get("jobs", [])
            if item.get("surface") == surface
        ]

    def startup_hook_bindings(self) -> list[dict[str, Any]]:
        return deepcopy(list(self.payload.get("assembly", {}).get("startup_hooks") or []))

    def resolve_symbol(self, reference: str) -> Any:
        module_name, separator, symbol_name = str(reference).partition(":")
        if not separator or not module_name or not symbol_name:
            raise RuntimeRegistryError("runtime_symbol_invalid", f"invalid symbol reference {reference!r}")
        try:
            module = importlib.import_module(module_name)
            return getattr(module, symbol_name)
        except (ImportError, AttributeError) as exc:
            raise RuntimeRegistryError("runtime_symbol_unresolved", f"cannot resolve {reference!r}: {exc}") from exc

    def resolve_capability(self, capability: str, symbol: str) -> Any:
        """Resolve an explicitly exported provider from this enabled Profile only."""
        providers = [
            module for module in self.payload.get("modules", [])
            if capability in (module.get("capabilities") or {}).get("provides", [])
        ]
        if len(providers) != 1:
            raise RuntimeRegistryError("capability_unavailable", f"unavailable capability: {capability}")
        reference = str(providers[0]["package"]["public_api"])
        module_name = reference.partition(":")[0]
        module = importlib.import_module(module_name)
        if symbol not in getattr(module, "__all__", ()):
            raise RuntimeRegistryError("capability_unavailable", f"provider does not export {symbol}")
        if capability.endswith(".read") and symbol not in getattr(module, "__read_api__", ()):
            raise RuntimeRegistryError("capability_unavailable", f"{capability} does not export read symbol {symbol}")
        return self.resolve_symbol(f"{module_name}:{symbol}")

    def activate_model_catalog(self) -> None:
        for module_name in self.payload.get("assembly", {}).get("model_imports", []):
            try:
                importlib.import_module(str(module_name))
            except ImportError as exc:
                raise RuntimeRegistryError("model_catalog_import_failed", str(exc)) from exc

    def migration_runner(self) -> Callable[..., Any]:
        reference = str(self.migration_catalog().get("runner") or "")
        runner = self.resolve_symbol(reference)
        if not callable(runner):
            raise RuntimeRegistryError("migration_runner_invalid", f"{reference!r} is not callable")
        return runner

    def migration_catalog(self) -> dict[str, Any]:
        return deepcopy(dict(self.payload.get("assembly", {}).get("migration_catalog") or {}))

    def resolve_mcp_tools(self, tools: Mapping[str, Any]) -> dict[str, Any]:
        expected = list(self.payload.get("assembly", {}).get("mcp_tool_ids", []))
        actual = list(tools)
        if len(actual) != len(expected) or set(actual) != set(expected):
            missing = sorted(set(expected) - set(actual))
            unexpected = sorted(set(actual) - set(expected))
            raise RuntimeRegistryError(
                "mcp_tool_catalog_drift",
                f"missing={missing}, unexpected={unexpected}",
            )
        return dict(tools)

    def mcp_tool_declarations(self) -> dict[str, dict[str, Any]]:
        """Each enabled module's own ``surfaces.mcp_tools[]`` entry: surfaces, profiles, write flag, duty desk."""
        return {
            str(tool["tool_id"]): deepcopy(dict(tool))
            for module in self.payload.get("modules", [])
            for tool in (module.get("surfaces") or {}).get("mcp_tools") or []
        }

    def agent_tool_declarations(self) -> dict[str, dict[str, Any]]:
        """Company-agent tools the enabled modules declare (``surfaces.agent_tools[]``)."""
        return {
            str(tool["tool_id"]): deepcopy(dict(tool))
            for module in self.payload.get("modules", [])
            for tool in (module.get("surfaces") or {}).get("agent_tools") or []
        }

    def duty_desk_sources(self) -> list[dict[str, Any]]:
        """Where each enabled module's duty-desk events come from (``surfaces.duty_desk_sources``)."""
        return [
            {"module_id": str(module.get("module_id")), **deepcopy(dict(source))}
            for module in self.payload.get("modules", [])
            for source in (module.get("surfaces") or {}).get("duty_desk_sources") or []
        ]

    def duty_desk_event_kinds(self) -> dict[str, dict[str, Any]]:
        """event_kind -> its declared duty-desk attributes; one module per kind."""
        kinds: dict[str, dict[str, Any]] = {}
        for source in self.duty_desk_sources():
            for kind in source.get("event_kinds") or []:
                name = str(kind["event_kind"])
                if name in kinds:
                    raise RuntimeRegistryError(
                        "duty_desk_event_kind_conflict",
                        f"{name!r} is declared by both {kinds[name]['module_id']!r} and {source['module_id']!r}",
                    )
                kinds[name] = {**kind, "module_id": source["module_id"], "attention": bool(source.get("attention"))}
        return kinds

    def module_mcp_tool_ids(self, module_id: str) -> tuple[str, ...]:
        """One module's declared MCP tool ids (its ``surfaces.mcp_tools[]``), as served by this Profile."""
        return tuple(
            str(tool["tool_id"])
            for module in self.payload.get("modules", [])
            if module.get("module_id") == module_id
            for tool in (module.get("surfaces") or {}).get("mcp_tools") or []
        )

    def duty_desk_tools(self) -> dict[str, dict[str, Any]]:
        """Tools the enabled modules declare for the unattended duty desk (``surfaces.mcp_tools[].duty_desk``)."""
        return {
            tool_id: dict(tool["duty_desk"])
            for tool_id, tool in self.mcp_tool_declarations().items()
            if "duty_desk" in tool
        }

    def duty_desk_answer_routes(self) -> dict[str, dict[str, str]]:
        """event_kind -> the one tool that executes its recorded owner answers, plus its case-opening fact."""
        routes: dict[str, dict[str, str]] = {}
        for tool_id, declaration in self.duty_desk_tools().items():
            for answer in declaration.get("answers") or []:
                kind = str(answer["event_kind"])
                if kind in routes:
                    raise RuntimeRegistryError(
                        "duty_desk_answer_route_conflict",
                        f"{kind!r} is executed by both {routes[kind]['tool_id']!r} and {tool_id!r}",
                    )
                routes[kind] = {"tool_id": tool_id, "case_fact": str(answer.get("case_fact") or "")}
        return routes

    def business_facts(self) -> list[dict[str, Any]]:
        return registered_business_facts(self.payload)

    def route_catalog(self) -> list[dict[str, Any]]:
        """Every registered route with its owner module, auth, permissions, read/write effect and stability."""
        return deepcopy(list(self.payload.get("assembly", {}).get("route_catalog") or []))

    def effective_system_map(self) -> dict[str, Any]:
        return deepcopy(dict(self.payload.get("effective_system_map") or {}))
