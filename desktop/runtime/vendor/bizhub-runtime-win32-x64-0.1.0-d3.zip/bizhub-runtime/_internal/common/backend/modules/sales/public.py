"""Stable facade for generic sales actions and reads."""

from __future__ import annotations

from backend.kernel.profile_registry import StorageTarget, read_storage, storage_connect

import sqlite3
from pathlib import Path
from typing import Any

from .contracts import SalesCommand, SalesLine, SalesPreview, SalesReturnCommand, SalesReturnItem, SalesReturnPreview
from .owner import (
    LINE_ROWS, ORDER_ROWS, SalesOwnerError, apply_preview, preview_action, read_action, read_order,
    apply_return_preview, preview_return_action, read_return_case, read_document_action,
)
from .contracts import InvoiceShipmentCoverage


def _connect(path: Path) -> sqlite3.Connection:
    connection = storage_connect(f"file:{path}?mode=ro", uri=True)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA query_only=ON")
    return connection


def list_orders(storage: StorageTarget, *, limit: int = 100) -> list[dict[str, Any]]:
    with read_storage(storage, _connect) as connection:
        return [
            dict(row)
            for row in connection.execute(
                f"""SELECT * FROM {ORDER_ROWS} o
                    WHERE NOT EXISTS (SELECT 1 FROM sales_orders l
                                      WHERE l.batch_id=o.id AND l.ship_from_location_id IS NULL)
                    ORDER BY o.ordered_at DESC, o.order_id DESC LIMIT ?""",
                (max(1, min(int(limit), 500)),),
            )
        ]


__all__ = [
    "InvoiceShipmentCoverage",
    "LINE_ROWS", "ORDER_ROWS",
    "SalesReturnCommand",
    "SalesReturnItem",
    "SalesReturnPreview",
    "apply_return_preview",
    "preview_return_action",
    "read_return_case",
    "read_document_action",
    "SalesCommand",
    "SalesLine",
    "SalesOwnerError",
    "SalesPreview",
    "apply_preview",
    "list_orders",
    "preview_action",
    "read_action",
    "read_order",
]


from .owner import (
    preview_action_in_transaction,
    preview_return_action_in_transaction,
    apply_preview_in_transaction,
    apply_return_preview_in_transaction,
    read_action_in_transaction,
    read_document_action_in_transaction
)

__all__ += ['preview_action_in_transaction', 'preview_return_action_in_transaction', 'apply_preview_in_transaction', 'apply_return_preview_in_transaction', 'read_action_in_transaction', 'read_document_action_in_transaction']

from .owner import preview_reversal_action, apply_reversal_preview, list_reversals, read_reversal
from backend.modules.trade_core.public import TradeReversalCommand, TradeReversalPreview
__all__ += ["TradeReversalCommand", "TradeReversalPreview", "preview_reversal_action", "apply_reversal_preview", "list_reversals", "read_reversal"]

from .owner import party_reference_counts
__all__ += ["party_reference_counts"]

from .segmented_pricing import calculate_segmented_pricing
__all__ += ["calculate_segmented_pricing"]

from . import settlement_writes  # noqa: E402

__all__ += ["settlement_writes"]

from . import return_writes  # noqa: E402

__all__ += ["return_writes"]

from . import order_writes  # noqa: E402

__all__ += ["order_writes"]

from . import order_schema  # noqa: E402

__all__ += ["order_schema"]

from . import return_origin  # noqa: E402
__all__ += ["return_origin"]

from .relation_reads import (  # noqa: E402
    SalesRelationExtension, read_latest_capacity_sale, read_order_by_external_item, read_order_preview,
    read_order_relation_candidates, read_return_case_candidates, plan_settled,
)
from .return_origin import returned_quantity  # noqa: E402
__all__ += [
    "SalesRelationExtension", "read_latest_capacity_sale", "read_order_by_external_item", "read_order_preview",
    "read_order_relation_candidates", "read_return_case_candidates", "returned_quantity",
    "plan_settled",
]

from .service_fulfillment import apply_service_preview, list_services, preview_service_action

__all__ += ["apply_service_preview", "list_services", "preview_service_action"]
