"""The one source phase driver; domain preparation and existing Owners stay outside."""
from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Any

from backend.kernel.profile_registry import wait_for_storage_retry

from .execution import execution_scope
from .source_journal import SourceClusterStateError


@dataclass
class InferenceCheckpoint:
    value: Any
    updates: dict[str, Any]
    model_call_count: int = 0


@dataclass
class PreparedBatch:
    value: Any
    has_visual_targets: bool = False


@dataclass
class VisualCheckpoint:
    value: Any
    updates: dict[str, Any]
    model_call_count: int = 0


@dataclass
class SourceCoverageOutcome:
    semantic_payload: dict[str, Any]
    processed_part_refs: tuple[str, ...]
    failures: tuple[dict[str, Any], ...] = ()
    review_source_refs: tuple[str, ...] = ()
    model_call_count: int = 0


@dataclass
class PendingSourceCommit:
    coverage: SourceCoverageOutcome
    output: dict[str, Any]
    value: Any = None


@dataclass
class SourceRunResult:
    claim: Any
    value: Any = None
    error: BaseException | None = None
    failure: dict[str, Any] | None = None


async def _save_checkpoint(store, claim, updates):
    # Re-write only the same completed observation after a stale SQLite snapshot.
    for attempt in range(len(store.checkpoint_retry_delays) + 1):
        try:
            await store.journal.checkpoint_source_cluster(claim=claim, updates=updates)
            await store.commit()
            return
        except Exception as exc:
            if not store.is_contention(exc):
                raise
            await store.rollback()
            if attempt == len(store.checkpoint_retry_delays):
                raise
            await wait_for_storage_retry(store.checkpoint_retry_delays[attempt])


async def run_source_lifecycle(*, manifest, identity, store, preparation, consumer, claim=None):
    existing = await consumer.existing(manifest)
    if existing is not None:
        return SourceRunResult(None, existing)
    budget = None
    calls = 0
    try:
        if claim is None:
            claim = await store.claim(manifest, identity)
            await store.commit()
        await consumer.admitted(manifest, claim)
        if claim.promotion_only:
            return SourceRunResult(claim, await consumer.resume_persisted_effects(claim))
        if not claim.should_run:
            return SourceRunResult(claim)
        budget = await store.journal.begin_source_cluster_execution(claim=claim, timeout_seconds=store.timeout_seconds)
        await store.commit()
        with execution_scope(budget):
            # Name snapshots follow the committed revision before any context, prompt or compile reads them.
            await store.refresh_published_snapshots()
            inference = preparation.reuse(claim, manifest)
            if inference is None:
                context = await preparation.read_context(manifest)
                await store.release_reads()
                inference = await preparation.infer(manifest, context)
                calls += inference.model_call_count
            inference = preparation.sanitize(inference, manifest)
            await _save_checkpoint(store, claim, inference.updates)
            await store.journal.renew_source_cluster_execution_budget_after_checkpoint(claim=claim, budget=budget,
                completed_stage="semantic_inference", timeout_seconds=store.timeout_seconds)
            await store.commit()
            await store.release_reads()
            # 编译所读的名称快照随已提交代次刷新（停用即退出新解析，不等进程重启）。
            await store.refresh_published_snapshots()
            prepared = await preparation.compile(inference, visual=None)
            await store.release_reads()
            if prepared.has_visual_targets:
                visual = await preparation.verify(prepared, inference, cached_visual=claim)
                calls += visual.model_call_count
                await _save_checkpoint(store, claim, visual.updates)
                await store.journal.renew_source_cluster_execution_budget_after_checkpoint(claim=claim, budget=budget,
                    completed_stage="visual_verification", timeout_seconds=store.timeout_seconds)
                await store.commit()
                await store.release_reads()
                await store.refresh_published_snapshots()
                prepared = await preparation.compile(inference, visual=visual)
                await store.release_reads()
            budget.check()
            pending = await consumer.consume(prepared, claim)
            # Prepared, Decision/Owner/Review and source completion share this commit.
            status = await store.journal.complete_source_cluster(claim=claim,
                semantic_payload=pending.coverage.semantic_payload,
                processed_part_refs=pending.coverage.processed_part_refs,
                output=pending.output, failures=pending.coverage.failures,
                review_source_refs=pending.coverage.review_source_refs, model_call_count=calls)
            pending.output["source_cluster_status"] = status
            await consumer.project_pending(pending)
            await store.commit()
            await consumer.after_commit(pending)
            return SourceRunResult(claim, pending.value if pending.value is not None else pending.output)
    except asyncio.CancelledError:
        if budget is not None:
            budget.cancel_event.set()
        if claim is not None and claim.claim_token:
            async def release():
                await store.rollback()
                failure = {"category": "worker_cancelled", "reason": "worker_cancelled_before_source_cluster_completion",
                    "source_refs": [], "retryable": True, "failure_fingerprint": store.cancellation_fingerprint(claim)}
                if claim.promotion_only:
                    await store.journal.fail_source_cluster_promotion(claim=claim, failure=failure, retry_seconds=1)
                else:
                    await store.journal.fail_source_cluster(claim=claim, failure=failure, model_call_count=calls,
                        retry_seconds=1, enforce_model_retry_policy=False)
                await store.commit()
            try:
                await asyncio.shield(release())
            except Exception as exc:
                await store.rollback()
                store.cleanup_failed(exc)
        raise
    except Exception as exc:
        await store.rollback()
        failure = preparation.failure(exc, manifest)
        calls += int(getattr(exc, "model_call_count", 0) or 0)
        lost = isinstance(exc, SourceClusterStateError) and str(exc).startswith("source_cluster_claim_lost:")
        if claim is not None and claim.claim_token and not lost:
            try:
                if claim.promotion_only:
                    await store.journal.fail_source_cluster_promotion(claim=claim, failure=failure)
                else:
                    await store.journal.fail_source_cluster(claim=claim, failure=failure, model_call_count=calls)
                await consumer.project_failure(failure)
                await store.commit()
            except SourceClusterStateError as state_error:
                await store.rollback()
                if not str(state_error).startswith("source_cluster_claim_lost:"):
                    raise
        return SourceRunResult(claim, error=exc, failure=failure)
