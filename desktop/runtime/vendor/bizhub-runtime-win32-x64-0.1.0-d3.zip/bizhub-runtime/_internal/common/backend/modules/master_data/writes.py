"""主数据标准表的写入原语：只在调用方的事务里写，不提交、不留痕。

每个函数都是“同样的事做第二次零变化”：已存在且一样就返回 ``noop``。留痕（处理记录）
由上层命令统一写。客户特有的规则经 :class:`MasterDataPolicy` 进来。
"""

from __future__ import annotations

import hashlib
import json
import sqlite3
import uuid
from decimal import Decimal
from typing import Any, Iterable

from .contracts import storage_timestamp
from .matching import normalize_identity
from .name_types import catalog_rows, scope_key, scopes_overlap, target_key
from .policy import DEFAULT_POLICY, MasterDataPolicy
from .public import MasterDataError
from .schema import ALIAS_ENTITY_TYPES

PARTY_IDENTIFIER_TYPES = ("tax_id", "unified_social_credit_code", "registration_no", "phone")
_ENTITY_TABLES = {"party": "business_parties", "product": "products", "unit": "measurement_units"}


def _json(value: Any) -> str:
    return value if isinstance(value, str) else json.dumps(value or {}, ensure_ascii=False)


def _one(connection: sqlite3.Connection, sql: str, params: Iterable[Any] = ()) -> dict[str, Any] | None:
    cursor = connection.execute(sql, tuple(params))
    row = cursor.fetchone()
    return None if row is None else dict(zip([item[0] for item in cursor.description], row))


def _all(connection: sqlite3.Connection, sql: str, params: Iterable[Any] = ()) -> list[dict[str, Any]]:
    cursor = connection.execute(sql, tuple(params))
    names = [item[0] for item in cursor.description]
    return [dict(zip(names, row)) for row in cursor.fetchall()]


def alias_entity_types(policy: MasterDataPolicy = DEFAULT_POLICY) -> frozenset[str]:
    return frozenset(ALIAS_ENTITY_TYPES) | policy.extra_alias_entity_types | frozenset(policy.name_types)


def entity_row(connection: sqlite3.Connection, domain: str, entity_id: int | str, *,
               policy: MasterDataPolicy = DEFAULT_POLICY) -> dict[str, Any] | None:
    if domain in policy.name_types:
        declaration = policy.name_types[domain]
        key = target_key(entity_id, declaration)
        return next((row for row in catalog_rows(connection, domain, declaration, policy.name_catalogs) if row["id"] == key), None)
    table = _ENTITY_TABLES.get(domain)
    if table is None:
        if domain in policy.extra_entity_rows:
            return policy.extra_entity_rows[domain](connection, int(entity_id))
        raise MasterDataError("master_data_resource_kind_invalid", domain)
    return _one(connection, f"SELECT * FROM {table} WHERE id=?", (int(entity_id),))


def require_active(connection: sqlite3.Connection, domain: str, entity_id: int | str, *,
                   policy: MasterDataPolicy = DEFAULT_POLICY) -> dict[str, Any]:
    row = entity_row(connection, domain, entity_id, policy=policy)
    if row is None:
        raise MasterDataError("master_data_resource_missing", f"{domain}:{entity_id}")
    if row["status"] != "active":
        raise MasterDataError("master_data_resource_inactive", f"{domain}:{entity_id}")
    return row


def normalize_party_identifier(identifier_type: str, value: object, policy: MasterDataPolicy = DEFAULT_POLICY) -> str:
    if identifier_type not in PARTY_IDENTIFIER_TYPES:
        raise MasterDataError("master_data_identifier_type_invalid", identifier_type)
    if identifier_type == "phone":
        return policy.normalize_phone(value)
    normalized = policy.normalize_identifier(value)
    return normalized if len(normalized) >= 8 else ""


def require_alias_identity(connection: sqlite3.Connection, entity_type: str, entity_id: int | str, normalized: str,
                           *, exclude_alias_id: int | None = None, source_scope: str = "",
                           policy: MasterDataPolicy = DEFAULT_POLICY) -> list[dict[str, Any]]:
    rows = _all(connection, "SELECT * FROM master_data_aliases WHERE entity_type=? AND normalized_alias=? ORDER BY id",
                (entity_type, normalized))
    declaration = policy.name_types.get(entity_type)
    if declaration:
        require_active(connection, entity_type, entity_id, policy=policy)
        scope = scope_key(source_scope, declaration)
        for other in catalog_rows(connection, entity_type, declaration, policy.name_catalogs):
            if other["status"] == "active" and other["id"] != entity_id and policy.normalize_alias(entity_type, other["canonical_name"]) == normalized:
                raise MasterDataError("master_data_alias_owned_by_other", f"{entity_type}:{normalized}")
        rows = [row for row in rows if scopes_overlap(row["source_scope"], scope)]
    others = [row for row in rows if row["id"] != exclude_alias_id and row["alias_status"] == "confirmed"
              and (row["entity_id"] if row["entity_id"] is not None else row["entity_key"]) != entity_id]
    if others:
        raise MasterDataError("master_data_alias_owned_by_other", f"{entity_type}:{normalized}")
    return rows


def record_alias(
    connection: sqlite3.Connection,
    *,
    entity_type: str,
    entity_id: int | str,
    alias_name: str,
    source_scope: str = "",
    origin: str = "",
    confidence: Any = None,
    evidence: Any = None,
    confirmed_by: str = "",
    normalized_alias: str | None = None,
    policy: MasterDataPolicy = DEFAULT_POLICY,
) -> dict[str, Any]:
    """确认一个写法指向一个主数据：新增、恢复或零变化。

    同一种主数据里一个写法最多指向一个对象：已确认指向别人就拒收（来源范围只是出处）；
    往来方的写法若是本公司名称也拒收。
    """

    entity_type = str(entity_type or "").strip().casefold()
    if entity_type not in alias_entity_types(policy):
        raise MasterDataError("master_data_alias_entity_type_invalid", entity_type)
    alias_name = str(alias_name or "").strip()[:240]
    if entity_type == "party" and policy.own_company_label(alias_name) is not None:
        raise MasterDataError("master_data_alias_names_own_company", alias_name)
    normalized = normalized_alias or policy.normalize_alias(entity_type, alias_name)
    if not normalized:
        raise MasterDataError("master_data_alias_text_required", entity_type)
    declaration = policy.name_types.get(entity_type)
    scope = scope_key(source_scope, declaration) if declaration else str(source_scope or "")[:160]
    if len(scope) > 160:
        raise MasterDataError("master_data_scope_too_long", entity_type)
    rows = require_alias_identity(connection, entity_type, entity_id, normalized, source_scope=scope, policy=policy)
    own = [row for row in rows if (row["entity_id"] if row["entity_id"] is not None else row["entity_key"]) == entity_id
           and (not declaration or row["source_scope"] == scope)]
    confirmed = next((row for row in own if row["alias_status"] == "confirmed"), None)
    if confirmed is not None:
        return {"action": "noop", "alias_id": int(confirmed["id"]), "normalized_alias": normalized}
    now = storage_timestamp()
    same_scope = next((row for row in own if row["source_scope"] == scope), None)
    if same_scope is not None:
        connection.execute(
            """UPDATE master_data_aliases SET alias_status='confirmed', origin=?, evidence_json=?,
               confirmed_by=?, confirmed_at=? WHERE id=?""",
            (str(origin or same_scope["origin"] or "")[:160], _json(evidence), str(confirmed_by or "")[:120], now,
             int(same_scope["id"])),
        )
        return {"action": "reactivate", "alias_id": int(same_scope["id"]), "normalized_alias": normalized}
    cursor = connection.execute(
        """INSERT INTO master_data_aliases
           (entity_type, entity_id, entity_key, alias_name, normalized_alias, source_scope, alias_status, origin,
            confidence, evidence_json, confirmed_by, confirmed_at, created_at)
           VALUES (?, ?, ?, ?, ?, ?, 'confirmed', ?, ?, ?, ?, ?, ?)""",
        (entity_type, entity_id if isinstance(entity_id, int) else None, entity_id if isinstance(entity_id, str) else None, alias_name, normalized, scope, str(origin or "")[:160],
         str(Decimal(str(confidence))) if confidence not in (None, "") else None, _json(evidence),
         str(confirmed_by or "")[:120], now, now),
    )
    return {"action": "insert", "alias_id": int(cursor.lastrowid), "normalized_alias": normalized}


def set_alias_status(connection: sqlite3.Connection, alias_id: int, status: str, *, confirmed_by: str = "",
                     policy: MasterDataPolicy = DEFAULT_POLICY) -> str:
    """把一条别名改成已确认 / 有歧义 / 停用；已是这个状态就零变化。"""

    if status not in {"confirmed", "ambiguous", "deprecated"}:
        raise MasterDataError("master_data_alias_status_invalid", status)
    row = _one(connection, "SELECT * FROM master_data_aliases WHERE id=?", (int(alias_id),))
    if row is None:
        raise MasterDataError("master_data_alias_missing", str(alias_id))
    if row["alias_status"] == status:
        return "noop"
    if status == "confirmed":
        if row["entity_type"] in policy.name_types:
            key = row["entity_id"] if row["entity_id"] is not None else row["entity_key"]
            require_alias_identity(connection, row["entity_type"], key, row["normalized_alias"],
                                   exclude_alias_id=alias_id, source_scope=row["source_scope"], policy=policy)
        clash = _one(
            connection,
            """SELECT id FROM master_data_aliases WHERE entity_type=? AND normalized_alias=? AND source_scope=?
               AND alias_status='confirmed' AND id<>?""",
            (row["entity_type"], row["normalized_alias"], row["source_scope"], int(alias_id)),
        )
        if clash is not None:
            raise MasterDataError("master_data_alias_owned_by_other", str(alias_id))
    connection.execute(
        "UPDATE master_data_aliases SET alias_status=?, confirmed_by=? WHERE id=?",
        (status, str(confirmed_by or row["confirmed_by"] or "")[:120], int(alias_id)),
    )
    return "update"


def delete_alias(connection: sqlite3.Connection, alias_id: int) -> None:
    connection.execute("DELETE FROM master_data_aliases WHERE id=?", (int(alias_id),))


def set_alias_evidence(connection: sqlite3.Connection, alias_id: int, evidence: Any) -> None:
    """只改一条别名的来源证据（如页面叫法的命中次数）；不改指向和状态。"""

    connection.execute("UPDATE master_data_aliases SET evidence_json=? WHERE id=?", (_json(evidence), int(alias_id)))


def move_alias(connection: sqlite3.Connection, alias_id: int, entity_id: int | str) -> None:
    """一条别名改指另一个对象（合并、目录收口时用）。"""

    connection.execute("UPDATE master_data_aliases SET entity_id=?, entity_key=? WHERE id=?",
                       (entity_id if isinstance(entity_id, int) else None, entity_id if isinstance(entity_id, str) else None, int(alias_id)))


def retire_alias(
    connection: sqlite3.Connection, alias_id: int, *, confirmed_by: str | None = None,
    evidence_update: dict[str, Any] | None = None,
) -> None:
    """停用一条别名；可同时记下谁、为什么停用（并进原有证据）。"""

    row = _one(connection, "SELECT evidence_json, confirmed_by FROM master_data_aliases WHERE id=?", (int(alias_id),))
    if row is None:
        raise MasterDataError("master_data_alias_missing", str(alias_id))
    evidence_json = row["evidence_json"]
    if evidence_update:
        evidence = json.loads(evidence_json or "{}")
        evidence.update(evidence_update)
        evidence_json = json.dumps(evidence, ensure_ascii=False)
    connection.execute(
        "UPDATE master_data_aliases SET alias_status='deprecated', confirmed_by=?, evidence_json=? WHERE id=?",
        (row["confirmed_by"] if confirmed_by is None else str(confirmed_by)[:120], evidence_json, int(alias_id)),
    )


def update_candidates(
    connection: sqlite3.Connection,
    *,
    domain: str,
    statuses: Iterable[str],
    normalized_text: str | None = None,
    suggested_entity_id: int | None = None,
    set_entity_id: int | None = None,
    set_canonical_name: str | None = None,
    set_status: str | None = None,
    review_note: str | None = None,
) -> int:
    """按种类、状态（和写法或所指对象）批量改待确认名称：改指、改状态、补说明。"""

    where = ["domain=?", f"status IN ({','.join('?' for _ in tuple(statuses))})"]
    params: list[Any] = [domain, *tuple(statuses)]
    if normalized_text is not None:
        where.append("normalized_text=?")
        params.append(normalized_text)
    if suggested_entity_id is not None:
        where.append("suggested_entity_id=?")
        params.append(int(suggested_entity_id))
    sets: list[str] = []
    values: list[Any] = []
    for column, value in (("suggested_entity_id", set_entity_id), ("suggested_canonical_name", set_canonical_name),
                          ("status", set_status), ("review_note", review_note)):
        if value is not None:
            sets.append(f"{column}=?")
            values.append(value)
    if not sets:
        return 0
    if review_note is not None:
        sets.append("updated_at=?")
        values.append(storage_timestamp())
    cursor = connection.execute(
        f"UPDATE master_data_alias_candidates SET {', '.join(sets)} WHERE {' AND '.join(where)}", (*values, *params),
    )
    return int(cursor.rowcount or 0)


def party_alias_identity(
    connection: sqlite3.Connection,
    *,
    party_id: int,
    raw_text: str,
    canonical_name: str | None = None,
    policy: MasterDataPolicy = DEFAULT_POLICY,
) -> dict[str, Any]:
    """一个往来方写法的唯一结论：正式名与别名共用一个身份空间。

    来源范围只是出处，不能为同一个往来方再造一行；已停用且明确合并到本方的旧名可以
    转指本方，其余撞到别的往来方一律拒收。
    """

    party = require_active(connection, "party", party_id)
    alias_name = str(raw_text or "").strip()[:200]
    if policy.own_company_label(alias_name) is not None:
        raise MasterDataError("master_data_alias_names_own_company", alias_name)
    normalized = normalize_identity(alias_name)
    if not normalized:
        raise MasterDataError("master_data_alias_text_required", "party")
    canonical = str(canonical_name if canonical_name is not None else party["canonical_name"]).strip()
    for other in _all(connection, "SELECT * FROM business_parties WHERE id<>?", (int(party_id),)):
        names = {normalize_identity(value) for value in (other["canonical_name"], other["legal_name"]) if str(value or "").strip()}
        if normalized not in names:
            continue
        redirect = other["status"] == "deprecated" and other["successor_party_id"] is not None and int(
            other["successor_party_id"]) == int(party_id)
        if not redirect:
            raise MasterDataError("master_data_alias_is_other_canonical", alias_name)
    rows = _all(connection, """SELECT * FROM master_data_aliases WHERE entity_type='party' AND alias_status='confirmed'
                               AND normalized_alias=? ORDER BY id""", (normalized,))
    if any(int(row["entity_id"]) != int(party_id) for row in rows):
        raise MasterDataError("master_data_alias_owned_by_other", alias_name)
    if normalized == normalize_identity(canonical):
        return {"action": "canonical_identity_noop", "party_id": int(party_id), "normalized_alias": normalized, "alias_id": None}
    if rows:
        return {"action": "existing_identity_noop", "party_id": int(party_id), "normalized_alias": normalized,
                "alias_id": int(rows[0]["id"])}
    return {"action": "create_identity", "party_id": int(party_id), "normalized_alias": normalized, "alias_id": None}


def remember_decision(
    connection: sqlite3.Connection, *, domain: str, raw_text: str, entity_id: int | str,
    policy: MasterDataPolicy = DEFAULT_POLICY, source_scope: object = "",
) -> str:
    """只读：记住这个写法是零变化（``noop``）还是要新记（``create``）；指向别人时拒收。"""

    domain = str(domain or "").strip().casefold()
    raw_text = str(raw_text or "").strip()
    if domain not in alias_entity_types(policy):
        raise MasterDataError("master_data_alias_entity_type_invalid", domain)
    if not raw_text:
        raise MasterDataError("master_data_alias_text_required", domain)
    if domain in policy.name_types:
        normalized = policy.normalize_alias(domain, raw_text)
        scope = scope_key(source_scope, policy.name_types[domain])
        rows = require_alias_identity(connection, domain, entity_id, normalized, source_scope=scope, policy=policy)
        return "noop" if any(row["alias_status"] == "confirmed" and row["source_scope"] == scope for row in rows) else "create"
    if domain in _ENTITY_TABLES:
        require_active(connection, domain, entity_id)
    if domain == "party":
        identity = party_alias_identity(connection, party_id=entity_id, raw_text=raw_text, policy=policy)
        return "noop" if identity["action"] in {"canonical_identity_noop", "existing_identity_noop"} else "create"
    normalized = policy.normalize_alias(domain, raw_text)
    if domain != "product":
        existing = _all(
            connection,
            """SELECT entity_id FROM master_data_aliases WHERE entity_type=? AND normalized_alias=?
               AND alias_status IN ('confirmed', 'deprecated')""",
            (domain, normalized),
        )
        if existing:
            if any(int(row["entity_id"]) != int(entity_id) for row in existing):
                raise MasterDataError("master_data_alias_owned_by_other", f"{domain}:{raw_text}")
            return "noop"
        return "create"
    rows = _all(connection, "SELECT entity_id, alias_status FROM master_data_aliases WHERE entity_type='product' AND normalized_alias=?",
                (normalized,))
    if any(row["alias_status"] == "confirmed" and int(row["entity_id"]) != int(entity_id) for row in rows):
        raise MasterDataError("master_data_alias_owned_by_other", f"product:{raw_text}")
    if any(row["alias_status"] == "confirmed" and int(row["entity_id"]) == int(entity_id) for row in rows):
        return "noop"
    return "create"


def remember_confirmed_alias(
    connection: sqlite3.Connection,
    *,
    domain: str,
    raw_text: str,
    entity_id: int | str,
    business_role: str,
    source_scope: str,
    reviewer: str,
    source_key: str,
    review_note: str = "",
    source_kind: str = "historical_governance",
    policy: MasterDataPolicy = DEFAULT_POLICY,
    evidence: dict[str, Any] | None = None,
) -> int | None:
    """记住一个经管理人确认的写法：留一条已确认的待确认名称记录，再把写法记成别名。

    已经是本方的正式名或别名时零变化，返回 None；指向别人时拒收。
    """

    domain = str(domain or "").strip().casefold()
    raw_text = str(raw_text or "").strip()
    if remember_decision(connection, domain=domain, raw_text=raw_text, entity_id=entity_id, policy=policy, source_scope=source_scope) == "noop":
        return None
    if domain in policy.name_types:
        source_scope = scope_key(source_scope, policy.name_types[domain])
    now = storage_timestamp()
    pending = []
    if domain in policy.name_types:
        pending = _all(connection, """SELECT id FROM master_data_alias_candidates WHERE domain=? AND normalized_text=?
            AND suggested_entity_id IS ? AND suggested_entity_key IS ? AND source_scope=? AND status='candidate' ORDER BY id""",
            (domain, policy.normalize_alias(domain, raw_text), entity_id if isinstance(entity_id, int) else None,
             entity_id if isinstance(entity_id, str) else None, source_scope))
    if pending:
        for row in pending:
            connection.execute("""UPDATE master_data_alias_candidates SET status='confirmed', reviewed_by=?,
                reviewed_at=?, review_note=?, updated_at=? WHERE id=?""", (reviewer, now, review_note, now, row["id"]))
        candidate_id = int(pending[0]["id"])
    else:
        cursor = connection.execute(
            """INSERT INTO master_data_alias_candidates
               (domain, raw_text, normalized_text, suggested_entity_type, suggested_entity_id, suggested_entity_key, suggested_canonical_name,
                business_role, source_kind, source_id, source_key, source_scope, agent_name, confidence,
                strong_anchors_json, evidence_json, status, reviewed_by, reviewed_at, review_note, created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, '', ?, ?, NULL, ?, ?, 'management_review', '1', '[]', ?, 'confirmed', ?, ?, ?, ?, ?)""",
            (domain, raw_text, policy.normalize_alias(domain, raw_text) if domain != "party" else normalize_identity(raw_text),
             domain, entity_id if isinstance(entity_id, int) else None, entity_id if isinstance(entity_id, str) else None, str(business_role or ""), source_kind, str(source_key or "")[:240],
             str(source_scope or "")[:160], json.dumps({"reviewNote": str(review_note or "")}, ensure_ascii=False),
             reviewer, now, str(review_note or ""), now, now),
        )
        candidate_id = int(cursor.lastrowid)
    evidence = {**(evidence or {}), "reviewNote": str(review_note or "")}
    if domain == "party" and str(business_role or "").strip():
        evidence.setdefault("role_hint", str(business_role).strip())
    record_alias(
        connection, entity_type=domain, entity_id=entity_id, alias_name=raw_text,
        source_scope=source_scope if domain in {"party", "product"} or domain in policy.name_types else "",
        origin=f"alias_candidate:{candidate_id}", confidence="1", evidence=evidence, confirmed_by=reviewer,
        policy=policy,
    )
    return candidate_id


def ensure_role(connection: sqlite3.Connection, *, party_id: int, role_key: str) -> bool:
    """往来方角色的唯一写入原语：已有返回 False，新增返回 True。"""

    role_key = str(role_key or "").strip()
    if not role_key:
        raise MasterDataError("master_data_role_required", str(party_id))
    if _one(connection, "SELECT id FROM business_party_roles WHERE party_id=? AND role_key=?",
            (int(party_id), role_key)) is not None:
        return False
    connection.execute(
        "INSERT INTO business_party_roles (party_id, role_key, created_at) VALUES (?, ?, ?)",
        (int(party_id), role_key, storage_timestamp()),
    )
    return True


def upsert_contact(
    connection: sqlite3.Connection, *, party_id: int, contact_name: str, contact_role: str = "", source: str = "",
) -> str:
    name = str(contact_name or "").strip()[:120]
    if not name:
        raise MasterDataError("master_data_contact_name_required", str(party_id))
    normalized = normalize_identity(name)
    role = str(contact_role or "").strip()[:80]
    row = _one(connection, "SELECT * FROM business_contacts WHERE party_id=? AND normalized_name=?",
               (int(party_id), normalized))
    now = storage_timestamp()
    if row is None:
        connection.execute(
            """INSERT INTO business_contacts
               (party_id, contact_name, normalized_name, contact_role, email_domain, source, status, created_at, updated_at)
               VALUES (?, ?, ?, ?, '', ?, 'active', ?, ?)""",
            (int(party_id), name, normalized, role, str(source or "")[:160], now, now),
        )
        return "insert"
    if (row["contact_name"], row["contact_role"], row["status"]) == (name, role, "active"):
        return "noop"
    connection.execute(
        """UPDATE business_contacts SET contact_name=?, contact_role=?, source=?, status='active', updated_at=?
           WHERE id=?""",
        (name, role, str(source or "")[:160], now, int(row["id"])),
    )
    return "update"


_STATUSES = ("active", "deprecated")


def update_contact(
    connection: sqlite3.Connection, contact_id: int, *, contact_name: Any = None, contact_role: Any = None,
    status: Any = None,
) -> dict[str, Any]:
    """改一个联系人的姓名、职务或停用；返回改前的样子。同名联系人在同一往来方下只有一个。"""

    row = _one(connection, "SELECT * FROM business_contacts WHERE id=?", (int(contact_id),))
    if row is None:
        raise MasterDataError("master_data_contact_missing", str(contact_id))
    name = row["contact_name"] if contact_name is None else str(contact_name).strip()[:120]
    if not name:
        raise MasterDataError("master_data_contact_name_required", str(row["party_id"]))
    role = row["contact_role"] if contact_role is None else str(contact_role).strip()[:80]
    new_status = row["status"] if status is None else str(status)
    if new_status not in _STATUSES:
        raise MasterDataError("master_data_status_invalid", new_status)
    normalized = normalize_identity(name)
    if normalized != row["normalized_name"] and _one(
            connection, "SELECT id FROM business_contacts WHERE party_id=? AND normalized_name=? AND id<>?",
            (int(row["party_id"]), normalized, int(contact_id))) is not None:
        raise MasterDataError("master_data_contact_exists", name)
    if (name, role, new_status) != (row["contact_name"], row["contact_role"], row["status"]):
        connection.execute(
            """UPDATE business_contacts SET contact_name=?, normalized_name=?, contact_role=?, status=?, updated_at=?
               WHERE id=?""",
            (name, normalized, role, new_status, storage_timestamp(), int(contact_id)),
        )
    return row


def update_identifier(
    connection: sqlite3.Connection, identifier_id: int, *, party_id: Any = None, status: Any = None,
) -> dict[str, Any]:
    """把一个号码改归另一个往来方，或停用 / 恢复它；返回改前的样子。"""

    row = _one(connection, "SELECT * FROM business_party_identifiers WHERE id=?", (int(identifier_id),))
    if row is None:
        raise MasterDataError("master_data_identifier_missing", str(identifier_id))
    owner = int(row["party_id"]) if party_id is None else int(party_id)
    new_status = row["status"] if status is None else str(status)
    if new_status not in _STATUSES:
        raise MasterDataError("master_data_status_invalid", new_status)
    if owner != int(row["party_id"]):
        require_active(connection, "party", owner)
    if (owner, new_status) != (int(row["party_id"]), row["status"]):
        connection.execute("UPDATE business_party_identifiers SET party_id=?, status=?, updated_at=? WHERE id=?",
                           (owner, new_status, storage_timestamp(), int(identifier_id)))
    return row


def upsert_identifier(
    connection: sqlite3.Connection,
    *,
    party_id: int,
    identifier_type: str,
    value: str,
    source_kind: str = "",
    source_ref: str = "",
    evidence: Any = None,
    confirmed_by: str = "",
    policy: MasterDataPolicy = DEFAULT_POLICY,
) -> str:
    """税号、统一信用代码、登记号、电话：一个号码只属于一个往来方。"""

    normalized = normalize_party_identifier(identifier_type, value, policy)
    if not normalized:
        raise MasterDataError("master_data_identifier_value_invalid", identifier_type)
    display = str(value or "").strip()[:80]
    evidence_json = json.dumps(evidence or {}, ensure_ascii=False, sort_keys=True)
    evidence_hash = hashlib.sha256(evidence_json.encode()).hexdigest()
    row = _one(connection, "SELECT * FROM business_party_identifiers WHERE identifier_type=? AND normalized_value=?",
               (identifier_type, normalized))
    now = storage_timestamp()
    if row is None:
        connection.execute(
            """INSERT INTO business_party_identifiers
               (party_id, identifier_type, normalized_value, display_value, status, source_kind, source_ref,
                evidence_hash, evidence_json, confirmed_by, confirmed_at, created_at, updated_at)
               VALUES (?, ?, ?, ?, 'active', ?, ?, ?, ?, ?, ?, ?, ?)""",
            (int(party_id), identifier_type, normalized, display, str(source_kind)[:60], str(source_ref)[:240],
             evidence_hash, evidence_json, str(confirmed_by)[:120], now, now, now),
        )
        return "insert"
    if int(row["party_id"]) != int(party_id):
        raise MasterDataError("master_data_identifier_owned_by_other", f"{identifier_type}:{row['party_id']}")
    if (row["display_value"], row["status"], row["evidence_hash"]) == (display, "active", evidence_hash):
        return "noop"
    connection.execute(
        """UPDATE business_party_identifiers SET display_value=?, status='active', source_kind=?, source_ref=?,
           evidence_hash=?, evidence_json=?, confirmed_by=?, confirmed_at=?, updated_at=? WHERE id=?""",
        (display, str(source_kind)[:60], str(source_ref)[:240], evidence_hash, evidence_json, str(confirmed_by)[:120],
         now, now, int(row["id"])),
    )
    return "update"


def extension_values(table: str, extensions: Any, policy: MasterDataPolicy = DEFAULT_POLICY) -> dict[str, Any]:
    """客户扩展列的取值：只收策略里为这张表声明过的列。"""

    values = dict(extensions or {})
    unknown = set(values) - set(policy.extension_columns.get(table, ()))
    if unknown:
        raise MasterDataError("master_data_attribute_unknown", f"{table}:{sorted(unknown)}")
    return values


def create_product(
    connection: sqlite3.Connection, *, canonical_name: str, product_family: str = "", extensions: Any = None,
    policy: MasterDataPolicy = DEFAULT_POLICY,
) -> int:
    extra = extension_values("products", extensions, policy)
    now = storage_timestamp()
    columns = ["canonical_name", "product_family", "status", "successor_product_id", "created_at", "updated_at", *extra]
    params = [canonical_name, product_family, "active", None, now, now, *extra.values()]
    cursor = connection.execute(
        f"INSERT INTO products ({', '.join(columns)}) VALUES ({', '.join('?' for _ in columns)})", params,
    )
    return int(cursor.lastrowid)


def create_unit(
    connection: sqlite3.Connection, *, code: str, display_name: str, dimension: str, factor_to_base: Any = None,
) -> int:
    now = storage_timestamp()
    factor = None if factor_to_base in (None, "") else str(factor_to_base)
    cursor = connection.execute(
        """INSERT INTO measurement_units (canonical_code, display_name, dimension, factor_to_base, status,
           created_at, updated_at) VALUES (?, ?, ?, ?, 'active', ?, ?)""",
        (code, display_name, dimension, factor, now, now),
    )
    return int(cursor.lastrowid)


_UPDATABLE_FIELDS = {"product": ("canonical_name", "product_family"), "unit": ("display_name", "dimension", "factor_to_base")}


def update_entity(
    connection: sqlite3.Connection, *, domain: str, entity_id: int, patch: Any, policy: MasterDataPolicy = DEFAULT_POLICY,
) -> str:
    """改产品 / 单位的资料列（含客户扩展列）；一样就零变化。"""

    fields = _UPDATABLE_FIELDS.get(domain)
    if fields is None:
        raise MasterDataError("master_data_resource_kind_invalid", domain)
    table = _ENTITY_TABLES[domain]
    values = dict(patch or {})
    extension_values(table, {key: value for key, value in values.items() if key not in fields}, policy)
    if "factor_to_base" in values and values["factor_to_base"] not in (None, ""):
        values["factor_to_base"] = str(values["factor_to_base"])
    row = entity_row(connection, domain, entity_id)
    if row is None:
        raise MasterDataError("master_data_resource_missing", f"{domain}:{entity_id}")
    changed = {key: value for key, value in values.items()
               if (None if row[key] is None else str(row[key])) != (None if value is None else str(value))}
    if not changed:
        return "noop"
    assignments = ", ".join(f"{key}=?" for key in changed)
    params = (*changed.values(), storage_timestamp(), int(entity_id))
    if domain == "product":
        connection.execute(f"UPDATE products SET {assignments}, updated_at=? WHERE id=?", params)
    else:
        connection.execute(f"UPDATE measurement_units SET {assignments}, updated_at=? WHERE id=?", params)
    return "update"


def deprecate_entity(connection: sqlite3.Connection, *, domain: str, entity_id: int) -> str:
    """停用一个产品 / 单位（往来方的停用走合并）。"""

    if domain not in _UPDATABLE_FIELDS:
        raise MasterDataError("master_data_resource_kind_invalid", domain)
    row = entity_row(connection, domain, entity_id)
    if row is None:
        raise MasterDataError("master_data_resource_missing", f"{domain}:{entity_id}")
    if row["status"] == "deprecated":
        return "noop"
    params = (storage_timestamp(), int(entity_id))
    if domain == "product":
        connection.execute("UPDATE products SET status='deprecated', updated_at=? WHERE id=?", params)
    else:
        connection.execute("UPDATE measurement_units SET status='deprecated', updated_at=? WHERE id=?", params)
    return "update"


def create_party(
    connection: sqlite3.Connection, *, canonical_name: str, legal_name: str = "", roles: Iterable[str] = (),
) -> int:
    now = storage_timestamp()
    cursor = connection.execute(
        """INSERT INTO business_parties (canonical_name, legal_name, status, successor_party_id, created_at, updated_at)
           VALUES (?, ?, 'active', NULL, ?, ?)""",
        (canonical_name, legal_name, now, now),
    )
    party_id = int(cursor.lastrowid)
    for role in dict.fromkeys(str(item).strip() for item in roles if str(item).strip()):
        ensure_role(connection, party_id=party_id, role_key=role)
    return party_id


def update_party_names(connection: sqlite3.Connection, *, party_id: int, canonical_name: str, legal_name: str) -> str:
    row = require_active(connection, "party", party_id)
    if (row["canonical_name"], row["legal_name"]) == (canonical_name, legal_name):
        return "noop"
    connection.execute(
        "UPDATE business_parties SET canonical_name=?, legal_name=?, updated_at=? WHERE id=?",
        (canonical_name, legal_name, storage_timestamp(), int(party_id)),
    )
    return "update"


def merge_party_plan(
    connection: sqlite3.Connection, *, source_party_id: int, target_party_id: int, remember_source_as_alias: bool,
) -> dict[str, Any]:
    """只读：往来方合并在主数据里要做的几件事（别名、联系人、角色、待确认名称）。"""

    source = require_active(connection, "party", source_party_id)
    target = require_active(connection, "party", target_party_id)
    if int(source["id"]) == int(target["id"]):
        raise MasterDataError("master_data_merge_same_party", str(source_party_id))
    normalized_source = normalize_identity(source["canonical_name"])
    if remember_source_as_alias and _one(
        connection,
        """SELECT id FROM master_data_aliases WHERE entity_type='party' AND normalized_alias=? AND alias_status='confirmed'
           AND entity_id NOT IN (?, ?) LIMIT 1""",
        (normalized_source, int(source["id"]), int(target["id"])),
    ) is not None:
        raise MasterDataError("master_data_alias_owned_by_other", "source name is a third party's alias")
    target_contacts = {row["normalized_name"] for row in _all(
        connection, "SELECT normalized_name FROM business_contacts WHERE party_id=?", (int(target["id"]),))}
    contact_moves = [
        {"id": int(row["id"]), "normalized_name": row["normalized_name"],
         "action": "deprecate_duplicate" if row["normalized_name"] in target_contacts else "move"}
        for row in _all(connection, "SELECT id, normalized_name FROM business_contacts WHERE party_id=? ORDER BY id",
                        (int(source["id"]),))
    ]
    alias_moves = [
        {"id": int(row["id"]), "action": "deprecate" if (not remember_source_as_alias
                                                         and row["normalized_alias"] == normalized_source) else "move"}
        for row in _all(connection, "SELECT id, normalized_alias FROM master_data_aliases WHERE entity_type='party' AND entity_id=? ORDER BY id",
                        (int(source["id"]),))
    ]
    source_roles = sorted(row["role_key"] for row in _all(
        connection, "SELECT role_key FROM business_party_roles WHERE party_id=?", (int(source["id"]),)))
    target_roles = {row["role_key"] for row in _all(
        connection, "SELECT role_key FROM business_party_roles WHERE party_id=?", (int(target["id"]),))}
    return {
        "source": {"id": int(source["id"]), "canonical_name": source["canonical_name"]},
        "target": {"id": int(target["id"]), "canonical_name": target["canonical_name"]},
        "remember_source_as_alias": bool(remember_source_as_alias),
        "alias_moves": alias_moves,
        "contact_moves": contact_moves,
        "roles_added": [role for role in source_roles if role not in target_roles],
    }


def merge_party_master_data(
    connection: sqlite3.Connection, plan: dict[str, Any], *, reviewer: str, review_note: str,
    policy: MasterDataPolicy = DEFAULT_POLICY,
) -> None:
    """按合并计划改主数据：别名、联系人、待确认名称改到新往来方，补角色，旧往来方停用并指向新的；
    要记住旧名时把旧正式名记成新往来方的别名。号码留在旧往来方。"""

    source_id, target_id = int(plan["source"]["id"]), int(plan["target"]["id"])
    for move in plan["alias_moves"]:
        if move["action"] == "deprecate":
            retire_alias(connection, move["id"])
        else:
            move_alias(connection, move["id"], target_id)
    now = storage_timestamp()
    for move in plan["contact_moves"]:
        if move["action"] == "move":
            connection.execute("UPDATE business_contacts SET party_id=? WHERE id=? AND party_id=?",
                               (target_id, move["id"], source_id))
        else:
            connection.execute("UPDATE business_contacts SET status='deprecated' WHERE id=?", (move["id"],))
    if plan["remember_source_as_alias"]:
        update_candidates(connection, domain="party", statuses=("candidate", "confirmed"), suggested_entity_id=source_id,
                          set_entity_id=target_id, set_canonical_name=plan["target"]["canonical_name"])
    for role in plan["roles_added"]:
        ensure_role(connection, party_id=target_id, role_key=role)
    connection.execute("UPDATE business_parties SET status='deprecated', successor_party_id=?, updated_at=? WHERE id=?",
                       (target_id, now, source_id))
    connection.execute("UPDATE business_parties SET updated_at=? WHERE id=?", (now, target_id))
    if plan["remember_source_as_alias"]:
        identity = party_alias_identity(connection, party_id=target_id, raw_text=plan["source"]["canonical_name"],
                                        policy=policy)
        if identity["action"] == "create_identity":
            record_alias(
                connection, entity_type="party", entity_id=target_id, alias_name=plan["source"]["canonical_name"],
                origin=f"party_merge:{source_id}->{target_id}", confidence="1",
                evidence={"reviewNote": review_note}, confirmed_by=reviewer, policy=policy,
            )


def record_governance_action(
    connection: sqlite3.Connection,
    *,
    domain: str,
    entity_id: int | str,
    label: str,
    raw_text: str,
    source_kind: str,
    source_field: str,
    before: Any,
    after: Any,
    reviewer: str,
    review_note: str = "",
    module_key: str = "master_data",
    affected_row_ids: Iterable[int] = (),
    action_key: str = "",
    normalized_text: str | None = None,
    canonical_ref: str = "",
    affected_rows: Any = None,
    affected_row_count: int | None = None,
) -> str:
    """一次主数据处理的留痕：改前、改后、谁、为什么。

    ``action_key`` 不给时新编一个；``affected_rows`` 可以给一份自定的受影响清单（如各单据表条数），
    这时 ``affected_row_count`` 一并给出。
    """

    action_key = action_key or f"mdg-{uuid.uuid4().hex}"
    if affected_rows is None:
        affected_rows = sorted({int(item) for item in affected_row_ids} or {entity_id})
    count = len(affected_rows) if affected_row_count is None else int(affected_row_count)
    connection.execute(
        """INSERT INTO master_data_governance_actions
           (action_key, module_key, source_kind, source_field, domain, raw_text, normalized_text,
            selected_canonical_ref, selected_entity_id, selected_entity_key, selected_canonical_label, affected_row_count,
            affected_row_ids_json, projection_before_json, projection_after_json, status, reviewed_by,
            review_note, reverted_at, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'applied', ?, ?, NULL, ?)""",
        (action_key, module_key, source_kind, source_field, domain, str(raw_text)[:240],
         (normalize_identity(raw_text) if normalized_text is None else str(normalized_text))[:240],
         canonical_ref or f"{domain}:{entity_id}", entity_id if isinstance(entity_id, int) else None,
         entity_id if isinstance(entity_id, str) else None, str(label)[:240],
         count, json.dumps(affected_rows, ensure_ascii=False), json.dumps(before, ensure_ascii=False, sort_keys=True),
         json.dumps(after, ensure_ascii=False, sort_keys=True), str(reviewer or "")[:120], str(review_note or ""),
         storage_timestamp()),
    )
    return action_key


def _group_state(connection, value_key: str) -> dict[str, Any] | None:
    row = connection.execute("SELECT id, status, attributes_json FROM master_data_name_values WHERE domain='name_group' "
                             "AND value_key=?", (value_key,)).fetchone()
    if row is None:
        return None
    attributes = json.loads(row[2] or "{}")
    members = [(member[0], member[1] if member[1] is not None else member[2]) for member in connection.execute(
        "SELECT member_type, member_id, member_key FROM master_data_name_group_members WHERE group_id=? ORDER BY id",
        (row[0],))]
    return {"status": row[1], "member_type": attributes.get("member_type"), "purpose": attributes.get("purpose"),
            "members": members}


def set_name_value(connection, values: dict[str, Any], *, policy: MasterDataPolicy = DEFAULT_POLICY) -> None:
    """受控目录和组目录共用一份主数据物理写者。"""
    now = storage_timestamp()
    before = _group_state(connection, values["value_key"]) if "members" in values else None
    connection.execute(
        """INSERT INTO master_data_name_values
           (domain, value_key, canonical_name, normalized_name, owner, status, attributes_json, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(domain, value_key) DO UPDATE SET canonical_name=excluded.canonical_name,
           normalized_name=excluded.normalized_name, status=excluded.status,
           attributes_json=excluded.attributes_json, updated_at=excluded.updated_at""",
        (*(values[key] for key in ("domain", "value_key", "canonical_name", "normalized_name", "owner", "status", "attributes_json")), now, now),
    )
    if "members" in values:
        group_id = connection.execute("SELECT id FROM master_data_name_values WHERE domain='name_group' AND value_key=?",
                                      (values["value_key"],)).fetchone()[0]
        connection.execute("DELETE FROM master_data_name_group_members WHERE group_id=?", (group_id,))
        for item in values["members"]:
            connection.execute(
                "INSERT INTO master_data_name_group_members (group_id, member_type, member_id, member_key) VALUES (?, ?, ?, ?)",
                (group_id, item["domain"], item["id"] if isinstance(item["id"], int) else None,
                 item["id"] if isinstance(item["id"], str) else None),
            )
        if policy.on_group_members_changed is not None:
            # 完整改前/改后（启停、成员类型、用途、带类型的成员）交给登记的派生投影，各自只认自己的实体。
            policy.on_group_members_changed(connection, values["value_key"], before,
                                            _group_state(connection, values["value_key"]))


def propose_name_alias(connection, values: dict[str, Any]) -> None:
    key, now = values["entity_id"], storage_timestamp()
    connection.execute(
        """INSERT INTO master_data_alias_candidates
        (domain, raw_text, normalized_text, suggested_entity_type, suggested_entity_id, suggested_entity_key,
         suggested_canonical_name, business_role, source_kind, source_key, source_scope, agent_name,
         strong_anchors_json, evidence_json, status, reviewed_by, review_note, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, '', '', 'name_proposal', ?, ?, '', '[]', '{}', 'candidate', '', '', ?, ?)""",
        (values["domain"], values["raw_text"], values["normalized_text"], values["domain"],
         key if isinstance(key, int) else None, key if isinstance(key, str) else None,
         values["source_key"], values["source_scope"], now, now),
    )


def set_governance_projection_after(connection: sqlite3.Connection, action_keys: Iterable[str], after: Any) -> None:
    """一批处理全部做完后，把它们留痕里的“改后”补成整批做完的样子。"""

    payload = json.dumps(after, ensure_ascii=False, sort_keys=True)
    for key in action_keys:
        connection.execute("UPDATE master_data_governance_actions SET projection_after_json=? WHERE action_key=?",
                           (payload, str(key)))


__all__ = [
    "PARTY_IDENTIFIER_TYPES",
    "alias_entity_types",
    "create_party",
    "create_product",
    "create_unit",
    "delete_alias",
    "deprecate_entity",
    "ensure_role",
    "entity_row",
    "extension_values",
    "merge_party_master_data",
    "move_alias",
    "merge_party_plan",
    "normalize_party_identifier",
    "party_alias_identity",
    "record_alias",
    "record_governance_action",
    "remember_confirmed_alias",
    "remember_decision",
    "require_active",
    "require_alias_identity",
    "retire_alias",
    "set_alias_status",
    "set_governance_projection_after",
    "update_candidates",
    "update_contact",
    "update_entity",
    "update_identifier",
    "update_party_names",
    "upsert_contact",
    "upsert_identifier",
]
