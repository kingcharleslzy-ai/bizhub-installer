"""Small customer-neutral helpers shared by procurement and sales."""

from __future__ import annotations

import hashlib
import json
import sqlite3
from zoneinfo import ZoneInfo
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta, timezone
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP, ROUND_HALF_EVEN
from typing import Any, Iterable, Literal, Mapping, Sequence


BUSINESS_TIMEZONE = "Asia/Shanghai"


class TradeRuleError(ValueError):
    """A customer-neutral trade invariant is not satisfied."""

    def __init__(self, message: str = "", *, risk_code: str | None = None) -> None:
        super().__init__(message)
        # 写入程序自报的审核原因，接住异常转成结果的地方原样带出（不再按错误字眼归类）。
        self.risk_code = risk_code


def bind_command_fields(
    fields: Mapping[str, Any],
    *,
    allowed_fields: Iterable[str],
    server_fields: Mapping[str, Any],
) -> dict[str, Any]:
    """Bind trusted source identity without accepting caller overrides."""
    if set(fields) - set(allowed_fields) or set(fields) & set(server_fields):
        raise TradeRuleError("trade_command_fields_invalid")
    return {**fields, **server_fields}


def check_decimal_range(value: Decimal, code: str) -> Decimal:
    if value.adjusted() >= 18 or value.as_tuple().exponent < -4:
        raise TradeRuleError(code)
    return value


from backend.kernel.runtime.quantity_parser import decimal_context, decimal_sum

from backend.kernel.runtime.quantity_parser import DecimalSpec, canonical_decimal_text, quantize_decimal

PROCESSING_OPERATIONS = ("coating", "polishing", "polishing_and_coating", "not_indicated", "unknown")


def processing_output_state(operation, *, confirmed=None, default=None):
    """人工已定状态优先；加工动作决定产出，不能被规范化默认值盖掉。"""
    if confirmed in {"coated", "uncoated"}:
        return confirmed
    if operation not in (*PROCESSING_OPERATIONS, None, ""):
        raise ValueError("processing_operation_invalid")
    return {"coating": "coated", "polishing": "uncoated",
        "polishing_and_coating": "coated"}.get(operation, default)

_NUMERIC_SCALE_2_EVEN = DecimalSpec("scale_2", 2, rounding=ROUND_HALF_EVEN, signed_zero=True)
_NUMERIC_SCALE_2_UP = DecimalSpec("scale_2", 2, rounding=ROUND_HALF_UP, signed_zero=True)


def strict_money(value: object, *, allow_zero: bool = False,
                 invalid_code: str, range_code: str, precision_code: str) -> Decimal:
    try:
        amount = quantity_decimal(value, allow_zero=allow_zero)
    except TradeRuleError as exc:
        raise TradeRuleError(invalid_code) from exc
    check_decimal_range(amount, range_code)
    rounded = quantize_decimal(amount, _NUMERIC_SCALE_2_EVEN)
    if rounded != amount:
        raise TradeRuleError(precision_code)
    return rounded


def money(value: object) -> Decimal:
    """Two decimal places, ROUND_HALF_UP, as every money column stores it."""

    try:
        parsed = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise TradeRuleError("trade_amount_invalid", risk_code="numeric_closure_failed") from exc
    if not parsed.is_finite():
        raise TradeRuleError("trade_amount_invalid", risk_code="numeric_closure_failed")
    return quantize_decimal(parsed, _NUMERIC_SCALE_2_UP)


def _allocation_decimal(value: object, *, code: str) -> Decimal:
    if isinstance(value, Decimal):
        parsed = value
    else:
        try:
            parsed = Decimal(str(value))
        except (InvalidOperation, TypeError, ValueError) as exc:
            raise TradeRuleError(code) from exc
    if not parsed.is_finite() or parsed < 0:
        raise TradeRuleError(code)
    return parsed


def allocation_headroom(total: object, allocated: object, *, tolerance: object = 0) -> Decimal:
    """How much more one target still accepts: ``max(0, total + tolerance - allocated)``.

    The hard-stop reading of allocation (money may never be over-allocated):
    ``tolerance`` widens the target itself, it never lets the sum of
    allocations pass ``total + tolerance``.
    """

    total_d = _allocation_decimal(total, code="trade_total_invalid")
    allocated_d = _allocation_decimal(allocated, code="trade_allocated_invalid")
    tolerance_d = _allocation_decimal(tolerance, code="trade_tolerance_invalid")
    return max(Decimal("0"), total_d + tolerance_d - allocated_d)


def allocation_exceeded(
    total: object,
    allocated: object,
    requested: object,
    *,
    tolerance: object = 0,
) -> bool:
    """Whether ``requested`` moves more than the target still accepts.

    Same rule as :func:`allocation_headroom`: ``tolerance`` widens the
    target itself, it never lets the sum of allocations pass
    ``total + tolerance``.
    """

    requested_d = _allocation_decimal(requested, code="trade_requested_invalid")
    return requested_d > allocation_headroom(total, allocated, tolerance=tolerance)


def canonical_json(payload: object) -> bytes:
    return (
        json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        + "\n"
    ).encode()


def digest_json(payload: object) -> str:
    return hashlib.sha256(canonical_json(payload)).hexdigest()


def quantity_decimal(value: object, *, allow_zero: bool = False) -> Decimal:
    try:
        parsed = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise TradeRuleError("trade_quantity_invalid", risk_code="numeric_closure_failed") from exc
    if not parsed.is_finite() or parsed < 0 or (not allow_zero and parsed == 0):
        raise TradeRuleError(
            "trade_quantity_must_be_nonnegative"
            if allow_zero
            else "trade_quantity_must_be_positive"
        )
    return parsed


def normalized_evidence_refs(values: Iterable[object]) -> tuple[str, ...]:
    refs = tuple(str(value).strip() for value in values)
    if not refs or any(not value for value in refs):
        raise TradeRuleError("trade_evidence_ref_required")
    if len(set(refs)) != len(refs):
        raise TradeRuleError("trade_evidence_ref_duplicate")
    return refs


def project_order_progress(
    *,
    ordered_quantity: object,
    completed_quantity: object,
    returned_quantity: object = 0,
    cancelled: bool = False,
) -> str:
    """Project a neutral order-line state without customer-specific policy."""

    ordered = quantity_decimal(ordered_quantity)
    completed = quantity_decimal(completed_quantity, allow_zero=True)
    returned = quantity_decimal(returned_quantity, allow_zero=True)
    if returned > completed:
        raise TradeRuleError("trade_return_exceeds_completed")
    if completed > ordered:
        raise TradeRuleError("trade_completion_exceeds_ordered")
    if cancelled:
        return "cancelled"
    if returned == completed and completed > 0:
        return "returned"
    if returned > 0:
        return "partially_returned"
    if completed == ordered:
        return "completed"
    if completed > 0:
        return "partial"
    return "open"


def aggregate_order_progress(states: Iterable[str]) -> str:
    values = tuple(states)
    if not values:
        raise TradeRuleError("trade_order_lines_required")
    if all(value == "cancelled" for value in values):
        return "cancelled"
    if all(value == "completed" for value in values):
        return "completed"
    if all(value == "returned" for value in values):
        return "returned"
    if any(value in {"partially_returned", "returned"} for value in values):
        return "partially_returned"
    if any(value in {"partial", "completed"} for value in values):
        return "partial"
    return "open"


@dataclass(frozen=True)
class FlowTally:
    """Upstream quantity (plan, dispatch) against what downstream settled."""

    planned: Decimal
    settled: Decimal
    fulfilled: Decimal
    over: Decimal
    cancelled: Decimal
    remaining: Decimal
    state: str


def tally_flow(
    planned: object,
    settled: Iterable[object] = (),
    *,
    cancelled: object = 0,
    tolerance: object = 0,
    shortfall_tolerance: object = 0,
) -> FlowTally:
    """remaining = planned - settled - cancelled (>= 0); over-settling completes.

    A remainder within ``tolerance`` (or, once something was settled, within
    ``shortfall_tolerance``) is zero.  States: open/partial/completed/cancelled.
    """

    plan = _lenient_decimal(planned) or Decimal("0")
    total = sum((_lenient_decimal(v) or Decimal("0") for v in settled), Decimal("0"))
    cancel = _lenient_decimal(cancelled) or Decimal("0")
    tol = _lenient_decimal(tolerance) or Decimal("0")
    shortfall = max(tol, _lenient_decimal(shortfall_tolerance) or Decimal("0"))
    remaining = max(Decimal("0"), plan - total - cancel)
    if remaining <= tol or (total > tol and remaining <= shortfall):
        remaining = Decimal("0")
    if remaining == 0:
        state = "cancelled" if cancel > 0 and total <= tol else "completed"
    else:
        state = "partial" if total > tol else "open"
    return FlowTally(
        planned=plan,
        settled=total,
        fulfilled=min(plan, total),
        over=max(Decimal("0"), total - plan),
        cancelled=cancel,
        remaining=remaining,
        state=state,
    )


# ---------------------------------------------------------------- 前序单配对
# 前序单配对：后续单（委外回收、退货……）按物品和数量认回一张还没收完的前序单（委外发出、发货……）。
#
# 同 ERPNext 委外收货认 Subcontracting Order 行、Odoo 收货认原移动（``move_orig_ids``）：
#
# - 能认的前序单：物品对得上、还开着、发出日不晚于本次、剩余量吸收得了本次数量；
#   企业要求时还得是同一往来方。
# - 恰好一张就认；一张没有就转人工；几张都能认时按企业参数：转人工（默认），或先发先回认最早一张。
# - 剩余量 = 发出 − 已回（含次品、损耗）；已回过一部分、差额不超过发出量 × 容差的，按收完闭合
#   （差额当加工损耗）。前序单的状态和剩余量都用这一条算。
# - 人指定前序单走单据内核的 ``relate``（值班台“连到这张前序单”），不经这里。
#
# 物品怎么算“对得上”由客户给（规格、规格族、晶体类型……），本模块只管选哪张。

FIRST_SENT = "first_sent"
MANUAL = "manual"


@dataclass(frozen=True)
class PredecessorRule:
    """企业参数：只认同一往来方、闭合容差（发出量的比例）、几张都能认时怎么办。"""

    same_party_only: bool = True
    shortfall_tolerance: Decimal = Decimal("0")
    when_several: Literal["manual", "first_sent"] = MANUAL


@dataclass(frozen=True)
class PredecessorCandidate:
    key: int
    sent_date: date | None
    party_id: int | None
    remaining: Decimal
    is_open: bool
    item_matches: bool


@dataclass(frozen=True)
class PredecessorPick:
    """``status``：``resolved`` 认上 ``key``；``none`` 没有能认的；``several`` 几张都能认、按参数转人工。"""

    status: str
    key: int | None
    eligible: tuple[int, ...]


def predecessor_tally(rule: PredecessorRule, sent: object, settled: Iterable[object]) -> FlowTally:
    """前序单的剩余量和状态（open / partial / completed），闭合容差按本企业参数。"""

    planned = Decimal(str(sent or 0))
    return tally_flow(planned, settled, shortfall_tolerance=rule.shortfall_tolerance * planned)


def processing_defect_quantity(rule: PredecessorRule, sent: object, settled: Iterable[object]) -> Decimal:
    """容差内闭合的缺口只作读侧损耗展示，不产生写账事实。"""
    tally = predecessor_tally(rule, sent, settled)
    return max(Decimal(0), tally.planned - tally.settled) if tally.settled > 0 and tally.remaining == 0 else Decimal(0)


def eligible_predecessor(
    rule: PredecessorRule, candidate: PredecessorCandidate, *, quantity: Decimal, on: date, party_id: int | None
) -> bool:
    return bool(
        candidate.item_matches
        and candidate.is_open
        and quantity > 0
        and candidate.sent_date is not None
        and candidate.sent_date <= on
        and candidate.remaining >= quantity
        and (not rule.same_party_only or (party_id is not None and candidate.party_id == party_id))
    )


def pick_predecessor(
    rule: PredecessorRule,
    candidates: Sequence[PredecessorCandidate],
    *,
    quantity: Decimal,
    on: date,
    party_id: int | None = None,
) -> PredecessorPick:
    eligible = sorted(
        (item for item in candidates if eligible_predecessor(rule, item, quantity=quantity, on=on, party_id=party_id)),
        key=lambda item: (item.sent_date, item.key),
    )
    keys = tuple(item.key for item in eligible)
    if not eligible:
        return PredecessorPick("none", None, keys)
    if len(eligible) == 1 or rule.when_several == FIRST_SENT:
        return PredecessorPick("resolved", eligible[0].key, keys)
    return PredecessorPick("several", None, keys)


def _lenient_decimal(value: Any) -> Decimal | None:
    if value in (None, ""):
        return None
    try:
        return Decimal(str(value).replace(",", "").strip())
    except (InvalidOperation, ValueError):
        return None


def _local_datetime(value: Any, *, tz: timezone, cutoff: time) -> datetime | None:
    if isinstance(value, datetime):
        parsed = value
    elif isinstance(value, date):
        parsed = datetime.combine(value, cutoff, tzinfo=tz)
    else:
        text = str(value or "").strip()
        if not text:
            return None
        if len(text) == 10:
            try:
                return datetime.combine(date.fromisoformat(text), cutoff, tzinfo=tz)
            except ValueError:
                return None
        try:
            parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
        except ValueError:
            return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=tz)
    return parsed.astimezone(tz)


def derive_due_at(
    received_at: Any,
    explicit_due_at: Any = None,
    *,
    tz: timezone,
    cutoff: time,
    same_day_source: str = "same_day_cutoff",
    next_day_source: str = "next_day_default",
    explicit_source: str = "explicit_order_due",
) -> tuple[datetime | None, str | None]:
    """Derive an order due moment from a business timezone and cutoff.

    ``tz`` is the business timezone and ``cutoff`` the daily cutoff time used
    both as the due-moment time-of-day and as the same-day/next-day boundary.
    ``same_day_source``/``next_day_source``/``explicit_source`` label the
    returned due-source. All customer policy is supplied by the caller.
    """

    explicit = _local_datetime(explicit_due_at, tz=tz, cutoff=cutoff)
    if explicit is not None:
        return explicit, explicit_source
    received = _local_datetime(received_at, tz=tz, cutoff=cutoff)
    if received is None:
        return None, None
    same_day = received.time() < cutoff
    due_date = received.date() if same_day else received.date() + timedelta(days=1)
    source = same_day_source if same_day else next_day_source
    return datetime.combine(due_date, cutoff, tzinfo=tz), source


def exact_duplicate_indexes(
    records: Iterable[dict[str, Any]],
    *,
    key_fields: Sequence[Sequence[str]],
    quantity_field: str = "quantity",
    date_positions: Sequence[int] = (),
) -> list[int]:
    """Return indexes of records that exactly duplicate an earlier record.

    ``key_fields`` lists, per key position, the field names that may carry that
    dimension (first non-empty wins). Positions listed in ``date_positions``
    are truncated to their first 10 characters. ``quantity_field`` names the
    field compared numerically after comma-stripping decimal normalization;
    text positions are stripped and casefolded. Records with any empty key
    component are skipped.
    """

    date_positions = set(date_positions)
    seen: set[tuple[str, ...]] = set()
    duplicates: list[int] = []
    for index, row in enumerate(records):
        quantity = _lenient_decimal(row.get(quantity_field))
        components: list[str] = []
        for position, fields in enumerate(key_fields):
            value: Any = None
            for field in fields:
                value = row.get(field)
                if value:
                    break
            text = str(value or "")
            if position in date_positions:
                components.append(text[:10])
            else:
                components.append(text.strip().casefold())
        key = (*components, canonical_decimal_text(quantity, notation="normalized", signed_zero=True) if quantity is not None else "")
        if not all(key):
            continue
        if key in seen:
            duplicates.append(index)
        else:
            seen.add(key)
    return duplicates


@dataclass(frozen=True)
class MatchResult:
    """One pairing attempt over candidates: only a unique survivor is a match.

    ``candidates`` carries the surviving candidates (after the key, date
    window and quantity filters) so a caller may run its own fallback
    heuristic on them instead of re-filtering.
    """

    status: str  # "matched" | "ambiguous" | "missing"
    item: Any = None
    candidates: tuple[Any, ...] = ()


def unique_match(
    candidates: Iterable[Any],
    *,
    key: Any,
    on_date: Any,
    before_days: int,
    after_days: int,
    quantity: object = None,
    tolerance: object = 0,
    quantity_of: Any,
    date_of: Any,
) -> MatchResult:
    """Pair one fact to the unique candidate that carries it (reconcile model).

    ``key`` is a predicate selecting the candidates that carry the same
    pairing key.  A candidate survives when its date (``date_of``) falls in
    ``[on_date - before_days, on_date + after_days]`` (day granularity; a
    datetime contributes its date) and, when ``quantity`` is not None, its
    quantity (``quantity_of``) differs from it by at most ``tolerance`` in
    absolute value (a candidate without a readable quantity never survives a
    quantity filter).  Exactly one survivor is ``matched``; none is
    ``missing``; more than one is ``ambiguous``.
    """

    if not isinstance(on_date, datetime) and not isinstance(on_date, date):
        raise TradeRuleError("trade_match_date_invalid")
    anchor = on_date.date() if isinstance(on_date, datetime) else on_date
    target = _lenient_decimal(quantity)
    allowed = _lenient_decimal(tolerance) or Decimal("0")
    survivors: list[Any] = []
    for item in candidates:
        if not key(item):
            continue
        item_date = date_of(item)
        if not isinstance(item_date, datetime) and not isinstance(item_date, date):
            continue
        item_day = item_date.date() if isinstance(item_date, datetime) else item_date
        if not (anchor - timedelta(days=int(before_days)) <= item_day <= anchor + timedelta(days=int(after_days))):
            continue
        if target is not None:
            item_quantity = _lenient_decimal(quantity_of(item))
            if item_quantity is None or abs(item_quantity - target) > allowed:
                continue
        survivors.append(item)
    if len(survivors) == 1:
        return MatchResult(status="matched", item=survivors[0], candidates=tuple(survivors))
    if not survivors:
        return MatchResult(status="missing", candidates=())
    return MatchResult(status="ambiguous", candidates=tuple(survivors))


OUTSTANDING_REMINDER_MODES = {
    "off": "全部不提醒",
    "all": "全部提醒",
    "parties": "只提醒指定的客户或供应商",
    "documents": "只提醒指定的单据",
}


@dataclass(frozen=True)
class OutstandingReminderSwitch:
    """单据未结清提醒的开关（销售没收款、采购没付款、外发加工没对账共用）。

    结清状态始终显示在单据上；这里只决定要不要报到值班台。由各企业在自己的配置里给，默认全部不提醒。
    ``parties`` 是往来方正式名，``documents`` 是单据行号（如 ``coating_orders:44``）。
    """

    mode: str = "off"
    parties: tuple[str, ...] = ()
    documents: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if self.mode not in OUTSTANDING_REMINDER_MODES:
            raise TradeRuleError(f"outstanding_reminder_mode_invalid:{self.mode}")

    @property
    def label(self) -> str:
        names = self.parties if self.mode == "parties" else self.documents if self.mode == "documents" else ()
        return OUTSTANDING_REMINDER_MODES[self.mode] + (f"（{'、'.join(names)}）" if names else "")

    def applies(self, *, party: str | None, document: str) -> bool:
        return (self.mode == "all" or (self.mode == "parties" and str(party or "") in self.parties)
                or (self.mode == "documents" and document in self.documents))


__all__ = [
    "FlowTally",
    "MatchResult",
    "OUTSTANDING_REMINDER_MODES",
    "OutstandingReminderSwitch",
    "TradeRuleError",
    "aggregate_order_progress",
    "allocation_exceeded",
    "allocation_headroom",
    "bind_command_fields",
    "business_datetime",
    "movement_references",
    "canonical_json",
    "check_decimal_range",
    "decimal_context",
    "decimal_sum",
    "strict_money",
    "derive_due_at",
    "digest_json",
    "exact_duplicate_indexes",
    "money",
    "normalized_evidence_refs",
    "project_order_progress",
    "quantity_decimal",
    "tally_flow",
    "unique_match",
    "PredecessorCandidate",
    "PredecessorPick",
    "PredecessorRule",
    "pick_predecessor",
    "predecessor_tally",
    "processing_defect_quantity",
]


def business_datetime(value: object) -> datetime:
    """Parse an ISO date or aware ISO timestamp in the shared business timezone."""
    if not isinstance(value, str):
        raise TradeRuleError("trade_time_invalid")
    text = value.strip()
    if text != value:
        raise TradeRuleError("trade_time_invalid")
    try:
        if len(text) == 10 and date.fromisoformat(text).isoformat() == text:
            parsed = _local_datetime(text, tz=ZoneInfo(BUSINESS_TIMEZONE), cutoff=time.min)
        else:
            # fromisoformat also accepts arbitrary Unicode separators. Keep
            # the standard ISO separator and the existing SQL-space form.
            if text[10:11] not in {"T", "t", " "}:
                raise ValueError("ISO date/time separator required")
            stamp = datetime.fromisoformat(text)
            if stamp.tzinfo is None or stamp.utcoffset() is None:
                raise ValueError("timezone required")
            parsed = _local_datetime(stamp, tz=ZoneInfo(BUSINESS_TIMEZONE), cutoff=time.min)
        if parsed is None:
            raise ValueError("ISO date required")
        return parsed
    except (ValueError, OverflowError) as exc:
        raise TradeRuleError("trade_time_invalid") from exc


def movement_references(connection: sqlite3.Connection, movement_id: str) -> list[dict[str, object]]:
    """Read all persisted document references using the schema's foreign keys.

    No dependency on a trade module is needed, including optional future modules.
    Inventory's own reversal relation is handled by its Owner.
    """
    references = []
    def quote(name: str) -> str:
        return '"' + name.replace('"', '""') + '"'
    for (table,) in connection.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"):
        if table == "material_inventory_events":
            continue
        columns = list(connection.execute(f"PRAGMA table_info({quote(table)})"))
        primary = [row[1] for row in columns if row[5]]
        for fk in connection.execute(f"PRAGMA foreign_key_list({quote(table)})"):
            if fk[2] != "material_inventory_events" or fk[4] != "movement_id":
                continue
            for row in connection.execute(f"SELECT * FROM {quote(table)} WHERE {quote(fk[3])}=?", (movement_id,)):
                record = dict(row)
                identity = {key: record[key] for key in primary}
                references.append({"document_type": table,
                                   "document_id": next(iter(identity.values())) if len(identity) == 1 else identity,
                                   **{key: record[key] for key in ("order_id", "document_id", "fulfillment_kind") if key in record}})
    return references


# Explicit public composition surface; lazy loading also permits direct imports
# of the implementation module without a partial-initialization cycle.
_REVERSAL_EXPORTS = frozenset({
    "TradeNumericTools", "TradeReversalCommand", "TradeReversalPreview", "apply_reversal",
    "preview_reversal", "reversal_documents", "reversed_movement", "target_voided",
    "reconciliation_reversal_blockers",
})
__all__ += sorted(_REVERSAL_EXPORTS)
__all__ += ["PROCESSING_OPERATIONS", "processing_output_state"]
from .tax_invoice_effectiveness import (
    INEFFECTIVE_TAX_INVOICE_RISK_TOKENS,
    INEFFECTIVE_TAX_INVOICE_STATUS_TOKENS,
    tax_invoice_is_effective,
)
__all__ += ["INEFFECTIVE_TAX_INVOICE_RISK_TOKENS", "INEFFECTIVE_TAX_INVOICE_STATUS_TOKENS", "tax_invoice_is_effective"]
from .reference_comparison import (
    StageRows, MAX_ROWS_PER_LINK, MAX_DIFFERENCE_ROWS,
    _link as reference_link, _coverage_link as reference_coverage_link,
)
__all__ += ["StageRows", "MAX_ROWS_PER_LINK", "MAX_DIFFERENCE_ROWS", "reference_link", "reference_coverage_link"]


def __getattr__(name):
    if name in _REVERSAL_EXPORTS:
        from . import reversal
        return getattr(reversal, name)
    raise AttributeError(name)

from .statement_reconciliation import compare_statement_sheet, parse_statement_number
