"""Request-scoped SQLite waiting budget; transaction authority stays with callers.

Uses sqlite3's supported Connection factory and native busy handler. Outside a
HTTP storage scope connections retain their existing timeout semantics.
"""
from __future__ import annotations

import asyncio
import sqlite3
import time
import uuid
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass
from os import PathLike
from typing import Any, Callable, Iterator


class StorageBusy(sqlite3.OperationalError):
    """No remaining storage waiting budget."""


@dataclass
class StorageBudget:
    remaining: float
    deadline: float | None = None
    cancelled: bool = False

    def available(self) -> float:
        if self.cancelled:
            raise StorageBusy("storage request cancelled")
        value = self.remaining
        if self.deadline is not None:
            value = min(value, self.deadline - time.monotonic())
        if value <= 0:
            raise StorageBusy("storage waiting budget exhausted")
        return value


STORAGE_BUDGET: ContextVar[StorageBudget | None] = ContextVar("sqlite_storage_budget", default=None)


class BudgetConnection(sqlite3.Connection):
    """Adapt the existing Generic execute/commit connection paths, not cursors."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._budget = STORAGE_BUDGET.get()
        self._closed = False
        self._initializing = True
        try:
            self._busy_timeout = int(super().execute("PRAGMA busy_timeout").fetchone()[0])
        except BaseException:
            self.close()
            raise

    def _call(self, operation, *args):
        if self._budget is None:
            return operation(*args)
        try:
            available = self._budget.available()
        except StorageBusy:
            super().rollback()
            if self._initializing:
                self.close()
            raise
        if args and isinstance(args[0], str) and not args[0].strip().upper().startswith("PRAGMA"):
            self._initializing = False
        super().execute(f"PRAGMA busy_timeout={min(self._busy_timeout, max(0, int(available * 1000)))}")
        started = time.monotonic()
        try:
            return operation(*args)
        except sqlite3.Error:
            # No thread is abandoned: the caller observes failure only after
            # the native statement finishes and its transaction is rolled back.
            super().rollback()
            if self._initializing:
                self.close()
            raise
        finally:
            self._budget.remaining -= time.monotonic() - started

    def execute(self, sql, parameters=(), /):
        if sql.strip().lower().startswith("pragma busy_timeout="):
            self._busy_timeout = int(sql.split("=", 1)[1].strip().rstrip(";"))
        return self._call(super().execute, sql, parameters)

    def rollback(self):
        if not self._closed:
            return super().rollback()
        return None

    def close(self):
        if not self._closed:
            super().close()
            self._closed = True

    def commit(self):
        if self._closed or not self.in_transaction:
            return None
        return self._call(super().commit)

    def __exit__(self, exc_type, exc_value, traceback):
        # sqlite3's C __exit__ would bypass the Python commit override.
        try:
            if exc_type is not None:
                self.rollback()
            else:
                self.commit()
            return False
        finally:
            self.close()


def connect(database, **kwargs) -> sqlite3.Connection:
    budget = STORAGE_BUDGET.get()
    if budget is not None:
        budget.available()  # Reject a queued request before opening a connection.
        kwargs["factory"] = BudgetConnection
    return sqlite3.connect(database, **kwargs)


async def wait_for_storage_retry(delay: float) -> None:
    """Charge existing cooperative zero-timeout lock retries to this request."""
    budget = STORAGE_BUDGET.get()
    if budget is None:
        await asyncio.sleep(delay)
        return
    available = budget.available()
    started = time.monotonic()
    try:
        await asyncio.sleep(min(delay, available))
    finally:
        budget.remaining -= time.monotonic() - started
    budget.available()



class StorageTransactionRequired(RuntimeError):
    """A lent transaction must already be open before an Owner writes in it."""


class BoundStorage:
    """The caller's open SQLite transaction, lent to one synchronous Owner unit.

    The caller keeps BEGIN/COMMIT/ROLLBACK. An Owner write runs in a savepoint,
    so its failure undoes only its own statements; reads run with query_only.
    """

    def __init__(self, connection: Any):
        self.connection = connection

    @contextmanager
    def reading(self) -> Iterator[Any]:
        connection = self.connection
        previous = int(connection.execute("PRAGMA query_only").fetchone()[0])
        started = not connection.in_transaction
        connection.execute("PRAGMA query_only=ON")
        try:
            if started:
                # One snapshot for composite readbacks, as an Owner's own file read does.
                connection.execute("BEGIN")
            try:
                yield connection
            finally:
                if started and connection.in_transaction:
                    connection.execute("COMMIT")
        finally:
            connection.execute(f"PRAGMA query_only={previous}")

    @contextmanager
    def writing(self) -> Iterator[Any]:
        connection = self.connection
        if not connection.in_transaction:
            # A savepoint outside a transaction would commit on RELEASE.
            raise StorageTransactionRequired("the lending caller must open a write transaction first")
        name = f"owner_unit_{uuid.uuid4().hex}"
        connection.execute(f"SAVEPOINT {name}")
        try:
            yield connection
        except BaseException as error:
            try:
                if connection.in_transaction:
                    connection.execute(f"ROLLBACK TO SAVEPOINT {name}")
                    connection.execute(f"RELEASE SAVEPOINT {name}")
            except BaseException as cleanup_error:
                if isinstance(error, asyncio.CancelledError):
                    raise error from cleanup_error
                raise
            raise
        connection.execute(f"RELEASE SAVEPOINT {name}")


StorageTarget = str | PathLike | BoundStorage


@contextmanager
def read_storage(storage: StorageTarget, connect: Callable[[Any], Any]) -> Iterator[Any]:
    """Yield a read connection: the Owner's own file, or the lent transaction."""
    if isinstance(storage, BoundStorage):
        with storage.reading() as connection:
            yield connection
        return
    connection = connect(storage)
    try:
        yield connection
    finally:
        connection.close()


@contextmanager
def write_storage(storage: StorageTarget, connect: Callable[[Any], Any]) -> Iterator[Any]:
    """One atomic Owner write unit in its own file or the lent transaction."""
    if isinstance(storage, BoundStorage):
        with storage.writing() as connection:
            yield connection
        return
    connection = connect(storage)
    try:
        connection.execute("BEGIN IMMEDIATE")
        yield connection
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()
