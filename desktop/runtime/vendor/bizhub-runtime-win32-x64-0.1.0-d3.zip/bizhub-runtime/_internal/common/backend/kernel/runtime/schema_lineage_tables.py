"""Which tables the platform migration line owns (names only, no SQLAlchemy).

Kept apart from ``schema_lineage_platform`` so a lineage that must not load
SQLAlchemy (the generic small backend) can still tell the platform line's
tables from its own.
"""

from __future__ import annotations


PLATFORM_LINEAGE_ID = "platform-core"
PLATFORM_MIGRATION_TABLE = "bizhub_platform_schema_migrations"

# Model tables every Profile's full backend builds: the kernel.* / platform.* module
# tables and the generic modules' tables the platform line claimed (v4 on).
PLATFORM_MODEL_TABLES = (
    "attendance_daily_records",
    "attendance_import_batches",
    "attention_occurrence_states",
    "attention_recheck_dirty_modules",
    "bank_transaction_invoice_allocations",
    "bank_transaction_settlement_links",
    "bank_transactions",
    "business_agent_decisions",
    "business_agent_review_experience_events",
    "business_agent_source_cluster_members",
    "business_agent_source_clusters",
    "business_data_revisions",
    "business_document_links",
    "business_document_versions",
    "business_documents",
    "business_edit_overrides",
    "business_evidence_assets",
    "business_evidence_documents",
    "business_message_presentations",
    "dashboard_director_briefs",
    "dashboard_overview_snapshots",
    "dashboard_snapshot_dirty",
    "director_pinned_views",
    "director_unresolved_phrases",
    "electricity_accounts",
    "electricity_balance_snapshots",
    "electricity_bill_details",
    "electricity_daily_usages",
    "electricity_monthly_summaries",
    "electricity_sync_batches",
    "group_agent_run_claims",
    "group_agent_runtime_states",
    "inventory_stocktake_records",
    "item_measurements",
    "item_observation_batches",
    "item_placements",
    "mail_agent_runs",
    "mail_attachments",
    "mail_business_links",
    "mail_messages",
    "mail_review_decisions",
    "office_daily_reports",
    "pwa_push_deliveries",
    "pwa_push_subscriptions",
    "resident_ai_action_logs",
    "resident_ai_feedback",
    "resident_ai_observations",
    "sales_order_evidence_document_links",
    "supervisor_health_snapshots",
    "supervisor_messages",
    "supervisor_runtime_states",
    "supervisor_wechat_events",
    "tax_invoice_evidence_links",
    "tax_invoices",
    "wechat_messages",
    "wechat_parse_reviews",
    "wechat_parse_tasks",
    "wechat_ui_failures",
    "workflow_artifacts",
    "workflow_business_links",
    "workflow_definitions",
    "workflow_runs",
    "workflow_steps",
)
# Tables without a model: their writers use the DDL below directly.
PLATFORM_RAW_TABLES = (
    "auth_legacy_password_bindings",
    "auth_revoked_sessions",
    "business_agent_source_funnel_cutovers",
)
PLATFORM_TABLES = PLATFORM_MODEL_TABLES + PLATFORM_RAW_TABLES
# Tables this line owned and retired (dropped by a platform migration; no model any more).
PLATFORM_RETIRED_TABLES = ("director_view_aliases",)


__all__ = [
    "PLATFORM_LINEAGE_ID",
    "PLATFORM_MIGRATION_TABLE",
    "PLATFORM_MODEL_TABLES",
    "PLATFORM_RAW_TABLES",
    "PLATFORM_RETIRED_TABLES",
    "PLATFORM_TABLES",
]
