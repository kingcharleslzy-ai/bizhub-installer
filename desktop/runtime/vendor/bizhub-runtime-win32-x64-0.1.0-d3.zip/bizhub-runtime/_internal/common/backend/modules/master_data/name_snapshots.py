"""已登记名称类型的进程快照与类型化叫法读写（通用机制；企业只交类型登记、目录、策略和数据）。

``NameAliasSnapshot``：按（类型, 用途）保存严格批量投影，只有调用方明确发布才替换，且只认同一数据库身份；
同步读取方拿实时只读视图，查找用格式键。``ProvidedNameAliases``：类型化的叫法读写（新叫法 ``record_alias``、
改指 ``correct_alias``、证据只改证据），学习策略由调用方决定；会话内读写由调用方传入的执行器完成。
"""

from __future__ import annotations

import json
from collections.abc import Mapping as _MappingABC
from typing import Any, Awaitable, Callable, Iterable, Mapping

from . import commands, lookup, writes
from .matching import normalize_identity
from .policy import MasterDataPolicy


class NameAliasSnapshot:
    def __init__(self) -> None:
        self._published: dict[tuple[str, str], Mapping[str, Any]] = {}
        self._identity: str | None = None

    @staticmethod
    def build(connection, keys: Iterable[tuple[str, str]], policy: MasterDataPolicy) -> dict[tuple[str, str], dict[str, Any]]:
        return {(domain, purpose): dict(lookup.confirmed_alias_map(
                    connection, domain, source_scope={"purpose": purpose}, policy=policy))
                for domain, purpose in keys}

    def publish(self, wordings: Mapping[tuple[str, str], Mapping[str, Any]], identity: str) -> None:
        if self._identity in (None, identity):
            self._published, self._identity = dict(wordings), identity

    def wordings(self, domain: str, purpose: str) -> Mapping[str, Any]:
        return self._published.get((domain, purpose), {})

    def wording(self, domain: str, purpose: str, text: object) -> Any | None:
        return self.wordings(domain, purpose).get(normalize_identity(text))

    def view(self, domain: str, purpose: str) -> "_WordingView":
        return _WordingView(self, domain, purpose)

    def reset(self) -> None:
        self._published, self._identity = {}, None


class _WordingView(_MappingABC):
    """Live read-only view of one type/purpose; lookups use the format key."""

    __slots__ = ("_snapshot", "_domain", "_purpose")

    def __init__(self, snapshot: NameAliasSnapshot, domain: str, purpose: str):
        self._snapshot, self._domain, self._purpose = snapshot, domain, purpose

    def __getitem__(self, key):
        return self._snapshot.wordings(self._domain, self._purpose)[normalize_identity(key)]

    def __iter__(self):
        return iter(self._snapshot.wordings(self._domain, self._purpose))

    def __len__(self) -> int:
        return len(self._snapshot.wordings(self._domain, self._purpose))


Runner = Callable[..., Awaitable[Any]]


class ProvidedNameAliases:
    """One name type's confirmed, unscoped wordings: typed read and Owner writes for a caller-owned policy."""

    def __init__(self, domain: str, policy: MasterDataPolicy, *, read: Runner, write: Runner, reviewer: str):
        self.domain, self.policy, self._read, self._write, self._reviewer = domain, policy, read, write, reviewer

    def _key(self, text: str) -> str:
        return self.policy.normalize_alias(self.domain, text)

    async def lookup(self, db, text: str) -> Any | None:
        return await self._read(db, lambda connection: lookup.confirmed_alias_map(
            connection, self.domain, policy=self.policy).get(self._key(text)))

    async def current(self, db, text: str) -> dict[str, Any] | None:
        def read(connection):
            row = writes._one(connection, """SELECT id, entity_key, evidence_json FROM master_data_aliases
                WHERE entity_type=? AND normalized_alias=? AND source_scope='' AND alias_status='confirmed'""",
                (self.domain, self._key(text)))
            if row is None:
                return None
            evidence = json.loads(row["evidence_json"] or "{}")
            return {"alias_id": int(row["id"]), "target": row["entity_key"], "learning": dict(evidence.get("learning") or {})}
        return await self._read(db, read)

    async def _change(self, db, change: commands.MasterDataChange) -> None:
        def work(connection):
            preview = commands.preview_change_in_transaction(connection, change, policy=self.policy)
            return commands.apply_change_in_transaction(connection, preview, policy=self.policy)
        await self._write(db, work)

    async def _evidence(self, db, alias_id: int, learning: dict[str, Any]) -> None:
        def work(connection):
            row = writes._one(connection, "SELECT evidence_json FROM master_data_aliases WHERE id=?", (alias_id,))
            writes.set_alias_evidence(connection, alias_id, {**json.loads(row["evidence_json"] or "{}"), "learning": learning})
        await self._write(db, work)

    async def record(self, db, text: str, target: str, learning: dict[str, Any], account: str | None, note: str) -> None:
        await self._change(db, commands.MasterDataChange("record_alias", {
            "domain": self.domain, "entity_id": target, "alias_name": text, "evidence": {"learning": learning},
        }, str(account or self._reviewer), note))

    async def repoint(self, db, alias_id: int, target: str, learning: dict[str, Any], account: str | None, note: str) -> None:
        await self._change(db, commands.MasterDataChange("correct_alias", {"alias_id": alias_id, "entity_id": target},
                                                         str(account or self._reviewer), note))
        await self._evidence(db, alias_id, learning)

    async def touch(self, db, alias_id: int, learning: dict[str, Any]) -> None:
        await self._evidence(db, alias_id, learning)


__all__ = ["NameAliasSnapshot", "ProvidedNameAliases"]
