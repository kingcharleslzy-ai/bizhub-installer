"""The single durable SourceCluster claim, checkpoint and coverage algorithm."""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
import hashlib
import json
import random
from types import SimpleNamespace
from typing import Any, Callable, Iterable, Mapping, Protocol
from uuid import uuid4
from .decision_journal import DecisionSql
from .source_contract import SourceManifestV1, stable_json
from .execution import current_execution_budget, ExecutionBudget, ExecutionBudgetError

def utc_now():
    return datetime.now(timezone.utc).replace(tzinfo=None)

class SourceSql(DecisionSql, Protocol):
    async def all(self, sql: str, params: Mapping[str, object]) -> list[Mapping[str, object]]: ...

@dataclass(frozen=True)
class ExecutionIdentity:
    runtime_fingerprint: str
    inference_fingerprint: str
    visual_fingerprint: str
    deterministic_fingerprint: str
    code_version: str
    executor_kind: str | None = None
    knowledge_digest: str | None = None
    recovery_execution_id: str | None = None
    sdk_continuation_fingerprint: str | None = None

TERMINAL_CLUSTER_STATUSES = {
    "completed",
    "completed_with_quarantine",
    "quarantined",
    "promotion_quarantined",
    "review_pending",
    "superseded",
}


DEFAULT_CLUSTER_LEASE_SECONDS = 1_800


DEFAULT_RETRY_SECONDS = 60


MAX_PROVIDER_MODEL_ATTEMPTS = 3


MAX_PROVIDER_RETRY_SECONDS = 15 * 60


PROVIDER_TRANSIENT_FAILURE_CATEGORIES = frozenset(
    {
        "model_auth_unavailable",
        "model_overloaded",
        "model_rate_limited",
        "model_transport",
    }
)


PROVIDER_RETRY_EXHAUSTED_CATEGORY = "model_retry_exhausted"


# After the in-cluster attempts are spent, an outage source is retried again
# at 30 minutes, then doubling, never waiting more than 6 hours.
PROVIDER_OUTAGE_RETRY_BASE_SECONDS = 30 * 60


PROVIDER_OUTAGE_RETRY_MAX_SECONDS = 6 * 60 * 60


SOURCE_TECHNICAL_FAILURE_STATUSES = {
    "quarantined",
    "promotion_quarantined",
    "retry_pending",
}


UNRESOLVED_MEMBER_COVERAGE_STATUSES = {
    "pending",
    "running",
    "promotion_running",
    "awaiting_owner_apply",
    "retry_pending",
    "review_pending",
}


DETERMINISTIC_MEMBER_COVERAGE_STATUSES = {
    "quarantined",
    "promotion_quarantined",
}


class SourceClusterStateError(RuntimeError):
    """The durable cluster state changed underneath the current worker."""

    category = "source_cluster_state"

    def __init__(self, message: str) -> None:
        super().__init__(message)
        self.source_refs: tuple[str, ...] = ()
        # A lost lease is a concurrency race; malformed persisted state or
        # incomplete coverage is deterministic for the current release.
        self.retryable = str(message).startswith(
            "source_cluster_claim_lost:"
        )


def reduce_source_cluster_status(
    *,
    pending_owner_apply: bool,
    has_retryable_failure: bool,
    has_deterministic_failure: bool,
    has_pending_review: bool,
) -> str:
    """The single precedence rule for one cluster's terminal/queue status.

    Semantic completion, Owner promotion and a later human Review closure all
    reduce the same four conditions here so the column can never mean two
    different things.
    """

    if pending_owner_apply:
        return "awaiting_owner_apply"
    if has_retryable_failure:
        return "retry_pending"
    if has_deterministic_failure:
        return "completed_with_quarantine"
    if has_pending_review:
        return "review_pending"
    return "completed"


def source_cluster_status_from_member_coverage(
    member_statuses: Iterable[str],
) -> str | None:
    """Reduce persisted member coverage once a Review reached a terminal.

    ``None`` means another lifecycle path (queue, retry or Owner apply) still
    owns the cluster, so the Review closure must leave the status untouched.
    """

    statuses = {str(item or "") for item in member_statuses}
    if (statuses & UNRESOLVED_MEMBER_COVERAGE_STATUSES) - {"review_pending"}:
        return None
    return reduce_source_cluster_status(
        pending_owner_apply=False,
        has_retryable_failure=False,
        has_deterministic_failure=bool(
            statuses & DETERMINISTIC_MEMBER_COVERAGE_STATUSES
        ),
        has_pending_review="review_pending" in statuses,
    )


def _cluster_result_payload(row: _Row) -> dict[str, Any]:
    try:
        payload = json.loads(row.result_json or "{}")
    except (TypeError, ValueError) as exc:
        raise SourceClusterStateError("source_cluster_checkpoint_invalid") from exc
    if not isinstance(payload, dict):
        raise SourceClusterStateError("source_cluster_checkpoint_invalid")
    return payload


@dataclass(frozen=True)
class SourceClusterClaim:
    cluster_row_id: int
    execution_key: str
    claim_token: str | None
    should_run: bool
    status: str
    reason: str
    code_version: str
    promotion_only: bool = False
    technical_failure: dict[str, Any] | None = None
    reuse_mode: str = "full_inference"
    reuse_source_cluster_id: int | None = None
    reused_result: dict[str, Any] | None = None


RetryDelayJitter = Callable[[int, int], int]


def source_cluster_retry_delay_seconds(
    *,
    attempt_count: int,
    base_seconds: int = DEFAULT_RETRY_SECONDS,
    max_seconds: int = MAX_PROVIDER_RETRY_SECONDS,
    jitter: RetryDelayJitter | None = None,
) -> int:
    """Return bounded exponential delay for the next durable model attempt."""

    current_attempt = max(1, int(attempt_count))
    base = max(1, int(base_seconds))
    ceiling = min(
        max(base, int(max_seconds)),
        base * (2 ** max(0, current_attempt - 1)),
    )
    floor = max(1, int(round(ceiling * 0.8)))
    choose = jitter or random.randint
    return max(floor, min(ceiling, int(choose(floor, ceiling))))


def source_cluster_failure_with_retry_policy(
    failure: dict[str, Any],
    *,
    attempt_count: int,
) -> dict[str, Any]:
    """Allow durable model retry only for four provider-transient categories."""

    normalized = dict(failure)
    category = str(normalized.get("category") or "runtime_failure")
    current_attempt = max(1, int(attempt_count))
    requested_retry = bool(normalized.get("retryable"))
    normalized["model_attempt_count"] = current_attempt
    normalized["retryable"] = bool(
        requested_retry
        and category in PROVIDER_TRANSIENT_FAILURE_CATEGORIES
        and current_attempt < MAX_PROVIDER_MODEL_ATTEMPTS
    )
    if (
        requested_retry
        and category in PROVIDER_TRANSIENT_FAILURE_CATEGORIES
        and current_attempt >= MAX_PROVIDER_MODEL_ATTEMPTS
    ):
        original_reason = str(normalized.get("reason") or category)
        normalized.update(
            {
                "category": PROVIDER_RETRY_EXHAUSTED_CATEGORY,
                "original_category": category,
                "reason": (
                    "provider_model_retry_exhausted:"
                    f"{category}:attempt={current_attempt}/"
                    f"{MAX_PROVIDER_MODEL_ATTEMPTS}:{original_reason}"
                ),
                "retryable": False,
                "retry_exhausted": True,
            }
        )
        normalized["failure_fingerprint"] = hashlib.sha256(
            stable_json(
                {
                    "category": normalized["category"],
                    "reason": normalized["reason"],
                    "source_refs": sorted(
                        str(item)
                        for item in normalized.get("source_refs") or []
                    ),
                }
            ).encode("utf-8")
        ).hexdigest()
    return normalized


def _source_identity(source_ref: str) -> tuple[str, str]:
    kind, separator, source_id = source_ref.partition(":")
    if not separator or not kind or not source_id:
        return "unknown", source_ref
    return kind, source_id


def _initial_coverage(manifest: SourceManifestV1) -> dict[str, Any]:
    return {
        "schema_version": "business_agent_source_cluster_coverage.v1",
        "expected_source_refs": list(manifest.source_refs),
        "expected_part_refs": list(manifest.part_refs),
        "processed_source_refs": [],
        "processed_part_refs": [],
        "missing_source_refs": list(manifest.source_refs),
        "missing_part_refs": list(manifest.part_refs),
        "source_status": {
            source_ref: "pending" for source_ref in manifest.source_refs
        },
    }


def _completed_execution_stage_shape(payload: dict[str, Any]) -> str | None:
    """已持久化完整模型阶段的形状，与 renew_after_completed_stage 同一口径。"""
    if isinstance(payload.get("visual_verification"), dict):
        return "visual_verification"
    if isinstance(payload.get("semantic_candidates"), dict) and isinstance(
        payload.get("processed_part_refs"), list
    ):
        return "semantic_inference"
    return None


def _failure_index(
    failures: Iterable[dict[str, Any]],
) -> dict[str, list[dict[str, Any]]]:
    output: dict[str, list[dict[str, Any]]] = {}
    for failure in failures:
        for source_ref in failure.get("source_refs") or []:
            output.setdefault(str(source_ref), []).append(failure)
    return output


def _pending_owner_effect_refs(output: dict[str, Any]) -> set[str]:
    refs: set[str] = set(str(ref) for ref in output.get("pending_owner_source_refs") or [])
    for execution in output.get("executions") or []:
        if not isinstance(execution, dict):
            continue
        if (
            str(execution.get("action") or "") not in {"write", "context"}
            or str(execution.get("decision_state") or "") != "current"
            or execution.get("readback") is not None
        ):
            continue
        refs.update(
            str(item)
            for item in execution.get("source_refs") or []
            if str(item)
        )
    return refs


def source_cluster_execution_key(
    *,
    manifest_hash: str,
    inference_fingerprint: str,
    visual_fingerprint: str,
    deterministic_fingerprint: str,
    runtime_fingerprint: str | None = None,
    code_version: str | None = None,
    recovery_execution_id: str | None = None,
    knowledge_digest: str | None = None,
) -> str:
    """Return the semantic execution identity; release is provenance only.

    ``runtime_fingerprint`` and ``code_version`` remain accepted for callers
    compiled against the previous contract, but deliberately do not influence
    the key. An exact authorized terminal recovery adds a server-generated
    identity so it creates a new immutable execution without changing source
    truth or component fingerprints.
    """
    recovery_id = str(recovery_execution_id or "").strip().casefold()
    if recovery_id and (
        len(recovery_id) != 32
        or any(character not in "0123456789abcdef" for character in recovery_id)
    ):
        raise ValueError("invalid source cluster recovery execution id")
    identity = {
        "manifest_hash": manifest_hash,
        "inference_fingerprint": inference_fingerprint,
        "visual_fingerprint": visual_fingerprint,
        "deterministic_fingerprint": deterministic_fingerprint,
    }
    if recovery_id:
        identity["recovery_execution_id"] = recovery_id
    if knowledge_digest:
        identity["knowledge_digest"] = knowledge_digest
    return hashlib.sha256(
        stable_json(identity).encode("utf-8")
    ).hexdigest()


class _Row(SimpleNamespace):
    pass

class SourceJournal:
    def __init__(self, sql: SourceSql, *, legacy_adoptions=(), runtime_version="business_agent_semantic_runtime.v1", owner_promotion_enabled=False, promoter_runtime_fingerprint=""):
        self.sql = sql
        self.legacy_adoptions = legacy_adoptions
        self.runtime_version = runtime_version
        self.owner_promotion_enabled = owner_promotion_enabled
        self.promoter_runtime_fingerprint = promoter_runtime_fingerprint
        self._rows = {}
        self.updated_cluster_ids = set()
        self.updated_member_ids = set()

    @staticmethod
    def _params(params):
        return {key: value.strftime("%Y-%m-%d %H:%M:%S.%f") if isinstance(value, datetime) else value for key, value in params.items()}

    def _row(self, table, values):
        key = (table, values["id"])
        if key in self._rows:
            return self._rows[key]
        values = dict(values)
        for name, value in values.items():
            if name.endswith("_at") and isinstance(value, str):
                values[name] = datetime.fromisoformat(value).replace(tzinfo=None)
        row = _Row(**values, _table=table, _original=dict(values))
        self._rows[key] = row
        return row

    async def _clusters(self, where, params, *, order="id", limit=None):
        await self.flush()
        rows = await self.sql.all("SELECT * FROM business_agent_source_clusters WHERE " + where + " ORDER BY " + order + (f" LIMIT {int(limit)}" if limit is not None else ""), self._params(params))
        return [self._row("business_agent_source_clusters", row) for row in rows]

    async def _cluster(self, row_id):
        rows = await self._clusters("id=:id", {"id": row_id})
        return rows[0] if rows else None

    async def _members(self, cluster_id):
        await self.flush()
        rows = await self.sql.all("SELECT * FROM business_agent_source_cluster_members WHERE cluster_id=:id ORDER BY ordinal", {"id": cluster_id})
        return [self._row("business_agent_source_cluster_members", row) for row in rows]

    async def flush(self):
        await self.sql.flush()
        for row in self._rows.values():
            changed = {key: value for key, value in vars(row).items() if not key.startswith("_") and key != "id" and row._original.get(key) != value}
            if not changed:
                continue
            changed["updated_at"] = utc_now()
            params = {**changed, "row_id": row.id}
            fence = ""
            if row._table == "business_agent_source_clusters":
                params.update(old_generation=row._original["claim_generation"], old_token=row._original["claim_token"], old_status=row._original["status"])
                fence = " AND claim_generation=:old_generation AND claim_token IS :old_token AND status=:old_status"
            else:
                params["old_status"] = row._original["coverage_status"]
                fence = " AND coverage_status=:old_status"
            count = await self.sql.execute("UPDATE " + row._table + " SET " + ", ".join(key + "=:" + key for key in changed) + " WHERE id=:row_id" + fence, self._params(params))
            if count != 1:
                raise SourceClusterStateError(f"source_cluster_claim_lost:{getattr(row, 'cluster_id', row.id)}")
            vars(row).update(changed)
            row._original.update(changed)
            (self.updated_cluster_ids if row._table == "business_agent_source_clusters" else self.updated_member_ids).add(row.id)

    async def _update_clusters(self, statement, params):
        rows = await self.sql.all(statement + " RETURNING id", self._params(params))
        for row in rows:
            self.updated_cluster_ids.add(row["id"])
            self._rows.pop(("business_agent_source_clusters", row["id"]), None)
        return len(rows)

    async def _insert_cluster(self, **values):
        nullable = "result_json failure_category error_fingerprint last_error next_retry_at claim_token lease_expires_at started_at completed_at".split()
        values = {**dict.fromkeys(nullable), "created_at": utc_now(), "updated_at": utc_now(), **values}
        await self.sql.execute("INSERT INTO business_agent_source_clusters (" + ",".join(values) + ") VALUES (" + ",".join(":" + key for key in values) + ")", self._params(values))
        rows = await self._clusters("execution_key=:key", {"key": values["execution_key"]})
        row = rows[0]
        self.updated_cluster_ids.add(row.id)
        return row

    async def _insert_member(self, **values):
        values = {"candidate_refs_json": None, "error_fingerprint": None, "processed_at": None, "created_at": utc_now(), "updated_at": utc_now(), **values}
        await self.sql.execute("INSERT INTO business_agent_source_cluster_members (" + ",".join(values) + ") VALUES (" + ",".join(":" + key for key in values) + ")", self._params(values))

    async def _quarantine_exhausted_inference_claim(
        self,
        *,
        row: _Row,
        now: datetime,
    ) -> dict[str, Any]:
        """Close an expired/due execution before a fourth model lease."""

        members = await self._members(row.id)
        affected_refs = sorted(
            str(member.source_ref)
            for member in members
            if str(member.coverage_status or "")
            in {"pending", "running", "retry_pending", "unavailable"}
        ) or sorted(str(member.source_ref) for member in members)
        original_category = str(
            row.failure_category or "inference_lease_expired"
        )
        reason = (
            "source_cluster_model_attempt_budget_exhausted:"
            f"attempt={int(row.attempt_count or 0)}/"
            f"{MAX_PROVIDER_MODEL_ATTEMPTS}:"
            f"original_category={original_category}:"
            f"{str(row.last_error or '')}"
        )
        failure = {
            "category": PROVIDER_RETRY_EXHAUSTED_CATEGORY,
            "original_category": original_category,
            "reason": reason,
            "source_refs": affected_refs,
            "retryable": False,
            "retry_exhausted": True,
            "model_attempt_count": int(row.attempt_count or 0),
        }
        failure["failure_fingerprint"] = hashlib.sha256(
            stable_json(
                {
                    "category": failure["category"],
                    "reason": failure["reason"],
                    "source_refs": affected_refs,
                    "execution_key": row.execution_key,
                }
            ).encode("utf-8")
        ).hexdigest()
        row.status = "quarantined"
        row.retryable = False
        row.failure_category = PROVIDER_RETRY_EXHAUSTED_CATEGORY
        row.error_fingerprint = failure["failure_fingerprint"]
        row.last_error = reason[:4_000]
        row.next_retry_at = None
        row.claim_token = None
        row.lease_expires_at = None
        row.completed_at = now
        try:
            coverage = json.loads(row.coverage_json or "{}")
        except (TypeError, ValueError, json.JSONDecodeError):
            coverage = {}
        if not isinstance(coverage, dict):
            coverage = {}
        source_status = dict(coverage.get("source_status") or {})
        for member in members:
            if str(member.source_ref) not in affected_refs:
                continue
            member.coverage_status = "quarantined"
            member.error_fingerprint = failure["failure_fingerprint"]
            member.processed_at = now
            source_status[str(member.source_ref)] = "quarantined"
        coverage["source_status"] = source_status
        row.coverage_json = stable_json(coverage)
        try:
            output = json.loads(row.result_json or "{}")
        except (TypeError, ValueError, json.JSONDecodeError):
            output = {}
        if not isinstance(output, dict):
            output = {}
        existing_failures = [
            dict(item)
            for item in output.get("technical_failures") or []
            if isinstance(item, dict)
        ]
        existing_failures.append(failure)
        output["technical_failures"] = existing_failures
        output["technical_failure"] = failure
        output["source_retry_refs"] = []
        output["source_quarantined_refs"] = sorted(
            {
                *(str(item) for item in output.get("source_quarantined_refs") or []),
                *affected_refs,
            }
        )
        row.result_json = stable_json(output)
        await self.flush()
        return failure


    async def supersede_stale_unfinished_source_clusters(
        self,
        *,
        agent_name: str,
        runtime_fingerprint: str | None = None,
        inference_fingerprint: str | None = None,
        additional_inference_fingerprints: Iterable[str] = (),
        visual_fingerprint: str | None = None,
        deterministic_fingerprint: str | None = None,
        code_version: str | None = None,
        now: datetime | None = None,
    ) -> int:
        """Fence old claims and supersede only semantically stale executions.

        Source windows may change between releases even when they contain some of
        the same sources.  Matching only ``manifest_hash`` therefore cannot recover
        an expired predecessor whose later retry was regrouped into a different
        manifest.  Each active role performs this Agent-wide sweep before queue
        discovery; source rows remain untouched and are still selected by their
        normal durable pending state.
        """
        current_time = now or utc_now()
        release = str(code_version)
        available_inference = tuple(dict.fromkeys((str(inference_fingerprint), *additional_inference_fingerprints)))
        params = {"agent": str(agent_name), "release": release, "runtime": str(runtime_fingerprint), "visual": str(visual_fingerprint), "deterministic": str(deterministic_fingerprint), "now": current_time}
        params.update({f"inference_{index}": value for index, value in enumerate(available_inference)})
        inference_set = ",".join(f":inference_{index}" for index in range(len(available_inference)))
        active = "agent_name=:agent AND status IN ('pending','retry_pending','running')"
        same = f"inference_fingerprint IN ({inference_set}) AND visual_fingerprint=:visual AND deterministic_fingerprint=:deterministic"
        takeover = await self._update_clusters("UPDATE business_agent_source_clusters SET code_version=:release, runtime_fingerprint=:runtime, claim_generation=claim_generation+1, status='pending', claim_token=NULL, lease_expires_at=NULL, next_retry_at=NULL, started_at=NULL, updated_at=:now WHERE " + active + " AND code_version!=:release AND " + same, self._params(params))
        params["error"] = f"unfinished_execution_superseded_by_semantic_component:inference={inference_fingerprint}:visual={visual_fingerprint}:deterministic={deterministic_fingerprint}"
        superseded = await self._update_clusters("UPDATE business_agent_source_clusters SET status='superseded', retryable=0, failure_category='superseded_by_component_fingerprint', last_error=:error, claim_token=NULL, lease_expires_at=NULL, next_retry_at=NULL, completed_at=:now, updated_at=:now WHERE " + active + " AND NOT (" + same + ")", self._params(params))
        await self.flush()
        return int(takeover or 0) + int(superseded or 0)


    def _reusable_stage_result(
        self, row: _Row | None,
        *,
        inference_fingerprint: str,
        visual_fingerprint: str,
        knowledge_digest: str | None = None,
    ) -> tuple[str, dict[str, Any] | None]:
        if row is None:
            return "full_inference", None
        try:
            payload = json.loads(row.result_json or "{}")
        except (TypeError, ValueError, json.JSONDecodeError):
            return "full_inference", None
        if not isinstance(payload, dict) or not isinstance(
            payload.get("semantic_candidates"), dict
        ):
            return "full_inference", None
        if (payload.get("semantic_executor") or {}).get("knowledge_digest") != knowledge_digest:
            return "full_inference", None
        if any(self._matches_exact_legacy_stage_adoption(row, payload=payload, adoption=adoption) for adoption in self.legacy_adoptions):
            return "deterministic_only", payload
        if str(row.inference_fingerprint or "") != str(inference_fingerprint):
            return "full_inference", None
        if (
            str(row.visual_fingerprint or "") == str(visual_fingerprint)
            and isinstance(payload.get("visual_verification"), dict)
        ):
            return "deterministic_only", payload
        return "visual_only", payload


    def _matches_exact_legacy_stage_adoption(
        self, row: _Row,
        *,
        payload: dict[str, Any],
        adoption: Mapping[str, Any],
    ) -> bool:
        if any(
            (
                str(row.agent_name or "") != adoption["agent_name"],
                str(row.code_version or "") != adoption["code_version"],
                str(row.runtime_fingerprint or "")
                != adoption["runtime_fingerprint"],
                str(row.manifest_hash or "") != adoption["manifest_hash"],
                str(row.inference_fingerprint or "") != "legacy",
                str(row.visual_fingerprint or "") != "legacy",
                str(row.deterministic_fingerprint or "") != "legacy",
                int(row.expected_source_count or 0) != adoption["source_count"],
                int(row.processed_source_count or 0) != adoption["source_count"],
                int(row.expected_part_count or 0) != adoption["part_count"],
                int(row.processed_part_count or 0) != adoption["part_count"],
                hashlib.sha256(str(row.manifest_json or "").encode()).hexdigest()
                != adoption["manifest_json_sha256"],
                hashlib.sha256(str(row.result_json or "").encode()).hexdigest()
                != adoption["result_json_sha256"],
                not isinstance(payload.get("visual_verification"), dict),
            )
        ):
            return False
        try:
            manifest_payload = json.loads(row.manifest_json or "{}")
        except (TypeError, ValueError, json.JSONDecodeError):
            return False
        expected_parts = {
            str(item.get("part_ref") or "")
            for item in manifest_payload.get("parts") or []
            if isinstance(item, dict) and str(item.get("part_ref") or "")
        }
        processed_parts = {
            str(item)
            for item in payload.get("processed_part_refs") or []
            if str(item)
        }
        return (
            len(expected_parts) == adoption["part_count"]
            and processed_parts == expected_parts
        )


    async def register_and_claim_source_cluster(
        self,
        *,
        manifest: SourceManifestV1,
        runtime_fingerprint: str | None = None,
        inference_fingerprint: str | None = None,
        visual_fingerprint: str | None = None,
        deterministic_fingerprint: str | None = None,
        code_version: str | None = None,
        recovery_execution_id: str | None = None,
        executor_kind: str | None = None,
        sdk_continuation_fingerprint: str | None = None,
        knowledge_digest: str | None = None,
        lease_seconds: int = DEFAULT_CLUSTER_LEASE_SECONDS,
        now: datetime | None = None,
    ) -> SourceClusterClaim:
        """Persist the complete manifest, then atomically claim its execution."""
        if executor_kind not in {None, "legacy", "agents_sdk"}:
            raise ValueError("source_executor_kind_invalid")
        if sdk_continuation_fingerprint and executor_kind != "legacy":
            raise ValueError("source_executor_continuation_requires_legacy_binding")
        executor_identity = ({"kind": executor_kind, "inference_fingerprint": inference_fingerprint}
                             if executor_kind is not None else None)
        if knowledge_digest:
            if executor_identity is None:
                raise ValueError("knowledge digest requires a declared source executor")
            executor_identity["knowledge_digest"] = knowledge_digest
        if recovery_execution_id and executor_identity is not None:
            executor_identity["recovery_execution_id"] = recovery_execution_id
        if sdk_continuation_fingerprint:
            executor_identity["sdk_continuation_fingerprint"] = sdk_continuation_fingerprint
        current_time = now or utc_now()
        release = str(code_version)
        execution_key = source_cluster_execution_key(
            manifest_hash=manifest.manifest_hash,
            inference_fingerprint=inference_fingerprint,
            visual_fingerprint=visual_fingerprint,
            deterministic_fingerprint=deterministic_fingerprint,
            recovery_execution_id=recovery_execution_id,
            knowledge_digest=knowledge_digest,
        )
        # A worker may be stopped after claiming a source but before it updates the
        # source row.  A later immutable release owns a distinct execution key and
        # must immediately invalidate every unfinished predecessor, including one
        # whose lease is still active.  Preserve the predecessor as an explicit
        # terminal audit row; a late worker cannot write because its claim token is
        # cleared.  Completed Decisions and awaiting Owner promotion are
        # deliberately not touched here.
        await self._update_clusters("UPDATE business_agent_source_clusters SET status='superseded', retryable=0, failure_category='superseded_by_component_fingerprint', last_error=:error, claim_token=NULL, lease_expires_at=NULL, next_retry_at=NULL, completed_at=:now, updated_at=:now WHERE agent_name=:agent AND manifest_hash=:manifest AND execution_key!=:key AND status IN ('pending','retry_pending','running')", self._params({"agent": manifest.agent_name, "manifest": manifest.manifest_hash, "key": execution_key, "error": f"unfinished_execution_superseded_by_semantic_component:{execution_key}", "now": current_time}))
        matches = await self._clusters("execution_key=:key", {"key": execution_key})
        row = matches[0] if matches else None
        reuse_mode = "full_inference"
        reused_result: dict[str, Any] | None = None
        reuse_source_cluster_id: int | None = None
        prior = row
        if row is not None:
            reuse_mode, reused_result = self._reusable_stage_result(
                row,
                inference_fingerprint=inference_fingerprint,
                visual_fingerprint=visual_fingerprint,
                knowledge_digest=knowledge_digest,
            )
            if reused_result is not None:
                reuse_source_cluster_id = int(row.id)
        # Explicit recovery must reread the source rather than inherit the failed
        # interpretation it was requested to replace. Its own checkpoints above
        # remain reusable, so resuming the same recovery stays idempotent.
        if reused_result is None and not recovery_execution_id:
            prior_rows = await self._clusters("agent_name=:agent AND manifest_hash=:manifest AND result_json IS NOT NULL AND id!=:id", {"agent": manifest.agent_name, "manifest": manifest.manifest_hash, "id": row.id if row is not None else -1}, order="created_at DESC, id DESC", limit=100)
            for prior_candidate in prior_rows:
                reuse_mode, reused_result = self._reusable_stage_result(
                    prior_candidate,
                    inference_fingerprint=inference_fingerprint,
                    visual_fingerprint=visual_fingerprint,
                    knowledge_digest=knowledge_digest,
                )
                if reused_result is not None:
                    prior = prior_candidate
                    reuse_source_cluster_id = int(prior_candidate.id)
                    break
        if row is None:
            row = await self._insert_cluster(
                execution_key=execution_key,
                cluster_id=manifest.cluster_id,
                agent_name=manifest.agent_name,
                business_date=manifest.business_date,
                source_scope=manifest.scope,
                runtime_version=self.runtime_version,
                runtime_fingerprint=runtime_fingerprint,
                inference_fingerprint=inference_fingerprint,
                visual_fingerprint=visual_fingerprint,
                deterministic_fingerprint=deterministic_fingerprint,
                code_version=release,
                claim_generation=0,
                manifest_hash=manifest.manifest_hash,
                status="pending",
                manifest_json=stable_json(manifest.to_persisted_payload()),
                coverage_json=stable_json(_initial_coverage(manifest)),
                result_json=(stable_json({"semantic_executor": executor_identity}) if executor_identity else None),
                expected_source_count=len(manifest.source_refs),
                expected_part_count=len(manifest.part_refs),
                processed_source_count=0,
                processed_part_count=0,
                attempt_count=0,
                model_call_count=0,
                retryable=True,
            )
            await self.flush()
            for source in manifest.sources:
                source_kind, source_id = _source_identity(source.source_ref)
                await self._insert_member(
                    cluster_id=row.id,
                    ordinal=source.ordinal,
                    source_ref=source.source_ref,
                    source_kind=source_kind,
                    source_id=source_id,
                    source_sha256=manifest.source_sha256(source.source_ref),
                    coverage_status="pending",
                )
            await self.flush()
        else:
            if row.manifest_hash != manifest.manifest_hash:
                raise SourceClusterStateError(
                    f"source_cluster_execution_collision:{execution_key}"
                )
            if row.code_version != release and row.status in {
                "pending",
                "retry_pending",
                "running",
            }:
                # The release changed but the semantic identity did not. Invalidate
                # the old worker token and continue on the same durable row.
                row.code_version = release
                row.runtime_fingerprint = runtime_fingerprint
                row.claim_generation = int(row.claim_generation or 0) + 1
                row.status = "pending"
                row.claim_token = None
                row.lease_expires_at = None
                row.next_retry_at = None
                row.started_at = None
                await self.flush()
            if row.status in {"awaiting_owner_apply", "promotion_running"}:
                if (
                    row.status == "promotion_running"
                    and row.lease_expires_at is not None
                    and row.lease_expires_at > current_time
                ):
                    return SourceClusterClaim(
                        cluster_row_id=row.id,
                        execution_key=execution_key,
                        claim_token=None,
                        should_run=False,
                        status=row.status,
                        reason="active_promotion_lease",
                        code_version=release,
                    )
                if (
                    row.next_retry_at is not None
                    and row.next_retry_at > current_time
                ):
                    return SourceClusterClaim(
                        cluster_row_id=row.id,
                        execution_key=execution_key,
                        claim_token=None,
                        should_run=False,
                        status=row.status,
                        reason="promotion_retry_not_due",
                        code_version=release,
                    )
                # Import locally so the queue ledger remains usable by migration
                # tooling without creating a module-level lifecycle dependency.
                if not self.owner_promotion_enabled:
                    return SourceClusterClaim(
                        cluster_row_id=row.id,
                        execution_key=execution_key,
                        claim_token=None,
                        should_run=False,
                        status="awaiting_owner_apply",
                        reason="decision_mode_review_only_pending_apply",
                        code_version=release,
                    )
                token = uuid4().hex
                row.status = "promotion_running"
                row.claim_token = token
                row.lease_expires_at = current_time + timedelta(
                    seconds=max(60, int(lease_seconds))
                )
                row.started_at = current_time
                row.completed_at = None
                row.next_retry_at = None
                await self.flush()
                return SourceClusterClaim(
                    cluster_row_id=row.id,
                    execution_key=execution_key,
                    claim_token=token,
                    should_run=False,
                    status="promotion_running",
                    reason="claimed_for_owner_promotion",
                    code_version=release,
                    promotion_only=True,
                )
            # A terminal cluster whose complete model stages still match the
            # current component fingerprints is re-runnable: the claim re-executes
            # only the deterministic stages (formal-relation lookup, Owner
            # preview, Decision/Review projection) against the current database
            # with zero model calls, so an explicit replay observes formal records
            # that landed after the first run and can supersede its Review.
            # ``superseded`` only records an interrupted run, so when a later
            # release returns to the same identity the row is claimed again;
            # skipping it would strand the still-pending sources forever.  Any
            # other terminal row without a reusable stage result (incomplete
            # inference) still fails closed to a skip.
            if (
                row.status in TERMINAL_CLUSTER_STATUSES
                and row.status != "superseded"
                and reused_result is None
            ):
                return SourceClusterClaim(
                    cluster_row_id=row.id,
                    execution_key=execution_key,
                    claim_token=None,
                    should_run=False,
                    status=row.status,
                    reason="same_semantic_execution_terminal",
                    code_version=release,
                )
            if (
                row.status == "running"
                and row.lease_expires_at is not None
                and row.lease_expires_at > current_time
            ):
                return SourceClusterClaim(
                    cluster_row_id=row.id,
                    execution_key=execution_key,
                    claim_token=None,
                    should_run=False,
                    status=row.status,
                    reason="active_lease",
                    code_version=release,
                )
            if (
                row.status == "retry_pending"
                and row.next_retry_at is not None
                and row.next_retry_at > current_time
                and reused_result is None
            ):
                return SourceClusterClaim(
                    cluster_row_id=row.id,
                    execution_key=execution_key,
                    claim_token=None,
                    should_run=False,
                    status=row.status,
                    reason="retry_not_due",
                    code_version=release,
                )
            if (
                row.status in {"running", "retry_pending"}
                and int(row.attempt_count or 0)
                >= MAX_PROVIDER_MODEL_ATTEMPTS
                and reused_result is None
            ):
                failure = await self._quarantine_exhausted_inference_claim(
                    row=row,
                    now=current_time,
                )
                return SourceClusterClaim(
                    cluster_row_id=row.id,
                    execution_key=execution_key,
                    claim_token=None,
                    should_run=False,
                    status="quarantined",
                    reason="model_retry_exhausted_before_claim",
                    code_version=release,
                    technical_failure=failure,
                )

        if sdk_continuation_fingerprint:
            payload = _cluster_result_payload(row)
            previous = (payload.get("semantic_executor") or {}).get("sdk_continuation_fingerprint")
            if previous and previous != sdk_continuation_fingerprint:
                raise SourceClusterStateError("pinned_sdk_continuation_version_unavailable")
            row.result_json = stable_json({**payload, "semantic_executor": executor_identity})
        token = uuid4().hex
        row.status = "running"
        row.code_version = release
        row.runtime_fingerprint = runtime_fingerprint
        row.claim_token = token
        row.lease_expires_at = current_time + timedelta(
            seconds=max(60, int(lease_seconds))
        )
        row.started_at = current_time
        row.completed_at = None
        row.next_retry_at = None
        row.attempt_count = int(row.attempt_count or 0) + 1
        row.claim_generation = int(row.claim_generation or 0) + 1
        await self.flush()
        return SourceClusterClaim(
            cluster_row_id=row.id,
            execution_key=execution_key,
            claim_token=token,
            should_run=True,
            status="running",
            reason="claimed",
            code_version=release,
            reuse_mode=reuse_mode,
            reuse_source_cluster_id=reuse_source_cluster_id,
            reused_result=reused_result,
        )


    async def claim_next_source_cluster_promotion(
        self,
        *,
        agent_name: str,
        business_date: str | None = None,
        runtime_fingerprint: str | None = None,
        code_version: str | None = None,
        lease_seconds: int = DEFAULT_CLUSTER_LEASE_SECONDS,
        now: datetime | None = None,
    ) -> SourceClusterClaim | None:
        """Claim one persisted review-only Decision set without source requeue.

        Owner promotion is intentionally release-independent.  The cluster keeps
        the immutable runtime/code provenance that compiled it, while the current
        worker reconstructs its persisted Decision and runs the *current* Owner
        preview before any apply.  Filtering this queue by the current fingerprint
        strands every ``awaiting_owner_apply`` row as soon as a new release ships.
        """
        if runtime_fingerprint is None:
            runtime_fingerprint = self.promoter_runtime_fingerprint

        if not self.owner_promotion_enabled:
            return None
        current_time = now or utc_now()
        release = str(code_version)
        params = {"agent": str(agent_name), "now": current_time}
        where = "agent_name=:agent AND status IN ('awaiting_owner_apply','promotion_running') AND (next_retry_at IS NULL OR next_retry_at<=:now) AND (status='awaiting_owner_apply' OR lease_expires_at IS NULL OR lease_expires_at<=:now)"
        if business_date is not None:
            where += " AND business_date=:date"
            params["date"] = str(business_date)
        matches = await self._clusters(where, params, order="created_at, id", limit=1)
        row = matches[0] if matches else None
        if row is None:
            return None
        prior_status = str(row.status)
        token = uuid4().hex
        result = await self.sql.execute("UPDATE business_agent_source_clusters SET status='promotion_running', claim_token=:token, lease_expires_at=:lease, started_at=:now, completed_at=NULL, next_retry_at=NULL, updated_at=:now WHERE id=:id AND status=:status AND (next_retry_at IS NULL OR next_retry_at<=:now) AND (lease_expires_at IS NULL OR lease_expires_at<=:now OR status='awaiting_owner_apply')", self._params({"id": row.id, "status": prior_status, "now": current_time, "token": token, "lease": current_time + timedelta(seconds=max(60, int(lease_seconds)))}))
        if int(result or 0) != 1:
            return None
        self.updated_cluster_ids.add(row.id)
        return SourceClusterClaim(
            cluster_row_id=row.id,
            execution_key=row.execution_key,
            claim_token=token,
            should_run=False,
            status="promotion_running",
            reason="claimed_for_owner_promotion",
            # ``code_version`` identifies the worker that owns this lease.  The
            # immutable originating code remains on the persisted cluster row.
            code_version=release,
            promotion_only=True,
        )


    async def _claimed_row(
        self,
        *,
        claim: SourceClusterClaim,
        expected_status: str = "running",
    ) -> _Row:
        row = await self._cluster(claim.cluster_row_id)
        if (
            row is None
            or not claim.claim_token
            or row.status != expected_status
            or row.claim_token != claim.claim_token
        ):
            raise SourceClusterStateError(
                f"source_cluster_claim_lost:{claim.cluster_row_id}"
            )
        return row


    async def checkpoint_source_cluster(
        self, *, claim: SourceClusterClaim, updates: dict[str, Any],
    ) -> dict[str, Any]:
        """Save completed inference work under the existing claim, never business facts."""

        row = await self._claimed_row( claim=claim)
        payload = {**_cluster_result_payload(row), **updates}
        budget = current_execution_budget()
        if budget is not None:
            payload["execution_budget"] = budget.checkpoint()
        row.result_json = stable_json(payload)
        await self.flush()
        return payload


    async def begin_source_cluster_execution(
        self, *, claim: SourceClusterClaim, timeout_seconds: float,
    ):
        """Restore the same execution budget after failures, cancellation or takeover."""

        row = await self._claimed_row( claim=claim)
        payload = _cluster_result_payload(row)
        budget = None
        renewed_stage: str | None = None
        if "execution_budget" in payload:
            try:
                budget = ExecutionBudget.restore(payload["execution_budget"])
            except ExecutionBudgetError as exc:
                # #894：阶段 checkpoint 与下一阶段预算续期是两次提交，进程在
                # 中间退出后旧预算必然过期。已完成阶段的模型结果完整可复用，
                # 此时按 renew_after_completed_stage 的合同起下一阶段的新预算
                # 继续执行；每个完成阶段只恢复一次——存档预算已属于最新完成
                # 阶段还过期，说明续出的下一阶段执行中途崩溃且预算也耗尽，
                # 再续期只会无限重跑（3 次尝试上限失效），维持 fail-closed。
                completed_stage = _completed_execution_stage_shape(payload)
                if (
                    str(exc) != "execution_budget_exhausted"
                    or completed_stage is None
                    or str(payload.get("execution_budget_stage") or "") == completed_stage
                ):
                    raise
                budget = ExecutionBudget.start(timeout_seconds)
                renewed_stage = completed_stage
        if budget is None:
            budget = ExecutionBudget.start(timeout_seconds)
        updates: dict[str, Any] = {"execution_budget": budget.checkpoint()}
        if renewed_stage is not None:
            updates["execution_budget_stage"] = renewed_stage
        await self.checkpoint_source_cluster( claim=claim, updates=updates)
        return budget


    async def renew_source_cluster_execution_budget_after_checkpoint(
        self,
        *,
        claim: SourceClusterClaim,
        budget,
        completed_stage: str,
        timeout_seconds: float,
    ) -> None:
        """Renew only after the current claim durably exposes the completed stage."""


        row = await self._claimed_row( claim=claim)
        payload = _cluster_result_payload(row)
        required_shape = {
            "semantic_inference": (
                isinstance(payload.get("semantic_candidates"), dict)
                and isinstance(payload.get("processed_part_refs"), list)
            ),
            "visual_verification": isinstance(
                payload.get("visual_verification"), dict
            ),
        }
        if completed_stage not in required_shape:
            raise SourceClusterStateError(
                f"source_cluster_execution_stage_unknown:{completed_stage}"
            )
        if not required_shape[completed_stage]:
            raise SourceClusterStateError(
                f"source_cluster_execution_stage_not_checkpointed:{completed_stage}"
            )
        if current_execution_budget() is not budget:
            raise SourceClusterStateError("source_cluster_execution_budget_not_current")
        budget.renew_after_completed_stage(timeout_seconds)
        # 存档记下这份预算属于哪个已完成阶段：begin 恢复时据此区分
        # "阶段已存盘、续期未提交"（可续一次）与"已续期、下一阶段中途
        # 崩溃后预算再过期"（不得再续，每个完成阶段只恢复一次）。
        await self.checkpoint_source_cluster( claim=claim, updates={"execution_budget_stage": completed_stage}
        )


    async def complete_source_cluster(
        self,
        *,
        claim: SourceClusterClaim,
        semantic_payload: dict[str, Any],
        processed_part_refs: Iterable[str],
        output: dict[str, Any],
        failures: Iterable[dict[str, Any]] = (),
        review_source_refs: Iterable[str] = (),
        model_call_count: int = 0,
        retry_delay_jitter: RetryDelayJitter | None = None,
        now: datetime | None = None,
    ) -> str:
        """Persist exact coverage and terminal/retry state for one cluster."""

        row = await self._claimed_row( claim=claim)
        current_time = now or utc_now()
        manifest = json.loads(row.manifest_json)
        expected_sources = tuple(manifest.get("sources") or [])
        expected_source_refs = tuple(
            str(item.get("source_ref") or "") for item in expected_sources
        )
        expected_part_refs = tuple(
            str(item.get("part_ref") or "") for item in manifest.get("parts") or []
        )
        processed_parts = tuple(dict.fromkeys(str(item) for item in processed_part_refs))
        failure_rows = tuple(
            source_cluster_failure_with_retry_policy(
                dict(failure),
                attempt_count=int(row.attempt_count or 0),
            )
            for failure in failures
        )
        failed_parts = {
            str(part_ref)
            for failure in failure_rows
            for part_ref in failure.get("part_refs") or []
            if str(part_ref)
        }
        accounted_part_refs = set(processed_parts) | failed_parts
        if accounted_part_refs != set(expected_part_refs):
            raise SourceClusterStateError(
                "source_cluster_part_coverage_incomplete:"
                f"missing={sorted(set(expected_part_refs) - accounted_part_refs)}"
            )
        accounted_parts = tuple(
            part_ref for part_ref in expected_part_refs if part_ref in accounted_part_refs
        )
        source_coverage = {
            str(item.get("source_ref") or ""): str(item.get("status") or "")
            for item in semantic_payload.get("source_coverage") or []
            if isinstance(item, dict)
        }
        if set(source_coverage) != set(expected_source_refs):
            raise SourceClusterStateError(
                "source_cluster_source_coverage_incomplete"
            )
        if failure_rows:
            output["technical_failures"] = [dict(item) for item in failure_rows]
            output["source_retry_refs"] = sorted(
                {
                    str(source_ref)
                    for item in failure_rows
                    if bool(item.get("retryable"))
                    for source_ref in item.get("source_refs") or []
                }
            )
            output["source_quarantined_refs"] = sorted(
                {
                    str(source_ref)
                    for item in failure_rows
                    if not bool(item.get("retryable"))
                    for source_ref in item.get("source_refs") or []
                }
            )
        failures_by_source = _failure_index(failure_rows)
        review_refs = {str(item) for item in review_source_refs}
        pending_owner_refs = _pending_owner_effect_refs(output)
        candidate_refs_by_source: dict[str, list[str]] = {}
        for candidate in semantic_payload.get("candidates") or []:
            if not isinstance(candidate, dict):
                continue
            candidate_ref = str(candidate.get("candidate_ref") or "")
            for source_ref in candidate.get("source_refs") or []:
                candidate_refs_by_source.setdefault(str(source_ref), []).append(
                    candidate_ref
                )

        members = await self._members(row.id)
        source_status: dict[str, str] = {}
        for member in members:
            source_failures = failures_by_source.get(member.source_ref) or []
            if any(bool(item.get("retryable")) for item in source_failures):
                status = "retry_pending"
            elif source_failures:
                status = "quarantined"
            elif member.source_ref in review_refs:
                status = "review_pending"
            elif member.source_ref in pending_owner_refs:
                status = "awaiting_owner_apply"
            else:
                status = {
                    "observed": "completed",
                    "not_business": "not_business",
                    "unavailable": "unavailable",
                }.get(
                    source_coverage[member.source_ref],
                    source_coverage[member.source_ref],
                )
            source_status[member.source_ref] = status
            member.coverage_status = status
            member.candidate_refs_json = stable_json(
                sorted(set(candidate_refs_by_source.get(member.source_ref) or []))
            )
            member.error_fingerprint = next(
                (
                    str(item.get("failure_fingerprint") or "") or None
                    for item in source_failures
                ),
                None,
            )
            member.processed_at = current_time

        any_retryable = any(bool(item.get("retryable")) for item in failure_rows)
        any_deterministic = any(not bool(item.get("retryable")) for item in failure_rows)
        status = reduce_source_cluster_status(
            pending_owner_apply=bool(pending_owner_refs),
            has_retryable_failure=any_retryable,
            has_deterministic_failure=any_deterministic,
            has_pending_review=bool(review_refs),
        )
        row.status = status
        row.coverage_json = stable_json(
            {
                "schema_version": "business_agent_source_cluster_coverage.v1",
                "expected_source_refs": list(expected_source_refs),
                "expected_part_refs": list(expected_part_refs),
                "processed_source_refs": list(expected_source_refs),
                "processed_part_refs": list(accounted_parts),
                "missing_source_refs": [],
                "missing_part_refs": [],
                "source_status": source_status,
            }
        )
        budget_payload = _cluster_result_payload(row).get("execution_budget")
        if budget_payload is not None:
            output["execution_budget"] = budget_payload
        executor_identity = _cluster_result_payload(row).get("semantic_executor")
        if executor_identity is not None:
            output["semantic_executor"] = executor_identity
        row.result_json = stable_json(output)
        row.processed_source_count = len(expected_source_refs)
        row.processed_part_count = len(accounted_parts)
        row.model_call_count = int(row.model_call_count or 0) + int(model_call_count)
        row.retryable = any_retryable
        first_failure = next(iter(failure_rows), None)
        row.failure_category = (
            str((first_failure or {}).get("category") or "") or None
        )
        row.error_fingerprint = (
            str((first_failure or {}).get("failure_fingerprint") or "") or None
        )
        row.last_error = (
            str((first_failure or {}).get("reason") or "")[:4_000] or None
        )
        row.next_retry_at = (
            current_time
            + timedelta(
                seconds=source_cluster_retry_delay_seconds(
                    attempt_count=int(row.attempt_count or 0),
                    jitter=retry_delay_jitter,
                )
            )
            if any_retryable
            else None
        )
        row.claim_token = None
        row.lease_expires_at = None
        row.completed_at = (
            current_time
            if status not in {"retry_pending", "awaiting_owner_apply"}
            else None
        )
        await self.flush()
        return status


    async def apply_source_review_closure_coverage(
        self,
        *,
        coverage_by_source: Mapping[str, str],
        now: datetime | None = None,
    ) -> dict[str, list[int]]:
        """Write one terminal human Review back into cluster coverage.

        Only members still parked on ``review_pending`` for those exact sources
        are rewritten, and only a cluster whose own status is still
        ``review_pending`` is re-reduced.  Every other member or cluster state
        belongs to the queue, retry or Owner-apply path and is left untouched, so
        this closure can run again without changing anything.
        """

        refs = sorted(
            {
                str(source_ref)
                for source_ref, status in coverage_by_source.items()
                if str(source_ref) and str(status) and str(status) != "review_pending"
            }
        )
        if not refs:
            return {"updated_member_ids": [], "updated_cluster_ids": []}
        params = {f"ref_{index}": ref for index, ref in enumerate(refs)}
        placeholders = ",".join(":" + key for key in params)
        values = await self.sql.all("SELECT * FROM business_agent_source_cluster_members WHERE coverage_status='review_pending' AND source_ref IN (" + placeholders + ")", params)
        members = [self._row("business_agent_source_cluster_members", value) for value in values]
        if not members:
            return {"updated_member_ids": [], "updated_cluster_ids": []}
        current_time = now or utc_now()
        updated_member_ids: list[int] = []
        cluster_row_ids: set[int] = set()
        for member in members:
            member.coverage_status = str(coverage_by_source[member.source_ref])
            updated_member_ids.append(int(member.id))
            cluster_row_ids.add(int(member.cluster_id))

        updated_cluster_ids: list[int] = []
        for cluster_row_id in sorted(cluster_row_ids):
            row = await self._cluster(cluster_row_id)
            if row is None or str(row.status or "") != "review_pending":
                continue
            row_members = await self._members(row.id)
            source_status = {
                str(item.source_ref): str(item.coverage_status or "")
                for item in row_members
            }
            next_status = source_cluster_status_from_member_coverage(
                source_status.values()
            )
            if next_status is None:
                continue
            try:
                coverage = json.loads(row.coverage_json or "{}")
            except (TypeError, ValueError, json.JSONDecodeError):
                coverage = {}
            if not isinstance(coverage, dict):
                coverage = {}
            coverage["source_status"] = {
                **(coverage.get("source_status") or {}),
                **source_status,
            }
            row.coverage_json = stable_json(coverage)
            if next_status != str(row.status or ""):
                row.status = next_status
                row.completed_at = row.completed_at or current_time
                updated_cluster_ids.append(int(row.id))
        await self.flush()
        return {
            "updated_member_ids": sorted(updated_member_ids),
            "updated_cluster_ids": updated_cluster_ids,
        }


    async def load_source_cluster_promotion_payload(
        self,
        *,
        claim: SourceClusterClaim,
    ) -> dict[str, Any]:
        """Load the persisted no-recall payload under the promotion lease."""

        row = await self._claimed_row(
            claim=claim,
            expected_status="promotion_running",
        )
        try:
            payload = json.loads(row.result_json or "{}")
        except (TypeError, ValueError, json.JSONDecodeError) as exc:
            raise SourceClusterStateError(
                "source_cluster_promotion_payload_invalid"
            ) from exc
        if not isinstance(payload, dict):
            raise SourceClusterStateError(
                "source_cluster_promotion_payload_invalid"
            )
        if not _pending_owner_effect_refs(payload):
            raise SourceClusterStateError(
                "source_cluster_promotion_has_no_pending_owner_effect"
            )
        return payload


    async def unresolved_prior_promotion_failures(
        self,
        *,
        executions: Iterable[dict[str, Any]],
        replaced_decision_ids: Iterable[str] = (),
    ) -> tuple[dict[str, Any], ...]:
        """仍无 resolution 的前轮 promotion 故障（按 Decision lineage 归并）。

        #893：不可重试候选失败会把 ``promotion_failure`` 持久化进 execution。
        后续轮次同源兄弟成功不能解决它；invalidated 是终态，不能拿它本身
        的状态判已解决——只有同一 source_key+record_type 下比失败那个更新、
        且已消费或人工覆盖的后继 Decision 存在才算解决。本轮已替换的条目
        由本轮结果负责，不在这里重复计入。
        """
        replaced_ids = {str(item) for item in replaced_decision_ids if str(item)}
        candidate_entries: list[tuple[str, dict[str, Any]]] = []
        for execution in executions:
            if not isinstance(execution, dict):
                continue
            decision_id = str(execution.get("decision_id") or "")
            if (
                str(execution.get("decision_state") or "") != "invalidated"
                or decision_id in replaced_ids
                or not isinstance(execution.get("promotion_failure"), dict)
            ):
                continue
            candidate_entries.append((decision_id, execution["promotion_failure"]))
        if not candidate_entries:
            return ()
        params = {f"decision_{index}": decision_id for index, (decision_id, _) in enumerate(candidate_entries)}
        rows = await self.sql.all("SELECT id, decision_id, state, source_key, record_type FROM business_agent_decisions WHERE decision_id IN (" + ",".join(":" + key for key in params) + ")", params)
        invalidated_rows_by_id = {str(row["decision_id"]): row for row in rows}
        unresolved_ids = set()
        for decision_id, _failure in candidate_entries:
            row = invalidated_rows_by_id.get(decision_id)
            if row is None or str(row["state"] or "") != "invalidated":
                continue
            successor = await self.sql.one("SELECT id FROM business_agent_decisions WHERE source_key=:source AND record_type=:record AND id>:id AND state IN ('consumed','human_overridden') LIMIT 1", {"source": row["source_key"], "record": row["record_type"], "id": row["id"]})
            if successor is None:
                unresolved_ids.add(decision_id)
        failures: dict[str, dict[str, Any]] = {}
        for decision_id, failure in candidate_entries:
            if decision_id not in unresolved_ids:
                continue
            fingerprint = str(failure.get("failure_fingerprint") or "")
            failures.setdefault(fingerprint or f"decision:{decision_id}", failure)
        return tuple(failures.values())


    async def complete_source_cluster_promotion(
        self,
        *,
        claim: SourceClusterClaim,
        execution_replacements: dict[str, dict[str, Any]],
        promotion_failures: Iterable[dict[str, Any]] = (),
        now: datetime | None = None,
    ) -> str:
        """Finalize persisted Decisions after Owner apply/readback, without inference."""

        row = await self._claimed_row(
            claim=claim,
            expected_status="promotion_running",
        )
        current_time = now or utc_now()
        output = await self.load_source_cluster_promotion_payload( claim=claim)
        executions: list[dict[str, Any]] = []
        for raw in output.get("executions") or []:
            if not isinstance(raw, dict):
                continue
            decision_id = str(raw.get("decision_id") or "")
            replacement = execution_replacements.get(decision_id)
            executions.append(dict(replacement or raw))
        output["executions"] = executions
        # #893：归约使用完整耐久候选结果——前轮持久化、仍未解决的 promotion
        # 故障按 Decision lineage 并入本轮故障，本轮成功只清理它自己解决的
        # 故障，不能按同源兄弟清掉另一个候选的永久失败。
        prior_failure_rows = await self.unresolved_prior_promotion_failures(
            executions=executions,
            replaced_decision_ids=(
                str(replacement.get("decision_id") or "")
                for replacement in execution_replacements.values()
            ),
        )
        promotion_failure_rows = (*prior_failure_rows, *promotion_failures)
        output["owner_promotion"] = {
            "schema_version": "business_agent_owner_promotion.v1",
            "promoted_at": current_time.isoformat(),
            "originating_runtime_fingerprint": str(
                row.runtime_fingerprint or ""
            ),
            "originating_code_version": str(row.code_version or ""),
            "promoter_runtime_fingerprint": self.promoter_runtime_fingerprint,
            "promoter_code_version": str(claim.code_version or ""),
            "reused_decision_count": len(execution_replacements),
            "model_call_count": 0,
            "failures": list(promotion_failure_rows),
        }
        pending_owner_refs = _pending_owner_effect_refs(output)
        retryable_promotion_refs = {
            str(source_ref)
            for failure in promotion_failure_rows
            if bool(failure.get("retryable"))
            for source_ref in failure.get("source_refs") or []
        }
        if pending_owner_refs - retryable_promotion_refs:
            raise SourceClusterStateError(
                "source_cluster_promotion_incomplete"
            )

        inference_failure_rows = tuple(
            item
            for item in output.get("technical_failures") or []
            if isinstance(item, dict)
        )
        failure_rows = (*inference_failure_rows, *promotion_failure_rows)
        failures_by_source = _failure_index(failure_rows)
        review_refs = {
            str(source_ref)
            for execution in executions
            if str(execution.get("action") or "") == "review"
            for source_ref in execution.get("source_refs") or []
        }
        members = await self._members(row.id)
        coverage = json.loads(row.coverage_json or "{}")
        source_status = dict(coverage.get("source_status") or {})
        promoted_refs = {
            str(source_ref)
            for execution in execution_replacements.values()
            for source_ref in execution.get("source_refs") or []
        }
        for member in members:
            source_failures = failures_by_source.get(member.source_ref) or []
            if any(bool(item.get("retryable")) for item in source_failures):
                member_status = "retry_pending"
            elif source_failures:
                member_status = "quarantined"
            elif member.source_ref in review_refs:
                member_status = "review_pending"
            elif (
                member.source_ref in promoted_refs
                and member.coverage_status
                in {
                    "awaiting_owner_apply",
                    "retry_pending",
                    "promotion_quarantined",
                }
            ):
                member_status = "completed"
            else:
                member_status = str(member.coverage_status or "completed")
            member.coverage_status = member_status
            member.processed_at = current_time
            source_status[member.source_ref] = member_status

        any_retryable = any(bool(item.get("retryable")) for item in failure_rows)
        any_deterministic = any(
            not bool(item.get("retryable")) for item in failure_rows
        )
        status = reduce_source_cluster_status(
            pending_owner_apply=bool(pending_owner_refs),
            has_retryable_failure=any_retryable,
            has_deterministic_failure=any_deterministic,
            has_pending_review=bool(review_refs),
        )
        coverage["source_status"] = source_status
        row.status = status
        row.coverage_json = stable_json(coverage)
        row.result_json = stable_json(output)
        row.retryable = any_retryable
        first_promotion_failure = next(iter(promotion_failure_rows), None)
        if first_promotion_failure is not None:
            row.failure_category = (
                str(first_promotion_failure.get("category") or "") or None
            )
            row.error_fingerprint = (
                str(first_promotion_failure.get("failure_fingerprint") or "")
                or None
            )
            row.last_error = (
                str(first_promotion_failure.get("reason") or "")[:4_000]
                or None
            )
        elif not inference_failure_rows:
            row.failure_category = None
            row.error_fingerprint = None
            row.last_error = None
        row.claim_token = None
        row.lease_expires_at = None
        row.next_retry_at = (
            current_time + timedelta(seconds=DEFAULT_RETRY_SECONDS)
            if any_retryable
            else None
        )
        row.completed_at = (
            current_time
            if status not in {"retry_pending", "awaiting_owner_apply"}
            else None
        )
        await self.flush()
        return status


    async def fail_source_cluster_promotion(
        self,
        *,
        claim: SourceClusterClaim,
        failure: dict[str, Any],
        retry_seconds: int = DEFAULT_RETRY_SECONDS,
        now: datetime | None = None,
    ) -> str:
        """Release a promotion lease without ever falling back to model inference."""

        row = await self._claimed_row(
            claim=claim,
            expected_status="promotion_running",
        )
        current_time = now or utc_now()
        retryable = bool(failure.get("retryable"))
        row.status = (
            "awaiting_owner_apply" if retryable else "promotion_quarantined"
        )
        row.retryable = retryable
        row.failure_category = str(failure.get("category") or "") or None
        row.error_fingerprint = (
            str(failure.get("failure_fingerprint") or "") or None
        )
        row.last_error = str(failure.get("reason") or "")[:4_000] or None
        row.next_retry_at = (
            current_time + timedelta(seconds=max(1, int(retry_seconds)))
            if retryable
            else None
        )
        row.claim_token = None
        row.lease_expires_at = None
        row.completed_at = None if retryable else current_time
        members = await self._members(row.id)
        affected = {str(item) for item in failure.get("source_refs") or []}
        if not affected:
            affected = {str(member.source_ref) for member in members}
            failure["source_refs"] = sorted(affected)
        try:
            coverage = json.loads(row.coverage_json or "{}")
        except (TypeError, ValueError, json.JSONDecodeError):
            coverage = {}
        source_status = dict(coverage.get("source_status") or {})
        for member in members:
            if affected and member.source_ref not in affected:
                continue
            member.coverage_status = row.status
            member.error_fingerprint = row.error_fingerprint
            member.processed_at = current_time
            source_status[member.source_ref] = row.status
        coverage["source_status"] = source_status
        row.coverage_json = stable_json(coverage)
        try:
            output = json.loads(row.result_json or "{}")
        except (TypeError, ValueError, json.JSONDecodeError):
            output = {}
        if not isinstance(output, dict):
            output = {}
        technical_failures = [
            item
            for item in output.get("technical_failures") or []
            if isinstance(item, dict)
        ]
        # A retryable Owner promotion fault is lease state, not an inference
        # failure.  Persist it under ``owner_promotion`` and on the row, but do not
        # poison the immutable inference failure list: a later successful retry
        # must be able to close this cluster.  Deterministic promotion quarantine
        # is terminal and belongs in the visible technical-failure projection.
        if not retryable:
            technical_failures.append(dict(failure))
        output["technical_failures"] = technical_failures
        output["owner_promotion"] = {
            "schema_version": "business_agent_owner_promotion.v1",
            "promoted_at": current_time.isoformat(),
            "originating_runtime_fingerprint": str(
                row.runtime_fingerprint or ""
            ),
            "originating_code_version": str(row.code_version or ""),
            "promoter_runtime_fingerprint": self.promoter_runtime_fingerprint,
            "promoter_code_version": str(claim.code_version or ""),
            "reused_decision_count": 0,
            "model_call_count": 0,
            "failures": [dict(failure)],
        }
        row.result_json = stable_json(output)
        await self.flush()
        return row.status


    async def fail_source_cluster(
        self,
        *,
        claim: SourceClusterClaim,
        failure: dict[str, Any],
        model_call_count: int = 0,
        retry_seconds: int | None = None,
        retry_delay_jitter: RetryDelayJitter | None = None,
        enforce_model_retry_policy: bool = True,
        now: datetime | None = None,
    ) -> str:
        """Persist a cluster-level failure without creating a business Review."""

        row = await self._claimed_row( claim=claim)
        current_time = now or utc_now()
        effective_failure = (
            source_cluster_failure_with_retry_policy(
                failure,
                attempt_count=int(row.attempt_count or 0),
            )
            if enforce_model_retry_policy
            else dict(failure)
        )
        failure.clear()
        failure.update(effective_failure)
        retryable = bool(effective_failure.get("retryable"))
        row.status = "retry_pending" if retryable else "quarantined"
        row.retryable = retryable
        row.failure_category = (
            str(effective_failure.get("category") or "") or None
        )
        row.error_fingerprint = (
            str(effective_failure.get("failure_fingerprint") or "") or None
        )
        row.last_error = (
            str(effective_failure.get("reason") or "")[:4_000] or None
        )
        row.model_call_count = int(row.model_call_count or 0) + int(model_call_count)
        row.next_retry_at = (
            current_time
            + timedelta(
                seconds=(
                    max(1, int(retry_seconds))
                    if retry_seconds is not None
                    else source_cluster_retry_delay_seconds(
                        attempt_count=int(row.attempt_count or 0),
                        jitter=retry_delay_jitter,
                    )
                )
            )
            if retryable
            else None
        )
        row.claim_token = None
        row.lease_expires_at = None
        row.completed_at = None if retryable else current_time
        members = await self._members(row.id)
        affected = {
            str(item)
            for item in effective_failure.get("source_refs") or []
        }
        if not affected:
            affected = {str(member.source_ref) for member in members}
            effective_failure["source_refs"] = sorted(affected)
            failure["source_refs"] = sorted(affected)
        result_payload = {**_cluster_result_payload(row), "technical_failure": effective_failure}
        row.result_json = stable_json(result_payload)
        for member in members:
            if affected and member.source_ref not in affected:
                continue
            member.coverage_status = row.status
            member.error_fingerprint = row.error_fingerprint
        await self.flush()
        return row.status


    async def close_prepared_reference(self, *, agent_name, source_ref, prepared_ref, verified_readback):
        """Close only existing Generic metadata after the original Owner proved its effect."""
        if not isinstance(verified_readback, dict):
            raise SourceClusterStateError("source_cluster_prepared_readback_missing")
        rows = await self._clusters("agent_name=:agent AND status IN ('awaiting_owner_apply','completed')", {"agent": agent_name})
        updated = []
        for row in rows:
            payload = _cluster_result_payload(row)
            if payload.get("prepared_ref") != prepared_ref:
                continue
            manifest = json.loads(row.manifest_json)
            if [source.get("source_ref") for source in manifest.get("sources") or []] != [source_ref]:
                raise SourceClusterStateError("source_cluster_prepared_source_conflict")
            members = await self._members(row.id)
            if len(members) != 1 or members[0].source_ref != source_ref or manifest.get("source_hashes", {}).get(source_ref) != members[0].source_sha256:
                raise SourceClusterStateError("source_cluster_prepared_source_conflict")
            for member in members:
                if member.coverage_status == "awaiting_owner_apply":
                    member.coverage_status = "completed"
                    member.processed_at = utc_now()
            status = source_cluster_status_from_member_coverage(member.coverage_status for member in members)
            if status is None:
                continue
            coverage = json.loads(row.coverage_json or "{}")
            coverage["source_status"] = {member.source_ref: member.coverage_status for member in members}
            row.coverage_json = stable_json(coverage)
            if row.status != status:
                row.status = status
                row.completed_at = utc_now()
                updated.append(row.id)
            await self.flush()
        return updated
