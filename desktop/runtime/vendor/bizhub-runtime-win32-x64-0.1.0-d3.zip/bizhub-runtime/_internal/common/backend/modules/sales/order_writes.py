"""销售单头 / 明细行的物理写入原语：在调用方借出的连接、同一个事务里用裸 SQL 写标准表
（``order_schema.SALES_BATCHES`` / ``SALES_ORDERS``）；列按库里这张表的实际列核对，部署或客户登记的扩展列同一条语句落。

页面、Agent、单据内核都经各自 Owner 走到这里（通用 Owner 与客户的销售单据 Owner 同一个写入程序），
这里只管"列合不合法、怎么落"：不提交、不开事务、不判业务规则。
- 列名必须是这张表的实际列（主键 id 不可写），否则整条拒绝；
- 新建时非空文本列的显式 None 按列默认值落（与 ORM 插入契约一致）；
- Decimal / date / datetime 以 ORM 现在落库的字面写入，回放对比按列值校。
"""

from __future__ import annotations

import sqlite3
from datetime import date, datetime
from decimal import Decimal
from typing import Any, Mapping

from .order_schema import SALES_BATCHES, SALES_ORDERS

_TABLES = {"header": SALES_BATCHES.name, "line": SALES_ORDERS.name}


class SalesOrderWriteError(RuntimeError):
    def __init__(self, code: str, message: str = ""):
        super().__init__(f"{code}: {message}" if message else code)
        self.code = code
        self.message = message


def _literal(value: Any) -> Any:
    if isinstance(value, datetime):
        return value.strftime("%Y-%m-%d %H:%M:%S.%f")
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, Decimal):
        return str(value)
    if isinstance(value, bool):
        return int(value)
    return value


def _text_default(declared: str | None) -> str:
    if declared is None:
        return ""
    return declared[1:-1].replace("''", "'") if len(declared) >= 2 and declared[0] == declared[-1] == "'" else declared


class SalesRecordWriter:
    """``kind`` 是 ``header``（sales_batches）或 ``line``（sales_orders）。"""

    def __init__(self, kind: str):
        if kind not in _TABLES:
            raise SalesOrderWriteError("sales_record_kind_invalid", str(kind))
        self.kind = kind
        self.table = _TABLES[kind]

    def _columns(self, connection: sqlite3.Connection) -> dict[str, tuple[Any, ...]]:
        # PRAGMA table_info 行：cid, name, type, notnull, dflt_value, pk
        return {str(row[1]): tuple(row) for row in connection.execute(f'PRAGMA table_info("{self.table}")').fetchall()}

    def materialize(self, connection: sqlite3.Connection, row_id: int | None, values: Mapping[str, Any]) -> int:
        """新建（``row_id`` 为 None）或改写一行；返回行编号。只写传入的列，其余列保持。"""

        values = dict(values)
        columns = self._columns(connection)
        illegal = sorted(set(values) - set(columns) | ({"id"} & set(values)))
        if illegal:
            raise SalesOrderWriteError("sales_record_column_invalid", ",".join(illegal))
        if row_id is None:
            for name, column in columns.items():
                if name in values and values[name] is None and column[3] and str(column[2]).upper().startswith(("VARCHAR", "TEXT")):
                    values[name] = _text_default(column[4])
            if not values:
                raise SalesOrderWriteError("sales_record_empty_insert", self.table)
            names = list(values)
            cursor = connection.execute(
                f'INSERT INTO "{self.table}" ({", ".join(f"{chr(34)}{n}{chr(34)}" for n in names)}) VALUES ({", ".join("?" for _ in names)})',
                tuple(_literal(values[n]) for n in names),
            )
            return int(cursor.lastrowid)
        if not values:
            return int(row_id)
        names = list(values)
        cursor = connection.execute(
            f'UPDATE "{self.table}" SET ' + ", ".join(f'"{n}"=?' for n in names) + " WHERE id=?",
            (*(_literal(values[n]) for n in names), int(row_id)),
        )
        if cursor.rowcount != 1:
            raise SalesOrderWriteError("sales_record_not_found", f"{self.table}:{row_id}")
        return int(row_id)

    def delete(self, connection: sqlite3.Connection, row_id: int) -> None:
        cursor = connection.execute(f'DELETE FROM "{self.table}" WHERE id=?', (int(row_id),))
        if cursor.rowcount != 1:
            raise SalesOrderWriteError("sales_record_not_found", f"{self.table}:{row_id}")


__all__ = ["SalesOrderWriteError", "SalesRecordWriter"]
