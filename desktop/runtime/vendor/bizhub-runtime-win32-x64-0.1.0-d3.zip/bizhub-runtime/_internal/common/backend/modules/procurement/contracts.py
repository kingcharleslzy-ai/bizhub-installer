"""Typed procurement commands and state-bound previews."""

from __future__ import annotations

from dataclasses import dataclass, field, fields
from typing import Any, Mapping

from backend.modules.master_data.public import contract_scalar_ok
from backend.modules.trade_core.public import digest_json


@dataclass(frozen=True)
class ProcurementLine:
    line_id: str
    product_id: int
    unit_id: int
    quantity: str
    receive_location_id: str

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> "ProcurementLine":
        if not isinstance(payload, Mapping) or any(not contract_scalar_ok(key, value) for key, value in payload.items()):
            raise TypeError("procurement line must be an object with string fields")
        return cls(**dict(payload))

    def to_dict(self) -> dict[str, str]:
        return {
            "line_id": self.line_id,
            "product_id": self.product_id,
            "unit_id": self.unit_id,
            "quantity": self.quantity,
            "receive_location_id": self.receive_location_id,
        }


@dataclass(frozen=True)
class ProcurementCommand:
    action: str
    idempotency_key: str
    order_id: str
    supplier_party_id: int | None = None
    ordered_at: str = ""
    lines: tuple[ProcurementLine, ...] = field(default_factory=tuple)
    target_line_id: str = ""
    quantity: str = ""
    occurred_at: str = ""
    source_ref: str = ""
    evidence_refs: tuple[str, ...] = field(default_factory=tuple)
    reason: str = ""

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> "ProcurementCommand":
        if not isinstance(payload, Mapping):
            raise TypeError("command must be an object")
        values = dict(payload)
        if any(not contract_scalar_ok(key, value, nullable=("supplier_party_id",))
               for key, value in payload.items() if key not in {"lines", "evidence_refs"}):
            raise TypeError("procurement command fields must be strings")
        lines = payload.get("lines", ())
        evidence_refs = payload.get("evidence_refs", ())
        if not isinstance(lines, (list, tuple)) or not isinstance(evidence_refs, (list, tuple)):
            raise TypeError("lines and evidence_refs must be arrays")
        if any(not isinstance(item, str) for item in evidence_refs):
            raise TypeError("evidence_refs items must be strings")
        values["lines"] = tuple(
            ProcurementLine.from_dict(item) for item in lines
        )
        values["evidence_refs"] = tuple(evidence_refs)
        return cls(**values)

    def to_dict(self) -> dict[str, Any]:
        return {
            "action": self.action,
            "idempotency_key": self.idempotency_key,
            "order_id": self.order_id,
            "supplier_party_id": self.supplier_party_id,
            "ordered_at": self.ordered_at,
            "lines": [item.to_dict() for item in self.lines],
            "target_line_id": self.target_line_id,
            "quantity": self.quantity,
            "occurred_at": self.occurred_at,
            "source_ref": self.source_ref,
            "evidence_refs": list(self.evidence_refs),
            "reason": self.reason,
        }

    @property
    def command_digest(self) -> str:
        return digest_json(self.to_dict())


@dataclass(frozen=True)
class ProcurementPreview:
    command: ProcurementCommand
    state_generation: str
    planned_order: dict[str, Any]
    planned_lines: tuple[dict[str, Any], ...]
    planned_receipt: dict[str, Any] | None
    inventory_preview: dict[str, Any] | None
    preview_digest: str

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> "ProcurementPreview":
        if not isinstance(payload, Mapping):
            raise TypeError("preview must be an object")
        for key in ("state_generation", "preview_digest"):
            if not isinstance(payload[key], str):
                raise TypeError(f"{key} must be a string")
        command_payload = payload.get("command")
        if not isinstance(command_payload, Mapping):
            raise TypeError("command is required")
        planned_order = payload.get("planned_order")
        if not isinstance(planned_order, Mapping):
            raise TypeError("planned_order is required")
        receipt = payload.get("planned_receipt")
        inventory = payload.get("inventory_preview")
        for key, value in (("planned_receipt", receipt), ("inventory_preview", inventory)):
            if value is not None and not isinstance(value, Mapping):
                raise TypeError(f"{key} must be an object or null")
        planned_lines = payload.get("planned_lines", ())
        if not isinstance(planned_lines, (list, tuple)) or any(not isinstance(item, Mapping) for item in planned_lines):
            raise TypeError("planned_lines must be an array of objects")
        return cls(
            command=ProcurementCommand.from_dict(command_payload),
            state_generation=payload["state_generation"],
            planned_order=dict(planned_order),
            planned_lines=tuple(dict(item) for item in planned_lines),
            planned_receipt=dict(receipt) if isinstance(receipt, Mapping) else None,
            inventory_preview=dict(inventory) if isinstance(inventory, Mapping) else None,
            preview_digest=payload["preview_digest"],
        )

    def content(self) -> dict[str, Any]:
        return {
            "command": self.command.to_dict(),
            "state_generation": self.state_generation,
            "planned_order": self.planned_order,
            "planned_lines": list(self.planned_lines),
            "planned_receipt": self.planned_receipt,
            "inventory_preview": self.inventory_preview,
        }

    def to_dict(self) -> dict[str, Any]:
        return {**self.content(), "preview_digest": self.preview_digest}


@dataclass(frozen=True)
class ProcurementReceiptLine:
    line_id: str
    product_id: int | None = None
    unit_id: int | None = None
    arrived_quantity: str = ""
    order_line_id: str = ""
    received_quantity: str = ""
    accepted_quantity: str = ""
    rejected_quantity: str = ""

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> "ProcurementReceiptLine":
        if not isinstance(payload, Mapping) or any(
            not contract_scalar_ok(key, value, nullable=("product_id", "unit_id")) for key, value in payload.items()
        ):
            raise TypeError("receipt line must be an object with string fields")
        return cls(**dict(payload))

    def to_dict(self) -> dict[str, str]:
        return dict(vars(self))


@dataclass(frozen=True)
class ProcurementReceiptAllocation:
    receipt_line_id: str
    order_line_id: str
    location_id: str
    quantity: str
    over_receipt_allowance: str = "0"

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> "ProcurementReceiptAllocation":
        if not isinstance(payload, Mapping) or any(not contract_scalar_ok(key, value) for key, value in payload.items()):
            raise TypeError("receipt allocation must be an object with string fields")
        return cls(**dict(payload))

    def to_dict(self) -> dict[str, str]:
        return dict(vars(self))


@dataclass(frozen=True)
class ProcurementReceiptCommand:
    action: str
    idempotency_key: str
    document_id: str
    supplier_party_id: int | None = None
    source_identity: str = ""
    occurred_at: str = ""
    source_ref: str = ""
    evidence_refs: tuple[str, ...] = field(default_factory=tuple)
    reason: str = ""
    lines: tuple[ProcurementReceiptLine, ...] = field(default_factory=tuple)
    allocations: tuple[ProcurementReceiptAllocation, ...] = field(default_factory=tuple)
    post_reference: str | None = None

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> "ProcurementReceiptCommand":
        if not isinstance(payload, Mapping):
            raise TypeError("receipt command must be an object")
        values = dict(payload)
        arrays = {"lines", "allocations", "evidence_refs"}
        if any(not contract_scalar_ok(key, value, nullable=("post_reference", "supplier_party_id"))
               for key, value in payload.items() if key not in arrays):
            raise TypeError("receipt command fields must be strings")
        for key in arrays:
            if not isinstance(payload.get(key, ()), (list, tuple)):
                raise TypeError(f"{key} must be an array")
        if any(not isinstance(item, str) for item in payload.get("evidence_refs", ())):
            raise TypeError("evidence_refs items must be strings")
        values["lines"] = tuple(ProcurementReceiptLine.from_dict(item) for item in payload.get("lines", ()))
        values["allocations"] = tuple(ProcurementReceiptAllocation.from_dict(item) for item in payload.get("allocations", ()))
        values["evidence_refs"] = tuple(payload.get("evidence_refs", ()))
        return cls(**values)

    def to_dict(self) -> dict[str, Any]:
        return {**{key: value for key, value in vars(self).items() if key != "post_reference" or value is not None},
                "lines": [item.to_dict() for item in self.lines],
                "allocations": [item.to_dict() for item in self.allocations], "evidence_refs": list(self.evidence_refs)}

    @property
    def command_digest(self) -> str:
        return digest_json(self.to_dict())


@dataclass(frozen=True)
class ProcurementReceiptPreview:
    command: ProcurementReceiptCommand
    state_generation: str
    planned_document: dict[str, Any]
    planned_lines: tuple[dict[str, Any], ...]
    planned_allocations: tuple[dict[str, Any], ...]
    inventory_previews: tuple[dict[str, Any], ...]
    preview_digest: str

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> "ProcurementReceiptPreview":
        if not isinstance(payload, Mapping):
            raise TypeError("receipt preview must be an object")
        for key in ("state_generation", "preview_digest"):
            if not isinstance(payload[key], str):
                raise TypeError(f"{key} must be a string")
        if not isinstance(payload["planned_document"], Mapping):
            raise TypeError("planned_document must be an object")
        arrays = {}
        for key in ("planned_lines", "planned_allocations", "inventory_previews"):
            value = payload[key]
            if not isinstance(value, (list, tuple)) or any(not isinstance(item, Mapping) for item in value):
                raise TypeError(f"{key} must be an array of objects")
            arrays[key] = tuple(dict(item) for item in value)
        return cls(command=ProcurementReceiptCommand.from_dict(payload["command"]),
                   state_generation=payload["state_generation"], planned_document=dict(payload["planned_document"]),
                   preview_digest=payload["preview_digest"], **arrays)

    def content(self) -> dict[str, Any]:
        return {"command": self.command.to_dict(), "state_generation": self.state_generation,
                "planned_document": self.planned_document, "planned_lines": list(self.planned_lines),
                "planned_allocations": list(self.planned_allocations), "inventory_previews": list(self.inventory_previews)}

    def to_dict(self) -> dict[str, Any]:
        return {**self.content(), "preview_digest": self.preview_digest}


def _document_fields(cls: type, payload: object, *, nullable: tuple[str, ...] = (),
                     arrays: tuple[str, ...] = ()) -> dict[str, Any]:
    if not isinstance(payload, Mapping):
        raise TypeError("procurement document must be an object")
    if set(payload) - {item.name for item in fields(cls)}:
        raise TypeError("unknown procurement document fields")
    for key, value in payload.items():
        if key in arrays:
            if not isinstance(value, (list, tuple)):
                raise TypeError(f"{key} must be an array")
        elif key in {"invoice_id", "payment_id", "procurement_id"}:
            if not (value is None and key in nullable) and (not isinstance(value, int) or isinstance(value, bool) or value <= 0):
                raise TypeError(f"{key} must be a positive integer")
        elif not contract_scalar_ok(key, value, nullable=nullable):
            raise TypeError(f"{key} must be a string" + (" or null" if key in nullable else ""))
    return dict(payload)


_TERMS_CONVERSION_KEYS = ("conversion_from_unit_id", "conversion_to_unit_id", "conversion_factor", "conversion_source_ref")
