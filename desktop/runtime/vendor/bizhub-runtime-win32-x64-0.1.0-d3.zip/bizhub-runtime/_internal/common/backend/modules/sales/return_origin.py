"""退货追溯原销售单：所有入口共用的一个查找。

规则（通用）：每一条退货都要追溯到唯一一条原销售明细（``sales_orders`` 标准表的一行），AI 读单、页面、
单据内核、退货单对账都用这里同一个查找，不各写一份：

1. 退货自带原销售明细就用它；
2. 没带，按它退回的那次出库去找：同一件物品、卖给同一客户、在退货日或之前最近的那次有效出库；
3. 出库直接挂销售明细的就是那条；挂整张销售单据的（单据内核切换后），在那张单据的单头下按退回的物品
   唯一定位一条明细；
4. 找不到或不唯一返回空，由调用方转人工，不猜。

企业差异只是参数，不改规则：
- 物品怎么认：按编号（每件有编号）还是按规格（同规格不分件），写在 :class:`Outbound` 的 ``item`` 里；
- 一张销售单头下哪几条明细装了这件物品（``LinesForItem``）：按编号卖的查编号所在的明细，按规格卖的查同客户
  同规格的明细；
- 出库流水在哪：用通用库存账 ``stock_moves`` 的直接用 :func:`stock_outbound`（企业给出物品类别和客户库位）；
  逐件另记流水的企业自己找到那次出库，交给 :func:`original_order_line`。

别的企业：按规格卖的只要给 ``LinesForItem``（同客户同规格的明细），出库用 :func:`stock_outbound`；
按编号卖的给编号对应的明细。

已退数量（:func:`returned_quantity`）和读已收到的退货（:func:`received_returns`，写法见
``return_writes.write_received_return``）也只有这里一份。
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable, Collection, Iterable, Mapping, Sequence
from dataclasses import dataclass
from datetime import date
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from sqlalchemy.ext.asyncio import AsyncSession

# 出库直接挂销售明细时的来源名（库存流水各自的写法）。
_LINE_SOURCES = frozenset({"sales_order", "sales_orders"})
_DOCUMENT_SOURCE = "business_document"
# 销售单据的单头（``sales_batches`` 标准表）。
_SALES_HEADER = "SalesBatch"


@dataclass(frozen=True)
class Outbound:
    """一次销售出库：``key`` 是调用方的流水身份，``source_*`` 是它挂在哪（销售明细或整张销售单据）。"""

    key: Any
    source_model: str
    source_id: int | None
    item: str
    party_id: int | None = None


# 一张销售单头下装了这件物品的明细：{单头编号: [出库]} → {出库 key: 明细编号集合}。
LinesForItem = Callable[["AsyncSession", Mapping[int, Sequence[Outbound]]], Awaitable[Mapping[Any, Collection[int]]]]


async def outbound_order_lines(
    db: AsyncSession, outbounds: Iterable[Outbound], lines_for_item: LinesForItem
) -> dict[Any, int]:
    """多次出库各自的原销售明细（出库 key → 明细编号；认不出、不唯一的不在结果里），一次查完。"""

    from sqlalchemy import select

    from backend.models.documents import BusinessDocument

    result: dict[Any, int] = {}
    by_document: dict[int, list[Outbound]] = {}
    for outbound in outbounds:
        if outbound.source_id is None:
            continue
        if outbound.source_model in _LINE_SOURCES:
            result[outbound.key] = int(outbound.source_id)
        elif outbound.source_model == _DOCUMENT_SOURCE:
            by_document.setdefault(int(outbound.source_id), []).append(outbound)
    if not by_document:
        return result
    headers = dict((await db.execute(select(BusinessDocument.id, BusinessDocument.header_id).where(
        BusinessDocument.id.in_(by_document), BusinessDocument.docstatus == 1,
        BusinessDocument.header_model == _SALES_HEADER, BusinessDocument.header_id.is_not(None),
    ))).all())
    by_header: dict[int, list[Outbound]] = {}
    for document_id, header_id in headers.items():
        by_header.setdefault(int(header_id), []).extend(by_document[int(document_id)])
    lines = await lines_for_item(db, by_header) if by_header else {}
    for key, line_ids in lines.items():
        if len(set(line_ids)) == 1:
            result[key] = int(next(iter(line_ids)))
    return result


async def original_order_line(
    db: AsyncSession,
    *,
    stored: int | None,
    reversed_outbound: Callable[[], Awaitable[Outbound | None]],
    lines_for_item: LinesForItem,
) -> int | None:
    """一条退货的原销售明细：自带的优先，没带按退回的那次出库找；认不出返回空。"""

    if stored is not None:
        return int(stored)
    outbound = await reversed_outbound()
    if outbound is None:
        return None
    return (await outbound_order_lines(db, [outbound], lines_for_item)).get(outbound.key)


async def stock_outbound(
    db: AsyncSession,
    *,
    item_kind: str,
    spec: str,
    party_id: int,
    on_or_before: date,
    customer_location: str,
) -> Outbound | None:
    """通用库存账里退回的那次出库：同类同规格、进客户库位、在退货日或之前最近一次有效的销售出库。

    只认销售出库（挂销售明细或销售单据），退货检验后退回客户那类移动不算。客户按流水上的往来方认；
    直接挂销售明细的旧流水没记往来方，按那条明细的客户认。作废的流水 ORM 默认不读。"""

    from sqlalchemy import or_, select

    from backend.models.documents import BusinessDocument
    from backend.models.inventory import StockMove
    from backend.models.sales import SalesOrder

    line_customer = select(SalesOrder.id).where(SalesOrder.customer_party_id == int(party_id))
    sales_documents = select(BusinessDocument.id).where(BusinessDocument.header_model == _SALES_HEADER)
    move = await db.scalar(
        select(StockMove)
        .where(
            StockMove.item_kind == item_kind,
            StockMove.spec == spec,
            StockMove.to_location == customer_location,
            StockMove.move_date <= on_or_before,
            or_(
                (StockMove.source_model == _DOCUMENT_SOURCE) & StockMove.source_id.in_(sales_documents)
                & (StockMove.party_id == int(party_id)),
                StockMove.source_model.in_(_LINE_SOURCES) & StockMove.source_id.in_(line_customer),
            ),
        )
        .order_by(StockMove.move_date.desc(), StockMove.id.desc())
        .limit(1)
    )
    if move is None:
        return None
    return Outbound(int(move.id), str(move.source_model), int(move.source_id), str(move.spec), int(party_id))


def returned_quantity(order_id: Any, *, unit: str, exclude_case_ids: Collection[int] = ()) -> Any:
    """一条销售明细已退的数量（SQL 标量，``order_id`` 可以是列）：挂着它、同一单位的退货单明细数量合计。

    不同单位不相加（按克重退的和按件退的各算各的）；作废的退货单已删，不计。"""

    from sqlalchemy import func, select

    from backend.models.sales_return_case import SalesReturnCaseItem, SalesReturnCaseOrderLink

    query = (
        select(func.coalesce(func.sum(SalesReturnCaseItem.claimed_quantity), 0))
        .join(SalesReturnCaseOrderLink,
              SalesReturnCaseOrderLink.sales_return_case_id == SalesReturnCaseItem.sales_return_case_id)
        .where(SalesReturnCaseOrderLink.sales_order_id == order_id, SalesReturnCaseItem.claimed_unit == unit)
    )
    excluded = [int(value) for value in exclude_case_ids if value]
    if excluded:
        query = query.where(SalesReturnCaseItem.sales_return_case_id.not_in(excluded))
    return query.scalar_subquery()


@dataclass(frozen=True)
class ReceivedReturn:
    """一张已收到的退货单：单头、原销售明细、退回日（“已签收待检验”事件的日子）、明细、来源、检验结论。"""

    case: Any
    sales_order_id: int
    received_on: date
    item: Any
    source: Any
    outcomes: tuple[Any, ...]


def document_returns(doc_type: str) -> Any:
    """某类有效单据的退货单（单据内核里单头是退货单的那些），子查询；给 :func:`received_returns` 圈定范围。"""

    from sqlalchemy import select

    from backend.models.documents import BusinessDocument

    return select(BusinessDocument.header_id).where(
        BusinessDocument.doc_type == doc_type, BusinessDocument.docstatus == 1,
        BusinessDocument.header_model == "SalesReturnCase",
    )


async def received_returns(
    db: AsyncSession,
    *,
    case_ids: Any = None,
    order_ids: Iterable[int] | None = None,
    start: date | None = None,
    end: date | None = None,
) -> list[ReceivedReturn]:
    """已收到的退货单，按退回日、编号排。``case_ids`` 是调用方圈定的退货单（编号列表或子查询）。"""

    from datetime import datetime, time, timedelta

    from sqlalchemy import select
    from sqlalchemy.orm import selectinload

    from backend.models.sales_return_case import (
        SalesReturnCase,
        SalesReturnCaseEvent,
        SalesReturnCaseInspectionResult,
        SalesReturnCaseOrderLink,
    )

    query = (
        select(SalesReturnCase, SalesReturnCaseEvent.event_at)
        .join(SalesReturnCaseEvent, SalesReturnCaseEvent.sales_return_case_id == SalesReturnCase.id)
        .where(SalesReturnCaseEvent.event_type == "received_pending_weigh")
        .options(selectinload(SalesReturnCase.order_links), selectinload(SalesReturnCase.sources),
                 selectinload(SalesReturnCase.items))
        .order_by(SalesReturnCaseEvent.event_at, SalesReturnCase.id)
    )
    if case_ids is not None:
        query = query.where(SalesReturnCase.id.in_(case_ids))
    if order_ids is not None:
        query = query.where(SalesReturnCase.id.in_(select(SalesReturnCaseOrderLink.sales_return_case_id).where(
            SalesReturnCaseOrderLink.sales_order_id.in_(sorted({int(value) for value in order_ids})))))
    if start is not None:
        query = query.where(SalesReturnCaseEvent.event_at >= datetime.combine(start, time.min))
    if end is not None:
        query = query.where(SalesReturnCaseEvent.event_at < datetime.combine(end + timedelta(days=1), time.min))
    rows = (await db.execute(query)).all()
    item_ids = [int(item.id) for case, _ in rows for item in case.items]
    results: dict[int, list[Any]] = {}
    if item_ids:
        for result in await db.scalars(select(SalesReturnCaseInspectionResult).where(
            SalesReturnCaseInspectionResult.sales_return_case_item_id.in_(item_ids)
        ).order_by(SalesReturnCaseInspectionResult.outcome_kind, SalesReturnCaseInspectionResult.id)):
            results.setdefault(int(result.sales_return_case_item_id), []).append(result)
    return [
        ReceivedReturn(case, int(case.order_links[0].sales_order_id), received_at.date(), case.items[0],
                       case.sources[0], tuple(results.get(int(case.items[0].id), ())))
        for case, received_at in rows
    ]


__all__ = ["LinesForItem", "Outbound", "ReceivedReturn", "document_returns", "original_order_line", "outbound_order_lines",
           "received_returns", "returned_quantity", "stock_outbound"]
