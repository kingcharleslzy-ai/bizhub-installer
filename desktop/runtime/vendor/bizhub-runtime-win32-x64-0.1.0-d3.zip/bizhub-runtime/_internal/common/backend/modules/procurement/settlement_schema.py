"""采购结算标准表：发票、发票分到采购行、付款、付款分到采购行、结算日期修订。

和主数据标准表同一套做法（``master_data.schema``）：这里是唯一定义，取的是首家客户生产库
现在的形状（数字编号、按采购行对账、作废留痕不删）。客户库里的同名表必须等于
“标准表 + 该客户登记的扩展”，由一致性检查逐项核对。

- 对账口径按采购行（10-19 所有者定）：发票、付款都分到采购行，付款可以先不分、按供应商记。
- 分摊指向的“采购行”表在标准里叫 ``procurements``；通用小库自第 21 版起也用同一张表（加自己的文字键扩展列）。
- 证据关联表（发票原件、付款截图）指向各客户自己的证据表，不在标准里。
"""

from __future__ import annotations

from backend.modules.master_data.schema import (
    Check,
    Column,
    ExpressionCheck,
    ForeignKey,
    Index,
    Table,
    create_table_sql,
)

PROCUREMENT_LINE_TABLE = "procurements"
_CONFIRMED_REVERSED = ("confirmed", "reversed")


def _c(name: str, type_: str, *, nullable: bool = False, default: str | None = None) -> Column:
    return Column(name, type_, nullable, default)


def _confirmation_columns() -> tuple[Column, ...]:
    """确认与冲销留痕：谁确认、谁冲销、什么时候；冲销只改状态，不删行。"""

    return (
        _c("status", "VARCHAR(30)", default="confirmed"),
        _c("source_kind", "VARCHAR(60)", default="management_confirmed"),
        _c("source_ref", "TEXT"),
        _c("notes", "TEXT"),
        _c("confirmed_by", "VARCHAR(120)"),
        _c("confirmed_at", "DATETIME"),
        _c("reversed_by", "VARCHAR(120)"),
        _c("reversed_at", "DATETIME", nullable=True),
        _c("created_at", "DATETIME"),
    )


PROCUREMENT_INVOICES = Table(
    "procurement_invoices",
    (
        _c("id", "INTEGER"),
        _c("invoice_number", "VARCHAR(80)"),
        _c("normalized_invoice_number", "VARCHAR(80)"),
        _c("supplier_party_id", "INTEGER"),
        _c("supplier_legal_name", "VARCHAR(240)"),
        _c("supplier_tax_id", "VARCHAR(40)"),
        _c("buyer_legal_name", "VARCHAR(240)"),
        _c("buyer_tax_id", "VARCHAR(40)"),
        _c("invoice_date", "DATE"),
        _c("total_amount", "NUMERIC"),
        _c("currency", "VARCHAR(3)", default="CNY"),
        _c("positive_flag", "VARCHAR(20)", default="unknown"),
        _c("source_key", "VARCHAR(240)"),
        # 税额拆分与证据引用（可空，首家客户老数据留空）。
        _c("tax_basis", "VARCHAR(30)", nullable=True),
        _c("net_amount", "NUMERIC", nullable=True),
        _c("tax_amount", "NUMERIC", nullable=True),
        _c("tax_rate", "NUMERIC", nullable=True),
        _c("evidence_refs_json", "TEXT", nullable=True),
        *_confirmation_columns(),
    ),
    checks=(
        Check("ck_procurement_invoices_positive_flag", "positive_flag", ("positive", "negative", "unknown")),
        Check("ck_procurement_invoices_status", "status", _CONFIRMED_REVERSED),
    ),
    expression_checks=(
        ExpressionCheck("ck_procurement_invoices_amount_nonzero", "total_amount <> 0"),
        ExpressionCheck("ck_procurement_invoices_currency", "length(currency)=3 AND currency NOT GLOB '*[^A-Z]*'"),
    ),
    foreign_keys=(ForeignKey("supplier_party_id", "business_parties", "id", "RESTRICT"),),
    indexes=(
        Index("uq_procurement_invoices_source_key", ("source_key",), unique=True, where="source_key != ''"),
        Index("ix_procurement_invoices_supplier_date", ("supplier_party_id", "invoice_date")),
        Index("ix_procurement_invoices_status_date", ("status", "invoice_date")),
    ),
)

PROCUREMENT_INVOICE_ALLOCATIONS = Table(
    "procurement_invoice_allocations",
    (
        _c("id", "INTEGER"),
        _c("invoice_id", "INTEGER"),
        _c("procurement_id", "INTEGER"),
        _c("invoice_line_key", "VARCHAR(160)", default=""),
        _c("allocated_amount", "NUMERIC"),
        *_confirmation_columns(),
    ),
    checks=(Check("ck_procurement_invoice_allocation_status", "status", _CONFIRMED_REVERSED),),
    expression_checks=(ExpressionCheck("ck_procurement_invoice_allocation_nonzero", "allocated_amount <> 0"),),
    foreign_keys=(
        ForeignKey("invoice_id", "procurement_invoices", "id", "CASCADE"),
        ForeignKey("procurement_id", PROCUREMENT_LINE_TABLE, "id", "RESTRICT"),
    ),
    indexes=(
        Index(
            "uq_procurement_invoice_allocation_pair",
            ("invoice_id", "procurement_id", "invoice_line_key"),
            unique=True,
            where="status = 'confirmed'",
        ),
        Index("ix_procurement_invoice_allocation_invoice", ("invoice_id", "status")),
        Index("ix_procurement_invoice_allocation_procurement", ("procurement_id", "status")),
    ),
)

PROCUREMENT_PAYMENTS = Table(
    "procurement_payments",
    (
        _c("id", "INTEGER"),
        _c("supplier_party_id", "INTEGER"),
        _c("payer_legal_name", "VARCHAR(240)"),
        _c("payer_tax_id", "VARCHAR(40)"),
        _c("business_date", "DATE"),
        _c("amount", "NUMERIC"),
        _c("currency", "VARCHAR(3)", default="CNY"),
        _c("payment_method", "VARCHAR(30)", default="unknown"),
        _c("reference_no", "VARCHAR(160)"),
        _c("source_key", "VARCHAR(240)"),
        # 实际支付时间与渠道原文（可空）。
        _c("paid_at", "DATETIME", nullable=True),
        _c("channel", "VARCHAR(60)", nullable=True),
        *_confirmation_columns(),
    ),
    checks=(
        Check(
            "ck_procurement_payments_method",
            "payment_method",
            ("bank_transfer", "bank_acceptance", "cash", "other", "unknown"),
        ),
        Check("ck_procurement_payments_status", "status", _CONFIRMED_REVERSED),
    ),
    expression_checks=(
        ExpressionCheck("ck_procurement_payments_amount_positive", "amount > 0"),
        ExpressionCheck("ck_procurement_payments_currency", "length(currency)=3 AND currency NOT GLOB '*[^A-Z]*'"),
    ),
    foreign_keys=(ForeignKey("supplier_party_id", "business_parties", "id", "RESTRICT"),),
    indexes=(
        # 流水号只约束有效付款：作废后同号可重录。
        Index(
            "uq_procurement_payments_supplier_reference",
            ("supplier_party_id", "reference_no"),
            unique=True,
            where="reference_no != '' AND status = 'confirmed'",
        ),
        Index("uq_procurement_payments_source_key", ("source_key",), unique=True, where="source_key != ''"),
        Index("ix_procurement_payments_supplier_date", ("supplier_party_id", "business_date")),
        Index("ix_procurement_payments_status_date", ("status", "business_date")),
    ),
)

PROCUREMENT_PAYMENT_ALLOCATIONS = Table(
    "procurement_payment_allocations",
    (
        _c("id", "INTEGER"),
        _c("payment_id", "INTEGER"),
        _c("procurement_id", "INTEGER"),
        _c("allocated_amount", "NUMERIC"),
        *_confirmation_columns(),
    ),
    checks=(Check("ck_procurement_payment_allocation_status", "status", _CONFIRMED_REVERSED),),
    expression_checks=(ExpressionCheck("ck_procurement_payment_allocation_positive", "allocated_amount > 0"),),
    foreign_keys=(
        ForeignKey("payment_id", "procurement_payments", "id", "CASCADE"),
        ForeignKey("procurement_id", PROCUREMENT_LINE_TABLE, "id", "RESTRICT"),
    ),
    indexes=(
        Index(
            "uq_procurement_payment_allocation_pair",
            ("payment_id", "procurement_id"),
            unique=True,
            where="status = 'confirmed'",
        ),
        Index("ix_procurement_payment_allocation_payment", ("payment_id", "status")),
        Index("ix_procurement_payment_allocation_procurement", ("procurement_id", "status")),
    ),
)

PROCUREMENT_SETTLEMENT_DATE_REVISIONS = Table(
    "procurement_settlement_date_revisions",
    (
        _c("id", "INTEGER"),
        _c("invoice_id", "INTEGER", nullable=True),
        _c("payment_id", "INTEGER", nullable=True),
        _c("before_date", "DATE"),
        _c("after_date", "DATE"),
        _c("editor", "VARCHAR(120)"),
        _c("notes", "TEXT"),
        _c("created_at", "DATETIME"),
    ),
    expression_checks=(
        ExpressionCheck(
            "ck_procurement_settlement_date_revision_single_owner",
            "(invoice_id IS NOT NULL AND payment_id IS NULL) OR (invoice_id IS NULL AND payment_id IS NOT NULL)",
        ),
        ExpressionCheck("ck_procurement_settlement_date_revision_changed", "before_date <> after_date"),
    ),
    foreign_keys=(
        ForeignKey("invoice_id", "procurement_invoices", "id", "RESTRICT"),
        ForeignKey("payment_id", "procurement_payments", "id", "RESTRICT"),
    ),
    indexes=(
        Index("ix_procurement_settlement_date_revision_invoice", ("invoice_id", "created_at")),
        Index("ix_procurement_settlement_date_revision_payment", ("payment_id", "created_at")),
    ),
)

SETTLEMENT_STANDARD_TABLES: tuple[Table, ...] = (
    PROCUREMENT_INVOICES,
    PROCUREMENT_INVOICE_ALLOCATIONS,
    PROCUREMENT_PAYMENTS,
    PROCUREMENT_PAYMENT_ALLOCATIONS,
    PROCUREMENT_SETTLEMENT_DATE_REVISIONS,
)


def settlement_schema_sql() -> tuple[str, ...]:
    return tuple(statement for table in SETTLEMENT_STANDARD_TABLES for statement in create_table_sql(table))


__all__ = [
    "PROCUREMENT_LINE_TABLE",
    "SETTLEMENT_STANDARD_TABLES",
    "settlement_schema_sql",
]
