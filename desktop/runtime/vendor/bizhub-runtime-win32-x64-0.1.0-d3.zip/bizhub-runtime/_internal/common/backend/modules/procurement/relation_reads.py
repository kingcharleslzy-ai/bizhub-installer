"""采购正式关系候选的通用读取：只读采购明细的标准列，企业扩展由企业登记。

读单上下文按记录类型找采购候选时调这里；参数由调用方先做有界校验。标准规则：按明细编号、供应方（标准表里
在单头上）、业务日（或截至业务日的活跃窗口、某日或之前、某编号之前）以及付款反推的金额收窄，按编号倒序最多
``limit`` 条，满页时给出下一页从哪个编号之前接着读。

企业差异只走 :class:`ProcurementRelationExtension`：同一张物理表上多读的扩展列、企业认的扩展参数（如明细上
自己记的供应方、物料、来源消息）和扩展字段。没登记扩展的企业只读标准列，扩展参数明确拒绝。
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import timedelta
from typing import TYPE_CHECKING, Any, Callable, Mapping

from backend.modules.trade_core.public import TradeRuleError

from .order_schema import PROCUREMENT_BATCHES, PROCUREMENTS

if TYPE_CHECKING:
    from sqlalchemy.ext.asyncio import AsyncSession

_STANDARD_FILTERS = frozenset({
    "procurement_id", "before_procurement_id", "supplier_party_id", "business_date", "activity_window_days",
    "latest_on_or_before_date", "total_amount_between",
})
_CANDIDATE = (
    "procurement_id", "business_date", "supplier_party_id", "supplier", "material_item_id", "item_name",
    "quantity", "unit", "quantity_unit_id", "unit_price", "notes", "source_wechat_message_id", "created_at",
    "total_amount",
)


@dataclass(frozen=True)
class ProcurementRelationExtension:
    """一家企业在标准采购明细上登记的扩展：多读的扩展列、扩展参数（``filter_keys`` 经 ``filters(filters)``
    变成筛选条件；企业认 ``supplier_party_id`` 时按它自己的列筛，不再走单头）与一条明细的扩展字段。"""

    line_columns: tuple[str, ...] = ()
    filter_keys: frozenset[str] = frozenset()
    filters: Callable[[Mapping[str, Any]], list[Any]] | None = None
    fields: Callable[[Any], Mapping[str, Any]] | None = None


_NONE = ProcurementRelationExtension()


async def read_order_relation_candidates(
    db: AsyncSession, *, filters: Mapping[str, Any], extension: ProcurementRelationExtension | None = None,
    limit: int,
) -> dict[str, Any]:
    """按已校验的筛选找采购明细候选（见模块说明）。"""

    from sqlalchemy import select

    from backend.database import Base
    from backend.models.procurement import Procurement  # noqa: F401  (表定义所在的模型目录)

    extension = extension or _NONE
    unknown = sorted(set(filters) - _STANDARD_FILTERS - extension.filter_keys)
    if unknown:
        raise TradeRuleError(f"procurement_relation_extension_not_registered:{unknown[0]}")
    lines = Base.metadata.tables[PROCUREMENTS.name]
    columns = [lines.c[column.name] for column in PROCUREMENTS.columns] + [lines.c[name] for name in extension.line_columns]
    query = select(*columns)
    if "before_procurement_id" in filters:
        query = query.where(lines.c.id < filters["before_procurement_id"])
    if "latest_on_or_before_date" in filters:
        query = query.where(lines.c.business_date <= filters["latest_on_or_before_date"])
    if "procurement_id" in filters:
        query = query.where(lines.c.id == filters["procurement_id"])
    if "supplier_party_id" in filters and "supplier_party_id" not in extension.filter_keys:
        batches = Base.metadata.tables[PROCUREMENT_BATCHES.name]
        query = query.where(lines.c.batch_id.in_(
            select(batches.c.id).where(batches.c.supplier_party_id == filters["supplier_party_id"])))
    if extension.filters:
        query = query.where(*extension.filters(filters))
    if "business_date" in filters:
        business_date = filters["business_date"]
        if filters.get("activity_window_days") is not None:
            query = query.where(
                lines.c.business_date >= business_date - timedelta(days=int(filters["activity_window_days"])),
                lines.c.business_date <= business_date,
            )
        else:
            query = query.where(lines.c.business_date == business_date)
    if "total_amount_between" in filters:
        low, high = filters["total_amount_between"]
        query = query.where(lines.c.total_amount.is_not(None), lines.c.total_amount >= low, lines.c.total_amount <= high)
    rows = (await db.execute(query.order_by(lines.c.id.desc()).limit(limit))).all()
    return {
        "relation_type": "procurement",
        "next_before_procurement_id": rows[-1].id if len(rows) == limit else None,
        "candidates": [_candidate(row, extension) for row in rows],
    }


def _candidate(row: Any, extension: ProcurementRelationExtension) -> dict[str, Any]:
    values = {
        "procurement_id": row.id, "business_date": row.business_date, "item_name": row.item_name,
        "quantity": row.quantity, "quantity_unit_id": row.quantity_unit_id, "unit_price": row.unit_price,
        "notes": row.notes, "created_at": row.created_at, "total_amount": row.total_amount,
        **(extension.fields(row) if extension.fields else {}),
    }
    return {key: values[key] for key in _CANDIDATE if key in values}


__all__ = ["ProcurementRelationExtension", "read_order_relation_candidates"]
