"""Typed sales commands and state-bound previews."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping

from backend.modules.master_data.public import contract_scalar_ok
from backend.modules.trade_core.public import digest_json


@dataclass(frozen=True)
class SalesLine:
    line_id: str
    product_id: int
    unit_id: int
    quantity: str
    ship_from_location_id: str

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> "SalesLine":
        if not isinstance(payload, Mapping) or any(not contract_scalar_ok(key, value) for key, value in payload.items()):
            raise TypeError("sales line must be an object with string fields")
        return cls(**dict(payload))

    def to_dict(self) -> dict[str, str]:
        return {
            "line_id": self.line_id,
            "product_id": self.product_id,
            "unit_id": self.unit_id,
            "quantity": self.quantity,
            "ship_from_location_id": self.ship_from_location_id,
        }


@dataclass(frozen=True)
class SalesCommand:
    action: str
    idempotency_key: str
    order_id: str
    customer_party_id: int | None = None
    ordered_at: str = ""
    lines: tuple[SalesLine, ...] = field(default_factory=tuple)
    target_line_id: str = ""
    quantity: str = ""
    occurred_at: str = ""
    source_ref: str = ""
    evidence_refs: tuple[str, ...] = field(default_factory=tuple)
    reason: str = ""

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> "SalesCommand":
        if not isinstance(payload, Mapping):
            raise TypeError("command must be an object")
        values = dict(payload)
        if any(not contract_scalar_ok(key, value, nullable=("customer_party_id",))
               for key, value in payload.items() if key not in {"lines", "evidence_refs"}):
            raise TypeError("sales command fields must be strings")
        lines = payload.get("lines", ())
        evidence_refs = payload.get("evidence_refs", ())
        if not isinstance(lines, (list, tuple)) or not isinstance(evidence_refs, (list, tuple)):
            raise TypeError("lines and evidence_refs must be arrays")
        if any(not isinstance(item, str) for item in evidence_refs):
            raise TypeError("evidence_refs items must be strings")
        values["lines"] = tuple(
            SalesLine.from_dict(item) for item in lines
        )
        values["evidence_refs"] = tuple(evidence_refs)
        return cls(**values)

    def to_dict(self) -> dict[str, Any]:
        return {
            "action": self.action,
            "idempotency_key": self.idempotency_key,
            "order_id": self.order_id,
            "customer_party_id": self.customer_party_id,
            "ordered_at": self.ordered_at,
            "lines": [item.to_dict() for item in self.lines],
            "target_line_id": self.target_line_id,
            "quantity": self.quantity,
            "occurred_at": self.occurred_at,
            "source_ref": self.source_ref,
            "evidence_refs": list(self.evidence_refs),
            "reason": self.reason,
        }

    @property
    def command_digest(self) -> str:
        return digest_json(self.to_dict())


@dataclass(frozen=True)
class SalesPreview:
    command: SalesCommand
    state_generation: str
    planned_order: dict[str, Any]
    planned_lines: tuple[dict[str, Any], ...]
    planned_fulfillment: dict[str, Any] | None
    inventory_preview: dict[str, Any] | None
    preview_digest: str

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> "SalesPreview":
        if not isinstance(payload, Mapping):
            raise TypeError("preview must be an object")
        for key in ("state_generation", "preview_digest"):
            if not isinstance(payload[key], str):
                raise TypeError(f"{key} must be a string")
        command_payload = payload.get("command")
        if not isinstance(command_payload, Mapping):
            raise TypeError("command is required")
        planned_order = payload.get("planned_order")
        if not isinstance(planned_order, Mapping):
            raise TypeError("planned_order is required")
        fulfillment = payload.get("planned_fulfillment")
        inventory = payload.get("inventory_preview")
        for key, value in (("planned_fulfillment", fulfillment), ("inventory_preview", inventory)):
            if value is not None and not isinstance(value, Mapping):
                raise TypeError(f"{key} must be an object or null")
        planned_lines = payload.get("planned_lines", ())
        if not isinstance(planned_lines, (list, tuple)) or any(not isinstance(item, Mapping) for item in planned_lines):
            raise TypeError("planned_lines must be an array of objects")
        return cls(
            command=SalesCommand.from_dict(command_payload),
            state_generation=payload["state_generation"],
            planned_order=dict(planned_order),
            planned_lines=tuple(dict(item) for item in planned_lines),
            planned_fulfillment=(
                dict(fulfillment) if isinstance(fulfillment, Mapping) else None
            ),
            inventory_preview=dict(inventory) if isinstance(inventory, Mapping) else None,
            preview_digest=payload["preview_digest"],
        )

    def content(self) -> dict[str, Any]:
        return {
            "command": self.command.to_dict(),
            "state_generation": self.state_generation,
            "planned_order": self.planned_order,
            "planned_lines": list(self.planned_lines),
            "planned_fulfillment": self.planned_fulfillment,
            "inventory_preview": self.inventory_preview,
        }

    def to_dict(self) -> dict[str, Any]:
        return {**self.content(), "preview_digest": self.preview_digest}


@dataclass(frozen=True)
class SalesReturnItem:
    order_line_id: str
    unit_id: int
    quantity: str = "0"
    good_quantity: str = "0"
    scrap_quantity: str = "0"

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> "SalesReturnItem":
        if not isinstance(payload, Mapping) or any(not contract_scalar_ok(key, value) for key, value in payload.items()):
            raise TypeError("return item fields must be strings")
        return cls(**dict(payload))

    def to_dict(self) -> dict[str, str]:
        return {key: getattr(self, key) for key in self.__dataclass_fields__}


@dataclass(frozen=True)
class SalesReturnCommand:
    action: str
    idempotency_key: str
    order_id: str
    case_id: str = ""
    items: tuple[SalesReturnItem, ...] = field(default_factory=tuple)
    occurred_at: str = ""
    source_ref: str = ""
    evidence_refs: tuple[str, ...] = field(default_factory=tuple)
    reason: str = ""

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> "SalesReturnCommand":
        values = dict(payload)
        if any(not contract_scalar_ok(key, value) for key, value in payload.items() if key not in {"items", "evidence_refs"}):
            raise TypeError("return command fields must be strings")
        if not isinstance(payload.get("items", ()), (tuple, list)) or not isinstance(payload.get("evidence_refs", ()), (tuple, list)):
            raise TypeError("items and evidence_refs must be arrays")
        values["items"] = tuple(SalesReturnItem.from_dict(item) for item in (payload.get("items") or ()))
        values["evidence_refs"] = tuple(payload.get("evidence_refs") or ())
        return cls(**values)

    def to_dict(self) -> dict[str, Any]:
        return {
            **{key: getattr(self, key) for key in self.__dataclass_fields__ if key not in {"items", "evidence_refs"}},
            "items": [item.to_dict() for item in self.items],
            "evidence_refs": list(self.evidence_refs),
        }

    @property
    def command_digest(self) -> str:
        return digest_json(self.to_dict())


@dataclass(frozen=True)
class SalesReturnPreview:
    command: SalesReturnCommand
    state_generation: str
    planned_case: dict[str, Any]
    planned_items: tuple[dict[str, Any], ...]
    effects: tuple[dict[str, Any], ...]
    preview_digest: str

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> "SalesReturnPreview":
        return cls(
            command=SalesReturnCommand.from_dict(payload["command"]),
            state_generation=str(payload["state_generation"]),
            planned_case=dict(payload["planned_case"]),
            planned_items=tuple(dict(item) for item in payload["planned_items"]),
            effects=tuple(dict(item) for item in payload["effects"]),
            preview_digest=str(payload["preview_digest"]),
        )

    def content(self) -> dict[str, Any]:
        return {
            "command": self.command.to_dict(),
            "state_generation": self.state_generation,
            "planned_case": self.planned_case,
            "planned_items": list(self.planned_items),
            "effects": list(self.effects),
        }

    def to_dict(self) -> dict[str, Any]:
        return {**self.content(), "preview_digest": self.preview_digest}


@dataclass(frozen=True)
class InvoiceShipmentCoverage:
    """Reviewed shipment scope on an invoice header, independent of order allocation.

    Signed quantities/amounts represent reviewed corrections, never payments.
    Source metadata preserves the evidence row as received; month/basis are
    explicit reviewed facts and must not be inferred again by a reader.
    """

    coverage_id: str
    business_month: str
    attribution_basis: str
    product: str
    quantity: str
    quantity_unit: str
    amount: str
    source_ref: str
    source_metadata: dict[str, str] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> "InvoiceShipmentCoverage":
        import re
        from decimal import Decimal, InvalidOperation

        values = dict(payload)
        metadata = values.pop("source_metadata", {})
        if any(not isinstance(value, str) for value in values.values()) or not isinstance(metadata, dict) or any(
            not isinstance(key, str) or not isinstance(value, str) for key, value in metadata.items()
        ):
            raise ValueError("invoice coverage fields must be text")
        item = cls(**values, source_metadata=dict(metadata))
        if not all((item.coverage_id, item.product, item.quantity_unit, item.source_ref, item.attribution_basis)):
            raise ValueError("invoice coverage identity/source required")
        if not re.fullmatch(r"\d{4}-(0[1-9]|1[0-2])", item.business_month):
            raise ValueError("invoice coverage month invalid")
        try:
            if not Decimal(item.quantity).is_finite() or not Decimal(item.amount).is_finite():
                raise ValueError("invoice coverage measure invalid")
        except InvalidOperation as exc:
            raise ValueError("invoice coverage measure invalid") from exc
        return item

    def to_dict(self) -> dict[str, Any]:
        return {key: getattr(self, key) for key in self.__dataclass_fields__}
