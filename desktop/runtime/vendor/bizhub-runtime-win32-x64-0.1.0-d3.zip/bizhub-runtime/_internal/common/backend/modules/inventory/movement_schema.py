"""库存流水标准表：按量记的收、领、退、调、废，一条一行，纠错只追加冲销行。

和库位标准表同一套做法（``location_schema``）：这里是唯一定义，取的是首家客户生产库物料流水表现在的形状。
客户库里的同名表必须等于“标准表 + 该客户登记的扩展”，由一致性检查逐项核对。

- ``event_type``：receipt 收货 / return 退回（入）、usage 领用 / scrap 报废（出）、transfer 调拨（出一入一）。
- 入只有去向、出只有来源、调拨两头不同（表上的方向约束）。
- ``product_id`` 可空：货品在产品主数据里的记产品；首家客户的物料另有品目表，用它自己的扩展列引用。
- ``source_record_key`` 全表唯一：同一来源重放零写入，内容不同拒绝。
- 冲销行 ``is_reversal=1`` 指向原行，原行状态改 reversed；一行最多冲销一次。
"""

from __future__ import annotations

from backend.modules.master_data.schema import Check, Column, ExpressionCheck, ForeignKey, Index, Table, create_table_sql

EVENT_TYPES = ("receipt", "usage", "return", "transfer", "scrap")
MOVEMENT_STATUSES = ("confirmed", "reversed")
MOVEMENTS = "material_inventory_events"

DIRECTION_RULE = (
    "(event_type IN ('receipt', 'return') AND from_location_id IS NULL AND to_location_id IS NOT NULL) "
    "OR (event_type IN ('usage', 'scrap') AND from_location_id IS NOT NULL AND to_location_id IS NULL) "
    "OR (event_type = 'transfer' AND from_location_id IS NOT NULL AND to_location_id IS NOT NULL "
    "AND from_location_id <> to_location_id)"
)
REVERSAL_SHAPE_RULE = (
    "(is_reversal = 0 AND reverses_event_id IS NULL) OR "
    "(is_reversal = 1 AND reverses_event_id IS NOT NULL)"
)


def _c(name: str, type_: str, *, nullable: bool = False) -> Column:
    return Column(name, type_, nullable)


MATERIAL_INVENTORY_EVENTS = Table(
    MOVEMENTS,
    (
        _c("id", "INTEGER"),
        _c("event_date", "DATE"),
        _c("event_type", "VARCHAR(30)"),
        _c("product_id", "INTEGER", nullable=True),
        _c("quantity", "NUMERIC"),
        _c("quantity_unit_id", "INTEGER"),
        _c("from_location_id", "INTEGER", nullable=True),
        _c("to_location_id", "INTEGER", nullable=True),
        _c("source_kind", "VARCHAR(60)"),
        _c("source_record_key", "TEXT"),
        _c("evidence_ref", "TEXT"),
        _c("is_reversal", "BOOLEAN"),
        _c("reverses_event_id", "INTEGER", nullable=True),
        _c("status", "VARCHAR(30)"),
        _c("notes", "TEXT"),
        _c("created_by", "VARCHAR(120)"),
        _c("created_at", "DATETIME"),
    ),
    uniques=(
        ("uq_material_inventory_events_source", ("source_record_key",)),
        ("uq_material_inventory_events_reversal", ("reverses_event_id",)),
    ),
    checks=(
        Check("ck_material_inventory_events_type", "event_type", EVENT_TYPES),
        Check("ck_material_inventory_events_status", "status", MOVEMENT_STATUSES),
    ),
    expression_checks=(
        ExpressionCheck("ck_material_inventory_events_positive_quantity", "quantity > 0"),
        ExpressionCheck("ck_material_inventory_events_direction", DIRECTION_RULE),
        ExpressionCheck("ck_material_inventory_events_reversal_shape", REVERSAL_SHAPE_RULE),
    ),
    foreign_keys=(
        ForeignKey("product_id", "products", "id", "RESTRICT"),
        ForeignKey("quantity_unit_id", "measurement_units", "id", "RESTRICT"),
        ForeignKey("from_location_id", "locations", "id", "RESTRICT"),
        ForeignKey("to_location_id", "locations", "id", "RESTRICT"),
        ForeignKey("reverses_event_id", MOVEMENTS, "id", "RESTRICT"),
    ),
    indexes=(
        Index("ix_material_inventory_events_from_date", ("from_location_id", "event_date")),
        Index("ix_material_inventory_events_to_date", ("to_location_id", "event_date")),
        Index("ix_material_inventory_events_status_date", ("status", "event_date")),
    ),
)

MOVEMENT_STANDARD_TABLES: tuple[Table, ...] = (MATERIAL_INVENTORY_EVENTS,)


def movement_schema_sql() -> tuple[str, ...]:
    return tuple(statement for table in MOVEMENT_STANDARD_TABLES for statement in create_table_sql(table))


__all__ = [
    "DIRECTION_RULE",
    "EVENT_TYPES",
    "MATERIAL_INVENTORY_EVENTS",
    "MOVEMENTS",
    "MOVEMENT_STANDARD_TABLES",
    "MOVEMENT_STATUSES",
    "REVERSAL_SHAPE_RULE",
    "movement_schema_sql",
]
