"""销售退货写入原语：在调用方借出的连接、同一个事务里用裸 SQL 写退货标准表（``return_schema``）的子表，
外加生命周期规则。

页面、Agent、单据内核都经各自 Owner 走到这里；这里不提交、不开事务。规则和首家客户生产上一直用的一致：

- 一个退货事件可挂多张订单（同一对只记一次）；一条来源只属于一个退货事件。
- 明细按身份去重追加（身份由调用方给，客户口径不同），序号接着排。
- 生命周期事件按幂等键只记一次、只追加；状态只进不退；关闭前实物要回库、财务要定。
- 待人工判定的来源同一条只留一份，判定后记上归到哪个退货事件。
- 一条明细的检验结论（各去向数量）只记一次，同样的重放零写入；处置累计不超过检验数量。

退货事件头（``sales_return_cases``）是单据表头，只由单据内核的物化写；这里给出状态推进、关闭条件和
字段合并的规则，表头由客户的单据 Owner 按这些规则落。

已收到的退货一次记完（:func:`write_received_return`）：适合退回当天就过账库存、按件检验的退货——一张原订单
一张退货单，单头 + 挂原订单 + 来源 + 一条明细 + “已签收待检验”事件（退回日就是它的时间）；带了检验结论就
记结论、再记“已检验”。单据 Owner 物化时调它，更正时先 :func:`drop_return` 删子表、Owner 删单头，再按新版本记一张。
"""

from __future__ import annotations

import sqlite3
from datetime import UTC, datetime
from decimal import Decimal
from typing import Any, Callable, Mapping, Sequence

from backend.modules.trade_core.public import decimal_sum

from .return_schema import INSPECTION_OUTCOMES, LIFECYCLE_STATES


class ReturnWriteError(RuntimeError):
    def __init__(self, code: str, message: str = ""):
        super().__init__(f"{code}: {message}" if message else code)
        self.code = code
        self.message = message


STATE_RANK = {state: index for index, state in enumerate(LIFECYCLE_STATES)}
EVENT_TARGET_STATE = {
    "reported": "reported",
    "accepted": "accepted",
    "dispatched": "in_transit",
    "received_pending_weigh": "received_pending_weigh",
    "weighed": "weighed",
    "closed": "closed",
}
_FILL_IF_EMPTY = frozenset({"customer_name"})


# ---- 生命周期与字段合并规则（纯函数） -------------------------------------------------------

def advanced_state(current: str, event_type: str) -> str:
    """事件之后的状态：只进不退，不推进状态的事件（更正、明细整理等）保持原状态。"""

    target = EVENT_TARGET_STATE.get(event_type)
    return target if target and STATE_RANK[target] > STATE_RANK[current] else current


def close_blockers(case: Mapping[str, Any]) -> list[str]:
    """普通关闭的前提：要实物退回的先回库，财务调整先定下来。"""

    blockers = []
    if case.get("physical_return_mode") != "not_required" and case.get("inventory_resolution_status") != "applied":
        blockers.append("sales_return_case_inventory_not_closed")
    if case.get("financial_adjustment_status") == "pending":
        blockers.append("sales_return_case_financial_not_closed")
    return blockers


def merged_case_facts(case: Mapping[str, Any], incoming: Mapping[str, Any]) -> dict[str, Any]:
    """同一退货事件的后续来源带来的头字段，返回要改的字段（调用方已清洗）。

    新值为空不覆盖；客户名只补不改；实物口径一旦“混合”就保持；财务口径不退回“待处理”。
    """

    changes: dict[str, Any] = {}
    for key, value in incoming.items():
        current = case.get(key)
        if value in (None, ""):
            continue
        if key in _FILL_IF_EMPTY and current not in (None, ""):
            continue
        if key == "physical_return_mode":
            if value not in {"required", "not_required", "mixed"} or (current == "mixed" and value != "mixed"):
                continue
        if key == "financial_adjustment_status" and value == "pending" and current != "pending":
            continue
        if value != current:
            changes[key] = value
    return changes


# ---- 子表写入 ------------------------------------------------------------------------------

def _stamp(value: datetime | None = None) -> str:
    # Same text the customer's ORM stores for a naive DateTime.
    return (value or datetime.now(UTC).replace(tzinfo=None)).strftime("%Y-%m-%d %H:%M:%S.%f")


def _bind(value: Any) -> Any:
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, Decimal):
        return format(value, "f")
    if isinstance(value, datetime):
        return _stamp(value)
    return value


def _columns(connection: sqlite3.Connection, table: str) -> dict[str, tuple[bool, bool]]:
    """列名 → (NOT NULL, 是文字列)；客户扩展列也在里面。"""

    return {
        str(row[1]): (bool(row[3]), any(word in str(row[2]).upper() for word in ("CHAR", "TEXT")))
        for row in connection.execute(f"PRAGMA table_info({table})")
    }


def _insert(connection: sqlite3.Connection, table: str, values: Mapping[str, Any], *, now: str) -> int:
    columns = _columns(connection, table)
    unknown = sorted(set(values) - set(columns))
    if unknown:
        raise ReturnWriteError("sales_return_column_unknown", f"{table}:{unknown}")
    row = {key: _bind(value) for key, value in values.items()}
    for name, (not_null, text) in columns.items():
        if name in {"created_at", "updated_at"}:
            row.setdefault(name, now)
        elif not_null and text and row.get(name) is None and name != "id":
            row[name] = ""
    names = sorted(row)
    cursor = connection.execute(
        f"INSERT INTO {table} ({', '.join(names)}) VALUES ({', '.join('?' for _ in names)})",
        tuple(row[name] for name in names),
    )
    return int(cursor.lastrowid)


def _row(connection: sqlite3.Connection, sql: str, params: tuple) -> sqlite3.Row | None:
    connection.row_factory = sqlite3.Row
    return connection.execute(sql, params).fetchone()


def link_order(connection: sqlite3.Connection, case_id: int, sales_order_id: int, *, now: datetime | None = None) -> bool:
    """退货事件挂上一张订单；已挂的零写入返回 False。"""

    if _row(connection, "SELECT 1 FROM sales_return_case_order_links WHERE sales_return_case_id=? AND sales_order_id=?",
            (int(case_id), int(sales_order_id))):
        return False
    _insert(connection, "sales_return_case_order_links",
            {"sales_return_case_id": int(case_id), "sales_order_id": int(sales_order_id)}, now=_stamp(now))
    return True


def link_source(
    connection: sqlite3.Connection,
    case_id: int,
    *,
    source_channel: str,
    source_id: str,
    source_item_key: str = "",
    source_role: str = "evidence",
    evidence_hash: str = "",
    payload_json: str = "{}",
    replace: bool = False,
    now: datetime | None = None,
) -> bool:
    """登记一条来源。别的退货事件已登记过这条来源时拒绝；本事件已登记的零写入，
    ``replace=True`` 时改成新的角色和内容（更正）。返回是否写入。"""

    existing = _row(
        connection,
        "SELECT id, sales_return_case_id, source_role, evidence_hash, payload_json FROM sales_return_case_sources "
        "WHERE source_channel=? AND source_id=? AND source_item_key=?",
        (source_channel, source_id, source_item_key),
    )
    if existing is not None:
        if int(existing["sales_return_case_id"]) != int(case_id):
            raise ReturnWriteError("sales_return_case_source_already_owned", f"{source_channel}:{source_id}")
        wanted = (source_role, evidence_hash, payload_json)
        if not replace or tuple(existing[key] for key in ("source_role", "evidence_hash", "payload_json")) == wanted:
            return False
        connection.execute(
            "UPDATE sales_return_case_sources SET source_role=?, evidence_hash=?, payload_json=? WHERE id=?",
            (*wanted, int(existing["id"])),
        )
        return True
    _insert(connection, "sales_return_case_sources", {
        "sales_return_case_id": int(case_id), "source_channel": source_channel, "source_id": source_id,
        "source_item_key": source_item_key, "source_role": source_role or "evidence",
        "evidence_hash": evidence_hash, "payload_json": payload_json or "{}",
    }, now=_stamp(now))
    return True


def case_items(connection: sqlite3.Connection, case_id: int) -> list[dict[str, Any]]:
    connection.row_factory = sqlite3.Row
    return [dict(row) for row in connection.execute(
        "SELECT * FROM sales_return_case_items WHERE sales_return_case_id=? ORDER BY item_index, id", (int(case_id),)
    )]


def append_items(
    connection: sqlite3.Connection,
    case_id: int,
    items: Sequence[Mapping[str, Any]],
    *,
    identity: Callable[[Mapping[str, Any]], str],
    now: datetime | None = None,
) -> list[int]:
    """追加明细，库里已有同身份的跳过（重放零写入），序号接着排；返回新明细编号。

    同一批里身份相同的几条是几件实物（没有编号的同规格同重量），都记。"""

    existing = case_items(connection, case_id)
    seen = {identity(item) for item in existing}
    next_index = max((int(item["item_index"]) for item in existing), default=-1) + 1
    created = []
    stamp = _stamp(now)
    for item in items:
        if identity(item) in seen:
            continue
        created.append(_insert(connection, "sales_return_case_items", {
            **item, "sales_return_case_id": int(case_id), "item_index": next_index,
        }, now=stamp))
        next_index += 1
    return created


def update_items(
    connection: sqlite3.Connection,
    case_id: int,
    changes: Mapping[int, Mapping[str, Any]],
    *,
    now: datetime | None = None,
) -> int:
    """改明细字段（编号、序号、所属事件不可改）；值没变的不写。返回改了几条。"""

    columns = _columns(connection, "sales_return_case_items")
    current = {int(item["id"]): item for item in case_items(connection, case_id)}
    written = 0
    for item_id, values in changes.items():
        row = current.get(int(item_id))
        if row is None:
            raise ReturnWriteError("sales_return_case_item_not_found", str(item_id))
        bad = sorted(set(values) - set(columns) | set(values) & {"id", "item_index", "sales_return_case_id", "created_at"})
        if bad:
            raise ReturnWriteError("sales_return_case_item_field_invalid", str(bad))
        diff = {key: _bind(value) for key, value in values.items() if _comparable(row[key]) != _comparable(value)}
        if not diff:
            continue
        diff["updated_at"] = _stamp(now)
        names = sorted(diff)
        connection.execute(
            f"UPDATE sales_return_case_items SET {', '.join(f'{name}=?' for name in names)} WHERE id=?",
            (*(diff[name] for name in names), int(item_id)),
        )
        written += 1
    return written


def _comparable(value: Any) -> Any:
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, (int, float, Decimal)) and not isinstance(value, bool):
        return Decimal(str(value)).normalize()
    return value


def record_event(
    connection: sqlite3.Connection,
    case_id: int,
    *,
    event_type: str,
    event_at: datetime,
    source_channel: str,
    source_id: str,
    actor: str,
    idempotency_key: str,
    payload_json: str,
    now: datetime | None = None,
) -> bool:
    """记一条生命周期事件；同一幂等键已记过的零写入返回 False。"""

    existing = _row(connection, "SELECT sales_return_case_id FROM sales_return_case_events WHERE idempotency_key=?",
                    (idempotency_key,))
    if existing is not None:
        if int(existing["sales_return_case_id"]) != int(case_id):
            raise ReturnWriteError("sales_return_case_event_key_conflict", idempotency_key)
        return False
    _insert(connection, "sales_return_case_events", {
        "sales_return_case_id": int(case_id), "event_type": event_type, "event_at": event_at,
        "source_channel": source_channel or "manual", "source_id": source_id, "actor": actor,
        "idempotency_key": idempotency_key, "payload_json": payload_json,
    }, now=_stamp(now))
    return True


def upsert_review(
    connection: sqlite3.Connection,
    *,
    source_channel: str,
    source_id: str,
    source_item_key: str,
    values: Mapping[str, Any],
    now: datetime | None = None,
) -> int:
    """一条来源找不到唯一归属时留一份待人工判定（同一来源只留一份，重来就重开）。"""

    stamp = _stamp(now)
    fields = {**values, "status": "pending", "resolved_case_id": None}
    existing = _row(connection, "SELECT * FROM sales_return_case_reviews WHERE source_channel=? AND source_id=? AND source_item_key=?",
                    (source_channel, source_id, source_item_key))
    if existing is None:
        return _insert(connection, "sales_return_case_reviews", {
            **fields, "source_channel": source_channel, "source_id": source_id, "source_item_key": source_item_key,
        }, now=stamp)
    if all(existing[name] == _bind(value) for name, value in fields.items()):
        return int(existing["id"])
    names = sorted(fields)
    connection.execute(
        f"UPDATE sales_return_case_reviews SET {', '.join(f'{name}=?' for name in names)}, updated_at=? WHERE id=?",
        (*(_bind(fields[name]) for name in names), stamp, int(existing["id"])),
    )
    return int(existing["id"])


def resolve_review(
    connection: sqlite3.Connection,
    *,
    source_channel: str,
    source_id: str,
    source_item_key: str,
    case_id: int,
    now: datetime | None = None,
) -> bool:
    """来源已归到一个退货事件：把它的待判定记成已判定；没有待判定的零写入。"""

    cursor = connection.execute(
        "UPDATE sales_return_case_reviews SET status='resolved', resolved_case_id=?, updated_at=? "
        "WHERE source_channel=? AND source_id=? AND source_item_key=? "
        "AND NOT (status='resolved' AND resolved_case_id IS ?)",
        (int(case_id), _stamp(now), source_channel, source_id, source_item_key, int(case_id)),
    )
    return cursor.rowcount > 0


def inspection_results(connection: sqlite3.Connection, item_id: int) -> dict[str, dict[str, Any]]:
    """一条明细的检验结论，按去向。"""

    connection.row_factory = sqlite3.Row
    return {str(row["outcome_kind"]): dict(row) for row in connection.execute(
        "SELECT * FROM sales_return_case_inspection_results WHERE sales_return_case_item_id=?", (int(item_id),)
    )}


def _case_item(connection: sqlite3.Connection, case_id: int, item_id: int) -> None:
    if not _row(connection, "SELECT 1 FROM sales_return_case_items WHERE id=? AND sales_return_case_id=?",
                (int(item_id), int(case_id))):
        raise ReturnWriteError("sales_return_case_item_not_found", str(item_id))


def record_inspection(
    connection: sqlite3.Connection,
    case_id: int,
    item_id: int,
    outcomes: Mapping[str, Decimal],
    *,
    now: datetime | None = None,
) -> bool:
    """记一条明细的检验结论（数量为 0 的去向不记）。同样的结论零写入返回 False；已有不同结论的拒绝。"""

    _case_item(connection, case_id, item_id)
    unknown = sorted(set(outcomes) - set(INSPECTION_OUTCOMES))
    if unknown or any(Decimal(str(value)) < 0 for value in outcomes.values()):
        raise ReturnWriteError("sales_return_inspection_outcome_invalid", str(unknown or dict(outcomes)))
    wanted = {kind: Decimal(str(value)) for kind, value in outcomes.items() if Decimal(str(value)) > 0}
    existing = {kind: _comparable(row["quantity"]) for kind, row in inspection_results(connection, item_id).items()}
    if existing:
        if existing != {kind: value.normalize() for kind, value in wanted.items()}:
            raise ReturnWriteError("sales_return_inspection_already_recorded", str(item_id))
        return False
    stamp = _stamp(now)
    for kind in sorted(wanted):
        _insert(connection, "sales_return_case_inspection_results", {
            "sales_return_case_item_id": int(item_id), "outcome_kind": kind,
            "quantity": wanted[kind], "disposed_quantity": Decimal("0"),
        }, now=stamp)
    return bool(wanted)


def dispose_inspected(
    connection: sqlite3.Connection,
    case_id: int,
    item_id: int,
    outcome_kind: str,
    quantity: Decimal,
    *,
    now: datetime | None = None,
) -> None:
    """按检验结论处置一部分（好件回库、坏件留存……），累计不超过检验数量。"""

    _case_item(connection, case_id, item_id)
    row = inspection_results(connection, item_id).get(outcome_kind)
    quantity = Decimal(str(quantity))
    if row is None or quantity <= 0:
        raise ReturnWriteError("sales_return_disposition_invalid", f"{item_id}:{outcome_kind}")
    disposed = decimal_sum((Decimal(str(row["disposed_quantity"])), quantity))
    if disposed > Decimal(str(row["quantity"])):
        raise ReturnWriteError("sales_return_disposition_exceeds_inspection", f"{item_id}:{outcome_kind}")
    connection.execute(
        "UPDATE sales_return_case_inspection_results SET disposed_quantity=?, updated_at=? WHERE id=?",
        (format(disposed, "f"), _stamp(now), int(row["id"])),
    )


def write_received_return(
    connection: sqlite3.Connection,
    *,
    header: Mapping[str, Any],
    sales_order_id: int,
    source: Mapping[str, Any],
    item: Mapping[str, Any],
    received_at: datetime,
    outcomes: Mapping[str, Decimal],
    actor: str,
    now: datetime | None = None,
) -> int:
    """记一次已收到的退货，返回退货单编号。``header`` 是单头的其余列（客户、财务口径、库存口径等），
    ``source`` 是 :func:`link_source` 的参数，``outcomes`` 为空表示还没检验（停在“已签收待检验”）。"""

    stamp = _stamp(now)
    state = "weighed" if outcomes else "received_pending_weigh"
    case_id = _insert(connection, "sales_return_cases", {**header, "lifecycle_status": state}, now=stamp)
    link_order(connection, case_id, int(sales_order_id), now=now)
    link_source(connection, case_id, **source, now=now)
    (item_id,) = append_items(connection, case_id, [item], identity=lambda _item: "", now=now)
    channel, source_id = str(source["source_channel"]), str(source["source_id"])
    for event_type in ("received_pending_weigh", *(("weighed",) if outcomes else ())):
        record_event(connection, case_id, event_type=event_type, event_at=received_at, source_channel=channel,
                     source_id=source_id, actor=actor, idempotency_key=f"sales-return:{case_id}:{event_type}",
                     payload_json="{}", now=now)
    if outcomes:
        record_inspection(connection, case_id, item_id, outcomes, now=now)
    return case_id


def drop_return(connection: sqlite3.Connection, case_id: int) -> None:
    """删掉一张退货单的子表行（单据作废或更正前）：检验结论、明细、事件、来源、挂单；单头由单据 Owner 在物化里删。"""

    items = "SELECT id FROM sales_return_case_items WHERE sales_return_case_id=?"
    connection.execute(f"DELETE FROM sales_return_case_inspection_results WHERE sales_return_case_item_id IN ({items})",
                       (int(case_id),))
    for table in ("sales_return_case_items", "sales_return_case_events", "sales_return_case_sources",
                  "sales_return_case_order_links"):
        connection.execute(f"DELETE FROM {table} WHERE sales_return_case_id=?", (int(case_id),))


__all__ = [
    "EVENT_TARGET_STATE",
    "ReturnWriteError",
    "STATE_RANK",
    "advanced_state",
    "append_items",
    "case_items",
    "close_blockers",
    "dispose_inspected",
    "drop_return",
    "inspection_results",
    "link_order",
    "link_source",
    "merged_case_facts",
    "record_event",
    "record_inspection",
    "resolve_review",
    "update_items",
    "upsert_review",
    "write_received_return",
]
