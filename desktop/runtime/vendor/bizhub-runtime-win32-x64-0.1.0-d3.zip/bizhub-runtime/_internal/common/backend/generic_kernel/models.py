"""Explicit generic-kernel model catalog.

This catalog is intentionally independent from ``backend.models``. It is a
small schema descriptor used by the generic lineage and its artifact tests.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class KernelTable:
    name: str
    owner_ref: str
    purpose: str
    introduced_version: int = 1


MODEL_TABLES: tuple[KernelTable, ...] = (
    KernelTable("kernel_instance_metadata", "generic.kernel_smoke", "locked profile and lineage identity"),
    KernelTable("kernel_migration_ledger", "generic.kernel_smoke", "immutable migration identity and checksum"),
    KernelTable("kernel_audit_events", "generic.kernel_smoke", "customer-neutral lifecycle audit events"),
    KernelTable("business_parties", "master_data", "canonical party identity"),
    KernelTable("business_party_roles", "master_data", "party business roles"),
    KernelTable("business_party_identifiers", "master_data", "party tax, registration and phone identity"),
    KernelTable("business_contacts", "master_data", "party contacts"),
    KernelTable("master_data_name_values", "master_data", "controlled names and groups", 23),
    KernelTable("master_data_name_group_members", "master_data", "single-source group membership", 23),
    KernelTable("master_data_aliases", "master_data", "confirmed, ambiguous and retired wordings"),
    KernelTable("measurement_units", "master_data", "canonical measurement unit"),
    KernelTable("products", "master_data", "canonical product identity"),
    KernelTable("master_data_alias_candidates", "master_data", "proposed wordings awaiting human review"),
    KernelTable("master_data_write_intents", "master_data", "previewed master-data writes awaiting apply"),
    KernelTable("master_data_governance_actions", "master_data", "before/after trail of every master-data change"),
    KernelTable("master_data_resolution_events", "master_data", "every wording-to-entity resolution and its gate"),
    KernelTable("locations", "master_data", "standard locations plus the normalized display name", 20),
    KernelTable("master_data_external_identities", "master_data", "exact external system identity mapping"),
    KernelTable("material_inventory_events", "inventory", "standard inventory movements plus the text movement key", 20),
    KernelTable("inventory_stocktakes", "inventory", "physical stocktake record"),
    KernelTable("inventory_audit_events", "inventory", "inventory action audit"),
    KernelTable("inventory_action_receipts", "inventory", "idempotent action readback"),
    KernelTable("procurement_batches", "procurement", "standard purchase order header plus the text order key", 21),
    KernelTable("procurements", "procurement", "standard purchase order lines plus the text line key and received state", 21),
    KernelTable("procurement_receipt_documents", "procurement", "arrival identity and evidence", 9),
    KernelTable("procurement_receipt_lines", "procurement", "arrival and inspection quantities", 9),
    KernelTable("procurement_receipt_allocations", "procurement", "standard receipt allocations plus the text receipt key and movement", 21),
    KernelTable("procurement_order_line_terms", "procurement", "source-backed versioned purchase terms", 10),
    KernelTable("procurement_invoices", "procurement", "supplier invoice identity and explicit tax", 10),
    KernelTable("procurement_invoice_lines", "procurement", "invoice quantities and nullable amounts", 10),
    KernelTable("procurement_payments", "procurement", "paid supplier payment identity and evidence", 11),
    KernelTable("procurement_payment_allocations", "procurement", "invoice allocations and retained revocations", 11),
    KernelTable("procurement_invoice_allocations", "procurement", "standard invoice allocations to purchase lines", 17),
    KernelTable("procurement_settlement_date_revisions", "procurement", "standard settlement date revisions", 17),
    KernelTable("procurement_invoice_matches", "procurement", "receipt occupations and retained revocations", 10),
    KernelTable("procurement_audit_events", "procurement", "procurement action audit"),
    KernelTable("procurement_action_receipts", "procurement", "idempotent procurement readback"),
    KernelTable("sales_batches", "sales", "standard sales order header plus the text order key", 22),
    KernelTable("sales_orders", "sales", "standard sales order lines plus the text line key and fulfillment state"),
    KernelTable("sales_fulfillments", "sales", "standard shipment or return rows plus the text keys and movement"),
    KernelTable("sales_audit_events", "sales", "sales action audit"),
    KernelTable("sales_action_receipts", "sales", "idempotent sales readback"),
    KernelTable("sales_payments", "sales", "received payment identity and evidence", 8),
    KernelTable("sales_payment_allocations", "sales", "standard payment allocations to sales orders", 8),
    KernelTable("sales_invoice_allocations", "sales", "standard invoice allocations to sales orders", 18),
    KernelTable("sales_invoices", "sales", "invoice and original-bound credit note", 7),
    KernelTable("sales_invoice_lines", "sales", "explicit amounts, unknown tax and order links", 7),
    KernelTable("sales_return_cases", "sales", "physical return lifecycle", 6),
    KernelTable("sales_return_case_order_links", "sales", "orders a return case belongs to", 19),
    KernelTable("sales_return_case_sources", "sales", "evidence sources of a return case", 19),
    KernelTable("sales_return_case_items", "sales", "returned items per order line", 6),
    KernelTable("sales_return_case_inspection_results", "sales", "inspection and disposition quantities", 19),
    KernelTable("sales_return_case_events", "sales", "stage evidence and inventory effects", 6),
    KernelTable("sales_return_case_reviews", "sales", "return sources awaiting a human decision", 19),
    KernelTable("sales_service_contracts", "sales", "non-stock service agreements", 24),
    KernelTable("sales_service_lines", "sales", "service terms for sales order lines", 24),
    KernelTable("sales_service_acceptances", "sales", "service performance acknowledged by the customer", 24),
    KernelTable("sales_document_action_receipts", "sales", "idempotent sales document readback", 6),
    KernelTable("business_agent_decisions", "generic.kernel_smoke:runtime", "prepared execution authorization and verified readback", 14),
    KernelTable("business_agent_source_clusters", "generic.kernel_smoke:runtime", "durable source execution and coverage", 15),
    KernelTable("business_agent_source_cluster_members", "generic.kernel_smoke:runtime", "ordered source coverage", 15),
)

MODEL_TABLE_NAMES = tuple(table.name for table in MODEL_TABLES)
