"""Procurement source definition over the shared immutable audit lifecycle."""
from __future__ import annotations

from backend.modules.procurement.contracts import ProcurementCommand, ProcurementReceiptCommand
from backend.modules.procurement.public import (
    LINE_ROWS, RECEIPT_ROWS, ProcurementOwnerError, preview_action, preview_receipt_action, read_action,
)
from .agent_common import SourceStore, OWNER_REF

PREPARED_SCHEMA = "bizhub.procurement-agent-source-prepared.v1"
COMMAND_DISPOSITIONS = {"create_order", "receipt"}
PLAIN_DISPOSITIONS = {"needs_clarification", "not_covered"}


class ProcurementSourceError(RuntimeError):
    def __init__(self, code, message):
        super().__init__(f"{code}: {message}")
        self.code, self.message = code, message


def command_from_proposal(proposal):
    return {"create_order": ProcurementCommand, "receipt": ProcurementReceiptCommand}[proposal["disposition"]].from_dict(proposal["command"])


def preview_prepared(path, proposal, *, enabled_module_ids=None):
    preview = {"create_order": preview_action, "receipt": preview_receipt_action}[proposal["disposition"]]
    command = command_from_proposal(proposal)
    if isinstance(command, ProcurementReceiptCommand) and command.action == "post" and not (command.post_reference or "").strip():
        with _store._connect(path, readonly=True) as connection:
            if any(connection.execute("SELECT 1 FROM procurement_receipt_allocations WHERE receipt_line_id=? LIMIT 1",
                   (item.receipt_line_id,)).fetchone() for item in command.allocations):
                raise ProcurementOwnerError("procurement_agent_identity_required", "needs_clarification: missing post_reference")
    return preview(path, command, enabled_module_ids=enabled_module_ids)


def validate_prepared_proposal(proposal, *, source_id):
    fields = {"schema_version", "source_id", "disposition", "command", "command_digest",
              "unsupported_details", "clarifications", "not_covered_reason"}
    from .agent_common import validate_clarification_references
    validate_clarification_references(proposal, "procurement", ProcurementSourceError)
    if set(proposal) - {"references"} != fields or proposal["schema_version"] != PREPARED_SCHEMA or proposal["source_id"] != source_id:
        raise ProcurementSourceError("procurement_agent_proposal_invalid", "invalid prepared identity or fields")
    if (not isinstance(proposal["clarifications"], list) or
            any(not isinstance(item, str) or not item.strip() for item in proposal["clarifications"]) or
            not isinstance(proposal["not_covered_reason"], str) or
            not isinstance(proposal["unsupported_details"], list) or
            any(not isinstance(item, dict) or set(item) != {"detail", "handling"} or
                not isinstance(item["detail"], str) or item["handling"] != "recorded_not_executed"
                for item in proposal["unsupported_details"])):
        raise ProcurementSourceError("procurement_agent_proposal_invalid", "invalid prepared explanations")
    disposition = proposal["disposition"]
    if disposition in PLAIN_DISPOSITIONS:
        if (proposal["command"] is not None or proposal["command_digest"] is not None or
                (disposition == "needs_clarification" and (not proposal["clarifications"] or proposal["not_covered_reason"])) or
                (disposition == "not_covered" and (not proposal["not_covered_reason"].strip() or proposal["clarifications"]))):
            raise ProcurementSourceError("procurement_agent_proposal_invalid", "plain dispositions cannot contain commands")
        return
    if disposition not in COMMAND_DISPOSITIONS:
        raise ProcurementSourceError("procurement_agent_proposal_invalid", "unknown disposition")
    try:
        command = command_from_proposal(proposal)
    except (TypeError, KeyError, ValueError) as exc:
        raise ProcurementSourceError("procurement_agent_proposal_invalid", str(exc)) from exc
    if (command.command_digest != proposal["command_digest"] or
            command.idempotency_key != assigned_idempotency_key(source_id) or
            evidence_ref(source_id) not in command.evidence_refs or
            proposal["clarifications"] or proposal["not_covered_reason"]):
        raise ProcurementSourceError("procurement_agent_proposal_invalid", "invalid digest, evidence or unresolved command")
    if disposition == "create_order":
        valid = (command.action == "create" and command.order_id == assigned_order_id(source_id) and
                 all(line.line_id == f"{command.order_id}-l{index}" for index, line in enumerate(command.lines, 1)))
    else:
        valid = command.action in {"register", "inspect", "post"}
        if command.action == "register":
            valid = valid and command.document_id == assigned_document_id(source_id, "receipt") and all(
                line.line_id == assigned_line_id(source_id, "receipt", index) for index, line in enumerate(command.lines, 1))
    if not valid:
        raise ProcurementSourceError("procurement_agent_proposal_invalid", "invalid action or model-assigned identity")


def assigned_document_id(source_id, kind):
    return f"procurement-agent-{kind}-{source_id}"


def assigned_line_id(source_id, kind, index):
    return f"{assigned_document_id(source_id, kind)}-l{index}"


def _applied_readback(path, command, *, enabled_module_ids):
    # Procurement's historical public reader accepts action_id, not the key.
    with _store._connect(path, readonly=True) as connection:
        receipt = connection.execute(
            "SELECT action_id, command_digest FROM procurement_action_receipts WHERE idempotency_key=?",
            (command.idempotency_key,),
        ).fetchone()
    if receipt is None:
        return None
    if receipt["command_digest"] != command.command_digest:
        raise ProcurementSourceError("procurement_agent_receipt_command_conflict", "receipt differs from prepared command")
    return read_action(path, receipt["action_id"])


def record_orders(connection, record_type, record_id):
    """Resolve direct, posted, matched and allocated links without active filters."""
    if not record_id:
        return set()
    if record_type == "order":
        return {record_id}
    queries = {
        "order_line": f"SELECT order_id FROM {LINE_ROWS} WHERE line_id=?",
        "procurement_line": f"SELECT order_id FROM {LINE_ROWS} WHERE id=?",
        "receipt_line": f"SELECT o.order_id FROM procurement_receipt_lines l JOIN {LINE_ROWS} o ON o.line_id=l.order_line_id WHERE l.line_id=? UNION SELECT order_id FROM {RECEIPT_ROWS} WHERE receipt_line_id=? UNION SELECT o.order_id FROM {RECEIPT_ROWS} r JOIN {LINE_ROWS} o ON o.line_id=r.line_id WHERE r.receipt_line_id=?",
        "stock_receipt": f"SELECT order_id FROM {RECEIPT_ROWS} WHERE receipt_id=? UNION SELECT o.order_id FROM {RECEIPT_ROWS} r JOIN {LINE_ROWS} o ON o.line_id=r.line_id WHERE r.receipt_id=?",
    }
    record_type = {"inspection": "receipt_line"}.get(record_type, record_type)
    if record_type in queries:
        query = queries[record_type]
        return {row[0] for row in connection.execute(query, (record_id,) * query.count("?"))} - {"", None}
    children = {
        "receipt_document": ("receipt_line", "SELECT line_id FROM procurement_receipt_lines WHERE document_id=?"),
    }
    orders = set()
    if record_type in children:
        child_type, query = children[record_type]
        for row in connection.execute(query, (record_id,)):
            orders |= record_orders(connection, child_type, row[0])
    return orders


def _reference_orders(connection, references):
    legacy = {"order_id": "order", "order_line_id": "order_line", "document_id": "receipt_document",
              "receipt_line_id": "receipt_line", "receipt_id": "stock_receipt", "procurement_id": "procurement_line"}
    orders = set()
    for kind, ids in references.items():
        for record_id in ids:
            orders |= record_orders(connection, legacy.get(kind, kind), record_id)
    return orders


def _command_orders(connection, proposal):
    command = proposal.get("command")
    if not isinstance(command, dict):
        return set()
    references = {}

    def add(kind, value):
        if value:
            references.setdefault(kind, set()).add(value)

    fields = {"order_id": "order", "order_line_id": "order_line", "document_id": "receipt_document",
              "receipt_line_id": "receipt_line", "receipt_id": "stock_receipt", "procurement_id": "procurement_line"}
    for item in [command, *command.get("lines", []), *command.get("allocations", [])]:
        for key, kind in fields.items():
            add(kind, item.get(key))
    receipt = connection.execute("""SELECT document_kind, document_id FROM procurement_action_receipts
        WHERE idempotency_key=? AND command_digest=?""", (command["idempotency_key"], proposal["command_digest"])).fetchone()
    if receipt:
        add({"receipt": "receipt_document"}.get(receipt[0], receipt[0]), receipt[1])
    return _reference_orders(connection, references)


class _ProcurementSourceStore(SourceStore):
    order_prefix = "po"
    PLAIN_DISPOSITIONS = PLAIN_DISPOSITIONS
    owner_error_type = ProcurementOwnerError
    validate_prepared_proposal = staticmethod(validate_prepared_proposal)
    command_from_proposal = staticmethod(command_from_proposal)
    preview_prepared = staticmethod(preview_prepared)
    _applied_readback = staticmethod(_applied_readback)
    command_orders = staticmethod(_command_orders)
    reference_orders = staticmethod(_reference_orders)


_store = _ProcurementSourceStore("procurement", ProcurementSourceError, PREPARED_SCHEMA)
resolution_store = _store
preview_resolution = _store.preview_resolution
apply_resolution = _store.apply_resolution
prepare_context = _store.prepare_context
source_id_for_ref = _store.source_id_for_ref
evidence_ref = _store.evidence_ref
assigned_order_id = _store.assigned_order_id
assigned_idempotency_key = _store.assigned_idempotency_key
receive_source = _store.receive_source
record_prepared = _store.record_prepared
load_source_state = _store.load_source_state
list_sources = _store.list_sources


from backend.modules.procurement.public import (
    preview_action_in_transaction,
    preview_receipt_action_in_transaction,
    apply_preview_in_transaction,
    apply_receipt_preview_in_transaction,
    read_action_in_transaction
)
from backend.modules.platform.agent_runtime.prepared_owner_execution import OwnerEffect, VerifiedReadback, OwnerStateChanged
from .agent_common import generic_owner_plan, apply_prepared_source as _apply_prepared_source

class _PreparedProcurementOwner:
    def __init__(self, connection, proposal, enabled_module_ids, profile_source_digest):
        self.connection, self.proposal, self.enabled = connection, proposal, enabled_module_ids
        self.profile_source_digest = profile_source_digest
        self.command = command_from_proposal(proposal)

    def _read(self):
        row = self.connection.execute("SELECT action_id FROM procurement_action_receipts WHERE idempotency_key=?", (self.command.idempotency_key,)).fetchone()
        if row is None:
            raise ProcurementOwnerError("procurement_readback_missing", self.command.idempotency_key)
        return read_action_in_transaction(self.connection, row["action_id"], enabled_module_ids=self.enabled)

    def applied_readback(self):
        try:
            readback = self._read()
        except ProcurementOwnerError as exc:
            if exc.code == "procurement_readback_missing":
                return None
            raise
        if readback["command_digest"] != self.command.command_digest:
            raise ProcurementSourceError("procurement_agent_receipt_command_conflict", "receipt differs from prepared command")
        return readback

    async def preview(self):
        if isinstance(self.command, ProcurementReceiptCommand) and self.command.action == "post" and not (self.command.post_reference or "").strip():
            if any(self.connection.execute("SELECT 1 FROM procurement_receipt_allocations WHERE receipt_line_id=? LIMIT 1", (item.receipt_line_id,)).fetchone() for item in self.command.allocations):
                raise ProcurementOwnerError("procurement_agent_identity_required", "needs_clarification: missing post_reference")
        preview = {"create_order": preview_action_in_transaction, "receipt": preview_receipt_action_in_transaction}[self.proposal["disposition"]]
        return generic_owner_plan("procurement", self.proposal, preview(self.connection, self.command, enabled_module_ids=self.enabled),
            profile_source_digest=self.profile_source_digest)

    async def apply(self, plan):
        writer = {"create_order": apply_preview_in_transaction, "receipt": apply_receipt_preview_in_transaction}[self.proposal["disposition"]]
        try:
            result = writer(self.connection, plan.preview, enabled_module_ids=self.enabled)
        except ProcurementOwnerError as exc:
            if exc.code in {"procurement_state_generation_drift", "procurement_preview_content_drift"}:
                raise OwnerStateChanged(str(exc)) from exc
            raise
        return OwnerEffect("applied", result)

    async def readback(self, plan, effect):
        readback = self._read()
        expected = {key: value for key, value in effect.result.items() if key != "disposition"}
        mismatches = () if readback == expected else ({"check": "owner_readback", "expected": expected, "actual": readback},)
        return VerifiedReadback(not mismatches, mismatches, readback)


def apply_prepared_source(path, source_id, *, preview_digest, profile_source_digest, enabled_module_ids=None):
    return _apply_prepared_source(_store, path, source_id, preview_digest=preview_digest,
        enabled_module_ids=enabled_module_ids, profile_source_digest=profile_source_digest, owner_type=_PreparedProcurementOwner)
