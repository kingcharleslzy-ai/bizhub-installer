"""销售结算标准表：收款分到销售订单、发票分到销售订单。

和采购结算标准表同一套做法（``procurement.settlement_schema``）：这里是唯一定义，取的是首家客户
生产库现在的形状（数字编号、按订单对账、作废留痕不删）。客户库里的同名表必须等于
“标准表 + 该客户登记的扩展”，由一致性检查逐项核对。

- 对账口径按订单（10-19 所有者定）：收款、发票都分到销售订单，收款可以先不分、按客户记。
- 通用小库从第 18 版迁移起也按本标准表建这两张表（``generic_kernel.migrations``）。
"""

from __future__ import annotations

from backend.modules.master_data.schema import (
    Check,
    Column,
    ExpressionCheck,
    ForeignKey,
    Index,
    Table,
    create_table_sql,
)

SALES_ORDER_TABLE = "sales_orders"
_CONFIRMED_REVERSED = ("confirmed", "reversed")


def _c(name: str, type_: str, *, nullable: bool = False, default: str | None = None) -> Column:
    return Column(name, type_, nullable, default)


def _confirmation_columns() -> tuple[Column, ...]:
    """确认与冲销留痕：谁确认、谁冲销、什么时候；冲销只改状态，不删行。"""

    return (
        _c("status", "VARCHAR(30)", default="confirmed"),
        _c("source_kind", "VARCHAR(60)", default="management_confirmed"),
        _c("source_ref", "TEXT"),
        _c("notes", "TEXT"),
        _c("confirmed_by", "VARCHAR(120)"),
        _c("confirmed_at", "DATETIME"),
        _c("reversed_by", "VARCHAR(120)"),
        _c("reversed_at", "DATETIME", nullable=True),
        _c("created_at", "DATETIME"),
    )


def _allocation_table(name: str, owner_column: str, owner_table: str, prefix: str) -> Table:
    return Table(
        name,
        (
            _c("id", "INTEGER"),
            _c(owner_column, "INTEGER"),
            _c("sales_order_id", "INTEGER"),
            _c("allocated_amount", "NUMERIC"),
            *_confirmation_columns(),
        ),
        checks=(Check(f"ck_{prefix}_status", "status", _CONFIRMED_REVERSED),),
        expression_checks=(ExpressionCheck(f"ck_{prefix}_positive", "allocated_amount > 0"),),
        foreign_keys=(
            ForeignKey(owner_column, owner_table, "id", "CASCADE"),
            ForeignKey("sales_order_id", SALES_ORDER_TABLE, "id", "RESTRICT"),
        ),
        indexes=(
            Index(f"uq_{prefix}_pair", (owner_column, "sales_order_id"), unique=True, where="status = 'confirmed'"),
            Index(f"ix_{prefix}_{owner_column.removesuffix('_id')}", (owner_column, "status")),
            Index(f"ix_{prefix}_order", ("sales_order_id", "status")),
        ),
    )


SALES_PAYMENT_ALLOCATIONS = _allocation_table(
    "sales_payment_allocations", "payment_id", "sales_payments", "sales_payment_allocation"
)
SALES_INVOICE_ALLOCATIONS = _allocation_table(
    "sales_invoice_allocations", "invoice_id", "sales_invoices", "sales_invoice_allocation"
)

SETTLEMENT_STANDARD_TABLES: tuple[Table, ...] = (SALES_PAYMENT_ALLOCATIONS, SALES_INVOICE_ALLOCATIONS)


def settlement_schema_sql() -> tuple[str, ...]:
    return tuple(statement for table in SETTLEMENT_STANDARD_TABLES for statement in create_table_sql(table))


__all__ = ["SALES_ORDER_TABLE", "SETTLEMENT_STANDARD_TABLES", "settlement_schema_sql"]
