"""Shared read-only reference evidence links; no business writes."""
from __future__ import annotations
from typing import Any

MAX_ROWS_PER_LINK = 60
MAX_DIFFERENCE_ROWS = 100
CONFLICT_TYPES = {"weight_mismatch", "quantity_mismatch"}


class StageRows:
    """收集一个业务阶段的逐行核对结果，最后折叠成 reference_check 链接。"""

    def __init__(self, stage: str, module: str, record_type: str, missing_type: str) -> None:
        self.stage = stage
        self.module = module
        self.record_type = record_type
        self.missing_type = missing_type
        self.by_record: dict[str, dict[str, Any]] = {}
        self.missing: list[dict[str, Any]] = []
        self.parsed = 0
        self.skipped = 0
        self.historical = 0

    def add(
        self,
        record_id: str,
        *,
        sheet: str,
        row_number: int,
        matched: dict[str, Any],
        differences: list[dict[str, Any]] | None = None,
    ) -> None:
        entry = self.by_record.setdefault(record_id, {"rows": [], "differences": [], "conflict": False, "total_rows": 0})
        entry["total_rows"] += 1
        if len(entry["rows"]) < MAX_ROWS_PER_LINK:
            entry["rows"].append({"sheet": sheet, "row": row_number, **matched})
        for difference in differences or []:
            entry["differences"].append({"sheet": sheet, "row": row_number, **difference})
            if difference.get("type") in CONFLICT_TYPES:
                entry["conflict"] = True
        self.parsed += 1

    def add_missing(self, sheet: str, row_number: int, detail: dict[str, Any]) -> None:
        self.missing.append({"sheet": sheet, "row": row_number, **detail})
        self.parsed += 1

    def links(self, group_id: str, context: dict[str, Any]) -> list[dict[str, Any]]:
        result: list[dict[str, Any]] = []
        for record_id, entry in sorted(self.by_record.items()):
            result.append(
                _link(
                    group_id,
                    formal_module=self.module,
                    record_type=self.record_type,
                    record_id=record_id,
                    status="conflict" if entry["conflict"] else ("needs_review" if entry["differences"] else "matched_existing"),
                    context=context,
                    matched_fields={
                        "rows": entry["rows"],
                        "row_count": entry["total_rows"],
                        "rows_truncated": entry["total_rows"] > len(entry["rows"]),
                    },
                    differences=entry["differences"],
                )
            )
        if self.missing:
            result.append(
                _link(
                    group_id,
                    formal_module=self.module,
                    record_type=self.missing_type,
                    record_id="workbook",
                    status="needs_review",
                    context=context,
                    matched_fields={"row_count": len(self.missing)},
                    differences=self.missing,
                )
            )
        return result

    def coverage(self) -> dict[str, Any]:
        return {"parsed": self.parsed, "skipped": self.skipped, "historical": self.historical}


def _link(
    group_id: str,
    *,
    formal_module: str,
    record_type: str,
    record_id: str,
    status: str,
    context: dict[str, Any],
    matched_fields: dict[str, Any],
    differences: list[dict[str, Any]],
) -> dict[str, Any]:
    return {
        "group_id": group_id,
        "formal_module": formal_module,
        "formal_record_type": record_type,
        "formal_record_id": str(record_id),
        "link_status": status,
        "link_kind": "reference_check",
        "confidence": 1.0 if status == "matched_existing" else 0.5,
        "matched_fields": {"stage": context["stage"], **matched_fields,
                           "difference_count": len(differences),
                           "differences_truncated": len(differences) > MAX_DIFFERENCE_ROWS},
        "differences": differences[:MAX_DIFFERENCE_ROWS],
        "formal_snapshot": {"snapshot_generated_at": context["snapshot_generated_at"]},
    }


def _coverage_link(group: dict[str, Any], context: dict[str, Any], stage: str, fields: dict[str, Any], difference: dict[str, Any]) -> dict[str, Any]:
    return _link(
        str(group["group_id"]),
        formal_module=str(group.get("primary_category") or "company"),
        record_type="reference_coverage",
        record_id="workbook",
        status="needs_review",
        context={**context, "stage": stage},
        matched_fields=fields,
        differences=[difference],
    )
