"""库位标准表：一张表管所有库位，物料仓、片子状态桶、外发在途批次、对方库位都是一行。

和退货标准表同一套做法（``return_schema``）：这里是唯一定义，取的是首家客户生产库台账库位表现在的形状
（文字键唯一；整数编号沿用首家客户物料库位的旧编号，接口和外键不用改）。客户库里的同名表必须等于
“标准表 + 该客户登记的扩展”，由一致性检查逐项核对。

- ``usage``：在库 internal / 在途 transit（计入总数）/ 对方 virtual（生产、客户、报废、期初等）。
- ``item_kind``：这个库位装哪类东西（物料、片子、贵金属……），客户自定取值，不做枚举。
- ``counts_in_total`` / ``available_for_sale``：是否计入总库存、是否可售。
- ``status``：active / deprecated，停用的库位不再收发但历史流水照旧引用。
"""

from __future__ import annotations

from backend.modules.master_data.schema import Check, Column, Index, Table, create_table_sql

LOCATION_USAGES = ("internal", "transit", "virtual")
LOCATION_STATUSES = ("active", "deprecated")


def _c(name: str, type_: str, *, nullable: bool = False) -> Column:
    return Column(name, type_, nullable)


LOCATIONS = Table(
    "locations",
    (
        _c("id", "INTEGER"),
        _c("key", "VARCHAR(80)"),
        _c("display_name", "VARCHAR(120)"),
        _c("item_kind", "VARCHAR(40)"),
        _c("usage", "VARCHAR(20)"),
        _c("counts_in_total", "BOOLEAN"),
        _c("available_for_sale", "BOOLEAN"),
        _c("sort_order", "INTEGER"),
        _c("status", "VARCHAR(20)"),
    ),
    uniques=(("uq_locations_key", ("key",)),),
    checks=(
        Check("ck_locations_usage", "usage", LOCATION_USAGES),
        Check("ck_locations_status", "status", LOCATION_STATUSES),
    ),
    indexes=(Index("ix_locations_kind_sort", ("item_kind", "sort_order")),),
)

LOCATION_STANDARD_TABLES: tuple[Table, ...] = (LOCATIONS,)


def location_schema_sql() -> tuple[str, ...]:
    return tuple(statement for table in LOCATION_STANDARD_TABLES for statement in create_table_sql(table))


__all__ = [
    "LOCATIONS",
    "LOCATION_STANDARD_TABLES",
    "LOCATION_STATUSES",
    "LOCATION_USAGES",
    "location_schema_sql",
]
