"""Minimal FastAPI shell for generic-kernel-smoke."""

from __future__ import annotations

from backend.kernel.profile_registry import storage_connect

import os
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import Body, FastAPI, HTTPException, Query, Request
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, ConfigDict, Field, ValidationError

from backend.modules.inventory.contracts import InventoryCommand, InventoryPreview
from backend.modules.inventory.owner import InventoryOwnerError
from backend.modules.inventory.public import apply_preview, get_balance, list_movements, preview_action
from backend.modules.master_data.public import list_locations
from backend.modules.procurement.contracts import ProcurementCommand, ProcurementPreview
from backend.modules.procurement.owner import ProcurementOwnerError
from backend.modules.procurement.public import (
    apply_preview as apply_procurement_preview,
    list_orders as list_procurement_orders,
    ProcurementReceiptCommand, ProcurementReceiptPreview,
    preview_receipt_action, apply_receipt_preview, list_receipt_documents,
    read_receipt_document, read_action as read_procurement_action,
    preview_action as preview_procurement_action,
)
from backend.modules.sales.contracts import SalesCommand, SalesPreview, SalesReturnCommand, SalesReturnPreview
from backend.modules.sales.owner import SalesOwnerError
from backend.modules.sales.public import (
    apply_return_preview,
    apply_service_preview,
    list_services,
    preview_service_action,
    preview_return_action,
    read_return_case,
    read_document_action,
    apply_preview as apply_sales_preview,
    list_orders as list_sales_orders,
    preview_action as preview_sales_action,
)

from .cobuild import (
    STATE_SCHEMA as WORKSPACE_COBUILD_STATE_SCHEMA,
    WorkspaceCobuildError,
    answer_workspace_cobuild_question,
    observe_workspace_cobuild_material,
    read_workspace_cobuild,
    read_workspace_cobuild_handoff,
)
from .migrations import (
    ensure_generic_database,
    migrations_for_modules,
    readback_database,
    retained_migrations_for_database,
)
from .onboarding import (
    STATE_SCHEMA as WORKSPACE_ONBOARDING_STATE_SCHEMA,
    WorkspaceOnboardingError,
    enter_workspace,
    read_workspace_onboarding,
)
from backend.modules.platform.agent_runtime.contributions import (
    AgentContracts, AgentKnowledgeScope, AgentKnowledgeProjection, assemble_agent_contracts, read_agent_knowledge,
)

from .agent_common import receive_source_async, prepare_source
from .profile import generic_profile_source_digest, get_generic_registry
from .storage import StorageRoute, storage_wait_seconds
from .sales_agent import SalesAgentError
from .sales_sources import (
    SalesSourceError,
    list_sources,
    load_source_state,
    receive_source,
)

from .procurement_agent import ProcurementAgentError
from . import procurement_sources as procurement_agent_sources
from . import sales_sources as sales_source_module
from .agent_common import register_resolution_routes


class WorkspaceOnboardingEnterRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    schema_version: str
    expected_revision: int = Field(ge=1)
    idempotency_key: str = Field(min_length=8, max_length=128)


class WorkspaceCobuildAnswerRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    schema_version: str
    expected_revision: int = Field(ge=0)
    question_id: str = Field(min_length=1, max_length=120)
    text: str = Field(default="", max_length=2000)
    answer_kind: str
    actor_ref: str = Field(min_length=2, max_length=120)
    idempotency_key: str = Field(min_length=8, max_length=128)


class WorkspaceCobuildMaterialRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    schema_version: str
    expected_revision: int = Field(ge=0)
    material_kind: str
    display_name: str = Field(min_length=1, max_length=180)
    summary: str = Field(min_length=1, max_length=4000)
    source_ref: str = Field(min_length=3, max_length=200)
    provided_by: str = Field(min_length=2, max_length=120)
    idempotency_key: str = Field(min_length=8, max_length=128)


class AgentSourceRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    source_ref: str = Field(min_length=3, max_length=200)
    text: str = Field(min_length=1, max_length=20000)
    business_at: str = Field(default="", max_length=64)
    extra: dict[str, object] | list[object] | None = None


class AgentApplyRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    preview_digest: str = Field(min_length=16, max_length=128)


def create_app(
    database_path: Path,
    *,
    repo_root: Path | None = None,
    registry: object | None = None,
    agent_model: object | None = None,
) -> FastAPI:
    database_path = database_path.resolve()
    registry = registry or get_generic_registry(repo_root)
    registry.activate_model_catalog()
    effective_map = registry.effective_system_map()
    module_ids = {
        str(item["module_id"]) for item in registry.payload.get("modules", [])
    }
    # Assembly resolves only exports declared by this enabled Registry.
    has_contributions = any(
        f"agent.contracts.{item['module_id']}" in (item.get("capabilities") or {}).get("provides", [])
        for item in registry.payload.get("modules", [])
    )
    contracts = assemble_agent_contracts(registry) if has_contributions else AgentContracts(roles={}, records=())
    knowledge_scope = AgentKnowledgeScope(
        scene="source_interpretation", consumer="generic-sales-agent",
        record_types=tuple(spec.record_type for spec in contracts.records if "generic-sales-agent" in spec.agents),
    )

    async def read_sales_knowledge() -> AgentKnowledgeProjection:
        # Thin SalesCommand sources have no declared legacy event identity.
        # Do not infer a record_type, transport identity or hash from source text.
        return read_agent_knowledge(contracts, scope=knowledge_scope)

    procurement_knowledge_scope = AgentKnowledgeScope(
        scene="source_interpretation", consumer="generic-procurement-agent",
        record_types=tuple(spec.record_type for spec in contracts.records if "generic-procurement-agent" in spec.agents),
    )

    async def read_procurement_knowledge() -> AgentKnowledgeProjection:
        return read_agent_knowledge(contracts, scope=procurement_knowledge_scope)

    active_migrations = migrations_for_modules(module_ids)

    def database_migrations():
        return retained_migrations_for_database(database_path, active_migrations)

    @asynccontextmanager
    async def lifespan(_: FastAPI):
        ensure_generic_database(database_path, migrations=database_migrations())
        yield

    app = FastAPI(
        title="BizHub Generic Kernel Smoke",
        description="Minimal profile, database, health and system-map shell.",
        version="0.1.0-pack-c",
        lifespan=lifespan,
        docs_url=None,
        redoc_url=None,
        openapi_url=None,
    )

    app.router.route_class = StorageRoute
    app.state.storage_wait_seconds = storage_wait_seconds()

    @app.get("/", response_class=HTMLResponse)
    def shell() -> str:
        return (Path(__file__).with_name("ui") / "index.html").read_text(encoding="utf-8")

    @app.get("/health")
    @app.get("/api/health", include_in_schema=False)
    def health() -> dict[str, object]:
        state = readback_database(database_path, migrations=database_migrations())
        return {
            "status": "ok",
            "profile_id": state["profile_id"],
            "lineage_id": state["lineage_id"],
            "schema_version": state["schema_version"],
            "migration_set_digest": state["migration_set_digest"],
            "schema_fingerprint": state["schema_fingerprint"],
        }

    @app.get("/api/system-map")
    async def system_map() -> dict[str, object]:
        return effective_map

    if "generic.kernel_smoke" in module_ids:
        @app.get("/api/workspace-onboarding/state")
        def workspace_onboarding_state() -> dict[str, object]:
            try:
                return read_workspace_onboarding(
                    database_path,
                    enabled_module_ids=module_ids,
                )
            except WorkspaceOnboardingError as exc:
                raise HTTPException(
                    status_code=409,
                    detail={"code": exc.code, "message": exc.message},
                ) from exc

        @app.post("/api/workspace-onboarding/enter")
        def workspace_onboarding_enter(
            payload: WorkspaceOnboardingEnterRequest,
        ) -> dict[str, object]:
            if payload.schema_version != WORKSPACE_ONBOARDING_STATE_SCHEMA:
                raise HTTPException(
                    status_code=409,
                    detail={
                        "code": "workspace_onboarding_schema_invalid",
                        "message": payload.schema_version,
                    },
                )
            try:
                return enter_workspace(
                    database_path,
                    expected_revision=payload.expected_revision,
                    idempotency_key=payload.idempotency_key,
                    enabled_module_ids=module_ids,
                )
            except WorkspaceOnboardingError as exc:
                raise HTTPException(
                    status_code=409,
                    detail={"code": exc.code, "message": exc.message},
                ) from exc

        @app.get("/api/workspace-cobuild/state")
        def workspace_cobuild_state() -> dict[str, object]:
            try:
                return read_workspace_cobuild(
                    database_path,
                    enabled_module_ids=module_ids,
                )
            except WorkspaceCobuildError as exc:
                raise HTTPException(
                    status_code=409,
                    detail={"code": exc.code, "message": exc.message},
                ) from exc

        @app.post("/api/workspace-cobuild/answers")
        def workspace_cobuild_answer(
            payload: WorkspaceCobuildAnswerRequest,
        ) -> dict[str, object]:
            if payload.schema_version != WORKSPACE_COBUILD_STATE_SCHEMA:
                raise HTTPException(
                    status_code=409,
                    detail={
                        "code": "workspace_cobuild_schema_invalid",
                        "message": payload.schema_version,
                    },
                )
            try:
                return answer_workspace_cobuild_question(
                    database_path,
                    expected_revision=payload.expected_revision,
                    question_id=payload.question_id,
                    text=payload.text,
                    answer_kind=payload.answer_kind,
                    actor_ref=payload.actor_ref,
                    idempotency_key=payload.idempotency_key,
                    enabled_module_ids=module_ids,
                )
            except WorkspaceCobuildError as exc:
                raise HTTPException(
                    status_code=409,
                    detail={"code": exc.code, "message": exc.message},
                ) from exc

        @app.post("/api/workspace-cobuild/materials")
        def workspace_cobuild_material(
            payload: WorkspaceCobuildMaterialRequest,
        ) -> dict[str, object]:
            if payload.schema_version != WORKSPACE_COBUILD_STATE_SCHEMA:
                raise HTTPException(
                    status_code=409,
                    detail={
                        "code": "workspace_cobuild_schema_invalid",
                        "message": payload.schema_version,
                    },
                )
            try:
                return observe_workspace_cobuild_material(
                    database_path,
                    expected_revision=payload.expected_revision,
                    material_kind=payload.material_kind,
                    display_name=payload.display_name,
                    summary=payload.summary,
                    source_ref=payload.source_ref,
                    provided_by=payload.provided_by,
                    idempotency_key=payload.idempotency_key,
                    enabled_module_ids=module_ids,
                )
            except WorkspaceCobuildError as exc:
                raise HTTPException(
                    status_code=409,
                    detail={"code": exc.code, "message": exc.message},
                ) from exc

        @app.get("/api/workspace-cobuild/handoff")
        def workspace_cobuild_handoff() -> dict[str, object]:
            try:
                return read_workspace_cobuild_handoff(
                    database_path,
                    enabled_module_ids=module_ids,
                )
            except WorkspaceCobuildError as exc:
                raise HTTPException(
                    status_code=409,
                    detail={"code": exc.code, "message": exc.message},
                ) from exc

    if "master_data" in module_ids:
        @app.get("/api/master-data/locations")
        def master_data_locations() -> dict[str, object]:
            import sqlite3

            connection = storage_connect(f"file:{database_path}?mode=ro", uri=True)
            connection.row_factory = sqlite3.Row
            connection.execute("PRAGMA query_only=ON")
            try:
                return {"items": list_locations(connection)}
            finally:
                connection.close()

    if "inventory" in module_ids:
        @app.get("/api/inventory/movements")
        def inventory_movements(limit: int = Query(default=100, ge=1, le=500)) -> dict[str, object]:
            return {"items": list_movements(database_path, limit=limit)}

        @app.get("/api/inventory/balance")
        def inventory_balance(
            product_id: int | None = None,
            unit_id: int | None = None,
            location_id: str = "",
        ) -> dict[str, object]:
            missing = [key for key, value in {"product_id": product_id, "unit_id": unit_id, "location_id": location_id.strip()}.items() if not value]
            if missing:
                raise HTTPException(status_code=409, detail={"code": "inventory_balance_dimensions_required",
                    "message": "provide product_id, unit_id and location_id", "missing_fields": missing})
            return get_balance(
                database_path,
                product_id=product_id,
                unit_id=unit_id,
                location_id=location_id,
            )

        @app.post("/api/inventory/preview")
        def inventory_preview(payload: dict[str, object]) -> dict[str, object]:
            try:
                return preview_action(
                    database_path,
                    InventoryCommand.from_dict(payload),
                    enabled_module_ids=module_ids,
                ).to_dict()
            except (InventoryOwnerError, TypeError, ValueError) as exc:
                code = getattr(exc, "code", "inventory_request_invalid")
                raise HTTPException(status_code=409, detail={"code": code, "message": str(exc)}) from exc

        @app.post("/api/inventory/apply")
        def inventory_apply(payload: dict[str, object]) -> dict[str, object]:
            try:
                command = InventoryCommand.from_dict(payload["command"])
                preview = InventoryPreview(
                    command=command,
                    state_generation=str(payload["state_generation"]),
                    planned_movements=tuple(payload.get("planned_movements") or ()),
                    planned_stocktake=payload.get("planned_stocktake"),
                    before_balances=tuple(payload.get("before_balances") or ()),
                    preview_digest=str(payload["preview_digest"]),
                )
                return apply_preview(
                    database_path,
                    preview,
                    enabled_module_ids=module_ids,
                )
            except (InventoryOwnerError, KeyError, TypeError, ValueError) as exc:
                code = getattr(exc, "code", "inventory_request_invalid")
                raise HTTPException(status_code=409, detail={"code": code, "message": str(exc)}) from exc

    # The transport never accepts inventory's internal trade authority keyword.
    def register_trade_reversals(domain, owner, error_type):
        from backend.modules.trade_core.public import TradeNumericTools, TradeReversalCommand, TradeReversalPreview
        from backend.kernel.runtime.quantity_parser import canonical_decimal_text, finite_decimal
        numeric_tools = TradeNumericTools(finite_decimal, canonical_decimal_text)

        def reversal_preview(payload: object = Body(default=None)):
            try:
                command = TradeReversalCommand.from_dict(payload)
                return owner.preview_reversal_action(database_path, command, numeric_tools=numeric_tools, enabled_module_ids=module_ids).to_dict()
            except (TypeError, KeyError, ValueError) as exc:
                raise HTTPException(409, detail={"code": "trade_reversal_request_invalid", "message": str(exc)}) from exc
            except (error_type, InventoryOwnerError) as exc:
                raise HTTPException(409, detail={"code": exc.code, "message": exc.message}) from exc

        def reversal_apply(payload: object = Body(default=None)):
            try:
                preview = TradeReversalPreview.from_dict(payload)
                result = owner.apply_reversal_preview(database_path, preview, numeric_tools=numeric_tools, enabled_module_ids=module_ids)
            except (TypeError, KeyError, ValueError) as exc:
                raise HTTPException(409, detail={"code": "trade_reversal_request_invalid", "message": str(exc)}) from exc
            except (error_type, InventoryOwnerError) as exc:
                raise HTTPException(409, detail={"code": exc.code, "message": exc.message}) from exc
            if result["status"] == "needs_manual_review":
                # Owner has committed only the durable manual-review receipt.
                raise HTTPException(409, detail={"code": "trade_reversal_requires_manual_review", **result})
            return result

        def reversal_list(status: str = ""):
            return owner.list_reversals(database_path, status=status, enabled_module_ids=module_ids)

        def reversal_read(reversal_id: str):
            try:
                return owner.read_reversal(database_path, reversal_id, enabled_module_ids=module_ids)
            except error_type as exc:
                raise HTTPException(404, detail={"code": exc.code, "message": exc.message}) from exc

        for suffix, endpoint, method in (("/preview", reversal_preview, "POST"), ("/apply", reversal_apply, "POST"),
                                         ("", reversal_list, "GET"), ("/{reversal_id}", reversal_read, "GET")):
            app.add_api_route(f"/api/{domain}/reversals{suffix}", endpoint, methods=[method], name=f"{domain}_{endpoint.__name__}")

    if "procurement" in module_ids:
        from backend.modules.procurement import public as procurement_owner
        register_trade_reversals("procurement", procurement_owner, ProcurementOwnerError)
    if "sales" in module_ids:
        from backend.modules.sales import public as sales_owner
        register_trade_reversals("sales", sales_owner, SalesOwnerError)

    if "procurement" in module_ids:
        register_resolution_routes(app, store=procurement_agent_sources.resolution_store, database_path=database_path,
                                   enabled_module_ids=module_ids, model=agent_model,
                                   read_knowledge=read_procurement_knowledge, agent_error_type=ProcurementAgentError,
                                   owner_error_types=(ProcurementOwnerError, InventoryOwnerError), registry=registry)
        @app.get("/api/procurement/orders")
        def procurement_orders(limit: int = Query(default=100, ge=1, le=500)) -> dict[str, object]:
            return {"items": list_procurement_orders(database_path, limit=limit)}

        @app.post("/api/procurement/preview")
        def procurement_preview(payload: object = Body(default=None)) -> dict[str, object]:
            try:
                if not isinstance(payload, dict):
                    raise TypeError("command must be an object")
                command = ProcurementCommand.from_dict(payload)
            except (KeyError, TypeError, ValueError) as exc:
                raise HTTPException(status_code=409, detail={"code": "procurement_request_invalid", "message": str(exc)}) from exc
            try:
                return preview_procurement_action(
                    database_path,
                    command,
                    enabled_module_ids=module_ids,
                ).to_dict()
            except (ProcurementOwnerError, InventoryOwnerError) as exc:
                raise HTTPException(status_code=409, detail={"code": exc.code, "message": str(exc)}) from exc

        @app.post("/api/procurement/apply")
        def procurement_apply(payload: object = Body(default=None)) -> dict[str, object]:
            try:
                if not isinstance(payload, dict):
                    raise TypeError("preview must be an object")
                preview = ProcurementPreview.from_dict(payload)
            except (KeyError, TypeError, ValueError) as exc:
                raise HTTPException(status_code=409, detail={"code": "procurement_request_invalid", "message": str(exc)}) from exc
            try:
                return apply_procurement_preview(
                    database_path,
                    preview,
                    enabled_module_ids=module_ids,
                )
            except (ProcurementOwnerError, InventoryOwnerError) as exc:
                raise HTTPException(status_code=409, detail={"code": exc.code, "message": str(exc)}) from exc

        @app.post("/api/procurement/receipts/preview")
        def procurement_receipt_preview(payload: object = Body(default=None)) -> dict[str, object]:
            try:
                command = ProcurementReceiptCommand.from_dict(payload)
            except (KeyError, TypeError, ValueError) as exc:
                raise HTTPException(status_code=409, detail={"code": "procurement_request_invalid", "message": str(exc)}) from exc
            try:
                return preview_receipt_action(database_path, command, enabled_module_ids=module_ids).to_dict()
            except (ProcurementOwnerError, InventoryOwnerError) as exc:
                raise HTTPException(status_code=409, detail={"code": exc.code, "message": str(exc)}) from exc

        @app.post("/api/procurement/receipts/apply")
        def procurement_receipt_apply(payload: object = Body(default=None)) -> dict[str, object]:
            try:
                preview = ProcurementReceiptPreview.from_dict(payload)
            except (KeyError, TypeError, ValueError) as exc:
                raise HTTPException(status_code=409, detail={"code": "procurement_request_invalid", "message": str(exc)}) from exc
            try:
                return apply_receipt_preview(database_path, preview, enabled_module_ids=module_ids)
            except (ProcurementOwnerError, InventoryOwnerError) as exc:
                raise HTTPException(status_code=409, detail={"code": exc.code, "message": str(exc)}) from exc

        @app.get("/api/procurement/receipts")
        def procurement_receipts(query: str = "", offset: int = Query(default=0, ge=0),
                                       limit: int = Query(default=100, ge=1, le=500)) -> dict[str, object]:
            return list_receipt_documents(database_path, query=query, offset=offset, limit=limit)

        @app.get("/api/procurement/receipts/{document_id}")
        def procurement_receipt(document_id: str) -> dict[str, object]:
            try:
                return read_receipt_document(database_path, document_id)
            except ProcurementOwnerError as exc:
                raise HTTPException(status_code=409, detail={"code": exc.code, "message": str(exc)}) from exc

        @app.get("/api/procurement/actions/{action_id}")
        def procurement_action(action_id: str) -> dict[str, object]:
            try:
                return read_procurement_action(database_path, action_id)
            except ProcurementOwnerError as exc:
                raise HTTPException(status_code=409, detail={"code": exc.code, "message": str(exc)}) from exc

    if "procurement" in module_ids:
        def procurement_source_error(exc):
            status = 404 if exc.code == "procurement_agent_source_not_found" else 409
            return HTTPException(status_code=status, detail={"code": exc.code, "message": exc.message, **({"current_preview_digest": exc.current_preview_digest} if hasattr(exc, "current_preview_digest") else {})})

        @app.post("/api/procurement/agent/sources")
        async def procurement_agent_receive_source(payload: object = Body(...)) -> dict[str, object]:
            try:
                request = AgentSourceRequest.model_validate(payload)
            except ValidationError as exc:
                raise HTTPException(status_code=409, detail={"code": "procurement_agent_request_invalid", "message": str(exc)}) from exc
            source_id = ""
            try:
                received = await receive_source_async(procurement_agent_sources.resolution_store,
                    database_path, source_ref=request.source_ref, text=request.text,
                    business_at=request.business_at, extra=request.extra, enabled_module_ids=module_ids,
                )
                source_id = received["source_id"]
                state = await prepare_source(procurement_agent_sources.resolution_store, database_path, source_id,
                    model=agent_model,enabled_module_ids=module_ids,read_knowledge=read_procurement_knowledge,registry=registry)
                return {**state, "receive_disposition": received["disposition"]}
            except ProcurementAgentError as exc:
                status = 503 if exc.code in {"procurement_agent_ai_unavailable", "procurement_agent_run_failed"} else 409
                raise HTTPException(status_code=status, detail={"code": exc.code, "message": exc.message, "source_id": source_id}) from exc
            except procurement_agent_sources.ProcurementSourceError as exc:
                raise procurement_source_error(exc) from exc
            except (ProcurementOwnerError, InventoryOwnerError) as exc:
                raise HTTPException(status_code=409, detail={"code": exc.code, "message": exc.message}) from exc

        @app.get("/api/procurement/agent/sources")
        def procurement_agent_list_sources(order_id: str = Query(default=""), limit: int = Query(default=50, ge=1, le=200)) -> dict[str, object]:
            try:
                return {"items": procurement_agent_sources.list_sources(database_path, order_id=order_id, limit=limit, enabled_module_ids=module_ids)}
            except procurement_agent_sources.ProcurementSourceError as exc:
                raise procurement_source_error(exc) from exc

        @app.get("/api/procurement/agent/sources/{source_id}")
        def procurement_agent_read_source(source_id: str) -> dict[str, object]:
            try:
                return procurement_agent_sources.load_source_state(database_path, source_id, enabled_module_ids=module_ids)
            except procurement_agent_sources.ProcurementSourceError as exc:
                raise procurement_source_error(exc) from exc
            except (ProcurementOwnerError, InventoryOwnerError) as exc:
                raise HTTPException(status_code=409, detail={"code": exc.code, "message": exc.message}) from exc

        @app.post("/api/procurement/agent/sources/{source_id}/apply")
        def procurement_agent_apply_source(source_id: str, payload: object = Body(...)) -> dict[str, object]:
            try:
                request = AgentApplyRequest.model_validate(payload)
            except ValidationError as exc:
                raise HTTPException(status_code=409, detail={"code": "procurement_agent_request_invalid", "message": str(exc)}) from exc
            try:
                return procurement_agent_sources.apply_prepared_source(database_path, source_id,
                    preview_digest=request.preview_digest, enabled_module_ids=module_ids,
                    profile_source_digest=generic_profile_source_digest(getattr(registry, "repo_root", None)))
            except procurement_agent_sources.ProcurementSourceError as exc:
                raise procurement_source_error(exc) from exc
            except (ProcurementOwnerError, InventoryOwnerError) as exc:
                raise HTTPException(status_code=409, detail={"code": exc.code, "message": exc.message}) from exc

    if "sales" in module_ids:
        register_resolution_routes(app, store=sales_source_module.resolution_store, database_path=database_path,
                                   enabled_module_ids=module_ids, model=agent_model,
                                   read_knowledge=read_sales_knowledge, agent_error_type=SalesAgentError,
                                   owner_error_types=(SalesOwnerError, InventoryOwnerError), registry=registry)
        @app.get("/api/sales/orders")
        def sales_orders(limit: int = Query(default=100, ge=1, le=500)) -> dict[str, object]:
            return {"items": list_sales_orders(database_path, limit=limit)}

        @app.post("/api/sales/preview")
        def sales_preview(payload: object = Body(default=None)) -> dict[str, object]:
            try:
                if not isinstance(payload, dict):
                    raise TypeError("command must be an object")
                command = SalesCommand.from_dict(payload)
            except (KeyError, TypeError, ValueError) as exc:
                raise HTTPException(status_code=409, detail={"code": "sales_request_invalid", "message": str(exc)}) from exc
            try:
                return preview_sales_action(
                    database_path,
                    command,
                    enabled_module_ids=module_ids,
                ).to_dict()
            except (SalesOwnerError, InventoryOwnerError, ProcurementOwnerError) as exc:
                raise HTTPException(status_code=409, detail={"code": exc.code, "message": str(exc)}) from exc

        @app.post("/api/sales/apply")
        def sales_apply(payload: object = Body(default=None)) -> dict[str, object]:
            try:
                if not isinstance(payload, dict):
                    raise TypeError("preview must be an object")
                preview = SalesPreview.from_dict(payload)
            except (KeyError, TypeError, ValueError) as exc:
                raise HTTPException(status_code=409, detail={"code": "sales_request_invalid", "message": str(exc)}) from exc
            try:
                return apply_sales_preview(
                    database_path,
                    preview,
                    enabled_module_ids=module_ids,
                )
            except (SalesOwnerError, InventoryOwnerError, ProcurementOwnerError) as exc:
                raise HTTPException(status_code=409, detail={"code": exc.code, "message": str(exc)}) from exc

        @app.get("/api/sales/services")
        def service_contracts() -> dict[str, object]:
            return list_services(database_path, enabled_module_ids=module_ids)

        @app.post("/api/sales/services/preview")
        def service_preview(payload: dict[str, object]) -> dict[str, object]:
            try:
                return preview_service_action(database_path, payload, enabled_module_ids=module_ids)
            except SalesOwnerError as exc:
                raise HTTPException(status_code=409, detail={"code": exc.code, "message": exc.message}) from exc

        @app.post("/api/sales/services/apply")
        def service_apply(payload: dict[str, object]) -> dict[str, object]:
            try:
                return apply_service_preview(database_path, payload, enabled_module_ids=module_ids)
            except SalesOwnerError as exc:
                raise HTTPException(status_code=409, detail={"code": exc.code, "message": exc.message}) from exc

        @app.post("/api/sales/returns/preview")
        def sales_return_preview(payload: dict[str, object]) -> dict[str, object]:
            try:
                return preview_return_action(database_path, SalesReturnCommand.from_dict(payload), enabled_module_ids=module_ids).to_dict()
            except (SalesOwnerError, InventoryOwnerError, KeyError, TypeError, ValueError) as exc:
                raise HTTPException(status_code=409, detail={"code": getattr(exc, "code", "sales_request_invalid"), "message": str(exc)}) from exc

        @app.post("/api/sales/returns/apply")
        def sales_return_apply(payload: dict[str, object]) -> dict[str, object]:
            try:
                return apply_return_preview(database_path, SalesReturnPreview.from_dict(payload), enabled_module_ids=module_ids)
            except (SalesOwnerError, InventoryOwnerError, KeyError, TypeError, ValueError) as exc:
                raise HTTPException(status_code=409, detail={"code": getattr(exc, "code", "sales_request_invalid"), "message": str(exc)}) from exc

        @app.get("/api/sales/returns/{case_id}")
        def sales_return_read(case_id: str) -> dict[str, object]:
            try:
                return read_return_case(database_path, case_id, enabled_module_ids=module_ids)
            except SalesOwnerError as exc:
                raise HTTPException(status_code=404, detail={"code": exc.code, "message": exc.message}) from exc

        @app.get("/api/sales/document-actions/{idempotency_key}")
        def sales_document_read(idempotency_key: str) -> dict[str, object]:
            try:
                return read_document_action(database_path, idempotency_key, enabled_module_ids=module_ids)
            except SalesOwnerError as exc:
                raise HTTPException(status_code=404, detail={"code": exc.code, "message": exc.message}) from exc

        @app.post("/api/sales/agent/sources")
        async def sales_agent_receive_source(payload: AgentSourceRequest) -> dict[str, object]:
            source_id = ""
            try:
                received = await receive_source_async(sales_source_module.resolution_store,
                    database_path,
                    source_ref=payload.source_ref,
                    text=payload.text,
                    business_at=payload.business_at,
                    extra=payload.extra,
                    enabled_module_ids=module_ids,
                )
                source_id = str(received["source_id"])
                state = await prepare_source(sales_source_module.resolution_store, database_path, source_id,
                    model=agent_model,enabled_module_ids=module_ids,read_knowledge=read_sales_knowledge,registry=registry)
                state["receive_disposition"] = received["disposition"]
                return state
            except SalesAgentError as exc:
                raise HTTPException(
                    status_code=409 if exc.code in {"sales_agent_reference_invalid", "sales_agent_reference_unread"} else 503,
                    detail={"code": exc.code, "message": exc.message, "source_id": source_id},
                ) from exc
            except SalesSourceError as exc:
                status = 404 if exc.code == "sales_agent_source_not_found" else 409
                raise HTTPException(status_code=status, detail={"code": exc.code, "message": exc.message}) from exc

        @app.get("/api/sales/agent/sources")
        def sales_agent_sources(
            order_id: str = Query(default=""),
            limit: int = Query(default=50, ge=1, le=200),
        ) -> dict[str, object]:
            try:
                return {
                    "items": list_sources(
                        database_path,
                        order_id=order_id,
                        limit=limit,
                        enabled_module_ids=module_ids,
                    )
                }
            except SalesSourceError as exc:
                raise HTTPException(status_code=409, detail={"code": exc.code, "message": exc.message}) from exc

        @app.get("/api/sales/agent/sources/{source_id}")
        def sales_agent_source(source_id: str) -> dict[str, object]:
            try:
                return load_source_state(database_path, source_id, enabled_module_ids=module_ids)
            except SalesSourceError as exc:
                status = 404 if exc.code == "sales_agent_source_not_found" else 409
                raise HTTPException(status_code=status, detail={"code": exc.code, "message": exc.message}) from exc

        @app.post("/api/sales/agent/sources/{source_id}/apply")
        def sales_agent_apply_source(source_id: str, payload: AgentApplyRequest) -> dict[str, object]:
            try:
                return sales_source_module.apply_prepared_source(database_path, source_id,
                    preview_digest=payload.preview_digest, enabled_module_ids=module_ids,
                    profile_source_digest=generic_profile_source_digest(getattr(registry, "repo_root", None)))
            except HTTPException:
                raise
            except SalesSourceError as exc:
                status = 404 if exc.code == "sales_agent_source_not_found" else 409
                raise HTTPException(status_code=status, detail={"code": exc.code, "message": exc.message, **({"current_preview_digest": exc.current_preview_digest} if hasattr(exc, "current_preview_digest") else {})}) from exc
            except SalesOwnerError as exc:
                raise HTTPException(status_code=409, detail={"code": exc.code, "message": exc.message}) from exc

    return app


def create_app_from_env() -> FastAPI:
    value = os.environ.get("BIZHUB_GENERIC_DATABASE_PATH", "runtime/generic-kernel-smoke.sqlite")
    return create_app(Path(value))
