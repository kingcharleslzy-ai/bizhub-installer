"""Minimal FastAPI shell for generic-kernel-smoke."""

from __future__ import annotations

import os
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import HTMLResponse

from backend.modules.inventory.contracts import InventoryCommand, InventoryPreview
from backend.modules.inventory.owner import InventoryOwnerError
from backend.modules.inventory.public import apply_preview, get_balance, list_movements, preview_action
from backend.modules.master_data.public import list_locations
from backend.modules.procurement.contracts import ProcurementCommand, ProcurementPreview
from backend.modules.procurement.owner import ProcurementOwnerError
from backend.modules.procurement.public import (
    apply_preview as apply_procurement_preview,
    list_orders as list_procurement_orders,
    preview_action as preview_procurement_action,
)
from backend.modules.sales.contracts import SalesCommand, SalesPreview
from backend.modules.sales.owner import SalesOwnerError
from backend.modules.sales.public import (
    apply_preview as apply_sales_preview,
    list_orders as list_sales_orders,
    preview_action as preview_sales_action,
)

from .migrations import (
    ensure_generic_database,
    migrations_for_modules,
    readback_database,
    retained_migrations_for_database,
)
from .profile import get_generic_registry


def create_app(
    database_path: Path,
    *,
    repo_root: Path | None = None,
    registry: object | None = None,
) -> FastAPI:
    database_path = database_path.resolve()
    registry = registry or get_generic_registry(repo_root)
    registry.activate_model_catalog()
    effective_map = registry.effective_system_map()
    module_ids = {
        str(item["module_id"]) for item in registry.payload.get("modules", [])
    }
    active_migrations = migrations_for_modules(module_ids)

    def database_migrations():
        return retained_migrations_for_database(database_path, active_migrations)

    @asynccontextmanager
    async def lifespan(_: FastAPI):
        ensure_generic_database(database_path, migrations=database_migrations())
        yield

    app = FastAPI(
        title="BizHub Generic Kernel Smoke",
        description="Minimal profile, database, health and system-map shell.",
        version="0.1.0-cp4",
        lifespan=lifespan,
        docs_url=None,
        redoc_url=None,
        openapi_url=None,
    )

    @app.get("/", response_class=HTMLResponse)
    async def shell() -> str:
        return (Path(__file__).with_name("ui") / "index.html").read_text(encoding="utf-8")

    @app.get("/health")
    @app.get("/api/health", include_in_schema=False)
    async def health() -> dict[str, object]:
        state = readback_database(database_path, migrations=database_migrations())
        return {
            "status": "ok",
            "profile_id": state["profile_id"],
            "lineage_id": state["lineage_id"],
            "schema_version": state["schema_version"],
            "migration_set_digest": state["migration_set_digest"],
            "schema_fingerprint": state["schema_fingerprint"],
        }

    @app.get("/api/system-map")
    async def system_map() -> dict[str, object]:
        return effective_map

    if "master_data" in module_ids:
        @app.get("/api/master-data/locations")
        async def master_data_locations() -> dict[str, object]:
            import sqlite3

            connection = sqlite3.connect(f"file:{database_path}?mode=ro", uri=True)
            connection.row_factory = sqlite3.Row
            connection.execute("PRAGMA query_only=ON")
            try:
                return {"items": list_locations(connection)}
            finally:
                connection.close()

    if "inventory" in module_ids:
        @app.get("/api/inventory/movements")
        async def inventory_movements(limit: int = Query(default=100, ge=1, le=500)) -> dict[str, object]:
            return {"items": list_movements(database_path, limit=limit)}

        @app.get("/api/inventory/balance")
        async def inventory_balance(
            product_id: str,
            unit_id: str,
            location_id: str,
        ) -> dict[str, str]:
            return get_balance(
                database_path,
                product_id=product_id,
                unit_id=unit_id,
                location_id=location_id,
            )

        @app.post("/api/inventory/preview")
        async def inventory_preview(payload: dict[str, object]) -> dict[str, object]:
            try:
                return preview_action(
                    database_path,
                    InventoryCommand(**payload),
                    enabled_module_ids=module_ids,
                ).to_dict()
            except (InventoryOwnerError, TypeError, ValueError) as exc:
                code = getattr(exc, "code", "inventory_request_invalid")
                raise HTTPException(status_code=409, detail={"code": code, "message": str(exc)}) from exc

        @app.post("/api/inventory/apply")
        async def inventory_apply(payload: dict[str, object]) -> dict[str, object]:
            try:
                command = InventoryCommand(**dict(payload["command"]))
                preview = InventoryPreview(
                    command=command,
                    state_generation=str(payload["state_generation"]),
                    planned_movements=tuple(payload.get("planned_movements") or ()),
                    planned_stocktake=payload.get("planned_stocktake"),
                    before_balances=tuple(payload.get("before_balances") or ()),
                    preview_digest=str(payload["preview_digest"]),
                )
                return apply_preview(
                    database_path,
                    preview,
                    enabled_module_ids=module_ids,
                )
            except (InventoryOwnerError, KeyError, TypeError, ValueError) as exc:
                code = getattr(exc, "code", "inventory_request_invalid")
                raise HTTPException(status_code=409, detail={"code": code, "message": str(exc)}) from exc

    if "procurement" in module_ids:
        @app.get("/api/procurement/orders")
        async def procurement_orders(limit: int = Query(default=100, ge=1, le=500)) -> dict[str, object]:
            return {"items": list_procurement_orders(database_path, limit=limit)}

        @app.post("/api/procurement/preview")
        async def procurement_preview(payload: dict[str, object]) -> dict[str, object]:
            try:
                return preview_procurement_action(
                    database_path,
                    ProcurementCommand.from_dict(payload),
                    enabled_module_ids=module_ids,
                ).to_dict()
            except (ProcurementOwnerError, TypeError, ValueError) as exc:
                code = getattr(exc, "code", "procurement_request_invalid")
                raise HTTPException(status_code=409, detail={"code": code, "message": str(exc)}) from exc

        @app.post("/api/procurement/apply")
        async def procurement_apply(payload: dict[str, object]) -> dict[str, object]:
            try:
                return apply_procurement_preview(
                    database_path,
                    ProcurementPreview.from_dict(payload),
                    enabled_module_ids=module_ids,
                )
            except (ProcurementOwnerError, KeyError, TypeError, ValueError) as exc:
                code = getattr(exc, "code", "procurement_request_invalid")
                raise HTTPException(status_code=409, detail={"code": code, "message": str(exc)}) from exc

    if "sales" in module_ids:
        @app.get("/api/sales/orders")
        async def sales_orders(limit: int = Query(default=100, ge=1, le=500)) -> dict[str, object]:
            return {"items": list_sales_orders(database_path, limit=limit)}

        @app.post("/api/sales/preview")
        async def sales_preview(payload: dict[str, object]) -> dict[str, object]:
            try:
                return preview_sales_action(
                    database_path,
                    SalesCommand.from_dict(payload),
                    enabled_module_ids=module_ids,
                ).to_dict()
            except (SalesOwnerError, TypeError, ValueError) as exc:
                code = getattr(exc, "code", "sales_request_invalid")
                raise HTTPException(status_code=409, detail={"code": code, "message": str(exc)}) from exc

        @app.post("/api/sales/apply")
        async def sales_apply(payload: dict[str, object]) -> dict[str, object]:
            try:
                return apply_sales_preview(
                    database_path,
                    SalesPreview.from_dict(payload),
                    enabled_module_ids=module_ids,
                )
            except (SalesOwnerError, KeyError, TypeError, ValueError) as exc:
                code = getattr(exc, "code", "sales_request_invalid")
                raise HTTPException(status_code=409, detail={"code": code, "message": str(exc)}) from exc

    return app


def create_app_from_env() -> FastAPI:
    value = os.environ.get("BIZHUB_GENERIC_DATABASE_PATH", "runtime/generic-kernel-smoke.sqlite")
    return create_app(Path(value))
