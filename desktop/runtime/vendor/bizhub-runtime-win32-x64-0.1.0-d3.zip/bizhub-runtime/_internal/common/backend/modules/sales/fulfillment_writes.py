"""销售发货流水写入原语：在调用方借出的连接、同一个事务里用裸 SQL 写标准表（``order_schema.SALES_FULFILLMENTS``）。

页面、Agent、单据内核都经各自 Owner 走到这里；这里只管"这笔能不能记、记成什么样"，不提交、不开事务：

- 种类只能是发货或退货，数量必须为正；对应的库存流水由调用方给（可为空）。
- 明细的已发 / 已退累计、单头状态由调用方按自己的规则改，这里只落流水行。

"明细"的事实（是哪张明细、什么单位）由调用方按自己的表提供。
"""

from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from datetime import UTC, datetime
from decimal import Decimal, InvalidOperation
from typing import Any, Mapping

from backend.modules.trade_core.public import decimal_sum

from .order_schema import FULFILLMENTS, FULFILLMENT_KINDS
from .order_writes import SalesRecordWriter


class FulfillmentWriteError(RuntimeError):
    def __init__(self, code: str, message: str = ""):
        super().__init__(f"{code}: {message}" if message else code)
        self.code = code
        self.message = message


@dataclass(frozen=True)
class Provenance:
    source_kind: str = "management_confirmed"
    source_ref: str = ""
    notes: str = ""


def _stamp(value: datetime | None = None) -> str:
    # Same text the customer's ORM stores for a naive DateTime.
    return (value or datetime.now(UTC).replace(tzinfo=None)).strftime("%Y-%m-%d %H:%M:%S.%f")


def record_fulfillment(
    connection: sqlite3.Connection,
    *,
    sales_order_id: int,
    kind: str,
    quantity: Any,
    quantity_unit_id: int | None,
    event_id: int | None,
    business_date: str | None,
    provenance: Provenance = Provenance(),
    extra: Mapping[str, Any] | None = None,
    now: datetime | None = None,
) -> int:
    """记一条发货或退货流水，返回行编号。``extra`` 是调用方扩展列的取值（如通用小库的文字键）。"""

    if kind not in FULFILLMENT_KINDS:
        raise FulfillmentWriteError("sales_fulfillment_kind_invalid", str(kind))
    try:
        amount = Decimal(str(quantity))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise FulfillmentWriteError("sales_fulfillment_quantity_invalid", str(quantity)) from exc
    if not amount.is_finite() or amount <= 0:
        raise FulfillmentWriteError("sales_fulfillment_quantity_must_be_positive", str(quantity))
    values = {
        "sales_order_id": int(sales_order_id), "fulfillment_kind": kind, "quantity": format(amount, "f"),
        "quantity_unit_id": None if quantity_unit_id is None else int(quantity_unit_id),
        "event_id": None if event_id is None else int(event_id), "business_date": business_date,
        "source_kind": provenance.source_kind, "source_ref": provenance.source_ref, "notes": provenance.notes,
        "created_at": _stamp(now), **dict(extra or {}),
    }
    cursor = connection.execute(
        f"INSERT INTO {FULFILLMENTS} ({', '.join(values)}) VALUES ({', '.join('?' for _ in values)})",
        tuple(values.values()),
    )
    return int(cursor.lastrowid)


LINE_QUANTITY_FIELDS = ("fulfilled_quantity", "returned_quantity")
_LINE_WRITER = SalesRecordWriter("line")


def set_line_quantity(connection: sqlite3.Connection, *, line_where: tuple[str, Any], field: str, quantity: Any) -> None:
    """明细行的已发 / 已退累计列的唯一写入点：按 ``line_where``（列名, 值）定位一行，置为 ``quantity``。"""

    if field not in LINE_QUANTITY_FIELDS:
        raise FulfillmentWriteError("sales_line_quantity_field_invalid", str(field))
    try:
        amount = Decimal(str(quantity))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise FulfillmentWriteError("sales_line_quantity_invalid", str(quantity)) from exc
    if not amount.is_finite() or amount < 0:
        raise FulfillmentWriteError("sales_line_quantity_must_not_be_negative", str(quantity))
    column, key = line_where
    row = connection.execute(f"SELECT id FROM sales_orders WHERE {column}=?", (key,)).fetchone()
    if row is None:
        raise FulfillmentWriteError("sales_line_not_found", f"{column}={key}")
    _LINE_WRITER.materialize(connection, int(row[0]), {field: format(amount, "f")})


def accumulate_line_quantity(connection: sqlite3.Connection, *, line_where: tuple[str, Any], field: str, quantity: Any) -> str:
    """在现值上累加后置数，返回新累计值的文本。"""

    column, key = line_where
    if field not in LINE_QUANTITY_FIELDS:
        raise FulfillmentWriteError("sales_line_quantity_field_invalid", str(field))
    current = connection.execute(f"SELECT {field} FROM sales_orders WHERE {column}=?", (key,)).fetchone()
    if current is None:
        raise FulfillmentWriteError("sales_line_not_found", f"{column}={key}")
    total = decimal_sum((Decimal(str(current[0] or 0)), Decimal(str(quantity))))  # 不受调用方 Decimal 精度上下文影响
    set_line_quantity(connection, line_where=line_where, field=field, quantity=total)
    return format(total, "f")


__all__ = ["FulfillmentWriteError", "LINE_QUANTITY_FIELDS", "Provenance", "accumulate_line_quantity", "record_fulfillment", "set_line_quantity"]
