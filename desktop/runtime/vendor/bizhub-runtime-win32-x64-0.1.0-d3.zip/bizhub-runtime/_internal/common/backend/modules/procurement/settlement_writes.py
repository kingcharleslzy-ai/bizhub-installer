"""采购结算写入原语：在调用方借出的连接、同一个事务里用裸 SQL 写标准表（``settlement_schema``）。

页面、Agent、单据内核都经各自 Owner 走到这里；这里只管“这笔能不能记、记成什么样”，
不提交、不开事务。规则和首家客户生产上一直用的一致：

- 发票、付款都分到采购行；同一张发票（付款）对同一采购行（同一票面行）只能有一条有效分摊，
  同额重放返回原分摊（零写入），异额必须走更正（先冲销再记）。
- 发票按带符号金额分摊：红票分摊为负；单张发票按绝对值累计不超票面。
- 正向分摊按采购行核额度：采购行净开票额 + 本笔 ≤ 采购行金额（金额未定的采购行不核）。
- 付款分摊为正，累计不超付款额；付款可以不分摊、按供应商记。
- 冲销只改状态并留下冲销人、冲销时间，不删行。

“采购行”的事实（供应方、金额、供应方是否已确认）由调用方按自己的采购行表提供
（第 7 步采购单统一前，各部署的采购行表不同）。
"""

from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from datetime import UTC, date, datetime
from decimal import Decimal
from typing import Callable, Mapping

from backend.modules.trade_core.public import allocation_exceeded


class SettlementWriteError(RuntimeError):
    def __init__(self, code: str, message: str = "", *, risk_code: str | None = None):
        super().__init__(f"{code}: {message}" if message else code)
        self.code = code
        self.message = message
        # 写入程序自报的审核原因，接住异常转成结果的地方原样带出（不再按错误字眼归类）。
        self.risk_code = risk_code


@dataclass(frozen=True)
class LineFacts:
    """分摊目标采购行的事实。``total_amount`` 为空表示采购行金额未定：
    ``amount_required`` 为真时拒绝正向开票分摊，否则不核采购额度。"""

    procurement_id: int
    supplier_party_id: int | None
    total_amount: Decimal | None
    supplier_resolved: bool = True
    amount_required: bool = False


LineFactsReader = Callable[[sqlite3.Connection, int], "LineFacts | None"]


@dataclass(frozen=True)
class Provenance:
    """谁、凭什么记的这一笔。"""

    source_kind: str = "management_confirmed"
    source_ref: str = ""
    notes: str = ""
    actor: str = "management"


@dataclass(frozen=True)
class AllocationResult:
    allocation_id: int
    allocated_amount: Decimal
    deduplicated: bool


def utc_timestamp() -> str:
    """与生产库现有行同一种存法：无时区的 UTC 时间，带微秒。"""

    return datetime.now(UTC).replace(tzinfo=None).isoformat(sep=" ", timespec="microseconds")


def _amount(value: object) -> Decimal:
    return Decimal(str(value if value is not None else 0))


def _row(connection: sqlite3.Connection, sql: str, params: tuple) -> sqlite3.Row | None:
    # 调用方的连接按列名取行（通用库连接与客户会话借出的连接都是）。
    return connection.execute(sql, params).fetchone()


def _sum(connection: sqlite3.Connection, sql: str, params: tuple) -> Decimal:
    rows = connection.execute(sql, params).fetchall()
    return sum((_amount(row[0]) for row in rows), Decimal("0"))


def invoice_allocated(connection: sqlite3.Connection, invoice_id: int) -> Decimal:
    return _sum(connection, "SELECT allocated_amount FROM procurement_invoice_allocations "
                            "WHERE invoice_id=? AND status='confirmed'", (int(invoice_id),))


def payment_allocated(connection: sqlite3.Connection, payment_id: int) -> Decimal:
    return _sum(connection, "SELECT allocated_amount FROM procurement_payment_allocations "
                            "WHERE payment_id=? AND status='confirmed'", (int(payment_id),))


def line_net_invoiced(connection: sqlite3.Connection, procurement_id: int) -> Decimal:
    """采购行上仍有效的发票分摊净额（红票为负；已冲销的发票不算）。"""

    return _sum(connection, """SELECT a.allocated_amount FROM procurement_invoice_allocations a
                               JOIN procurement_invoices i ON i.id = a.invoice_id
                               WHERE a.procurement_id=? AND a.status='confirmed' AND i.status='confirmed'""",
                (int(procurement_id),))


def currency_code(value: str = "CNY") -> str:
    if value == "":
        value = "CNY"
    if len(value) != 3 or not value.isascii() or not value.isalpha() or value != value.upper():
        raise SettlementWriteError("procurement_currency_invalid", value, risk_code="numeric_closure_failed")
    return value


def insert_invoice(
    connection: sqlite3.Connection,
    *,
    invoice_number: str,
    normalized_invoice_number: str,
    supplier_party_id: int,
    invoice_date: str,
    total_amount: Decimal,
    source_key: str,
    provenance: Provenance,
    supplier_legal_name: str = "",
    supplier_tax_id: str = "",
    buyer_legal_name: str = "",
    buyer_tax_id: str = "",
    positive_flag: str | None = None,
    currency: str = "CNY",
    now: str | None = None,
) -> int:
    if total_amount == 0:
        raise SettlementWriteError("invoice_amount_zero")
    stamp = now or utc_timestamp()
    cursor = connection.execute(
        """INSERT INTO procurement_invoices (
               invoice_number, normalized_invoice_number, supplier_party_id, supplier_legal_name, supplier_tax_id,
               buyer_legal_name, buyer_tax_id, invoice_date, total_amount, currency, positive_flag, source_key,
               status, source_kind, source_ref, notes, confirmed_by, confirmed_at, reversed_by, reversed_at, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'confirmed', ?, ?, ?, ?, ?, '', NULL, ?)""",
        (invoice_number, normalized_invoice_number, int(supplier_party_id), supplier_legal_name, supplier_tax_id,
         buyer_legal_name, buyer_tax_id, invoice_date, str(total_amount), currency_code(currency),
         positive_flag if positive_flag is not None else ("positive" if total_amount > 0 else "negative"),
         source_key, provenance.source_kind, provenance.source_ref,
         provenance.notes, provenance.actor, stamp, stamp),
    )
    return int(cursor.lastrowid)


def insert_payment(
    connection: sqlite3.Connection,
    *,
    supplier_party_id: int,
    business_date: str,
    amount: Decimal,
    payment_method: str,
    reference_no: str,
    source_key: str,
    provenance: Provenance,
    payer_legal_name: str = "",
    payer_tax_id: str = "",
    currency: str = "CNY",
    now: str | None = None,
) -> int:
    if amount <= 0:
        raise SettlementWriteError("payment_amount_not_positive")
    if reference_no and _row(
        connection,
        "SELECT id FROM procurement_payments WHERE supplier_party_id=? AND reference_no=? AND status='confirmed'",
        (int(supplier_party_id), reference_no),
    ):
        raise SettlementWriteError("payment_reference_conflict", reference_no)
    stamp = now or utc_timestamp()
    cursor = connection.execute(
        """INSERT INTO procurement_payments (
               supplier_party_id, payer_legal_name, payer_tax_id, business_date, amount, currency, payment_method,
               reference_no, source_key, status, source_kind, source_ref, notes, confirmed_by, confirmed_at,
               reversed_by, reversed_at, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'confirmed', ?, ?, ?, ?, ?, '', NULL, ?)""",
        (int(supplier_party_id), payer_legal_name, payer_tax_id, business_date, str(amount), currency_code(currency), payment_method,
         reference_no, source_key, provenance.source_kind, provenance.source_ref, provenance.notes, provenance.actor,
         stamp, stamp),
    )
    return int(cursor.lastrowid)



class SettlementRecordWriter:
    """Physical document-row port; the document kernel owns identity and lifecycle.

    Insert delegates to the same primitives as API/Agent writes. Amendments patch
    only supplied standard columns, retaining provenance and timestamps otherwise.
    No transaction or commit is opened here.
    """

    def __init__(self, kind: str):
        from .settlement_schema import PROCUREMENT_INVOICES, PROCUREMENT_PAYMENTS

        if kind not in {"invoice", "payment"}:
            raise ValueError("settlement_record_kind_invalid")
        self.kind = kind
        self.schema = PROCUREMENT_INVOICES if kind == "invoice" else PROCUREMENT_PAYMENTS

    def materialize(self, connection: sqlite3.Connection, row_id: int | None, values: Mapping[str, object]) -> int:
        values = dict(values)
        allowed = {column.name for column in self.schema.columns} - {"id"}
        if set(values) - allowed:
            raise SettlementWriteError("settlement_record_column_invalid")
        if row_id is None:
            # ORM inserts apply defaults to explicit None; retain that contract.
            for column in self.schema.columns:
                if column.name in values and values[column.name] is None and not column.nullable:
                    if column.type.startswith(("VARCHAR", "TEXT")):
                        values[column.name] = column.server_default or ""
            provenance = Provenance(
                source_kind=str(values.get("source_kind", "document_kernel")),
                source_ref=str(values.get("source_ref", "")),
                notes=str(values.get("notes", "")), actor=str(values.get("confirmed_by", "management")),
            )
            common = dict(supplier_party_id=int(values["supplier_party_id"]),
                          source_key=str(values.get("source_key", "")), provenance=provenance,
                          currency=str(values.get("currency", "CNY")))
            if self.kind == "invoice":
                row_id = insert_invoice(
                    connection, **common, invoice_number=str(values.get("invoice_number") or ""),
                    normalized_invoice_number=str(values["normalized_invoice_number"]),
                    invoice_date=str(values["invoice_date"]), total_amount=_amount(values["total_amount"]),
                    positive_flag=values.get("positive_flag"),
                )
            else:
                row_id = insert_payment(
                    connection, **common, business_date=str(values["business_date"]),
                    amount=_amount(values["amount"]), payment_method=str(values.get("payment_method") or "unknown"),
                    reference_no=str(values.get("reference_no") or ""),
                )
        if values:
            names = sorted(values)
            params = tuple(
                values[name].isoformat() if isinstance(values[name], (date, datetime))
                else str(values[name]) if isinstance(values[name], Decimal) else values[name]
                for name in names
            )
            cursor = connection.execute(
                f'UPDATE "{self.schema.name}" SET ' + ", ".join(f'"{name}"=?' for name in names) + " WHERE id=?",
                (*params, int(row_id)),
            )
            if cursor.rowcount != 1:
                raise SettlementWriteError("settlement_record_not_found")
        return int(row_id)

def _line(connection: sqlite3.Connection, read_line: LineFactsReader, procurement_id: int) -> LineFacts:
    facts = read_line(connection, int(procurement_id))
    if facts is None:
        raise SettlementWriteError("procurement_not_found", str(procurement_id))
    return facts


def check_invoice_allocation(
    connection: sqlite3.Connection,
    *,
    invoice_id: int | None,
    invoice_total: Decimal,
    procurement_id: int,
    amount: Decimal,
    read_line: LineFactsReader,
    invoice_line_key: str = "",
    invoice_allocated_amount: Decimal | None = None,
    line_net_amount: Decimal | None = None,
) -> int | None:
    """发票分摊能不能记（预览与写入共用）：同键已有同额分摊返回它的编号，不能记就报错。

    预览一批分摊时可传入“本批已叠加的拟增量”（``invoice_allocated_amount`` / ``line_net_amount``），
    不传就读库里现在的正式事实。供应方核对由调用方先做。
    """

    if amount == 0 or (amount > 0) != (invoice_total > 0):
        raise SettlementWriteError("invoice_allocation_sign_conflict", str(amount))
    if invoice_id is not None:
        existing = _row(
            connection,
            """SELECT id, allocated_amount FROM procurement_invoice_allocations
               WHERE invoice_id=? AND procurement_id=? AND invoice_line_key=? AND status='confirmed'""",
            (int(invoice_id), int(procurement_id), invoice_line_key),
        )
        if existing is not None:
            if _amount(existing["allocated_amount"]) != amount:
                raise SettlementWriteError("invoice_allocation_already_exists", str(existing["id"]))
            return int(existing["id"])
    if amount > 0:
        line = _line(connection, read_line, procurement_id)
        if line.total_amount is None or line.total_amount <= 0:
            if line.amount_required:
                code = "invalid" if line.total_amount is None else "must_be_positive"
                raise SettlementWriteError(f"procurement_total_amount_{code}", str(procurement_id))
        else:
            net = line_net_invoiced(connection, procurement_id) if line_net_amount is None else line_net_amount
            if net + amount > line.total_amount:
                raise SettlementWriteError("procurement_invoice_overallocated", str(procurement_id))
    if invoice_allocated_amount is None:
        invoice_allocated_amount = invoice_allocated(connection, invoice_id) if invoice_id is not None else Decimal("0")
    # 同一张发票的分摊同号，按绝对值核累计不超票面。
    if allocation_exceeded(abs(invoice_total), abs(invoice_allocated_amount), abs(amount)):
        raise SettlementWriteError("invoice_overallocated", str(invoice_id))
    return None


def allocate_invoice(
    connection: sqlite3.Connection,
    *,
    invoice_id: int,
    procurement_id: int,
    amount: Decimal,
    read_line: LineFactsReader,
    provenance: Provenance,
    invoice_line_key: str = "",
    allow_unresolved_supplier: bool = False,
    before_new_row: Callable[[], None] | None = None,
    now: str | None = None,
) -> AllocationResult:
    """记一条发票分摊。``before_new_row`` 只在真要新增时调用（客户专属的拦截放这里，同额重放不受影响）。"""

    invoice = _row(connection, "SELECT * FROM procurement_invoices WHERE id=?", (int(invoice_id),))
    if invoice is None or invoice["status"] != "confirmed":
        raise SettlementWriteError("invoice_not_confirmed", str(invoice_id))
    line = _line(connection, read_line, procurement_id)
    if line.supplier_party_id is None or (not line.supplier_resolved and not allow_unresolved_supplier):
        raise SettlementWriteError("procurement_supplier_unresolved", str(procurement_id))
    if int(line.supplier_party_id) != int(invoice["supplier_party_id"]):
        raise SettlementWriteError("invoice_procurement_supplier_conflict", str(procurement_id))
    existing = check_invoice_allocation(
        connection, invoice_id=int(invoice_id), invoice_total=_amount(invoice["total_amount"]),
        procurement_id=int(procurement_id), amount=amount, read_line=read_line, invoice_line_key=invoice_line_key,
    )
    if existing is not None:
        return AllocationResult(existing, amount, True)
    if before_new_row is not None:
        before_new_row()
    stamp = now or utc_timestamp()
    cursor = connection.execute(
        """INSERT INTO procurement_invoice_allocations (
               invoice_id, procurement_id, invoice_line_key, allocated_amount, status, source_kind, source_ref, notes,
               confirmed_by, confirmed_at, reversed_by, reversed_at, created_at)
           VALUES (?, ?, ?, ?, 'confirmed', ?, ?, ?, ?, ?, '', NULL, ?)""",
        (int(invoice_id), int(procurement_id), invoice_line_key, str(amount), provenance.source_kind,
         provenance.source_ref, provenance.notes, provenance.actor, stamp, stamp),
    )
    return AllocationResult(int(cursor.lastrowid), amount, False)


def allocate_payment(
    connection: sqlite3.Connection,
    *,
    payment_id: int,
    procurement_id: int,
    amount: Decimal,
    read_line: LineFactsReader,
    provenance: Provenance,
    now: str | None = None,
) -> AllocationResult:
    if amount <= 0:
        raise SettlementWriteError("payment_allocation_not_positive", str(amount))
    payment = _row(connection, "SELECT * FROM procurement_payments WHERE id=?", (int(payment_id),))
    if payment is None or payment["status"] != "confirmed":
        raise SettlementWriteError("payment_not_confirmed", str(payment_id))
    line = _line(connection, read_line, procurement_id)
    if line.supplier_party_id is None or not line.supplier_resolved:
        raise SettlementWriteError("procurement_supplier_unresolved", str(procurement_id))
    if int(line.supplier_party_id) != int(payment["supplier_party_id"]):
        raise SettlementWriteError("payment_procurement_supplier_conflict", str(procurement_id))
    existing = _row(
        connection,
        """SELECT id, allocated_amount FROM procurement_payment_allocations
           WHERE payment_id=? AND procurement_id=? AND status='confirmed'""",
        (int(payment_id), int(procurement_id)),
    )
    if existing is not None:
        if _amount(existing["allocated_amount"]) != amount:
            raise SettlementWriteError("payment_allocation_already_exists", str(existing["id"]))
        return AllocationResult(int(existing["id"]), amount, True)
    if allocation_exceeded(_amount(payment["amount"]), payment_allocated(connection, payment_id), amount):
        raise SettlementWriteError("payment_overallocated", str(payment_id))
    stamp = now or utc_timestamp()
    cursor = connection.execute(
        """INSERT INTO procurement_payment_allocations (
               payment_id, procurement_id, allocated_amount, status, source_kind, source_ref, notes,
               confirmed_by, confirmed_at, reversed_by, reversed_at, created_at)
           VALUES (?, ?, ?, 'confirmed', ?, ?, ?, ?, ?, '', NULL, ?)""",
        (int(payment_id), int(procurement_id), str(amount), provenance.source_kind, provenance.source_ref,
         provenance.notes, provenance.actor, stamp, stamp),
    )
    return AllocationResult(int(cursor.lastrowid), amount, False)


_ALLOCATION_TABLES = {
    "invoice": ("procurement_invoice_allocations", "invoice_id"),
    "payment": ("procurement_payment_allocations", "payment_id"),
}


def reverse_allocation(
    connection: sqlite3.Connection,
    kind: str,
    *,
    owner_id: int,
    allocation_id: int,
    reversed_by: str,
    notes: str = "",
    now: str | None = None,
) -> bool:
    """冲销一条分摊；已冲销的原样返回 False（零写入）。"""

    table, owner_column = _ALLOCATION_TABLES[kind]
    row = _row(connection, f"SELECT {owner_column} AS owner_id, status, notes FROM {table} WHERE id=?",
               (int(allocation_id),))
    if row is None:
        raise SettlementWriteError(f"{kind}_allocation_not_found", str(allocation_id))
    if int(row["owner_id"]) != int(owner_id):
        raise SettlementWriteError(f"{kind}_allocation_owner_conflict", str(allocation_id))
    if row["status"] == "reversed":
        return False
    merged_notes = "；".join(value for value in (str(row["notes"] or ""), notes) if value)
    connection.execute(
        f"UPDATE {table} SET status='reversed', reversed_by=?, reversed_at=?, notes=? WHERE id=?",
        (reversed_by or "management", now or utc_timestamp(), merged_notes, int(allocation_id)),
    )
    return True


def record_date_revision(
    connection: sqlite3.Connection,
    *,
    before_date: str,
    after_date: str,
    editor: str,
    notes: str = "",
    invoice_id: int | None = None,
    payment_id: int | None = None,
    now: str | None = None,
) -> int | None:
    """结算日期改动留一条修订记录（只追加）；改前改后相同不记。"""

    if (invoice_id is None) == (payment_id is None):
        raise SettlementWriteError("date_revision_owner_invalid")
    if before_date == after_date:
        return None
    cursor = connection.execute(
        """INSERT INTO procurement_settlement_date_revisions
               (invoice_id, payment_id, before_date, after_date, editor, notes, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (invoice_id, payment_id, before_date, after_date, editor, notes, now or utc_timestamp()),
    )
    return int(cursor.lastrowid)


__all__ = [
    "AllocationResult",
    "LineFacts",
    "LineFactsReader",
    "Provenance",
    "SettlementWriteError",
    "allocate_invoice",
    "allocate_payment",
    "check_invoice_allocation",
    "insert_invoice",
    "insert_payment",
    "invoice_allocated",
    "line_net_invoiced",
    "payment_allocated",
    "record_date_revision",
    "reverse_allocation",
    "utc_timestamp",
]
