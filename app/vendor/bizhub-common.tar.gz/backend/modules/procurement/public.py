"""Stable facade for generic procurement actions and reads."""

from __future__ import annotations

from backend.kernel.profile_registry import StorageTarget, read_storage, storage_connect

import sqlite3
from pathlib import Path
from datetime import date
from typing import Any

from .contracts import (ProcurementCommand, ProcurementLine, ProcurementPreview, ProcurementReceiptCommand,
                        ProcurementReceiptLine, ProcurementReceiptAllocation, ProcurementReceiptPreview,
                        ProcurementTermsCommand, ProcurementInvoiceCommand, ProcurementInvoiceLine,
                        ProcurementInvoiceMatch, ProcurementDocumentPreview, ProcurementPaymentCommand,
                        ProcurementPaymentAllocation, ProcurementPaymentPreview)
from .owner import (_money, ProcurementOwnerError, apply_preview, preview_action, preview_receipt_action,
                    apply_receipt_preview, read_receipt_document, read_action, preview_document_action,
                    apply_document_preview, read_invoice, read_terms, read_three_way, preview_payment_action,
                    apply_payment_preview, read_payment, read_payables, read_payment_balances)


def _connect(path: Path) -> sqlite3.Connection:
    connection = storage_connect(f"file:{path}?mode=ro", uri=True)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA query_only=ON")
    return connection


def _connect_snapshot(path: Path) -> sqlite3.Connection:
    connection = _connect(path)
    connection.execute("BEGIN")
    return connection


def list_orders(storage: StorageTarget, *, limit: int = 100) -> list[dict[str, Any]]:
    with read_storage(storage, _connect) as connection:
        return [
            dict(row)
            for row in connection.execute(
                "SELECT * FROM procurement_orders ORDER BY ordered_at DESC, order_id DESC LIMIT ?",
                (max(1, min(int(limit), 500)),),
            )
        ]


def list_receipt_documents(storage: StorageTarget, *, query: str = "", offset: int = 0, limit: int = 100) -> dict[str, Any]:
    limit = max(1, min(int(limit), 500))
    offset = max(0, int(offset))
    with read_storage(storage, _connect_snapshot) as connection:
        rows = connection.execute(
            """SELECT * FROM procurement_receipt_documents
               WHERE instr(document_id, ?) OR instr(source_identity, ?) OR instr(supplier_party_id, ?)
               ORDER BY occurred_at DESC, document_id DESC LIMIT ? OFFSET ?""",
            (query, query, query, limit + 1, offset)).fetchall()
        from backend.modules.trade_core.public import reversal_documents
        voided_ids = {row["command"]["target_id"] for row in reversal_documents(connection, "procurement")
                      if row["status"] == "reversed" and row["command"]["target_kind"] == "receipt_document"}
    return {"items": [{**dict(row), **({"status": "voided"} if row["document_id"] in voided_ids else {})} for row in rows[:limit]],
            "next_offset": offset + limit if len(rows) > limit else None}


def _list_financial_documents(storage: StorageTarget, *, kind: str, query: str, offset: int, limit: int,
                              supplier_party_id: int | None, external_number: str, external_number_contains: str,
                              amount: str, date_from: str, date_to: str) -> dict[str, Any]:
    # Only these two fixed projections may enter the HTTP and model read surfaces.
    if kind == "invoice":
        table, id_field, number_field, amount_field, day_field = (
            "procurement_invoices", "invoice_id", "external_invoice_number", "total_amount", "business_date")
        columns = "invoice_id, supplier_party_id, external_invoice_number, currency, business_date, tax_basis, total_amount, net_amount, tax_amount, tax_rate"
    else:
        table, id_field, number_field, amount_field, day_field = (
            "procurement_payments", "payment_id", "external_reference", "amount", "paid_date")
        columns = "payment_id, supplier_party_id, currency, amount, channel, external_reference, paid_at, paid_date, business_at"
    for value in (date_from, date_to):
        if value:
            try:
                if date.fromisoformat(value).isoformat() != value:
                    raise ValueError("use YYYY-MM-DD")
            except ValueError as exc:
                raise ProcurementOwnerError("procurement_filter_date_invalid", value) from exc
    if date_from and date_to and date_from > date_to:
        raise ProcurementOwnerError("procurement_filter_date_invalid", "date_from exceeds date_to")
    clauses = [f"(instr({id_field}, ?) OR instr({number_field}, ?) OR instr(supplier_party_id, ?))"]
    values = [query, query, query]
    for value, expression in ((supplier_party_id, "supplier_party_id=?"),
                              (external_number.strip(), f"{number_field}=?"),
                              (external_number_contains, f"instr({number_field}, ?)"),
                              (format(_money(amount), "f") if amount else "", f"{amount_field}=?"),
                              (date_from, f"{day_field}>=?"), (date_to, f"{day_field}<=?")):
        if value:
            clauses.append(expression)
            values.append(value)
    limit, offset = max(1, min(int(limit), 500)), max(0, int(offset))
    with read_storage(storage, _connect) as connection:
        rows = connection.execute(f"SELECT {columns} FROM {table} WHERE {' AND '.join(clauses)} "
                                  f"ORDER BY {day_field} DESC, {id_field} DESC LIMIT ? OFFSET ?",
                                  (*values, limit + 1, offset)).fetchall()
    return {"items": [dict(row) for row in rows[:limit]], "next_offset": offset + limit if len(rows) > limit else None}


def list_invoices(storage: StorageTarget, *, query: str = "", offset: int = 0, limit: int = 100,
                  supplier_party_id: int | None = None, external_number: str = "", external_number_contains: str = "",
                  amount: str = "", date_from: str = "", date_to: str = "") -> dict[str, Any]:
    return _list_financial_documents(storage, kind="invoice", query=query, offset=offset, limit=limit,
        supplier_party_id=supplier_party_id, external_number=external_number, external_number_contains=external_number_contains,
        amount=amount, date_from=date_from, date_to=date_to)


__all__ = [
    "ProcurementPaymentCommand", "ProcurementPaymentAllocation", "ProcurementPaymentPreview",
    "preview_payment_action", "apply_payment_preview", "read_payment", "read_payables", "read_payment_balances", "list_payments",
    "ProcurementTermsCommand", "ProcurementInvoiceCommand", "ProcurementInvoiceLine", "ProcurementInvoiceMatch", "ProcurementDocumentPreview",
    "preview_document_action", "apply_document_preview", "read_invoice", "read_terms", "read_three_way", "list_invoices",
    "ProcurementReceiptCommand", "ProcurementReceiptLine", "ProcurementReceiptAllocation", "ProcurementReceiptPreview",
    "preview_receipt_action", "apply_receipt_preview", "read_receipt_document", "read_action", "list_receipt_documents",
    "ProcurementCommand",
    "ProcurementLine",
    "ProcurementOwnerError",
    "ProcurementPreview",
    "apply_preview",
    "list_orders",
    "preview_action",
]


def list_payments(storage: StorageTarget, *, query: str = "", offset: int = 0, limit: int = 100,
                  supplier_party_id: int | None = None, external_number: str = "", external_number_contains: str = "",
                  amount: str = "", date_from: str = "", date_to: str = "") -> dict[str, Any]:
    return _list_financial_documents(storage, kind="payment", query=query, offset=offset, limit=limit,
        supplier_party_id=supplier_party_id, external_number=external_number, external_number_contains=external_number_contains,
        amount=amount, date_from=date_from, date_to=date_to)


from .owner import (
    preview_action_in_transaction,
    preview_receipt_action_in_transaction,
    preview_document_action_in_transaction,
    preview_payment_action_in_transaction,
    apply_preview_in_transaction,
    apply_receipt_preview_in_transaction,
    apply_document_preview_in_transaction,
    apply_payment_preview_in_transaction,
    read_action_in_transaction
)

__all__ += ['preview_action_in_transaction', 'preview_receipt_action_in_transaction', 'preview_document_action_in_transaction', 'preview_payment_action_in_transaction', 'apply_preview_in_transaction', 'apply_receipt_preview_in_transaction', 'apply_document_preview_in_transaction', 'apply_payment_preview_in_transaction', 'read_action_in_transaction']

from .owner import preview_reversal_action, apply_reversal_preview, list_reversals, read_reversal
from backend.modules.trade_core.public import TradeReversalCommand, TradeReversalPreview
__all__ += ["TradeReversalCommand", "TradeReversalPreview", "preview_reversal_action", "apply_reversal_preview", "list_reversals", "read_reversal"]

from .owner import party_reference_counts
__all__ += ["party_reference_counts"]
