"""Customer-neutral procurement module."""
