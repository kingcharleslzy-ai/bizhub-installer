"""Runtime manifest for customer-neutral procurement."""

from __future__ import annotations

from typing import Any


MODULE_ID = "procurement"
MODULE_VERSION = "0.1.0-cp4"
OWNER_REF = f"{MODULE_ID}:order-owner"
# Physical store of TABLES. Until this module's migration step moves it onto
# the customer database, its tables live in the standalone generic lineage.
STORAGE_LINEAGE = "generic-kernel"
TABLES = (
    "procurement_action_receipts",
    "procurement_audit_events",
    "procurement_order_lines",
    "procurement_orders",
    "procurement_receipts",
    "procurement_receipt_documents",
    "procurement_receipt_lines",
    "procurement_order_line_terms",
    "procurement_invoices",
    "procurement_invoice_lines",
    "procurement_invoice_matches",
    "procurement_payments",
    "procurement_payment_allocations",
)


# HTTP addresses the standalone generic app (generic.kernel_smoke) mounts for
# this module. They belong to that app; a customer Profile that enables this
# module gets no address until its own router declares one.
STANDALONE_APP_ROUTES = (
    {"surface_id": "generic_api", "method": "POST", "path": "/api/procurement/reversals/preview"},
    {"surface_id": "generic_api", "method": "POST", "path": "/api/procurement/reversals/apply"},
    {"surface_id": "generic_api", "method": "GET", "path": "/api/procurement/reversals"},
    {"surface_id": "generic_api", "method": "GET", "path": "/api/procurement/reversals/{reversal_id}"},

    {"surface_id": "generic_api", "method": "GET", "path": "/api/procurement/orders"},
    {"surface_id": "generic_api", "method": "POST", "path": "/api/procurement/receipts/preview"},
    {"surface_id": "generic_api", "method": "POST", "path": "/api/procurement/receipts/apply"},
    {"surface_id": "generic_api", "method": "GET", "path": "/api/procurement/receipts"},
    {"surface_id": "generic_api", "method": "GET", "path": "/api/procurement/receipts/{document_id}"},
    {"surface_id": "generic_api", "method": "GET", "path": "/api/procurement/actions/{action_id}"},
    {"surface_id": "generic_api", "method": "POST", "path": "/api/procurement/terms/preview"},
    {"surface_id": "generic_api", "method": "POST", "path": "/api/procurement/terms/apply"},
    {"surface_id": "generic_api", "method": "GET", "path": "/api/procurement/terms/{order_line_id}"},
    {"surface_id": "generic_api", "method": "POST", "path": "/api/procurement/invoices/preview"},
    {"surface_id": "generic_api", "method": "POST", "path": "/api/procurement/invoices/apply"},
    {"surface_id": "generic_api", "method": "GET", "path": "/api/procurement/invoices"},
    {"surface_id": "generic_api", "method": "GET", "path": "/api/procurement/invoices/{invoice_id}"},
    {"surface_id": "generic_api", "method": "GET", "path": "/api/procurement/order-lines/{order_line_id}/three-way"},
    {"surface_id": "generic_api", "method": "POST", "path": "/api/procurement/payments/preview"},
    {"surface_id": "generic_api", "method": "POST", "path": "/api/procurement/payments/apply"},
    {"surface_id": "generic_api", "method": "GET", "path": "/api/procurement/payments"},
    {"surface_id": "generic_api", "method": "GET", "path": "/api/procurement/payments/balances"},
    {"surface_id": "generic_api", "method": "GET", "path": "/api/procurement/payments/{payment_id}"},
    {"surface_id": "generic_api", "method": "GET", "path": "/api/procurement/payables"},
    {"surface_id": "generic_api", "method": "POST", "path": "/api/procurement/preview"},
    {"surface_id": "generic_api", "method": "POST", "path": "/api/procurement/apply"},
)


def procurement_module_manifest(
    source_commit: str,
    migrations: list[dict[str, Any]],
) -> dict[str, Any]:
    return {
        "schema_version": "bizhub.runtime-module-manifest.v1",
        "module_id": MODULE_ID,
        "module_version": MODULE_VERSION,
        "source": {"kind": "generic", "commit": source_commit},
        "package": {
            "backend": "backend.modules.procurement",
            "public_api": "backend.modules.procurement.public:preview_action",
            "frontend_entry": None,
        },
        "dependencies": [
            "kernel.profile_registry",
            "kernel.numeric",
            "trade_core",
            "master_data",
            "inventory",
        ],
        "capabilities": {
            "provides": ["procurement.order", "procurement.receiving", "procurement.receipt-inspection",
                         "procurement.terms", "procurement.invoice", "procurement.three-way-match", "procurement.payment"],
            "requires": [
                "kernel.profile-registry",
                "kernel.numeric",
                "trade.order-lifecycle",
                "master-data.identity",
                "inventory.movement",
            ],
        },
        "surfaces": {
            "routes": [],
            "ui_routes": [],
            "jobs": [],
            "mcp_tools": [],
            "actions": [{"action_id": "procurement.reversal", "record_types": ["generic_procurement_reversal"], "owner_ref": OWNER_REF}, {
                "action_id": "procurement.apply",
                "record_types": ["procurement_order", "procurement_receipt", "generic_procurement_terms", "generic_procurement_invoice", "generic_procurement_invoice_match", "generic_procurement_payment", "generic_procurement_payment_allocation"],
                "owner_ref": OWNER_REF,
            }],
            "migrations": migrations,
        },
        "ownership": {
            "record_types": [
                {"record_type": "generic_procurement_reversal", "owner_ref": OWNER_REF,
                 "canonical_writer": "backend/modules/procurement/owner.py:apply_reversal_preview"},
                {"record_type": "procurement_order", "owner_ref": OWNER_REF,
                 "canonical_writer": "backend/modules/procurement/owner.py:apply_preview"},
                {"record_type": "procurement_receipt", "owner_ref": OWNER_REF,
                 "canonical_writer": "backend/modules/procurement/owner.py:apply_preview"},
                {"record_type": "generic_procurement_terms", "owner_ref": OWNER_REF,
                 "canonical_writer": "backend/modules/procurement/owner.py:apply_document_preview"},
                {"record_type": "generic_procurement_invoice", "owner_ref": OWNER_REF,
                 "canonical_writer": "backend/modules/procurement/owner.py:apply_document_preview"},
                {"record_type": "generic_procurement_invoice_match", "owner_ref": OWNER_REF,
                 "canonical_writer": "backend/modules/procurement/owner.py:apply_document_preview"},
                {"record_type": "generic_procurement_payment", "owner_ref": OWNER_REF,
                 "canonical_writer": "backend/modules/procurement/owner.py:apply_payment_preview"},
                {"record_type": "generic_procurement_payment_allocation", "owner_ref": OWNER_REF,
                 "canonical_writer": "backend/modules/procurement/owner.py:apply_payment_preview"},
            ],
            "tables": [
                {"table": table, "lineage_id": STORAGE_LINEAGE, "mode": "formal_writer", "owner_ref": OWNER_REF}
                for table in TABLES
            ],
        },
        "activation": {"mode": "build-time", "retains_existing_data_when_disabled": True},
    }
