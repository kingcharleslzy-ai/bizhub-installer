"""Small customer-neutral helpers shared by procurement and sales."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta, timezone
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from typing import Any, Iterable, Sequence


class TradeRuleError(ValueError):
    """A customer-neutral trade invariant is not satisfied."""


def money(value: object) -> Decimal:
    """Two decimal places, ROUND_HALF_UP, as every money column stores it."""

    try:
        parsed = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise TradeRuleError("trade_amount_invalid") from exc
    if not parsed.is_finite():
        raise TradeRuleError("trade_amount_invalid")
    return parsed.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def _allocation_decimal(value: object, *, code: str) -> Decimal:
    if isinstance(value, Decimal):
        parsed = value
    else:
        try:
            parsed = Decimal(str(value))
        except (InvalidOperation, TypeError, ValueError) as exc:
            raise TradeRuleError(code) from exc
    if not parsed.is_finite() or parsed < 0:
        raise TradeRuleError(code)
    return parsed


def allocation_headroom(total: object, allocated: object, *, tolerance: object = 0) -> Decimal:
    """How much more one target still accepts: ``max(0, total + tolerance - allocated)``.

    The hard-stop reading of allocation (money may never be over-allocated):
    ``tolerance`` widens the target itself, it never lets the sum of
    allocations pass ``total + tolerance``.
    """

    total_d = _allocation_decimal(total, code="trade_total_invalid")
    allocated_d = _allocation_decimal(allocated, code="trade_allocated_invalid")
    tolerance_d = _allocation_decimal(tolerance, code="trade_tolerance_invalid")
    return max(Decimal("0"), total_d + tolerance_d - allocated_d)


def allocation_exceeded(
    total: object,
    allocated: object,
    requested: object,
    *,
    tolerance: object = 0,
) -> bool:
    """Whether ``requested`` moves more than the target still accepts.

    Same rule as :func:`allocation_headroom`: ``tolerance`` widens the
    target itself, it never lets the sum of allocations pass
    ``total + tolerance``.
    """

    requested_d = _allocation_decimal(requested, code="trade_requested_invalid")
    return requested_d > allocation_headroom(total, allocated, tolerance=tolerance)


def canonical_json(payload: object) -> bytes:
    return (
        json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        + "\n"
    ).encode()


def digest_json(payload: object) -> str:
    return hashlib.sha256(canonical_json(payload)).hexdigest()


def quantity_decimal(value: object, *, allow_zero: bool = False) -> Decimal:
    try:
        parsed = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise TradeRuleError("trade_quantity_invalid") from exc
    if not parsed.is_finite() or parsed < 0 or (not allow_zero and parsed == 0):
        raise TradeRuleError(
            "trade_quantity_must_be_nonnegative"
            if allow_zero
            else "trade_quantity_must_be_positive"
        )
    return parsed


def normalized_evidence_refs(values: Iterable[object]) -> tuple[str, ...]:
    refs = tuple(str(value).strip() for value in values)
    if not refs or any(not value for value in refs):
        raise TradeRuleError("trade_evidence_ref_required")
    if len(set(refs)) != len(refs):
        raise TradeRuleError("trade_evidence_ref_duplicate")
    return refs


def project_order_progress(
    *,
    ordered_quantity: object,
    completed_quantity: object,
    returned_quantity: object = 0,
    cancelled: bool = False,
) -> str:
    """Project a neutral order-line state without customer-specific policy."""

    ordered = quantity_decimal(ordered_quantity)
    completed = quantity_decimal(completed_quantity, allow_zero=True)
    returned = quantity_decimal(returned_quantity, allow_zero=True)
    if returned > completed:
        raise TradeRuleError("trade_return_exceeds_completed")
    if completed > ordered:
        raise TradeRuleError("trade_completion_exceeds_ordered")
    if cancelled:
        return "cancelled"
    if returned == completed and completed > 0:
        return "returned"
    if returned > 0:
        return "partially_returned"
    if completed == ordered:
        return "completed"
    if completed > 0:
        return "partial"
    return "open"


def aggregate_order_progress(states: Iterable[str]) -> str:
    values = tuple(states)
    if not values:
        raise TradeRuleError("trade_order_lines_required")
    if all(value == "cancelled" for value in values):
        return "cancelled"
    if all(value == "completed" for value in values):
        return "completed"
    if all(value == "returned" for value in values):
        return "returned"
    if any(value in {"partially_returned", "returned"} for value in values):
        return "partially_returned"
    if any(value in {"partial", "completed"} for value in values):
        return "partial"
    return "open"


@dataclass(frozen=True)
class FlowTally:
    """Upstream quantity (plan, dispatch) against what downstream settled."""

    planned: Decimal
    settled: Decimal
    fulfilled: Decimal
    over: Decimal
    cancelled: Decimal
    remaining: Decimal
    state: str


def tally_flow(
    planned: object,
    settled: Iterable[object] = (),
    *,
    cancelled: object = 0,
    tolerance: object = 0,
    shortfall_tolerance: object = 0,
) -> FlowTally:
    """remaining = planned - settled - cancelled (>= 0); over-settling completes.

    A remainder within ``tolerance`` (or, once something was settled, within
    ``shortfall_tolerance``) is zero.  States: open/partial/completed/cancelled.
    """

    plan = _lenient_decimal(planned) or Decimal("0")
    total = sum((_lenient_decimal(v) or Decimal("0") for v in settled), Decimal("0"))
    cancel = _lenient_decimal(cancelled) or Decimal("0")
    tol = _lenient_decimal(tolerance) or Decimal("0")
    shortfall = max(tol, _lenient_decimal(shortfall_tolerance) or Decimal("0"))
    remaining = max(Decimal("0"), plan - total - cancel)
    if remaining <= tol or (total > tol and remaining <= shortfall):
        remaining = Decimal("0")
    if remaining == 0:
        state = "cancelled" if cancel > 0 and total <= tol else "completed"
    else:
        state = "partial" if total > tol else "open"
    return FlowTally(
        planned=plan,
        settled=total,
        fulfilled=min(plan, total),
        over=max(Decimal("0"), total - plan),
        cancelled=cancel,
        remaining=remaining,
        state=state,
    )


def _lenient_decimal(value: Any) -> Decimal | None:
    if value in (None, ""):
        return None
    try:
        return Decimal(str(value).replace(",", "").strip())
    except (InvalidOperation, ValueError):
        return None


def _local_datetime(value: Any, *, tz: timezone, cutoff: time) -> datetime | None:
    if isinstance(value, datetime):
        parsed = value
    elif isinstance(value, date):
        parsed = datetime.combine(value, cutoff, tzinfo=tz)
    else:
        text = str(value or "").strip()
        if not text:
            return None
        if len(text) == 10:
            try:
                return datetime.combine(date.fromisoformat(text), cutoff, tzinfo=tz)
            except ValueError:
                return None
        try:
            parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
        except ValueError:
            return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=tz)
    return parsed.astimezone(tz)


def derive_due_at(
    received_at: Any,
    explicit_due_at: Any = None,
    *,
    tz: timezone,
    cutoff: time,
    same_day_source: str = "same_day_cutoff",
    next_day_source: str = "next_day_default",
    explicit_source: str = "explicit_order_due",
) -> tuple[datetime | None, str | None]:
    """Derive an order due moment from a business timezone and cutoff.

    ``tz`` is the business timezone and ``cutoff`` the daily cutoff time used
    both as the due-moment time-of-day and as the same-day/next-day boundary.
    ``same_day_source``/``next_day_source``/``explicit_source`` label the
    returned due-source. All customer policy is supplied by the caller.
    """

    explicit = _local_datetime(explicit_due_at, tz=tz, cutoff=cutoff)
    if explicit is not None:
        return explicit, explicit_source
    received = _local_datetime(received_at, tz=tz, cutoff=cutoff)
    if received is None:
        return None, None
    same_day = received.time() < cutoff
    due_date = received.date() if same_day else received.date() + timedelta(days=1)
    source = same_day_source if same_day else next_day_source
    return datetime.combine(due_date, cutoff, tzinfo=tz), source


def exact_duplicate_indexes(
    records: Iterable[dict[str, Any]],
    *,
    key_fields: Sequence[Sequence[str]],
    quantity_field: str = "quantity",
    date_positions: Sequence[int] = (),
) -> list[int]:
    """Return indexes of records that exactly duplicate an earlier record.

    ``key_fields`` lists, per key position, the field names that may carry that
    dimension (first non-empty wins). Positions listed in ``date_positions``
    are truncated to their first 10 characters. ``quantity_field`` names the
    field compared numerically after comma-stripping decimal normalization;
    text positions are stripped and casefolded. Records with any empty key
    component are skipped.
    """

    date_positions = set(date_positions)
    seen: set[tuple[str, ...]] = set()
    duplicates: list[int] = []
    for index, row in enumerate(records):
        quantity = _lenient_decimal(row.get(quantity_field))
        components: list[str] = []
        for position, fields in enumerate(key_fields):
            value: Any = None
            for field in fields:
                value = row.get(field)
                if value:
                    break
            text = str(value or "")
            if position in date_positions:
                components.append(text[:10])
            else:
                components.append(text.strip().casefold())
        key = (*components, str(quantity.normalize()) if quantity is not None else "")
        if not all(key):
            continue
        if key in seen:
            duplicates.append(index)
        else:
            seen.add(key)
    return duplicates


@dataclass(frozen=True)
class MatchResult:
    """One pairing attempt over candidates: only a unique survivor is a match.

    ``candidates`` carries the surviving candidates (after the key, date
    window and quantity filters) so a caller may run its own fallback
    heuristic on them instead of re-filtering.
    """

    status: str  # "matched" | "ambiguous" | "missing"
    item: Any = None
    candidates: tuple[Any, ...] = ()


def unique_match(
    candidates: Iterable[Any],
    *,
    key: Any,
    on_date: Any,
    before_days: int,
    after_days: int,
    quantity: object = None,
    tolerance: object = 0,
    quantity_of: Any,
    date_of: Any,
) -> MatchResult:
    """Pair one fact to the unique candidate that carries it (reconcile model).

    ``key`` is a predicate selecting the candidates that carry the same
    pairing key.  A candidate survives when its date (``date_of``) falls in
    ``[on_date - before_days, on_date + after_days]`` (day granularity; a
    datetime contributes its date) and, when ``quantity`` is not None, its
    quantity (``quantity_of``) differs from it by at most ``tolerance`` in
    absolute value (a candidate without a readable quantity never survives a
    quantity filter).  Exactly one survivor is ``matched``; none is
    ``missing``; more than one is ``ambiguous``.
    """

    if not isinstance(on_date, datetime) and not isinstance(on_date, date):
        raise TradeRuleError("trade_match_date_invalid")
    anchor = on_date.date() if isinstance(on_date, datetime) else on_date
    target = _lenient_decimal(quantity)
    allowed = _lenient_decimal(tolerance) or Decimal("0")
    survivors: list[Any] = []
    for item in candidates:
        if not key(item):
            continue
        item_date = date_of(item)
        if not isinstance(item_date, datetime) and not isinstance(item_date, date):
            continue
        item_day = item_date.date() if isinstance(item_date, datetime) else item_date
        if not (anchor - timedelta(days=int(before_days)) <= item_day <= anchor + timedelta(days=int(after_days))):
            continue
        if target is not None:
            item_quantity = _lenient_decimal(quantity_of(item))
            if item_quantity is None or abs(item_quantity - target) > allowed:
                continue
        survivors.append(item)
    if len(survivors) == 1:
        return MatchResult(status="matched", item=survivors[0], candidates=tuple(survivors))
    if not survivors:
        return MatchResult(status="missing", candidates=())
    return MatchResult(status="ambiguous", candidates=tuple(survivors))


__all__ = [
    "FlowTally",
    "MatchResult",
    "TradeRuleError",
    "aggregate_order_progress",
    "allocation_exceeded",
    "allocation_headroom",
    "canonical_json",
    "derive_due_at",
    "digest_json",
    "exact_duplicate_indexes",
    "money",
    "normalized_evidence_refs",
    "project_order_progress",
    "quantity_decimal",
    "tally_flow",
    "unique_match",
]
