"""Small stable contracts shared by master-data consumers."""

from __future__ import annotations

import hashlib
import json
from dataclasses import KW_ONLY, dataclass
from datetime import UTC, datetime
from typing import Any


RESOURCE_KINDS = ("party", "product", "unit", "location")
# 往来方、产品、单位用标准表的数字编号；库位暂用文字编号（第 6 步并入）。
NUMERIC_RESOURCE_KINDS = frozenset({"party", "product", "unit"})
# 每种主数据新建时可带的标准字段（库位的附加属性仍是自由 JSON）。
DRAFT_ATTRIBUTES = {
    "party": frozenset({"legal_name"}),
    "product": frozenset({"product_family"}),
    "unit": frozenset({"code", "dimension", "factor_to_base"}),
}


def canonical_json(payload: object) -> bytes:
    return (
        json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        + "\n"
    ).encode()


def digest_json(payload: object) -> str:
    return hashlib.sha256(canonical_json(payload)).hexdigest()


def storage_timestamp() -> str:
    """标准表时间列的写法：无时区 UTC、空格分隔、固定六位微秒（与客户库现有行一致）。"""

    return datetime.now(UTC).replace(tzinfo=None).strftime("%Y-%m-%d %H:%M:%S.%f")


def is_master_data_ref(value: object) -> bool:
    """往来方、产品、单位的引用必须是正整数编号。"""

    return isinstance(value, int) and not isinstance(value, bool) and value > 0


# 业务单据里指向往来方、产品、单位的字段：取值是数字编号，不是文字。
MASTER_DATA_REF_FIELDS = frozenset({
    "customer_party_id", "supplier_party_id", "product_id", "unit_id", "pricing_unit_id",
    "quantity_tolerance_unit_id", "conversion_from_unit_id", "conversion_to_unit_id", "original_unit_id",
})


def contract_scalar_ok(key: str, value: object, *, nullable: frozenset[str] | tuple[str, ...] = ()) -> bool:
    """单据命令的标量字段：主数据引用是正整数，其余是文字；声明可空的字段可为 null。"""

    if value is None:
        return key in nullable
    if key in MASTER_DATA_REF_FIELDS:
        return is_master_data_ref(value)
    return isinstance(value, str)


@dataclass(frozen=True)
class CatalogDraft:
    """新建一条主数据。往来方、产品、单位的编号由库分配；库位仍由调用方给文字编号。"""

    resource_kind: str
    canonical_name: str
    _: KW_ONLY
    location_id: str = ""
    source_id: str = ""
    external_id: str = ""
    alias: str = ""
    attributes: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "resource_kind": self.resource_kind,
            "canonical_name": self.canonical_name,
            "location_id": self.location_id,
            "source_id": self.source_id,
            "external_id": self.external_id,
            "alias": self.alias,
            "attributes": dict(self.attributes or {}),
        }


@dataclass(frozen=True)
class CatalogPreview:
    state_generation: str
    drafts: tuple[CatalogDraft, ...]
    preview_digest: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": "bizhub.master-data-catalog-preview.v2",
            "state_generation": self.state_generation,
            "drafts": [item.to_dict() for item in self.drafts],
            "preview_digest": self.preview_digest,
        }
