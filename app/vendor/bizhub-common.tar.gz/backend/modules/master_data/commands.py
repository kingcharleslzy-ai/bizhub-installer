"""主数据的人工处理：先预览、再写、写完读回来核对。

每种处理都分两段：``plan`` 只读现状，算出要做的几步（零步表示已经是这个样子）；
``apply`` 在同一个事务里重新算一遍，与预览一致才按步写，写完留一条处理记录并读回。

- 预览时记下当时整套主数据的状态；写的时候状态已经变了就拒收，免得一份旧请求把后来
  人工改过的东西改回去；
- 同样的处理做第二次，重新算出来零步，直接返回“零变化”，不写也不再留痕。

支持的处理：新建往来方 / 产品 / 单位，改往来方资料（改名、全称、别名、联系人、号码），
改产品 / 单位，记住一个写法，停用一个写法，补一个往来方角色。
"""

from __future__ import annotations

import json
import sqlite3
import uuid
from dataclasses import dataclass
from typing import Any, Callable, Iterable, Mapping

from backend.kernel.profile_registry import StorageTarget

from . import lookup, writes
from .contracts import digest_json
from .matching import normalize_identity
from .owner import _reading, _require_module_enabled, _writing
from .policy import DEFAULT_POLICY, MasterDataPolicy
from .public import MasterDataError
from .schema import STANDARD_TABLE_NAMES

CHANGE_KINDS = ("create_entity", "party_profile", "update_entity", "record_alias", "retire_alias", "ensure_role",
                "merge_party")
_AUDIT_TABLES = {"master_data_governance_actions"}


@dataclass(frozen=True)
class MasterDataChange:
    kind: str
    values: Mapping[str, Any]
    reviewer: str
    review_note: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {"kind": self.kind, "values": dict(self.values), "reviewer": self.reviewer, "review_note": self.review_note}

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "MasterDataChange":
        if not isinstance(payload, Mapping) or set(payload) - {"kind", "values", "reviewer", "review_note"}:
            raise TypeError("master-data change fields invalid")
        if not isinstance(payload.get("values"), Mapping):
            raise TypeError("master-data change values must be an object")
        return cls(str(payload["kind"]), dict(payload["values"]), str(payload.get("reviewer") or ""),
                   str(payload.get("review_note") or ""))


@dataclass(frozen=True)
class MasterDataChangePreview:
    change: MasterDataChange
    state_token: str
    plan: Mapping[str, Any]
    preview_digest: str

    def content(self) -> dict[str, Any]:
        return {"change": self.change.to_dict(), "state_token": self.state_token, "plan": dict(self.plan)}

    def to_dict(self) -> dict[str, Any]:
        return {**self.content(), "preview_digest": self.preview_digest}

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "MasterDataChangePreview":
        return cls(MasterDataChange.from_dict(payload["change"]), str(payload["state_token"]), dict(payload["plan"]),
                   str(payload["preview_digest"]))


def _state_token(connection: sqlite3.Connection, policy: MasterDataPolicy) -> str:
    tables = [name for name in STANDARD_TABLE_NAMES if name not in _AUDIT_TABLES]
    payload: dict[str, Any] = {
        name: [list(row) for row in connection.execute(f"SELECT * FROM {name} ORDER BY id")] for name in tables
    }
    if policy.protected_projection is not None:
        payload["protected_projection"] = policy.protected_projection(connection)
    return digest_json(payload)


def _text(values: Mapping[str, Any], key: str, limit: int) -> str:
    return " ".join(str(values.get(key) or "").split())[:limit]


# ---------------------------------------------------------------- planners


def _plan_create(connection: sqlite3.Connection, change: MasterDataChange, policy: MasterDataPolicy) -> dict[str, Any]:
    values = change.values
    domain = str(values.get("domain") or "").strip().casefold()
    name = _text(values, "canonical_name", 200)
    if domain not in {"party", "product", "unit"}:
        raise MasterDataError("master_data_resource_kind_invalid", domain)
    if not name:
        raise MasterDataError("master_data_identity_invalid", "canonical name is required")
    if domain == "party":
        roles = list(dict.fromkeys(str(item).strip() for item in values.get("roles") or [] if str(item).strip()))
        if not roles:
            raise MasterDataError("master_data_role_required", name)
        legal = _text(values, "legal_name", 240)
        existing = connection.execute("SELECT id, canonical_name FROM business_parties").fetchall()
        same = [int(row[0]) for row in existing if row[1] == name]
        if same:
            # 已有同名往来方且角色齐全：这次新建零变化。
            have = {row[0] for row in connection.execute(
                "SELECT role_key FROM business_party_roles WHERE party_id=?", (same[0],))}
            if set(roles) <= have:
                return {"ops": [], "entity": {"domain": "party", "id": same[0]}}
            raise MasterDataError("master_data_catalog_conflict", f"party:{name}")
        if any(normalize_identity(row[1]) == normalize_identity(name) for row in existing):
            raise MasterDataError("master_data_catalog_conflict", f"party:{name}")
        identity_values = [writes.normalize_party_identifier(item["identifier_type"], item["value"], policy)
                           for item in values.get("identifiers") or []]
        for wording in dict.fromkeys(item for item in (name, legal) if item):
            found = lookup.resolve(connection, "party", wording, context={"identity_values": identity_values},
                                   policy=policy)
            if found.status not in {"new", "invalid"}:
                refs = [found.entity_id] if found.entity_id is not None else list(found.candidate_ids)
                raise MasterDataError("master_data_party_exists", f"reuse party:{refs} ({found.status}/{found.method})")
        return {"ops": [{"op": "create_party", "canonical_name": name, "legal_name": legal, "roles": roles}],
                "entity": {"domain": "party", "id": None}}
    if domain == "product":
        family = _text(values, "product_family", 80)
        extensions = writes.extension_values("products", values.get("extensions"), policy)
        rows = writes._all(connection, "SELECT * FROM products")
        same = [row for row in rows if row["canonical_name"] == name]
        if same and (same[0]["product_family"], same[0]["status"]) == (family, "active") and all(
                same[0][key] == value for key, value in extensions.items()):
            return {"ops": [], "entity": {"domain": "product", "id": int(same[0]["id"])}}
        if same or any(normalize_identity(row["canonical_name"]) == normalize_identity(name) for row in rows):
            raise MasterDataError("master_data_catalog_conflict", f"product:{name}")
        return {"ops": [{"op": "create_product", "canonical_name": name, "product_family": family,
                         "extensions": extensions}], "entity": {"domain": "product", "id": None}}
    code = _text(values, "code", 40)
    dimension = _text(values, "dimension", 40)
    if not code or not dimension:
        raise MasterDataError("master_data_identity_invalid", "unit requires code and dimension")
    factor = values.get("factor_to_base")
    factor_text = None if factor in (None, "") else str(factor)
    rows = connection.execute("SELECT id, canonical_code, display_name, dimension, factor_to_base, status FROM measurement_units").fetchall()
    same = [row for row in rows if row[1] == code]
    if same and (same[0][2], same[0][3], None if same[0][4] is None else str(same[0][4]), same[0][5]) == (
            name, dimension, factor_text, "active"):
        return {"ops": [], "entity": {"domain": "unit", "id": int(same[0][0])}}
    if same or any(row[1].casefold() == code.casefold() or normalize_identity(row[2]) == normalize_identity(name)
                   for row in rows):
        raise MasterDataError("master_data_catalog_conflict", f"unit:{code}")
    return {"ops": [{"op": "create_unit", "code": code, "display_name": name, "dimension": dimension,
                     "factor_to_base": factor_text}], "entity": {"domain": "unit", "id": None}}


def _plan_party_profile(connection: sqlite3.Connection, change: MasterDataChange, policy: MasterDataPolicy) -> dict[str, Any]:
    values = change.values
    party_id = int(values.get("party_id") or 0)
    party = writes.require_active(connection, "party", party_id)
    role = _text(values, "business_role", 40)
    if role and connection.execute("SELECT 1 FROM business_party_roles WHERE party_id=? AND role_key=?",
                                   (party_id, role)).fetchone() is None:
        raise MasterDataError("master_data_role_missing", f"party:{party_id}:{role}")
    canonical = _text(values, "canonical_name", 200)
    legal = _text(values, "legal_name", 240)
    contact = _text(values, "contact_name", 120)
    contact_role = _text(values, "contact_role", 80)
    disposition = str(values.get("previous_name_disposition") or "confirmed_alias")
    if not canonical:
        raise MasterDataError("master_data_identity_invalid", "canonical name is required")
    if disposition not in {"confirmed_alias", "rejected_erroneous_name"}:
        raise MasterDataError("master_data_previous_name_disposition_invalid", disposition)
    changed = canonical != party["canonical_name"]
    if disposition == "rejected_erroneous_name" and not changed:
        raise MasterDataError("master_data_previous_name_disposition_invalid", "rejecting the old name needs a new name")
    identifiers = []
    for item in values.get("identifiers") or []:
        identifier_type = str(item.get("identifier_type") or "").strip()
        normalized = writes.normalize_party_identifier(identifier_type, item.get("value"), policy)
        if not normalized:
            raise MasterDataError("master_data_identifier_value_invalid", identifier_type)
        identifiers.append({"identifier_type": identifier_type, "value": _text(item, "value", 80),
                            "normalized_value": normalized})
    identifiers = sorted({(i["identifier_type"], i["normalized_value"]): i for i in identifiers}.values(),
                         key=lambda item: (item["identifier_type"], item["normalized_value"]))
    requested = {item for item in (_text({"v": value}, "v", 200) for value in values.get("aliases") or []) if item}
    if changed and disposition == "confirmed_alias":
        requested.add(str(party["canonical_name"]))
    if changed and disposition == "rejected_erroneous_name" and normalize_identity(party["canonical_name"]) in {
            normalize_identity(item) for item in requested}:
        raise MasterDataError("master_data_previous_name_disposition_invalid", "a rejected old name cannot also be an alias")
    if legal and legal != canonical:
        requested.add(legal)
    wanted = {normalize_identity(item) for item in (canonical, legal) if item}
    for other in connection.execute("SELECT canonical_name, legal_name FROM business_parties WHERE status='active' AND id<>?",
                                    (party_id,)):
        if wanted & {normalize_identity(item) for item in other if item}:
            raise MasterDataError("master_data_catalog_conflict", "requested party name is owned by another active party")
    writes.party_alias_identity(connection, party_id=party_id, raw_text=canonical, canonical_name=canonical, policy=policy)
    ops: list[dict[str, Any]] = []
    if (party["canonical_name"], party["legal_name"]) != (canonical, legal):
        ops.append({"op": "update_party_names", "party_id": party_id, "canonical_name": canonical, "legal_name": legal})
    aliases = writes._all(connection, """SELECT * FROM master_data_aliases WHERE entity_type='party' AND entity_id=?
                                          AND alias_status='confirmed' ORDER BY id""", (party_id,))
    for row in aliases:
        if normalize_identity(row["alias_name"]) == normalize_identity(canonical):
            ops.append({"op": "delete_alias", "alias_id": int(row["id"])})
        elif changed and disposition == "rejected_erroneous_name" and normalize_identity(row["alias_name"]) == normalize_identity(party["canonical_name"]):
            ops.append({"op": "set_alias_status", "alias_id": int(row["id"]), "status": "deprecated"})
    for alias in sorted(requested):
        decision = writes.party_alias_identity(connection, party_id=party_id, raw_text=alias, canonical_name=canonical,
                                               policy=policy)
        if decision["action"] == "create_identity":
            ops.append({"op": "remember_confirmed_alias", "domain": "party", "raw_text": alias, "entity_id": party_id,
                        "business_role": role})
    for item in identifiers:
        owner = connection.execute(
            "SELECT party_id, display_value, status FROM business_party_identifiers WHERE identifier_type=? AND normalized_value=?",
            (item["identifier_type"], item["normalized_value"])).fetchone()
        if owner is not None and int(owner[0]) != party_id and owner[2] == "active":
            raise MasterDataError("master_data_identifier_owned_by_other", item["identifier_type"])
    evidence = policy.identifier_evidence(connection, legal, identifiers, role) if identifiers else []
    for item in identifiers:
        item_evidence = next((entry for entry in evidence if entry.get("identifierType") == item["identifier_type"]
                              and entry.get("normalizedValue") == item["normalized_value"]), {})
        current = connection.execute(
            "SELECT display_value, status, evidence_json FROM business_party_identifiers WHERE identifier_type=? AND normalized_value=?",
            (item["identifier_type"], item["normalized_value"])).fetchone()
        wanted_evidence = json.dumps(item_evidence, ensure_ascii=False, sort_keys=True)
        if current is None or (current[0], current[1], current[2]) != (item["value"], "active", wanted_evidence):
            ops.append({"op": "upsert_identifier", "party_id": party_id, "identifier_type": item["identifier_type"],
                        "value": item["value"], "evidence": item_evidence})
    if contact:
        row = connection.execute(
            "SELECT contact_name, contact_role, status FROM business_contacts WHERE party_id=? AND normalized_name=?",
            (party_id, normalize_identity(contact))).fetchone()
        if row is None or tuple(row) != (contact, contact_role, "active"):
            ops.append({"op": "upsert_contact", "party_id": party_id, "contact_name": contact, "contact_role": contact_role})
    return {
        "ops": ops,
        "entity": {"domain": "party", "id": party_id},
        "before": {"canonical_name": party["canonical_name"], "legal_name": party["legal_name"]},
        "after": {"canonical_name": canonical, "legal_name": legal, "previous_name_disposition": disposition,
                  "business_role": role, "identifier_evidence": evidence},
    }


def _plan_update_entity(connection: sqlite3.Connection, change: MasterDataChange, policy: MasterDataPolicy) -> dict[str, Any]:
    values = change.values
    domain = str(values.get("domain") or "")
    entity_id = int(values.get("entity_id") or 0)
    if domain not in {"product", "unit"}:
        raise MasterDataError("master_data_resource_kind_invalid", domain)
    row = writes.require_active(connection, domain, entity_id)
    table = "products" if domain == "product" else "measurement_units"
    fields = {"product": ("canonical_name", "product_family"),
              "unit": ("display_name", "dimension", "factor_to_base")}[domain] + tuple(policy.extension_columns.get(table, ()))
    unknown = set(values) - {"domain", "entity_id", "keep_previous_name_as_alias", *fields}
    if unknown:
        raise MasterDataError("master_data_attribute_unknown", f"{domain}:{sorted(unknown)}")
    patch = {key: (None if values[key] in (None, "") and key == "factor_to_base" else str(values[key]).strip())
             for key in fields if key in values}
    current = {key: (None if row[key] is None else str(row[key])) for key in fields}
    patch = {key: value for key, value in patch.items() if value != current[key]}
    name_key = fields[0]
    if not patch:
        return {"ops": [], "entity": {"domain": domain, "id": entity_id}}
    if name_key in patch:
        if not patch[name_key]:
            raise MasterDataError("master_data_identity_invalid", f"{domain} name is required")
        for other in connection.execute(f"SELECT {name_key} FROM {table} WHERE id<>?", (entity_id,)):
            if normalize_identity(other[0]) == normalize_identity(patch[name_key]):
                raise MasterDataError("master_data_catalog_conflict", f"{domain}:{patch[name_key]}")
    ops: list[dict[str, Any]] = [{"op": "update_entity", "domain": domain, "entity_id": entity_id, "patch": patch}]
    if name_key in patch and values.get("keep_previous_name_as_alias", True):
        ops.append({"op": "remember_confirmed_alias", "domain": domain, "raw_text": str(row[name_key]),
                    "entity_id": entity_id, "business_role": ""})
    return {"ops": ops, "entity": {"domain": domain, "id": entity_id}, "before": current,
            "after": {**current, **patch}}


def _plan_alias(connection: sqlite3.Connection, change: MasterDataChange, policy: MasterDataPolicy) -> dict[str, Any]:
    values = change.values
    domain = str(values.get("domain") or "").strip().casefold()
    entity_id = int(values.get("entity_id") or 0)
    raw_text = _text(values, "alias_name", 240)
    if change.kind == "retire_alias":
        normalized = policy.normalize_alias(domain, raw_text)
        rows = writes._all(connection, """SELECT id, alias_status FROM master_data_aliases WHERE entity_type=? AND entity_id=?
                                            AND normalized_alias=? ORDER BY id""", (domain, entity_id, normalized))
        if not rows:
            raise MasterDataError("master_data_alias_missing", f"{domain}:{entity_id}:{raw_text}")
        return {"ops": [{"op": "set_alias_status", "alias_id": int(row["id"]), "status": "deprecated"}
                        for row in rows if row["alias_status"] != "deprecated"],
                "entity": {"domain": domain, "id": entity_id}}
    decision = writes.remember_decision(connection, domain=domain, raw_text=raw_text, entity_id=entity_id, policy=policy)
    ops = [] if decision == "noop" else [{
        "op": "remember_confirmed_alias", "domain": domain, "raw_text": raw_text, "entity_id": entity_id,
        "business_role": _text(values, "business_role", 40), "source_scope": _text(values, "source_scope", 160)}]
    return {"ops": ops, "entity": {"domain": domain, "id": entity_id}}


def _plan_role(connection: sqlite3.Connection, change: MasterDataChange, policy: MasterDataPolicy) -> dict[str, Any]:
    party_id = int(change.values.get("party_id") or 0)
    role = _text(change.values, "role_key", 40)
    writes.require_active(connection, "party", party_id)
    if not role:
        raise MasterDataError("master_data_role_required", str(party_id))
    exists = connection.execute("SELECT 1 FROM business_party_roles WHERE party_id=? AND role_key=?", (party_id, role)).fetchone()
    return {"ops": [] if exists else [{"op": "ensure_role", "party_id": party_id, "role_key": role}],
            "entity": {"domain": "party", "id": party_id}}


def _plan_merge(connection: sqlite3.Connection, change: MasterDataChange, policy: MasterDataPolicy) -> dict[str, Any]:
    values = change.values
    source_id, target_id = int(values.get("source_party_id") or 0), int(values.get("target_party_id") or 0)
    source = writes.entity_row(connection, "party", source_id)
    if source is not None and source["status"] == "deprecated" and source["successor_party_id"] == target_id:
        # 已经合并过：同样的合并第二次零变化。
        return {"ops": [], "entity": {"domain": "party", "id": target_id}}
    remember = bool(values.get("remember_source_as_alias", True))
    merge = writes.merge_party_plan(connection, source_party_id=source_id, target_party_id=target_id,
                                    remember_source_as_alias=remember)
    references: dict[str, int] = {}
    for mover in policy.merge_reference_movers:
        try:
            references.update(mover(connection, source_party_id=source_id, target_party_id=target_id,
                                    reason="master_data_party_merge", actor=change.reviewer, dry_run=True))
        except MasterDataError:
            raise
        except Exception as exc:  # 业务模块拒绝改指（如撞号）：原样带出它的拒收原因
            code = getattr(exc, "code", None)
            if not code:
                raise
            raise MasterDataError(str(code), str(getattr(exc, "message", exc))) from exc
    return {
        "ops": [{"op": "move_references", "source_party_id": source_id, "target_party_id": target_id},
                {"op": "merge_party_master_data", "merge": merge}],
        "entity": {"domain": "party", "id": target_id},
        "before": {"canonical_name": merge["source"]["canonical_name"], "source_party_id": source_id},
        "after": {"target_party_id": target_id, "references": references,
                  "source_name_disposition": "confirmed_alias" if remember else "rejected_erroneous_name"},
    }


_PLANNERS: dict[str, Callable[[sqlite3.Connection, MasterDataChange, MasterDataPolicy], dict[str, Any]]] = {
    "create_entity": _plan_create,
    "party_profile": _plan_party_profile,
    "update_entity": _plan_update_entity,
    "record_alias": _plan_alias,
    "retire_alias": _plan_alias,
    "ensure_role": _plan_role,
    "merge_party": _plan_merge,
}


def _plan(connection: sqlite3.Connection, change: MasterDataChange, policy: MasterDataPolicy) -> dict[str, Any]:
    planner = _PLANNERS.get(change.kind)
    if planner is None:
        raise MasterDataError("master_data_change_kind_invalid", change.kind)
    if not change.reviewer.strip():
        raise MasterDataError("master_data_reviewer_required", change.kind)
    return planner(connection, change, policy)


# ---------------------------------------------------------------- executor


def _execute(connection: sqlite3.Connection, change: MasterDataChange, plan: Mapping[str, Any],
             policy: MasterDataPolicy, action_key: str) -> dict[str, Any]:
    entity = dict(plan["entity"])
    for index, op in enumerate(plan["ops"]):
        kind = op["op"]
        if kind == "create_party":
            entity["id"] = writes.create_party(connection, canonical_name=op["canonical_name"],
                                               legal_name=op["legal_name"], roles=op["roles"])
        elif kind == "create_product":
            entity["id"] = writes.create_product(connection, canonical_name=op["canonical_name"],
                                                 product_family=op["product_family"],
                                                 extensions=op.get("extensions"), policy=policy)
        elif kind == "create_unit":
            entity["id"] = writes.create_unit(connection, code=op["code"], display_name=op["display_name"],
                                              dimension=op["dimension"], factor_to_base=op["factor_to_base"])
        elif kind == "update_party_names":
            writes.update_party_names(connection, party_id=op["party_id"], canonical_name=op["canonical_name"],
                                      legal_name=op["legal_name"])
        elif kind == "update_entity":
            writes.update_entity(connection, domain=op["domain"], entity_id=op["entity_id"], patch=op["patch"],
                                 policy=policy)
        elif kind == "delete_alias":
            writes.delete_alias(connection, op["alias_id"])
        elif kind == "set_alias_status":
            writes.set_alias_status(connection, op["alias_id"], op["status"], confirmed_by=change.reviewer)
        elif kind == "remember_confirmed_alias":
            writes.remember_confirmed_alias(
                connection, domain=op["domain"], raw_text=op["raw_text"], entity_id=op["entity_id"],
                business_role=op.get("business_role", ""), source_scope=op.get("source_scope", ""),
                reviewer=change.reviewer, source_key=f"{action_key}:alias:{index}", review_note=change.review_note,
                policy=policy,
            )
        elif kind == "upsert_identifier":
            writes.upsert_identifier(
                connection, party_id=op["party_id"], identifier_type=op["identifier_type"], value=op["value"],
                source_kind="party_profile_owner", source_ref=action_key, evidence=op["evidence"],
                confirmed_by=change.reviewer, policy=policy,
            )
        elif kind == "upsert_contact":
            writes.upsert_contact(connection, party_id=op["party_id"], contact_name=op["contact_name"],
                                  contact_role=op["contact_role"], source=action_key)
        elif kind == "ensure_role":
            writes.ensure_role(connection, party_id=op["party_id"], role_key=op["role_key"])
        elif kind == "move_references":
            for mover in policy.merge_reference_movers:
                mover(connection, source_party_id=op["source_party_id"], target_party_id=op["target_party_id"],
                      reason=f"master_data_party_merge:{action_key}", actor=change.reviewer, dry_run=False)
        elif kind == "merge_party_master_data":
            writes.merge_party_master_data(connection, dict(op["merge"]), reviewer=change.reviewer,
                                           review_note=change.review_note, policy=policy)
        else:
            raise MasterDataError("master_data_change_op_invalid", kind)
    return entity


def _readback(connection: sqlite3.Connection, change: MasterDataChange, plan: Mapping[str, Any], entity: Mapping[str, Any],
              policy: MasterDataPolicy) -> dict[str, Any]:
    """写完重新算一遍：同样的处理此刻应当是零步。"""

    replanned = _plan(connection, change, policy)
    if replanned["ops"]:
        raise MasterDataError("master_data_readback_drift", f"{change.kind}: {len(replanned['ops'])} step(s) still pending")
    row = writes.entity_row(connection, entity["domain"], entity["id"]) if entity.get("id") and entity["domain"] in {
        "party", "product", "unit"} else None
    return {"domain": entity["domain"], "entity_id": entity.get("id"), "entity": row}


def preview_change_in_transaction(
    connection: sqlite3.Connection, change: MasterDataChange, *, policy: MasterDataPolicy = DEFAULT_POLICY,
) -> MasterDataChangePreview:
    plan = _plan(connection, change, policy)
    token = _state_token(connection, policy)
    body = {"change": change.to_dict(), "state_token": token, "plan": plan}
    return MasterDataChangePreview(change, token, plan, digest_json(body))


def apply_change_in_transaction(
    connection: sqlite3.Connection, preview: MasterDataChangePreview, *, policy: MasterDataPolicy = DEFAULT_POLICY,
) -> dict[str, Any]:
    if digest_json(preview.content()) != preview.preview_digest:
        raise MasterDataError("master_data_preview_content_drift", "preview digest differs")
    change = preview.change
    plan = _plan(connection, change, policy)
    if not plan["ops"]:
        entity = dict(plan["entity"])
        return {"disposition": "idempotent_noop", "kind": change.kind,
                "readback": _readback(connection, change, plan, entity, policy)}
    if _state_token(connection, policy) != preview.state_token:
        raise MasterDataError("master_data_state_generation_drift", "master data changed since preview")
    if digest_json(plan) != digest_json(dict(preview.plan)):
        raise MasterDataError("master_data_preview_content_drift", "plan differs from preview")
    protected_before = policy.protected_projection(connection) if policy.protected_projection is not None else None
    action_key = f"mdg-{uuid.uuid4().hex}"
    entity = _execute(connection, change, plan, policy, action_key)
    if policy.protected_projection is not None and policy.protected_projection(connection) != protected_before:
        raise MasterDataError("master_data_protected_projection_changed", change.kind)
    readback = _readback(connection, change, plan, entity, policy)
    label = ""
    if readback["entity"]:
        label = str(readback["entity"].get("canonical_name") or readback["entity"].get("display_name") or "")
    audit_key = writes.record_governance_action(
        connection, domain=entity["domain"], entity_id=int(entity["id"]), label=label,
        raw_text=str(plan.get("before", {}).get("canonical_name") or label), source_kind=_SOURCE_KIND[change.kind],
        source_field=change.kind, before={"plan_before": plan.get("before", {})},
        after={"plan_after": plan.get("after", {}), "ops": list(plan["ops"]), "action_key": action_key},
        reviewer=change.reviewer, review_note=change.review_note,
    )
    return {"disposition": "applied", "kind": change.kind, "action_key": audit_key, "readback": readback}


_SOURCE_KIND = {
    "create_entity": "master_data_catalog",
    "party_profile": "business_parties",
    "update_entity": "master_data_catalog",
    "record_alias": "master_data_aliases",
    "retire_alias": "master_data_aliases",
    "ensure_role": "business_party_roles",
    "merge_party": "business_parties",
}


def preview_change(
    storage: StorageTarget, change: MasterDataChange, *, policy: MasterDataPolicy = DEFAULT_POLICY,
    enabled_module_ids: Iterable[str] | None = None,
) -> MasterDataChangePreview:
    _require_module_enabled(enabled_module_ids)
    with _reading(storage) as connection:
        return preview_change_in_transaction(connection, change, policy=policy)


def apply_change(
    storage: StorageTarget, preview: MasterDataChangePreview, *, policy: MasterDataPolicy = DEFAULT_POLICY,
    enabled_module_ids: Iterable[str] | None = None,
) -> dict[str, Any]:
    _require_module_enabled(enabled_module_ids)
    with _writing(storage) as connection:
        return apply_change_in_transaction(connection, preview, policy=policy)


__all__ = [
    "CHANGE_KINDS",
    "MasterDataChange",
    "MasterDataChangePreview",
    "apply_change",
    "apply_change_in_transaction",
    "preview_change",
    "preview_change_in_transaction",
]
