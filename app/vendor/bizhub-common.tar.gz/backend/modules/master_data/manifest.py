"""Authoritative runtime manifest for the minimal master-data facade."""

from __future__ import annotations

from typing import Any

from .schema import STANDARD_TABLE_NAMES


MODULE_ID = "master_data"
MODULE_VERSION = "0.1.0-cp3"
OWNER_REF = f"{MODULE_ID}:catalog-owner"
# Physical store of TABLES. Until this module's migration step moves it onto
# the customer database, its tables live in the standalone generic lineage.
STORAGE_LINEAGE = "generic-kernel"
TABLES = tuple(sorted((*STANDARD_TABLE_NAMES, "location_catalog", "master_data_external_identities")))


# HTTP addresses the standalone generic app (generic.kernel_smoke) mounts for
# this module. They belong to that app; a customer Profile that enables this
# module gets no address until its own router declares one.
STANDALONE_APP_ROUTES = (
    {"surface_id": "generic_api", "method": "GET", "path": "/api/master-data/locations"},
)


def master_data_module_manifest(source_commit: str, migrations: list[dict[str, Any]]) -> dict[str, Any]:
    return {
        "schema_version": "bizhub.runtime-module-manifest.v1",
        "module_id": MODULE_ID,
        "module_version": MODULE_VERSION,
        "source": {"kind": "generic", "commit": source_commit},
        "package": {
            "backend": "backend.modules.master_data",
            "public_api": "backend.modules.master_data.public:get_resource",
            "frontend_entry": None,
        },
        "dependencies": ["kernel.profile_registry"],
        "capabilities": {
            "provides": ["master-data.identity", "master-data.location-catalog"],
            "requires": ["kernel.profile-registry"],
        },
        "surfaces": {
            "routes": [],
            "ui_routes": [], "jobs": [], "mcp_tools": [],
            "actions": [
                {"action_id": "master_data.catalog.apply", "record_types": ["master_data_catalog"], "owner_ref": OWNER_REF},
                {"action_id": "master_data.change.apply", "record_types": ["master_data_change"], "owner_ref": OWNER_REF},
            ],
            "migrations": migrations,
        },
        "ownership": {
            "record_types": [
                {"record_type": "master_data_catalog", "owner_ref": OWNER_REF,
                 "canonical_writer": "backend/modules/master_data/owner.py:apply_catalog"},
                {"record_type": "master_data_change", "owner_ref": OWNER_REF,
                 "canonical_writer": "backend/modules/master_data/commands.py:apply_change"},
            ],
            "tables": [{"table": table, "lineage_id": STORAGE_LINEAGE, "mode": "formal_writer", "owner_ref": OWNER_REF}
                       for table in TABLES],
        },
        "activation": {"mode": "build-time", "retains_existing_data_when_disabled": True},
    }
