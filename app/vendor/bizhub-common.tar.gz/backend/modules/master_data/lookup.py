"""主数据查找：一种写法到底指哪个往来方、产品、单位（只读）。

``search`` 给出有限候选，``resolve`` 做出唯一结论。顺序（往来方走全部步骤，其他种类
到第 3 步为止）：

0. 本公司名称：认作“我方”，不指向任何往来方；
1. 号码：资料里的税号、统一信用代码命中谁；电话只在名称不指向别人时作数；
2. 名称归一（客户策略）；
3. 正式名 / 全称 / 已确认别名 / 组合写法完全一致（可选：联系人）；多个时只按角色收窄；
4. 唯一一个安全的“包含”匹配；
5. 唯一一个错字容忍范围内的近似核心名（不按角色收窄），并请调用方在业务写成功后记住这个写法。

角色在身份之后检查：往来方没有要求的角色时结论为 ``role_missing``。这里不写库。
"""

from __future__ import annotations

import sqlite3
from dataclasses import dataclass, field
from typing import Any, Iterable, Mapping

from . import matching
from .policy import DEFAULT_POLICY, MasterDataPolicy

CONTRACT_VERSION = "bizhub-master-data-resolution.v1"
STANDARD_DOMAINS = frozenset({"party", "product", "unit"})
SERVER_EXACT_MATCH_METHODS = frozenset(
    {
        "canonical_name",
        "confirmed_alias",
        "confirmed_identifier",
        "spec_syntax",
        "catalog_compact_unique",
        "composite_exact_agreement",
    }
)
READABLE_ALIAS_STATUSES = ("confirmed", "ambiguous")
_normalize = matching.normalize_identity


def candidate(
    *,
    domain: str,
    entity_id: int,
    label: str,
    status: str,
    method: str,
    matched: str,
    score: float,
    attributes: dict[str, Any] | None = None,
) -> dict[str, Any]:
    payload = matching.candidate_payload(
        domain=domain, entity_id=entity_id, label=label, status=status,
        method=method, matched=matched, score=score, attributes=attributes,
    )
    return {
        "canonicalRef": payload["canonical_ref"],
        "domain": payload["domain"],
        "entityId": payload["entity_id"],
        "canonicalLabel": payload["canonical_label"],
        "status": payload["status"],
        "matchMethod": payload["match_method"],
        "matchedText": payload["matched_text"],
        "score": payload["score"],
        "attributes": payload["attributes"],
    }


def _score(query: str, value: object, *, exact_score: float, contains_score: float) -> float:
    return matching.match_score(
        query, str(value or ""), exact_score=exact_score, contains_score=contains_score, normalize=_normalize,
    )


def _rows(connection: sqlite3.Connection, sql: str, params: Iterable[Any] = ()) -> list[sqlite3.Row]:
    cursor = connection.execute(sql, tuple(params))
    names = [item[0] for item in cursor.description]
    return [dict(zip(names, row)) for row in cursor.fetchall()]  # type: ignore[misc]


def aliases(connection: sqlite3.Connection, entity_type: str, statuses: Iterable[str] = READABLE_ALIAS_STATUSES) -> list[dict[str, Any]]:
    wanted = tuple(statuses)
    marks = ",".join("?" for _ in wanted)
    return _rows(
        connection,
        f"SELECT * FROM master_data_aliases WHERE entity_type=? AND alias_status IN ({marks}) ORDER BY id",
        (entity_type, *wanted),
    )


def _search_parties(
    connection: sqlite3.Connection,
    policy: MasterDataPolicy,
    *,
    normalized: str,
    role: str,
    identity_values: Iterable[Any] = (),
) -> list[dict[str, Any]]:
    parties = _rows(connection, "SELECT * FROM business_parties WHERE status IN ('active', 'deprecated')")
    by_id = {int(item["id"]): item for item in parties}
    roles_by_party: dict[int, set[str]] = {}
    for item in _rows(connection, "SELECT party_id, role_key FROM business_party_roles"):
        roles_by_party.setdefault(int(item["party_id"]), set()).add(str(item["role_key"]))
    contacts = _rows(connection, "SELECT * FROM business_contacts WHERE status='active' ORDER BY id")
    identifiers = _rows(connection, "SELECT * FROM business_party_identifiers WHERE status='active' ORDER BY id")
    contacts_by_party: dict[int, list[dict[str, Any]]] = {}
    for item in contacts:
        contacts_by_party.setdefault(int(item["party_id"]), []).append(item)
    identifiers_by_party: dict[int, list[dict[str, Any]]] = {}
    for item in identifiers:
        identifiers_by_party.setdefault(int(item["party_id"]), []).append(item)

    def attributes(party_id: int) -> dict[str, Any]:
        return {
            "roles": sorted(roles_by_party.get(party_id, set())),
            "contacts": [
                {"contactRef": f"contact:{item['id']}", "name": item["contact_name"],
                 "role": item["contact_role"], "emailDomain": item["email_domain"]}
                for item in contacts_by_party.get(party_id, [])[:10]
            ],
            "identifiers": [
                {"identifierType": item["identifier_type"], "valueTail": str(item["normalized_value"])[-4:],
                 "status": item["status"]}
                for item in identifiers_by_party.get(party_id, [])[:10]
            ],
        }

    def allowed(party_id: int) -> bool:
        return not role or role in roles_by_party.get(party_id, set())

    result: list[dict[str, Any]] = []
    for party in parties:
        party_id = int(party["id"])
        if not allowed(party_id):
            continue
        score = max(
            _score(normalized, party["canonical_name"], exact_score=1.0, contains_score=0.78),
            _score(normalized, party["legal_name"], exact_score=1.0, contains_score=0.8),
        )
        if score:
            result.append(candidate(
                domain="party", entity_id=party_id, label=party["canonical_name"], status=party["status"],
                method="canonical_name" if score >= 0.99 else "canonical_contains",
                matched=party["canonical_name"], score=score, attributes=attributes(party_id),
            ))
    # 已确认别名不论最初在哪个角色、哪个来源下确认，都指向它的往来方：角色只筛往来方，不筛写法。
    for alias in aliases(connection, "party"):
        party = by_id.get(int(alias["entity_id"]))
        if party is None or not allowed(int(party["id"])):
            continue
        score = _score(normalized, alias["normalized_alias"], exact_score=1.0, contains_score=0.82)
        if score:
            result.append(candidate(
                domain="party", entity_id=int(party["id"]), label=party["canonical_name"], status=party["status"],
                method="confirmed_alias" if score >= 0.99 else "alias_contains",
                matched=alias["alias_name"], score=score, attributes=attributes(int(party["id"])),
            ))
    for contact in contacts:
        party = by_id.get(int(contact["party_id"]))
        if party is None or not allowed(int(party["id"])):
            continue
        score = _score(normalized, contact["normalized_name"], exact_score=0.96, contains_score=0.76)
        if score:
            result.append(candidate(
                domain="party", entity_id=int(party["id"]), label=party["canonical_name"], status=party["status"],
                method="formal_contact", matched=contact["contact_name"], score=score,
                attributes={**attributes(int(party["id"])), "contactId": int(contact["id"])},
            ))
    wanted_identifiers = {policy.normalize_identifier(value) for value in identity_values} - {""}
    raw_identifier = policy.normalize_identifier(normalized)
    if len(raw_identifier) >= 8:
        wanted_identifiers.add(raw_identifier)
    phones = {policy.normalize_phone(value) for value in identity_values} - {""}
    for identifier in identifiers:
        wanted = phones if identifier["identifier_type"] == "phone" else wanted_identifiers
        if identifier["normalized_value"] not in wanted:
            continue
        party = by_id.get(int(identifier["party_id"]))
        if party is None or not allowed(int(party["id"])):
            continue
        result.append(candidate(
            domain="party", entity_id=int(party["id"]), label=party["canonical_name"], status=party["status"],
            method="confirmed_identifier", matched=identifier["identifier_type"], score=1.0,
            attributes=attributes(int(party["id"])),
        ))
    return result


def _composite_party(
    connection: sqlite3.Connection, policy: MasterDataPolicy, *, raw_text: str, role: str,
) -> dict[str, Any] | None:
    """“简称 / 英文名”这类组合写法：每一段都单独精确指向同一个往来方才算。"""

    parts = [item.strip() for item in policy.composite_separator.split(raw_text) if item.strip()]
    if len(parts) < 2 or len(parts) > 6:
        return None
    agreed: dict[str, Any] | None = None
    for part in parts:
        rows = _search_parties(connection, policy, normalized=_normalize(part), role=role)
        exact = {
            item["canonicalRef"]: item for item in rows
            if item["status"] == "active" and item["score"] >= 0.99
            and item["matchMethod"] in {"canonical_name", "confirmed_alias"}
        }
        if len(exact) != 1:
            return None
        current = next(iter(exact.values()))
        if agreed is not None and current["canonicalRef"] != agreed["canonicalRef"]:
            return None
        agreed = current
    if agreed is None:
        return None
    return candidate(
        domain="party", entity_id=agreed["entityId"], label=agreed["canonicalLabel"], status=agreed["status"],
        method="composite_exact_agreement", matched=raw_text, score=1.0, attributes=agreed["attributes"],
    )


def _search_products(
    connection: sqlite3.Connection, policy: MasterDataPolicy, *, normalized: str, source_scope: str,
) -> list[dict[str, Any]]:
    products = _rows(connection, "SELECT * FROM products WHERE status IN ('active', 'deprecated')")
    by_id = {int(item["id"]): item for item in products}
    result: list[dict[str, Any]] = []
    for product in products:
        score = _score(normalized, policy.normalize_name("product", product["canonical_name"]),
                       exact_score=1.0, contains_score=0.8)
        if score:
            result.append(candidate(
                domain="product", entity_id=int(product["id"]), label=product["canonical_name"],
                status=product["status"], method="canonical_name" if score >= 0.99 else "canonical_contains",
                matched=product["canonical_name"], score=score, attributes=policy.product_attributes(product),
            ))
    hits = []
    for alias in aliases(connection, "product"):
        product = by_id.get(int(alias["entity_id"]))
        score = _score(normalized, policy.normalize_name("product", alias["alias_name"]),
                       exact_score=1.0, contains_score=0.82)
        if product is not None and score:
            hits.append((alias, product, score))
    # 来源范围从不藏起别名，只在同一写法指向不同产品时用来挑。
    scoped = {int(alias["entity_id"]) for alias, _p, _s in hits if alias["source_scope"] == source_scope}
    if source_scope and scoped and len({int(alias["entity_id"]) for alias, _p, _s in hits}) > 1:
        hits = [hit for hit in hits if int(hit[0]["entity_id"]) in scoped]
    for alias, product, score in hits:
        result.append(candidate(
            domain="product", entity_id=int(product["id"]), label=product["canonical_name"],
            status=product["status"], method="confirmed_alias" if score >= 0.99 else "alias_contains",
            matched=alias["alias_name"], score=score, attributes=policy.product_attributes(product),
        ))
    return result


def _search_units(connection: sqlite3.Connection, *, normalized: str) -> list[dict[str, Any]]:
    units = _rows(connection, "SELECT * FROM measurement_units WHERE status IN ('active', 'deprecated')")
    by_id = {int(item["id"]): item for item in units}
    result: list[dict[str, Any]] = []
    for unit in units:
        score = max(
            _score(normalized, unit["canonical_code"], exact_score=1.0, contains_score=0),
            _score(normalized, unit["display_name"], exact_score=1.0, contains_score=0),
        )
        if score:
            result.append(candidate(
                domain="unit", entity_id=int(unit["id"]), label=unit["display_name"], status=unit["status"],
                method="canonical_name", matched=unit["canonical_code"], score=score,
                attributes={"code": unit["canonical_code"], "dimension": unit["dimension"]},
            ))
    for alias in aliases(connection, "unit"):
        unit = by_id.get(int(alias["entity_id"]))
        score = _score(normalized, alias["normalized_alias"], exact_score=1.0, contains_score=0)
        if unit is not None and score:
            result.append(candidate(
                domain="unit", entity_id=int(unit["id"]), label=unit["display_name"], status=unit["status"],
                method="confirmed_alias", matched=alias["alias_name"], score=score,
                attributes={"code": unit["canonical_code"], "dimension": unit["dimension"]},
            ))
    return result


def supported_domains(policy: MasterDataPolicy = DEFAULT_POLICY) -> frozenset[str]:
    return STANDARD_DOMAINS | frozenset(policy.extra_search)


def search(
    connection: sqlite3.Connection,
    *,
    domain: str,
    raw_text: str,
    role: str = "",
    source_scope: str = "",
    identity_values: Iterable[Any] | None = None,
    limit: int = 10,
    policy: MasterDataPolicy = DEFAULT_POLICY,
) -> dict[str, Any]:
    domain = str(domain or "").strip().casefold()
    if domain not in supported_domains(policy):
        raise ValueError(f"unsupported master-data domain: {domain}")
    raw_text = str(raw_text or "").strip()
    normalized = _normalize(raw_text)
    base = {"contractVersion": CONTRACT_VERSION, "domain": domain, "rawText": raw_text,
            "normalizedText": policy.search_normalized_text(domain, raw_text)}
    if not normalized:
        return {**base, "candidates": [], "requiresAgentFallback": False}
    if domain == "party":
        # 我方名称不是任何往来方的候选：直接查的调用方拿到与 resolve 一样的结论。
        if policy.own_company_label(raw_text) is not None:
            return {**base, "candidates": [], "requiresAgentFallback": False, "ownCompany": True}
        candidates = _search_parties(connection, policy, normalized=normalized, role=role,
                                     identity_values=list(identity_values or []))
    elif domain == "product":
        candidates = _search_products(connection, policy, normalized=policy.normalize_name("product", raw_text),
                                      source_scope=source_scope)
    elif domain == "unit":
        candidates = _search_units(connection, normalized=normalized)
    else:
        candidates = policy.extra_search[domain](connection, policy, raw_text, normalized, source_scope)
    if domain == "party" and not any(item["status"] == "active" and item["score"] >= 0.99 for item in candidates):
        composite = _composite_party(connection, policy, raw_text=raw_text, role=role)
        if composite is not None:
            candidates.append(composite)
    deduplicated: dict[str, dict[str, Any]] = {}
    for item in candidates:
        existing = deduplicated.get(item["canonicalRef"])
        if (
            existing is None
            or item["score"] > existing["score"]
            or (item["score"] == existing["score"] and item["matchMethod"] == "confirmed_identifier"
                and existing["matchMethod"] != "confirmed_identifier")
        ):
            deduplicated[item["canonicalRef"]] = item
    ordered = sorted(
        deduplicated.values(),
        key=lambda item: (0 if item["status"] == "active" else 1, -item["score"], item["canonicalLabel"], item["entityId"]),
    )[: max(1, min(10, int(limit)))]
    exact = [item for item in ordered if item["status"] == "active" and item["score"] >= 0.99]
    return {**base, "candidates": ordered, "requiresAgentFallback": len(exact) != 1}


@dataclass(frozen=True)
class Resolution:
    """一种写法的唯一结论（见 :func:`resolve`）。"""

    status: str
    domain: str
    raw_text: str
    entity_id: int | None = None
    label: str = ""
    method: str = ""
    roles: tuple[str, ...] = ()
    contact_id: int | None = None
    candidate_ids: tuple[int, ...] = ()
    candidates: tuple[dict[str, Any], ...] = ()
    evidence: dict[str, Any] = field(default_factory=dict)
    remember_alias: bool = False

    @property
    def resolved(self) -> bool:
        return self.status == "resolved"

    def remember_entry(self) -> dict[str, Any] | None:
        if not (self.resolved and self.remember_alias and self.entity_id):
            return None
        return {"domain": self.domain, "entity_id": int(self.entity_id), "raw_text": self.raw_text,
                "evidence": dict(self.evidence)}


def _role_set(role: Any) -> frozenset[str]:
    if role in (None, ""):
        return frozenset()
    if isinstance(role, str):
        return frozenset({role.strip()}) - {""}
    return frozenset(str(item).strip() for item in role) - {""}


def _from_candidate(
    *, domain: str, raw_text: str, item: Mapping[str, Any], roles: frozenset[str], method: str | None = None,
    evidence: dict[str, Any] | None = None, remember_alias: bool = False, candidates: tuple[dict[str, Any], ...] = (),
) -> Resolution:
    attributes = item.get("attributes") if isinstance(item.get("attributes"), dict) else {}
    entity_roles = tuple(sorted(str(value) for value in attributes.get("roles") or []))
    status = "role_missing" if domain == "party" and roles and not roles.intersection(entity_roles) else "resolved"
    contact_id = attributes.get("contactId")
    return Resolution(
        status=status, domain=domain, raw_text=raw_text, entity_id=int(item["entityId"]),
        label=str(item.get("canonicalLabel") or ""), method=method or str(item.get("matchMethod") or ""),
        roles=entity_roles, contact_id=int(contact_id) if str(contact_id or "").isdigit() else None,
        candidate_ids=(int(item["entityId"]),), candidates=candidates, evidence=dict(evidence or {}),
        remember_alias=remember_alias and status == "resolved",
    )


def _party(
    connection: sqlite3.Connection, party_id: int, *, raw_text: str, roles: frozenset[str], method: str,
    evidence: dict[str, Any] | None = None, remember_alias: bool = False, candidates: tuple[dict[str, Any], ...] = (),
) -> Resolution:
    party = connection.execute("SELECT canonical_name FROM business_parties WHERE id=?", (party_id,)).fetchone()
    entity_roles = [row[0] for row in connection.execute(
        "SELECT role_key FROM business_party_roles WHERE party_id=?", (party_id,))]
    return _from_candidate(
        domain="party", raw_text=raw_text,
        item={"entityId": party_id, "canonicalLabel": party[0] if party else "", "attributes": {"roles": entity_roles}},
        roles=roles, method=method, evidence=evidence, remember_alias=remember_alias, candidates=candidates,
    )


def _fuzzy_names(connection: sqlite3.Connection, policy: MasterDataPolicy) -> dict[int, set[str]]:
    """每个在用往来方的核心名：正式名、全称、已确认别名。"""

    names: dict[int, set[str]] = {}
    for party in _rows(connection, "SELECT id, canonical_name, legal_name FROM business_parties WHERE status='active'"):
        for value in (party["canonical_name"], party["legal_name"]):
            if str(value or "").strip():
                names.setdefault(int(party["id"]), set()).add(policy.normalize_name("party", value))
    for alias in aliases(connection, "party"):
        if int(alias["entity_id"]) in names:
            names[int(alias["entity_id"])].add(policy.normalize_name("party", alias["alias_name"]))
    return {party_id: values - {""} for party_id, values in names.items()}


def safe_containment(policy: MasterDataPolicy, raw_text: str, item: Mapping[str, Any]) -> bool:
    """只认有方向、有意义的往来方名称包含（来源省了正式名或别名的前后缀；或在完整
    正式名后补了一个公司类型词）；别的反向包含一律不认。"""

    if str(item.get("status") or "") != "active":
        return False
    threshold = {
        "canonical_contains": policy.party_contains_min_score,
        "alias_contains": policy.alias_contains_min_score,
    }.get(str(item.get("matchMethod") or ""))
    if threshold is None or float(item.get("score") or 0) < threshold:
        return False
    source = _normalize(raw_text)
    matched = _normalize(item.get("matchedText"))
    if len(source) >= 3 and matched and source in matched:
        return True
    canonical = _normalize(item.get("canonicalLabel"))
    if len(canonical) < 4 or not source.startswith(canonical):
        return False
    return source[len(canonical):] in policy.canonical_legal_suffix_extensions


def _with_phone(
    connection: sqlite3.Connection, by_name: Resolution, phone_party_ids: set[int], *, roles: frozenset[str],
) -> Resolution:
    named = {int(by_name.entity_id)} if by_name.entity_id is not None else {int(item) for item in by_name.candidate_ids}
    if len(phone_party_ids) == 1:
        phone_party_id = next(iter(phone_party_ids))
        if by_name.entity_id == phone_party_id:
            return by_name
        if not named or (by_name.status == "ambiguous" and phone_party_id in named):
            return _party(connection, phone_party_id, raw_text=by_name.raw_text, roles=roles, method="confirmed_phone",
                          evidence={"identity": "phone", "nameStatus": by_name.status}, candidates=by_name.candidates)
    return Resolution(
        status="ambiguous", domain="party", raw_text=by_name.raw_text, method="phone_name_conflict",
        candidate_ids=tuple(sorted(phone_party_ids | named)), candidates=by_name.candidates,
        evidence={"conflict": "phone_vs_name", "phonePartyIds": sorted(phone_party_ids)},
    )


def resolve(
    connection: sqlite3.Connection,
    domain: str,
    text: Any,
    *,
    role: str | Any = None,
    context: Mapping[str, Any] | None = None,
    policy: MasterDataPolicy = DEFAULT_POLICY,
) -> Resolution:
    context = dict(context or {})
    domain = str(domain or "").strip().casefold()
    raw_text = str(text or "").strip()
    if domain == "party" and (own := policy.own_company_label(raw_text)) is not None:
        return Resolution(status="invalid", domain=domain, raw_text=raw_text, method="own_company", label=own,
                          evidence={"ownCompany": own})
    identity_values = list(context.get("identity_values") or [])
    phones = {policy.normalize_phone(value) for value in identity_values} - {""}
    if domain == "party" and phones:
        marks = ",".join("?" for _ in phones)
        phone_party_ids = {int(row[0]) for row in connection.execute(
            f"""SELECT party_id FROM business_party_identifiers
                WHERE identifier_type='phone' AND status='active' AND normalized_value IN ({marks})""",
            tuple(sorted(phones)),
        )}
        if phone_party_ids:
            by_name = resolve(
                connection, domain, raw_text, role=role, policy=policy,
                context={**context, "identity_values": [value for value in identity_values if not policy.normalize_phone(value)]},
            )
            return _with_phone(connection, by_name, phone_party_ids, roles=_role_set(role))
    if domain not in supported_domains(policy) or not _normalize(raw_text):
        return Resolution(status="invalid", domain=domain, raw_text=raw_text)
    roles = _role_set(role)
    found = search(connection, domain=domain, raw_text=raw_text, source_scope=str(context.get("source_scope") or ""),
                   identity_values=identity_values, policy=policy)
    candidates = tuple(found["candidates"])
    normalized = _normalize(raw_text)
    exact: dict[int, dict[str, Any]] = {}
    for item in candidates:
        if item["status"] != "active":
            continue
        if (float(item["score"]) >= 0.99 and item["matchMethod"] in SERVER_EXACT_MATCH_METHODS) or (
            domain == "party" and context.get("allow_contact") and item["matchMethod"] == "formal_contact"
            and _normalize(item["matchedText"]) == normalized
        ):
            exact[int(item["entityId"])] = item
    if len(exact) > 1 and domain == "party":
        strong = {entity_id for entity_id, item in exact.items() if item["matchMethod"] == "confirmed_identifier"
                  and str(item.get("matchedText") or "") in {"tax_id", "unified_social_credit_code"}}
        named = {entity_id for entity_id, item in exact.items() if item["matchMethod"] in {"canonical_name", "confirmed_alias"}}
        if strong and named and strong != named:
            # 税号与精确名称指向不同往来方是强冲突，不许按角色替人消解。
            return Resolution(status="ambiguous", domain=domain, raw_text=raw_text,
                              candidate_ids=tuple(sorted(exact)), candidates=candidates)
    if len(exact) > 1 and roles and domain == "party":
        narrowed = {entity_id: item for entity_id, item in exact.items()
                    if roles.intersection(item["attributes"].get("roles") or [])}
        if len(narrowed) == 1:
            exact = narrowed
    if len(exact) == 1:
        return _from_candidate(domain=domain, raw_text=raw_text, item=next(iter(exact.values())), roles=roles,
                               candidates=candidates)
    if exact or domain != "party":
        return Resolution(status="ambiguous" if exact else "new", domain=domain, raw_text=raw_text,
                          candidate_ids=tuple(sorted(exact)), candidates=candidates)
    contained = {int(item["entityId"]): item for item in candidates if safe_containment(policy, raw_text, item)}
    if len(contained) == 1:
        return _from_candidate(domain=domain, raw_text=raw_text, item=next(iter(contained.values())), roles=roles,
                               method="containment", candidates=candidates)
    if contained:
        return Resolution(status="ambiguous", domain=domain, raw_text=raw_text, method="containment",
                          candidate_ids=tuple(sorted(contained)), candidates=candidates)
    core = policy.normalize_name("party", raw_text)
    status, entity_id, distance, tied = matching.unique_nearest_entity(
        core, _fuzzy_names(connection, policy),
        distance_by_length=policy.party_fuzzy_distance_by_length, min_gap=policy.party_fuzzy_min_gap,
    )
    evidence = {"origin": policy.fuzzy_alias_origin, "rawText": raw_text, "normalized": normalized,
                "core": core, "distance": distance}
    if status == "ambiguous":
        return Resolution(status="ambiguous", domain=domain, raw_text=raw_text, method="fuzzy",
                          candidate_ids=tuple(sorted(int(item) for item in tied)), candidates=candidates,
                          evidence=evidence)
    if status != "resolved":
        return Resolution(status="new", domain=domain, raw_text=raw_text, candidates=candidates)
    return _party(connection, int(entity_id), raw_text=raw_text, roles=roles, method="fuzzy", evidence=evidence,
                  remember_alias=True, candidates=candidates)


__all__ = [
    "CONTRACT_VERSION",
    "READABLE_ALIAS_STATUSES",
    "Resolution",
    "SERVER_EXACT_MATCH_METHODS",
    "aliases",
    "candidate",
    "resolve",
    "safe_containment",
    "search",
    "supported_domains",
]
