"""主数据标准表：所有客户共用的一套表（成熟 ERP 的做法：标准表 + 客户扩展列）。

这里是标准表的唯一定义。通用小库按它建表（``generic_kernel.migrations``）；客户库里
已有的同名表必须等于“标准表 + 该客户登记的扩展”，由一致性检查逐项核对列、主键、
唯一约束、取值约束、外键和索引。客户扩展只能加列、给取值约束放宽取值、加索引，
不能改标准列。

外部系统编号映射（``master_data_external_identities``）是通用可选表：只在启用了
外部导入的部署里建，指向的主数据用数字编号，库位暂用文字编号（库位第 6 步并入）。
"""

from __future__ import annotations

import re
import sqlite3
from dataclasses import dataclass, field
from typing import Mapping


@dataclass(frozen=True)
class Column:
    name: str
    type: str
    nullable: bool = False
    server_default: str | None = None


@dataclass(frozen=True)
class Check:
    """``column IN (...)`` 取值约束；客户扩展可追加取值。"""

    name: str
    column: str
    values: tuple[str, ...]


@dataclass(frozen=True)
class ForeignKey:
    column: str
    ref_table: str
    ref_column: str
    ondelete: str


@dataclass(frozen=True)
class Index:
    name: str
    columns: tuple[str, ...]
    unique: bool = False
    where: str = ""


@dataclass(frozen=True)
class Table:
    name: str
    columns: tuple[Column, ...]
    uniques: tuple[tuple[str | None, tuple[str, ...]], ...] = ()
    checks: tuple[Check, ...] = ()
    foreign_keys: tuple[ForeignKey, ...] = ()
    indexes: tuple[Index, ...] = ()
    primary_key: str = "id"


@dataclass(frozen=True)
class TableExtension:
    """客户对一张标准表的扩展：追加列、给取值约束追加取值、追加索引、给已有列加外键。"""

    table: str
    columns: tuple[Column, ...] = ()
    check_values: Mapping[str, tuple[str, ...]] = field(default_factory=dict)
    indexes: tuple[Index, ...] = ()
    foreign_keys: tuple[ForeignKey, ...] = ()


def _c(name: str, type_: str, *, nullable: bool = False, default: str | None = None) -> Column:
    return Column(name, type_, nullable, default)


def _id() -> Column:
    return _c("id", "INTEGER")


_ACTIVE_DEPRECATED = ("active", "deprecated")

BUSINESS_PARTIES = Table(
    "business_parties",
    (
        _id(),
        _c("canonical_name", "VARCHAR(200)"),
        _c("legal_name", "VARCHAR(240)"),
        _c("status", "VARCHAR(30)"),
        _c("successor_party_id", "INTEGER", nullable=True),
        _c("created_at", "DATETIME"),
        _c("updated_at", "DATETIME"),
    ),
    uniques=(("uq_business_parties_canonical_name", ("canonical_name",)),),
    checks=(Check("ck_business_parties_status", "status", _ACTIVE_DEPRECATED),),
    foreign_keys=(ForeignKey("successor_party_id", "business_parties", "id", "RESTRICT"),),
    indexes=(Index("ix_business_parties_status_name", ("status", "canonical_name")),),
)

BUSINESS_PARTY_ROLES = Table(
    "business_party_roles",
    (
        _id(),
        _c("party_id", "INTEGER"),
        _c("role_key", "VARCHAR(40)"),
        _c("created_at", "DATETIME"),
    ),
    uniques=(("uq_business_party_roles_party_role", ("party_id", "role_key")),),
    foreign_keys=(ForeignKey("party_id", "business_parties", "id", "CASCADE"),),
    indexes=(Index("ix_business_party_roles_role_party", ("role_key", "party_id")),),
)

BUSINESS_PARTY_IDENTIFIERS = Table(
    "business_party_identifiers",
    (
        _id(),
        _c("party_id", "INTEGER"),
        _c("identifier_type", "VARCHAR(40)"),
        _c("normalized_value", "VARCHAR(80)"),
        _c("display_value", "VARCHAR(80)"),
        _c("status", "VARCHAR(30)", default="active"),
        _c("source_kind", "VARCHAR(60)"),
        _c("source_ref", "VARCHAR(240)"),
        _c("evidence_hash", "VARCHAR(64)"),
        _c("evidence_json", "TEXT"),
        _c("confirmed_by", "VARCHAR(120)"),
        _c("confirmed_at", "DATETIME", nullable=True),
        _c("created_at", "DATETIME"),
        _c("updated_at", "DATETIME"),
    ),
    uniques=(("uq_business_party_identifiers_type_value", ("identifier_type", "normalized_value")),),
    checks=(
        Check(
            "ck_business_party_identifiers_type",
            "identifier_type",
            ("tax_id", "unified_social_credit_code", "registration_no", "phone"),
        ),
        Check("ck_business_party_identifiers_status", "status", _ACTIVE_DEPRECATED),
    ),
    foreign_keys=(ForeignKey("party_id", "business_parties", "id", "CASCADE"),),
    indexes=(
        Index("ix_business_party_identifiers_party_status", ("party_id", "status")),
        Index("ix_business_party_identifiers_value_status", ("normalized_value", "status")),
    ),
)

BUSINESS_CONTACTS = Table(
    "business_contacts",
    (
        _id(),
        _c("party_id", "INTEGER"),
        _c("contact_name", "VARCHAR(120)"),
        _c("normalized_name", "VARCHAR(120)"),
        _c("contact_role", "VARCHAR(80)"),
        _c("email_domain", "VARCHAR(160)"),
        _c("source", "VARCHAR(160)"),
        _c("status", "VARCHAR(30)"),
        _c("created_at", "DATETIME"),
        _c("updated_at", "DATETIME"),
    ),
    uniques=(("uq_business_contacts_party_name", ("party_id", "normalized_name")),),
    checks=(Check("ck_business_contacts_status", "status", _ACTIVE_DEPRECATED),),
    foreign_keys=(ForeignKey("party_id", "business_parties", "id", "CASCADE"),),
    indexes=(Index("ix_business_contacts_normalized_name", ("normalized_name",)),),
)

# 产品类别（product_family）是通用列，取值由各客户配置；行业特有属性走客户扩展列。
PRODUCTS = Table(
    "products",
    (
        _id(),
        _c("canonical_name", "VARCHAR(160)"),
        _c("product_family", "VARCHAR(80)"),
        _c("status", "VARCHAR(30)"),
        _c("successor_product_id", "INTEGER", nullable=True),
        _c("created_at", "DATETIME"),
        _c("updated_at", "DATETIME"),
    ),
    uniques=(("uq_products_canonical_name", ("canonical_name",)),),
    checks=(Check("ck_products_status", "status", _ACTIVE_DEPRECATED),),
    foreign_keys=(ForeignKey("successor_product_id", "products", "id", "RESTRICT"),),
    indexes=(Index("ix_products_status_family", ("status", "product_family")),),
)

MEASUREMENT_UNITS = Table(
    "measurement_units",
    (
        _id(),
        _c("canonical_code", "VARCHAR(40)"),
        _c("display_name", "VARCHAR(60)"),
        _c("dimension", "VARCHAR(40)"),
        _c("factor_to_base", "NUMERIC", nullable=True),
        _c("status", "VARCHAR(30)"),
        _c("created_at", "DATETIME"),
        _c("updated_at", "DATETIME"),
    ),
    uniques=(("uq_measurement_units_code", ("canonical_code",)),),
    checks=(Check("ck_measurement_units_status", "status", _ACTIVE_DEPRECATED),),
    indexes=(Index("ix_measurement_units_dimension_status", ("dimension", "status")),),
)

# 别名能指向的主数据种类；客户扩展可追加（如规格、物料）。
ALIAS_ENTITY_TYPES = ("party", "product", "unit")

MASTER_DATA_ALIASES = Table(
    "master_data_aliases",
    (
        _id(),
        _c("entity_type", "VARCHAR(20)"),
        _c("entity_id", "INTEGER"),
        _c("alias_name", "VARCHAR(240)"),
        _c("normalized_alias", "VARCHAR(240)"),
        _c("source_scope", "VARCHAR(160)", default=""),
        _c("alias_status", "VARCHAR(30)"),
        _c("origin", "VARCHAR(160)"),
        _c("confidence", "NUMERIC", nullable=True),
        _c("evidence_json", "TEXT"),
        _c("confirmed_by", "VARCHAR(120)"),
        _c("confirmed_at", "DATETIME", nullable=True),
        _c("created_at", "DATETIME"),
    ),
    uniques=(
        ("uq_master_data_aliases_entity_identity", ("entity_type", "entity_id", "normalized_alias", "source_scope")),
    ),
    checks=(
        Check("ck_master_data_aliases_entity_type", "entity_type", ALIAS_ENTITY_TYPES),
        Check("ck_master_data_aliases_status", "alias_status", ("confirmed", "ambiguous", "deprecated")),
    ),
    indexes=(
        Index("ix_master_data_aliases_entity_status", ("entity_type", "entity_id", "alias_status")),
        Index(
            "uq_master_data_aliases_confirmed_wording",
            ("entity_type", "normalized_alias", "source_scope"),
            unique=True,
            where="alias_status = 'confirmed'",
        ),
    ),
)

MASTER_DATA_ALIAS_CANDIDATES = Table(
    "master_data_alias_candidates",
    (
        _id(),
        _c("domain", "VARCHAR(40)"),
        _c("raw_text", "VARCHAR(240)"),
        _c("normalized_text", "VARCHAR(240)"),
        _c("suggested_entity_type", "VARCHAR(40)"),
        _c("suggested_entity_id", "INTEGER", nullable=True),
        _c("suggested_canonical_name", "VARCHAR(240)"),
        _c("business_role", "VARCHAR(40)"),
        _c("source_kind", "VARCHAR(40)"),
        _c("source_id", "INTEGER", nullable=True),
        _c("source_key", "VARCHAR(240)"),
        _c("source_scope", "VARCHAR(160)"),
        _c("agent_name", "VARCHAR(80)"),
        _c("confidence", "NUMERIC", nullable=True),
        _c("strong_anchors_json", "TEXT"),
        _c("evidence_json", "TEXT"),
        _c("status", "VARCHAR(30)"),
        _c("reviewed_by", "VARCHAR(120)"),
        _c("reviewed_at", "DATETIME", nullable=True),
        _c("review_note", "TEXT"),
        _c("created_at", "DATETIME"),
        _c("updated_at", "DATETIME"),
    ),
    checks=(
        Check("ck_master_data_alias_candidates_domain", "domain", ALIAS_ENTITY_TYPES),
        Check(
            "ck_master_data_alias_candidates_status",
            "status",
            ("candidate", "confirmed", "rejected", "deprecated"),
        ),
    ),
    indexes=(
        Index("ix_master_data_alias_candidates_normalized", ("domain", "normalized_text")),
        Index("ix_master_data_alias_candidates_status_domain", ("status", "domain")),
        Index(
            "uq_master_data_alias_candidates_active_source",
            ("domain", "normalized_text", "source_key"),
            unique=True,
            where="status = 'candidate'",
        ),
    ),
)

MASTER_DATA_WRITE_INTENTS = Table(
    "master_data_write_intents",
    (
        _id(),
        _c("intent_key", "VARCHAR(80)"),
        _c("action", "VARCHAR(50)"),
        _c("domain", "VARCHAR(40)"),
        _c("raw_text", "VARCHAR(240)"),
        _c("normalized_text", "VARCHAR(240)"),
        _c("source_kind", "VARCHAR(60)"),
        _c("source_id", "INTEGER", nullable=True),
        _c("source_key", "VARCHAR(240)"),
        _c("source_hash", "VARCHAR(64)"),
        _c("payload_json", "TEXT"),
        _c("evidence_refs_json", "TEXT"),
        _c("evidence_hash", "VARCHAR(64)"),
        _c("preview_token", "VARCHAR(64)"),
        _c("selected_canonical_ref", "VARCHAR(80)"),
        _c("selected_entity_id", "INTEGER", nullable=True),
        _c("status", "VARCHAR(30)", default="previewed"),
        _c("owner", "VARCHAR(160)"),
        _c("requested_by", "VARCHAR(120)"),
        _c("applied_by", "VARCHAR(120)"),
        _c("governance_action_key", "VARCHAR(80)"),
        _c("error_text", "TEXT"),
        _c("created_at", "DATETIME"),
        _c("updated_at", "DATETIME"),
        _c("applied_at", "DATETIME", nullable=True),
    ),
    uniques=((None, ("intent_key",)),),
    checks=(
        Check(
            "ck_master_data_write_intents_action",
            "action",
            ("link_alias_to_existing", "enrich_party_profile", "create_supplier", "confirm_unit_alias"),
        ),
        Check("ck_master_data_write_intents_domain", "domain", ("party", "unit")),
        Check("ck_master_data_write_intents_status", "status", ("previewed", "applied", "rejected", "failed")),
    ),
    indexes=(
        Index("ix_master_data_write_intents_source", ("source_kind", "source_id")),
        Index("ix_master_data_write_intents_status_created", ("status", "created_at")),
    ),
)

# 主数据每次人工或规则处理的留痕：改名、改资料、合并、补角色等，记改前改后。
MASTER_DATA_GOVERNANCE_ACTIONS = Table(
    "master_data_governance_actions",
    (
        _id(),
        _c("action_key", "VARCHAR(80)"),
        _c("module_key", "VARCHAR(80)"),
        _c("source_kind", "VARCHAR(80)"),
        _c("source_field", "VARCHAR(80)"),
        _c("domain", "VARCHAR(40)"),
        _c("raw_text", "VARCHAR(240)"),
        _c("normalized_text", "VARCHAR(240)"),
        _c("selected_canonical_ref", "VARCHAR(80)"),
        _c("selected_entity_id", "INTEGER"),
        _c("selected_canonical_label", "VARCHAR(240)"),
        _c("affected_row_count", "INTEGER"),
        _c("affected_row_ids_json", "TEXT"),
        _c("projection_before_json", "TEXT"),
        _c("projection_after_json", "TEXT"),
        _c("status", "VARCHAR(30)"),
        _c("reviewed_by", "VARCHAR(120)"),
        _c("review_note", "TEXT"),
        _c("reverted_at", "DATETIME", nullable=True),
        _c("created_at", "DATETIME"),
    ),
    uniques=((None, ("action_key",)),),
    checks=(
        Check("ck_master_data_governance_actions_domain", "domain", ALIAS_ENTITY_TYPES),
        Check("ck_master_data_governance_actions_status", "status", ("applied", "reverted")),
    ),
    indexes=(
        Index("ix_master_data_governance_actions_source", ("module_key", "source_kind", "source_field")),
        Index("ix_master_data_governance_actions_target", ("domain", "selected_entity_id")),
    ),
)

# 每次把一种写法解析成主数据的记录（人工复核和 AI 提议都从这里追溯）。
MASTER_DATA_RESOLUTION_EVENTS = Table(
    "master_data_resolution_events",
    (
        _id(),
        _c("domain", "VARCHAR(40)"),
        _c("raw_text", "VARCHAR(240)"),
        _c("normalized_text", "VARCHAR(240)"),
        _c("canonical_entity_type", "VARCHAR(40)"),
        _c("canonical_entity_id", "INTEGER", nullable=True),
        _c("canonical_label", "VARCHAR(240)"),
        _c("resolution_method", "VARCHAR(60)"),
        _c("confidence", "NUMERIC", nullable=True),
        _c("evidence_refs_json", "TEXT"),
        _c("ambiguity_reasons_json", "TEXT"),
        _c("source_kind", "VARCHAR(40)"),
        _c("source_id", "INTEGER", nullable=True),
        _c("source_key", "VARCHAR(240)"),
        _c("agent_name", "VARCHAR(80)"),
        _c("decision_id", "INTEGER", nullable=True),
        _c("alias_candidate_id", "INTEGER", nullable=True),
        _c("status", "VARCHAR(30)"),
        _c("created_at", "DATETIME"),
    ),
    checks=(
        Check("ck_master_data_resolution_events_domain", "domain", ALIAS_ENTITY_TYPES),
        Check("ck_master_data_resolution_events_status", "status", ("resolved", "review", "new_entity_candidate")),
    ),
    foreign_keys=(ForeignKey("alias_candidate_id", "master_data_alias_candidates", "id", "SET NULL"),),
    indexes=(
        Index("ix_master_data_resolution_events_domain_created", ("domain", "created_at")),
        Index("ix_master_data_resolution_events_entity", ("canonical_entity_type", "canonical_entity_id")),
        Index("ix_master_data_resolution_events_source", ("source_kind", "source_id")),
    ),
)

STANDARD_TABLES: tuple[Table, ...] = (
    BUSINESS_PARTIES,
    BUSINESS_PARTY_ROLES,
    BUSINESS_PARTY_IDENTIFIERS,
    BUSINESS_CONTACTS,
    MASTER_DATA_ALIASES,
    MEASUREMENT_UNITS,
    PRODUCTS,
    MASTER_DATA_ALIAS_CANDIDATES,
    MASTER_DATA_WRITE_INTENTS,
    MASTER_DATA_GOVERNANCE_ACTIONS,
    MASTER_DATA_RESOLUTION_EVENTS,
)
STANDARD_TABLE_NAMES = tuple(table.name for table in STANDARD_TABLES)

# 通用可选表：外部系统编号 → 主数据。来源编号一字不差匹配，不套名称归一。
EXTERNAL_IDENTITIES_DDL = (
    """CREATE TABLE master_data_external_identities (
                resource_kind TEXT NOT NULL CHECK(resource_kind IN ('party', 'product', 'unit', 'location')),
                source_id TEXT NOT NULL,
                external_id TEXT NOT NULL,
                resource_id TEXT NOT NULL,
                alias TEXT NOT NULL,
                normalized_alias TEXT NOT NULL,
                status TEXT NOT NULL CHECK(status IN ('active', 'deprecated')),
                PRIMARY KEY(resource_kind, source_id, external_id)
            )""",
    """CREATE UNIQUE INDEX uq_master_data_external_alias
                ON master_data_external_identities(resource_kind, source_id, normalized_alias)
                WHERE normalized_alias <> '' AND status = 'active'""",
)


def extended_table(table: Table, extension: TableExtension | None) -> Table:
    """标准表并上客户扩展后的完整形状；扩展改动标准列或约束名时报错。"""

    if extension is None:
        return table
    if extension.table != table.name:
        raise ValueError(f"extension_table_mismatch:{extension.table}")
    standard = {column.name for column in table.columns}
    clashes = sorted(standard & {column.name for column in extension.columns})
    if clashes:
        raise ValueError(f"extension_redefines_standard_column:{table.name}:{clashes}")
    checks = {check.name: check for check in table.checks}
    unknown = sorted(set(extension.check_values) - set(checks))
    if unknown:
        raise ValueError(f"extension_check_unknown:{table.name}:{unknown}")
    widened = tuple(
        Check(check.name, check.column, check.values + tuple(
            value for value in extension.check_values.get(check.name, ()) if value not in check.values
        ))
        for check in table.checks
    )
    keyed = {key.column for key in table.foreign_keys}
    if keyed & {key.column for key in extension.foreign_keys}:
        raise ValueError(f"extension_redefines_standard_foreign_key:{table.name}")
    index_names = {index.name for index in table.indexes}
    if index_names & {index.name for index in extension.indexes}:
        raise ValueError(f"extension_redefines_standard_index:{table.name}")
    # 扩展列放在标准列里 status 之前的位置无关紧要：一致性按列名核对，不按顺序。
    return Table(
        table.name,
        table.columns + extension.columns,
        table.uniques,
        widened,
        table.foreign_keys + extension.foreign_keys,
        table.indexes + extension.indexes,
        table.primary_key,
    )


def _check_sql(check: Check) -> str:
    values = ", ".join(f"'{value}'" for value in check.values)
    return f"CONSTRAINT {check.name} CHECK ({check.column} IN ({values}))"


def create_table_sql(table: Table) -> tuple[str, ...]:
    """SQLite 建表语句（含索引）。"""

    lines = []
    for column in table.columns:
        text = f"{column.name} {column.type}"
        if column.server_default is not None:
            text += f" DEFAULT '{column.server_default}'"
        if not column.nullable:
            text += " NOT NULL"
        lines.append(text)
    lines.append(f"PRIMARY KEY ({table.primary_key})")
    for name, columns in table.uniques:
        prefix = f"CONSTRAINT {name} " if name else ""
        lines.append(f"{prefix}UNIQUE ({', '.join(columns)})")
    lines.extend(_check_sql(check) for check in table.checks)
    for key in table.foreign_keys:
        lines.append(
            f"FOREIGN KEY({key.column}) REFERENCES {key.ref_table} ({key.ref_column}) ON DELETE {key.ondelete}"
        )
    statements = [f"CREATE TABLE {table.name} (\n    " + ",\n    ".join(lines) + "\n)"]
    for index in table.indexes:
        unique = "UNIQUE " if index.unique else ""
        where = f" WHERE {index.where}" if index.where else ""
        statements.append(
            f"CREATE {unique}INDEX {index.name} ON {table.name} ({', '.join(index.columns)}){where}"
        )
    return tuple(statements)


def standard_schema_sql() -> tuple[str, ...]:
    return tuple(statement for table in STANDARD_TABLES for statement in create_table_sql(table))


_CHECK_PATTERN = re.compile(r"CONSTRAINT\s+(\w+)\s+CHECK\s*\(\s*(\w+)\s+IN\s*\(([^)]*)\)\s*\)", re.IGNORECASE)


def describe_sqlite_table(connection: sqlite3.Connection, name: str) -> dict[str, object]:
    """把库里一张表读成可比较的形状：列、主键、唯一约束、取值约束、外键、索引。"""

    row = connection.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name=?", (name,)).fetchone()
    if row is None:
        return {"missing": True}
    columns = {
        str(item[1]): (str(item[2]).upper(), bool(item[3]), None if item[4] is None else str(item[4]))
        for item in connection.execute(f"PRAGMA table_info({name})")
    }
    primary_key = tuple(str(item[1]) for item in sorted(
        (item for item in connection.execute(f"PRAGMA table_info({name})") if item[5]), key=lambda item: item[5]
    ))
    checks = {
        match.group(1): (match.group(2), frozenset(value.strip().strip("'") for value in match.group(3).split(",")))
        for match in _CHECK_PATTERN.finditer(str(row[0]))
    }
    foreign_keys = frozenset(
        (str(item[3]), str(item[2]), str(item[4]), str(item[6]).upper())
        for item in connection.execute(f"PRAGMA foreign_key_list({name})")
    )
    uniques = set()
    indexes = {}
    for item in connection.execute(f"PRAGMA index_list({name})"):
        index_name, unique, origin = str(item[1]), bool(item[2]), str(item[3])
        index_columns = tuple(str(col[2]) for col in connection.execute(f"PRAGMA index_info({index_name})"))
        if origin == "u":
            uniques.add(index_columns)
        elif origin == "c":
            sql = connection.execute("SELECT sql FROM sqlite_master WHERE type='index' AND name=?", (index_name,)).fetchone()
            where = ""
            if sql and sql[0] and " WHERE " in str(sql[0]).upper():
                where = " ".join(str(sql[0])[str(sql[0]).upper().rindex(" WHERE ") + 7:].split())
            indexes[index_name] = (index_columns, unique, where)
    return {
        "columns": columns,
        "primary_key": primary_key,
        "uniques": frozenset(uniques),
        "checks": checks,
        "foreign_keys": foreign_keys,
        "indexes": indexes,
    }


def table_conformance(
    connection: sqlite3.Connection,
    table: Table,
    extension: TableExtension | None = None,
) -> list[str]:
    """库里的表与“标准表 + 客户扩展”逐项比较；返回差异说明，空表示一致。"""

    expected_connection = sqlite3.connect(":memory:")
    try:
        for statement in create_table_sql(extended_table(table, extension)):
            expected_connection.execute(statement)
        expected = describe_sqlite_table(expected_connection, table.name)
    finally:
        expected_connection.close()
    actual = describe_sqlite_table(connection, table.name)
    if actual.get("missing"):
        return [f"{table.name}: table missing"]
    return [
        f"{table.name}.{key}: expected {expected[key]!r}, actual {actual[key]!r}"
        for key in ("columns", "primary_key", "uniques", "checks", "foreign_keys", "indexes")
        if expected[key] != actual[key]
    ]


__all__ = [
    "ALIAS_ENTITY_TYPES",
    "Check",
    "Column",
    "EXTERNAL_IDENTITIES_DDL",
    "ForeignKey",
    "Index",
    "STANDARD_TABLES",
    "STANDARD_TABLE_NAMES",
    "Table",
    "TableExtension",
    "create_table_sql",
    "describe_sqlite_table",
    "extended_table",
    "standard_schema_sql",
    "table_conformance",
]
