"""AI 写入请求的唯一负责方：Agent 只描述要做什么，归一、查冲突、证据闭合、幂等、
预览口令、写入和留痕都在这里。从不接受 Agent 给的 SQL 或表名。

动作：
- ``link_alias_to_existing`` / ``enrich_party_profile``：给已有往来方补写法、全称、联系人、号码；
- ``create_supplier``：新建供应商（名称或号码已指向现有往来方时拒收，改为补链）；
- ``confirm_unit_alias``：确认一个单位写法；
- 客户自有动作（如新建物料）经 ``policy.extra_intent_actions`` 挂进来。

同一来源、同一写法、同一组证据只算一个请求（``intent_key``）；已执行过再来，来源指纹一致
就原样返回当时的结果，不一致拒收。全部在调用方的事务里写，不提交。
"""

from __future__ import annotations

import hashlib
import json
import sqlite3
import uuid
from typing import Any, Mapping

from . import commands, lookup, writes
from .contracts import storage_timestamp
from .matching import normalize_identity
from .policy import DEFAULT_POLICY, MasterDataPolicy
from .public import MasterDataError

CONTRACT_VERSION = "bizhub-master-data-write-intent.v1"
OWNER = "backend/modules/master_data/intents.py:apply_write_intent"
STANDARD_ACTIONS = frozenset({"link_alias_to_existing", "enrich_party_profile", "create_supplier", "confirm_unit_alias"})


def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)


def _sha(value: Any) -> str:
    return hashlib.sha256(_json(value).encode()).hexdigest()


def intent_key(*, action: str, source_key: str, normalized_text: str, evidence_refs: list[str]) -> str:
    return "mdi-" + _sha({"action": action, "sourceKey": source_key, "rawText": normalized_text,
                          "evidenceRefsHash": _sha(evidence_refs)})[:48]


def _canonical_ref(value: Any, expected: str) -> int:
    prefix, separator, raw_id = str(value or "").strip().partition(":")
    if prefix != expected or separator != ":" or not raw_id.isdigit():
        raise MasterDataError("master_data_intent_ref_invalid", f"{expected} canonical reference is invalid")
    return int(raw_id)


def _identifiers(value: Any, policy: MasterDataPolicy) -> list[dict[str, str]]:
    drafts: dict[tuple[str, str], dict[str, str]] = {}
    for item in value or []:
        if not isinstance(item, Mapping):
            raise MasterDataError("master_data_identifier_invalid", "identifier must be an object")
        identifier_type = str(item.get("identifierType") or item.get("identifier_type") or "").strip()
        display = str(item.get("value") or "").strip()[:80]
        normalized = writes.normalize_party_identifier(identifier_type, display, policy)
        if not normalized:
            raise MasterDataError("master_data_identifier_value_invalid", identifier_type)
        drafts[(identifier_type, normalized)] = {"identifierType": identifier_type, "value": display,
                                                 "normalizedValue": normalized}
    return sorted(drafts.values(), key=lambda item: (item["identifierType"], item["normalizedValue"]))


def catalog_snapshot(connection: sqlite3.Connection, policy: MasterDataPolicy) -> dict[str, int]:
    count = lambda table: int(connection.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0])  # noqa: E731
    return {"partyCount": count("business_parties"), "identifierCount": count("business_party_identifiers"),
            **policy.extra_catalog_counts(connection), "unitCount": count("measurement_units")}


def _assert_identifiers_free(connection: sqlite3.Connection, identifiers: list[dict[str, str]], party_id: int | None) -> None:
    for item in identifiers:
        row = connection.execute(
            """SELECT party_id FROM business_party_identifiers WHERE status='active' AND identifier_type=?
               AND normalized_value=?""", (item["identifierType"], item["normalizedValue"])).fetchone()
        if row is not None and (party_id is None or int(row[0]) != party_id):
            raise MasterDataError("master_data_identifier_owned_by_other", item["identifierType"])


def _profile_change(raw_text: str, attrs: Mapping[str, Any], party: Mapping[str, Any], legal_name: str,
                    identifiers: list[dict[str, str]], reviewer: str, review_note: str) -> commands.MasterDataChange:
    return commands.MasterDataChange("party_profile", {
        "party_id": int(party["id"]),
        "canonical_name": str(attrs.get("canonicalName") or party["canonical_name"]),
        "legal_name": legal_name,
        "aliases": list(dict.fromkeys([raw_text, *[str(v).strip() for v in attrs.get("aliases") or [] if str(v).strip()]])),
        "contact_name": str(attrs.get("contactName") or ""),
        "contact_role": str(attrs.get("contactRole") or "业务联系人"),
        "business_role": str(attrs.get("businessRole") or "supplier"),
        "identifiers": [{"identifier_type": item["identifierType"], "value": item["value"]} for item in identifiers],
    }, reviewer=reviewer, review_note=review_note)


def preview_write_intent(
    connection: sqlite3.Connection,
    *,
    action: str,
    raw_text: str,
    attributes: Mapping[str, Any],
    selected_canonical_ref: str | None,
    evidence_refs: list[str],
    source_kind: str,
    source_id: int | None,
    source_key: str,
    source_hash: str,
    requested_by: str,
    server_verified_evidence: Mapping[str, Any] | None = None,
    policy: MasterDataPolicy = DEFAULT_POLICY,
) -> dict[str, Any]:
    """核对一个请求，不改任何正式数据。"""

    action = str(action or "").strip()
    if action not in STANDARD_ACTIONS | set(policy.extra_intent_actions):
        raise MasterDataError("master_data_intent_action_invalid", action)
    raw_text = str(raw_text or "").strip()[:240]
    source_key = str(source_key or "").strip()[:240]
    source_hash = str(source_hash or "").strip()
    requested_by = str(requested_by or "").strip()[:120]
    if not raw_text or not source_key or len(source_hash) != 64:
        raise MasterDataError("master_data_intent_source_incomplete", "raw text, source key and source hash are required")
    refs = sorted(dict.fromkeys(str(value).strip()[:240] for value in evidence_refs))
    if not refs:
        raise MasterDataError("master_data_intent_evidence_required", action)
    attrs = dict(attributes or {})
    verified = dict(server_verified_evidence or {})
    normalized = normalize_identity(raw_text)
    key = intent_key(action=action, source_key=source_key, normalized_text=normalized, evidence_refs=refs)
    existing = writes._one(connection, "SELECT * FROM master_data_write_intents WHERE intent_key=?", (key,))
    base = {"contractVersion": CONTRACT_VERSION, "action": action, "rawText": raw_text, "normalizedText": normalized,
            "sourceKind": source_kind, "sourceId": source_id, "sourceKey": source_key, "sourceHash": source_hash,
            "requestedBy": requested_by, "owner": OWNER,
            "writeBoundary": "formal party/material/unit identity and confirmed aliases only"}
    if existing is not None:
        if existing["source_hash"] != source_hash:
            raise MasterDataError("master_data_intent_idempotency_conflict", key)
        if existing["status"] != "applied":
            raise MasterDataError("master_data_intent_not_applied", key)
        return {**base, "intentKey": key, "previewToken": existing["preview_token"], "domain": existing["domain"],
                "selectedCanonicalRef": existing["selected_canonical_ref"], "selectedEntityId": existing["selected_entity_id"],
                "attributes": attrs, "evidence": {"evidenceRefs": json.loads(existing["evidence_refs_json"] or "[]"),
                                                  "idempotentReplay": True},
                "evidenceHash": existing["evidence_hash"], "catalogBefore": catalog_snapshot(connection, policy),
                "idempotentReplay": True}
    catalog_before = catalog_snapshot(connection, policy)
    selected_ref = str(selected_canonical_ref or "").strip()
    selected_id: int | None = None
    invoice_ids: list[int] = []
    if action in policy.extra_intent_actions:
        domain, selected_id, attrs = policy.extra_intent_actions[action][0](
            connection, raw_text=raw_text, attributes=attrs, selected_canonical_ref=selected_ref,
            server_verified_evidence=verified, policy=policy)
    elif action in {"link_alias_to_existing", "enrich_party_profile"}:
        domain = "party"
        selected_id = _canonical_ref(selected_ref, "party")
        party = writes.require_active(connection, "party", selected_id)
        role = str(attrs.get("businessRole") or "supplier").strip()
        if connection.execute("SELECT 1 FROM business_party_roles WHERE party_id=? AND role_key=?",
                              (selected_id, role)).fetchone() is None:
            raise MasterDataError("master_data_role_missing", f"party:{selected_id}:{role}")
        identifiers = _identifiers(attrs.get("identifiers"), policy)
        _assert_identifiers_free(connection, identifiers, selected_id)
        legal = str(attrs.get("legalName") or party["legal_name"] or "").strip()
        invoice_ids = policy.supplier_identifier_evidence(connection, legal, identifiers)
        change = _profile_change(raw_text, attrs, party, legal, identifiers, requested_by or "agent", "")
        attrs["_partyProfilePlan"] = commands._plan(connection, change, policy)
    elif action == "create_supplier":
        domain = "party"
        if selected_ref:
            raise MasterDataError("master_data_intent_ref_invalid", "create_supplier cannot select an existing party")
        canonical = str(attrs.get("canonicalName") or raw_text).strip()[:200]
        legal = str(attrs.get("legalName") or canonical).strip()[:240]
        identifiers = _identifiers(attrs.get("identifiers"), policy)
        _assert_identifiers_free(connection, identifiers, None)
        for wording in dict.fromkeys(item for item in (canonical, legal) if item):
            found = lookup.resolve(connection, "party", wording,
                                   context={"identity_values": [item["normalizedValue"] for item in identifiers]},
                                   policy=policy)
            if found.status not in {"new", "invalid"}:
                raise MasterDataError("master_data_party_exists", "supplier has an existing formal candidate; link instead")
        invoice_ids = policy.supplier_identifier_evidence(connection, legal, identifiers)
        exact_contract = bool(verified.get("exactContractParty") or verified.get("managementPreviewApply"))
        if policy.require_supplier_identifier_evidence:
            if identifiers and not invoice_ids and not exact_contract:
                raise MasterDataError("master_data_intent_evidence_missing", "identifier lacks formal invoice or contract evidence")
            if not identifiers and not exact_contract:
                raise MasterDataError("master_data_intent_evidence_missing", "new supplier needs a tax identifier or contract evidence")
        attrs.update({"canonicalName": canonical, "legalName": legal, "identifiers": identifiers, "roles": ["supplier"]})
    else:
        domain = "unit"
        selected_id = _canonical_ref(selected_ref, "unit")
        writes.require_active(connection, "unit", selected_id)
        found = lookup.resolve(connection, "unit", raw_text, policy=policy)
        if set(found.candidate_ids) - {selected_id}:
            raise MasterDataError("master_data_alias_owned_by_other", "unit wording names another unit")
    evidence = {"evidenceRefs": refs, "formalTaxInvoiceIds": invoice_ids, "serverVerified": verified}
    stable = {"action": action, "domain": domain, "rawText": raw_text, "normalizedText": normalized,
              "selectedCanonicalRef": selected_ref, "attributes": attrs, "sourceKind": source_kind, "sourceId": source_id,
              "sourceKey": source_key, "sourceHash": source_hash, "evidence": evidence, "catalogBefore": catalog_before}
    return {**base, "intentKey": key, "previewToken": _sha(stable), "domain": domain,
            "selectedCanonicalRef": selected_ref or None, "selectedEntityId": selected_id, "attributes": attrs,
            "evidence": evidence, "evidenceHash": _sha(evidence), "catalogBefore": catalog_before}


def record_applied_intent(
    connection: sqlite3.Connection, *, intent_key: str, action: str, domain: str, raw_text: str, normalized_text: str,
    source_kind: Any, source_id: Any, source_key: Any, source_hash: Any, payload: Any, evidence_refs: Any,
    evidence_hash: str, preview_token: str, selected_canonical_ref: str, selected_entity_id: Any, owner: str,
    requested_by: str, applied_by: str, governance_action_key: str,
) -> None:
    """写入请求执行完后留下的那一行（同一请求再来时据此原样返回）。"""

    now = storage_timestamp()
    connection.execute(
        """INSERT INTO master_data_write_intents
           (intent_key, action, domain, raw_text, normalized_text, source_kind, source_id, source_key, source_hash,
            payload_json, evidence_refs_json, evidence_hash, preview_token, selected_canonical_ref, selected_entity_id,
            status, owner, requested_by, applied_by, governance_action_key, error_text, created_at, updated_at, applied_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'applied', ?, ?, ?, ?, '', ?, ?, ?)""",
        (intent_key, action, domain, raw_text, normalized_text, source_kind, source_id, source_key, source_hash,
         _json(payload), _json(evidence_refs), evidence_hash, preview_token, selected_canonical_ref, selected_entity_id,
         owner, requested_by, applied_by, governance_action_key, now, now, now),
    )


def apply_write_intent(
    connection: sqlite3.Connection,
    *,
    preview_token: str,
    applied_by: str,
    review_note: str,
    policy: MasterDataPolicy = DEFAULT_POLICY,
    **request: Any,
) -> dict[str, Any]:
    """按预览口令执行一个请求，返回它落到的正式对象。"""

    action = str(request.get("action") or "").strip()
    raw_text = str(request.get("raw_text") or "").strip()
    refs = sorted(dict.fromkeys(str(value).strip()[:240] for value in request.get("evidence_refs") or []))
    key = intent_key(action=action, source_key=str(request.get("source_key") or "").strip()[:240],
                     normalized_text=normalize_identity(raw_text), evidence_refs=refs)
    existing = writes._one(connection, "SELECT * FROM master_data_write_intents WHERE intent_key=?", (key,))
    if existing is not None:
        if existing["source_hash"] != str(request.get("source_hash") or "").strip() or existing["preview_token"] != preview_token:
            raise MasterDataError("master_data_intent_idempotency_conflict", key)
        if existing["status"] != "applied":
            raise MasterDataError("master_data_intent_not_applied", key)
        return {"contractVersion": CONTRACT_VERSION, "intentKey": key, "status": "applied",
                "selectedCanonicalRef": existing["selected_canonical_ref"], "entityId": existing["selected_entity_id"],
                "idempotentReplay": True}
    preview = preview_write_intent(connection, policy=policy, **request)
    if preview_token != preview["previewToken"]:
        raise MasterDataError("master_data_state_generation_drift", "master-data intent changed after preview")
    attrs = dict(preview["attributes"])
    selected_ref = str(preview.get("selectedCanonicalRef") or "")
    selected_id = preview.get("selectedEntityId")
    action_key = f"mdg-{uuid.uuid4().hex}"
    if action in policy.extra_intent_actions:
        outcome = policy.extra_intent_actions[action][1](connection, preview=preview, applied_by=applied_by,
                                                         review_note=review_note, action_key=action_key, policy=policy)
        selected_ref, selected_id = outcome["selectedCanonicalRef"], outcome["entityId"]
    elif action in {"link_alias_to_existing", "enrich_party_profile"}:
        plan = attrs.pop("_partyProfilePlan")
        party = writes.require_active(connection, "party", int(selected_id))
        identifiers = _identifiers(attrs.get("identifiers"), policy)
        change = _profile_change(raw_text, attrs, party, plan.get("after", {}).get("legal_name", party["legal_name"]),
                                 identifiers, applied_by, review_note)
        result = commands.apply_change_in_transaction(
            connection, commands.preview_change_in_transaction(connection, change, policy=policy), policy=policy)
        action_key = str(result.get("action_key") or action_key)
    elif action == "create_supplier":
        selected_id = writes.create_party(connection, canonical_name=attrs["canonicalName"], legal_name=attrs["legalName"],
                                          roles=["supplier"])
        selected_ref = f"party:{selected_id}"
        for index, alias in enumerate(dict.fromkeys([raw_text, attrs["legalName"], *[str(v) for v in attrs.get("aliases") or []]])):
            if str(alias).strip():
                writes.remember_confirmed_alias(connection, domain="party", raw_text=str(alias), entity_id=selected_id,
                                                business_role="supplier", source_scope="", reviewer=applied_by,
                                                source_key=f"{preview['intentKey']}:alias:{index}", review_note=review_note,
                                                policy=policy)
        for item in attrs["identifiers"]:
            writes.upsert_identifier(connection, party_id=selected_id, identifier_type=item["identifierType"],
                                     value=item["value"], source_kind="master_data_write_intent", source_ref=action_key,
                                     evidence=preview["evidence"], confirmed_by=applied_by, policy=policy)
        action_key = writes.record_governance_action(
            connection, domain="party", entity_id=selected_id, label=attrs["canonicalName"], raw_text=raw_text,
            source_kind=str(request.get("source_kind") or ""), source_field="create_supplier",
            before=preview["catalogBefore"], after=catalog_snapshot(connection, policy), reviewer=applied_by,
            review_note=review_note, action_key=action_key)
    else:
        writes.remember_confirmed_alias(connection, domain="unit", raw_text=raw_text, entity_id=int(selected_id),
                                        business_role="", source_scope="", reviewer=applied_by,
                                        source_key=f"{preview['intentKey']}:alias", review_note=review_note, policy=policy)
        unit = writes.entity_row(connection, "unit", int(selected_id))
        action_key = writes.record_governance_action(
            connection, domain="unit", entity_id=int(selected_id), label=unit["display_name"] if unit else "",
            raw_text=raw_text, source_kind=str(request.get("source_kind") or ""), source_field="confirm_unit_alias",
            before=preview["catalogBefore"], after=catalog_snapshot(connection, policy), reviewer=applied_by,
            review_note=review_note, action_key=action_key)
    record_applied_intent(
        connection, intent_key=preview["intentKey"], action=action, domain=preview["domain"], raw_text=raw_text,
        normalized_text=preview["normalizedText"], source_kind=request.get("source_kind"),
        source_id=request.get("source_id"), source_key=request.get("source_key"), source_hash=request.get("source_hash"),
        payload={"attributes": attrs, "selectedCanonicalRef": selected_ref}, evidence_refs=request.get("evidence_refs") or [],
        evidence_hash=preview["evidenceHash"], preview_token=preview_token, selected_canonical_ref=selected_ref,
        selected_entity_id=selected_id, owner=OWNER, requested_by=preview["requestedBy"], applied_by=applied_by,
        governance_action_key=action_key,
    )
    return {"contractVersion": CONTRACT_VERSION, "intentKey": preview["intentKey"], "status": "applied",
            "selectedCanonicalRef": selected_ref, "entityId": selected_id, "governanceActionKey": action_key,
            "idempotentReplay": False}


__all__ = ["CONTRACT_VERSION", "OWNER", "STANDARD_ACTIONS", "apply_write_intent", "catalog_snapshot", "intent_key",
           "preview_write_intent", "record_applied_intent"]
