"""AI 提议 → 人确认：Agent 选中的主数据先过闸，过不了就记成待确认，等人点头才生效。

- ``preview_resolution``：按服务端候选核对 Agent 的选择，留一条解析记录；没过闸且选了
  现有对象时记一条“待确认名称”，完全没有候选时记一条“新对象候选”；以前被驳回过的同一
  映射不再提；
- ``remember_resolutions``：业务写成功后，把错字容忍解析到的写法记成别名（各自保存点，
  撞了只跳过这一条）；
- ``confirm_alias_candidate`` / ``reject_alias_candidate``：人确认或驳回待确认名称；
- ``attach_candidate_to_new_entity``：为“新对象候选”建好正式对象后把它挂上并确认。

全部在调用方的事务里写，不提交。
"""

from __future__ import annotations

import json
import sqlite3
from decimal import Decimal
from typing import Any, Iterable, Mapping

from . import lookup, writes
from .contracts import storage_timestamp
from .matching import normalize_identity, resolution_gate_reasons, resolve_server_selection
from .policy import DEFAULT_POLICY, MasterDataPolicy
from .public import MasterDataError

STRONG_ANCHOR_TYPES = frozenset(
    {"formal_contact", "po_customer_relation", "confirmed_email_domain", "source_mapping", "existing_business_relation"}
)
ALIAS_CANDIDATE_STATUSES = frozenset({"candidate", "confirmed", "rejected", "deprecated"})


def _dump(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _load(value: Any, fallback: Any) -> Any:
    try:
        return json.loads(value or "")
    except (TypeError, ValueError):
        return fallback


def _decimal_text(value: Any) -> str | None:
    return None if value in (None, "") else str(Decimal(str(value)))


def verified_strong_anchor_types(
    connection: sqlite3.Connection, *, domain: str, selected: Mapping[str, Any] | None, strong_anchors: Iterable[Any],
) -> set[str]:
    """只认能用正式关系证明的锚点（联系人、联系人邮箱域名），不信 Agent 自报的标签。"""

    if domain != "party" or selected is None:
        return set()
    party_id = int(selected["entityId"])
    verified: set[str] = set()
    for anchor in strong_anchors:
        if not isinstance(anchor, Mapping):
            continue
        anchor_type = str(anchor.get("type") or "").strip()
        evidence_ref = str(anchor.get("evidenceRef") or "").strip()
        if anchor_type not in STRONG_ANCHOR_TYPES or not evidence_ref:
            continue
        prefix, separator, raw = evidence_ref.partition(":")
        if anchor_type == "formal_contact" and prefix == "contact" and separator and raw.isdigit():
            row = connection.execute("SELECT party_id, status FROM business_contacts WHERE id=?", (int(raw),)).fetchone()
            if row is not None and row[1] == "active" and int(row[0]) == party_id:
                verified.add(anchor_type)
        elif anchor_type == "confirmed_email_domain" and prefix == "email-domain" and separator:
            wanted = normalize_identity(raw)
            domains = [row[0] for row in connection.execute(
                "SELECT email_domain FROM business_contacts WHERE party_id=? AND status='active'", (party_id,))]
            if wanted and any(normalize_identity(item) == wanted for item in domains if item):
                verified.add(anchor_type)
    return verified


def _upsert_candidate(
    connection: sqlite3.Connection, *, domain: str, raw_text: str, normalized_text: str, selected: Mapping[str, Any] | None,
    business_role: str, source_kind: str, source_id: int | None, source_key: str, source_scope: str, agent_name: str,
    confidence: Any, strong_anchors: list[Any], verified_anchor_types: set[str], evidence_refs: list[str],
) -> int:
    row = connection.execute(
        """SELECT id FROM master_data_alias_candidates WHERE domain=? AND normalized_text=? AND source_key=?
           AND status='candidate'""",
        (domain, normalized_text, source_key),
    ).fetchone()
    now = storage_timestamp()
    values = (
        selected["entityId"] if selected else None, selected["canonicalLabel"] if selected else "", business_role,
        source_kind, source_id, source_scope, agent_name, _decimal_text(confidence), _dump(strong_anchors),
        _dump({"evidenceRefs": evidence_refs, "verifiedStrongAnchorTypes": sorted(verified_anchor_types)}), now,
    )
    if row is None:
        cursor = connection.execute(
            """INSERT INTO master_data_alias_candidates
               (suggested_entity_id, suggested_canonical_name, business_role, source_kind, source_id, source_scope,
                agent_name, confidence, strong_anchors_json, evidence_json, updated_at,
                domain, raw_text, normalized_text, suggested_entity_type, source_key, status, reviewed_by, review_note,
                created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'candidate', '', '', ?)""",
            (*values, domain, raw_text, normalized_text, domain, source_key, now),
        )
        return int(cursor.lastrowid)
    connection.execute(
        """UPDATE master_data_alias_candidates SET suggested_entity_id=?, suggested_canonical_name=?, business_role=?,
           source_kind=?, source_id=?, source_scope=?, agent_name=?, confidence=?, strong_anchors_json=?,
           evidence_json=?, updated_at=? WHERE id=?""",
        (*values, int(row[0])),
    )
    return int(row[0])


def preview_resolution(
    connection: sqlite3.Connection,
    *,
    domain: str,
    raw_text: str,
    selected_canonical_ref: str | None,
    confidence: float | None,
    resolution_method: str,
    strong_anchors: list[Any],
    evidence_refs: list[str],
    ambiguity_reasons: list[str],
    source_kind: str,
    source_id: int | None,
    source_key: str,
    source_scope: str,
    business_role: str,
    agent_name: str,
    identity_values: list[str] | None = None,
    decision_id: int | None = None,
    server_verified_anchor_types: set[str] | None = None,
    policy: MasterDataPolicy = DEFAULT_POLICY,
) -> dict[str, Any]:
    found = lookup.search(connection, domain=domain, raw_text=raw_text, role=business_role, source_scope=source_scope,
                          identity_values=identity_values, policy=policy)
    candidates = found["candidates"]
    selected, server_exact, exact_selected = resolve_server_selection(
        candidates=candidates, selected_canonical_ref=selected_canonical_ref,
        exact_match_methods=lookup.SERVER_EXACT_MATCH_METHODS,
    )
    # 服务端用正式关系算出的锚点与 Agent 自报的锚点分开：Agent 不能给自己的模糊映射授权。
    verified = set(server_verified_anchor_types or set())
    if server_exact:
        verified.add("exact_party_identifier" if selected["matchMethod"] == "confirmed_identifier" else f"exact_{domain}_catalog")
    if not exact_selected:
        verified |= verified_strong_anchor_types(connection, domain=domain, selected=selected, strong_anchors=strong_anchors)
    gate, server_exact, selected, exact_selected = resolution_gate_reasons(
        selected=selected, server_selected_exact=server_exact, selected_canonical_ref=selected_canonical_ref,
        candidates=candidates, ambiguity_reasons=ambiguity_reasons, exact_match_methods=lookup.SERVER_EXACT_MATCH_METHODS,
        confidence=confidence, verified_anchor_types=verified,
    )
    status = "resolved" if not gate else ("new_entity_candidate" if not candidates else "review")
    normalized_raw = normalize_identity(raw_text)
    candidate_id: int | None = None
    rejected = None
    if selected and not exact_selected:
        rejected = connection.execute(
            """SELECT id FROM master_data_alias_candidates WHERE domain=? AND normalized_text=? AND suggested_entity_id=?
               AND status='rejected' ORDER BY id LIMIT 1""",
            (domain, normalized_raw, selected["entityId"]),
        ).fetchone()
        if rejected is not None:
            gate.append("alias_mapping_previously_rejected")
            status = "review"
    common = dict(domain=domain, raw_text=raw_text, normalized_text=normalized_raw, business_role=business_role,
                  source_kind=source_kind, source_id=source_id, source_key=source_key, source_scope=source_scope,
                  agent_name=agent_name, confidence=confidence, strong_anchors=strong_anchors,
                  verified_anchor_types=verified, evidence_refs=evidence_refs)
    if selected and not exact_selected and rejected is None:
        candidate_id = _upsert_candidate(connection, selected=selected, **common)
    elif not candidates:
        candidate_id = _upsert_candidate(connection, selected=None, **common)
    if server_exact:
        method = ("server_exact_party_identifier" if selected and selected["matchMethod"] == "confirmed_identifier"
                  else f"server_exact_{domain}_catalog")
    else:
        method = resolution_method or (selected["matchMethod"] if selected else "new_entity_candidate")
    cursor = connection.execute(
        """INSERT INTO master_data_resolution_events
           (domain, raw_text, normalized_text, canonical_entity_type, canonical_entity_id, canonical_label,
            resolution_method, confidence, evidence_refs_json, ambiguity_reasons_json, source_kind, source_id,
            source_key, agent_name, decision_id, alias_candidate_id, status, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (domain, raw_text, found["normalizedText"], domain if selected else "", selected["entityId"] if selected else None,
         selected["canonicalLabel"] if selected else "", method, _decimal_text(confidence), _dump(evidence_refs),
         _dump(ambiguity_reasons + gate), source_kind, source_id, source_key, agent_name, decision_id, candidate_id,
         status, storage_timestamp()),
    )
    return {
        "contractVersion": lookup.CONTRACT_VERSION,
        "resolutionEventId": int(cursor.lastrowid),
        "domain": domain,
        "rawText": raw_text,
        "candidates": candidates,
        "selectedCanonicalRef": selected["canonicalRef"] if selected else None,
        "selectedCanonicalLabel": selected["canonicalLabel"] if selected else None,
        "attributes": selected["attributes"] if selected else {},
        "confidence": confidence,
        "resolutionMethod": method,
        "evidenceRefs": evidence_refs,
        "ambiguityReasons": ambiguity_reasons,
        "aliasCandidateRef": candidate_id,
        "gate": {"allowed": not gate, "reasons": gate, "verifiedStrongAnchorTypes": sorted(verified)},
        "resolutionStatus": status,
    }


def remember_resolutions(
    connection: sqlite3.Connection,
    entries: Iterable[Mapping[str, Any]] | None,
    *,
    source_ref: str,
    reviewer: str = "master_data_resolver",
    policy: MasterDataPolicy = DEFAULT_POLICY,
) -> list[dict[str, Any]]:
    """业务写成功后，把错字容忍解析到的往来方写法记成别名；撞了只跳过这一条。"""

    outcomes: list[dict[str, Any]] = []
    for entry in entries or []:
        if str(entry.get("domain") or "") != "party":
            continue
        raw_text = str(entry.get("raw_text") or "").strip()
        evidence = {**dict(entry.get("evidence") or {}), "origin": policy.fuzzy_alias_origin, "sourceRef": source_ref}
        connection.execute("SAVEPOINT master_data_remember")
        try:
            decision = writes.party_alias_identity(connection, party_id=int(entry["entity_id"]), raw_text=raw_text,
                                                   policy=policy)
            if decision["action"] == "create_identity":
                outcome = writes.record_alias(
                    connection, entity_type="party", entity_id=int(entry["entity_id"]), alias_name=raw_text,
                    origin=policy.fuzzy_alias_origin, evidence=evidence, confirmed_by=reviewer, policy=policy,
                )
                decision = {**decision, "alias_id": outcome["alias_id"]}
        except (MasterDataError, sqlite3.IntegrityError) as exc:
            connection.execute("ROLLBACK TO master_data_remember")
            connection.execute("RELEASE master_data_remember")
            outcomes.append({"raw_text": raw_text, "action": "skipped", "reason": str(exc)})
            continue
        connection.execute("RELEASE master_data_remember")
        outcomes.append({"raw_text": raw_text, **decision})
    return outcomes


def candidate_payload(row: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "id": row["id"], "domain": row["domain"], "rawText": row["raw_text"], "normalizedText": row["normalized_text"],
        "suggestedEntityType": row["suggested_entity_type"], "suggestedEntityId": row["suggested_entity_id"],
        "suggestedCanonicalName": row["suggested_canonical_name"], "businessRole": row["business_role"],
        "sourceKind": row["source_kind"], "sourceId": row["source_id"], "sourceKey": row["source_key"],
        "sourceScope": row["source_scope"], "agentName": row["agent_name"],
        "confidence": float(row["confidence"]) if row["confidence"] is not None else None,
        "strongAnchors": _load(row["strong_anchors_json"], []), "evidence": _load(row["evidence_json"], {}),
        "status": row["status"], "reviewedBy": row["reviewed_by"], "reviewedAt": row["reviewed_at"],
        "reviewNote": row["review_note"], "createdAt": row["created_at"],
    }


def list_alias_candidates(
    connection: sqlite3.Connection, *, status: str = "candidate", domain: str | None = None, limit: int = 100,
) -> list[dict[str, Any]]:
    if status not in ALIAS_CANDIDATE_STATUSES:
        raise MasterDataError("master_data_candidate_status_invalid", status)
    sql = "SELECT * FROM master_data_alias_candidates WHERE status=?"
    params: list[Any] = [status]
    if domain:
        sql += " AND domain=?"
        params.append(domain)
    sql += " ORDER BY created_at DESC, id DESC LIMIT ?"
    params.append(max(1, min(500, int(limit))))
    return [candidate_payload(row) for row in writes._all(connection, sql, params)]


def _pending(connection: sqlite3.Connection, candidate_id: int) -> dict[str, Any]:
    row = writes._one(connection, "SELECT * FROM master_data_alias_candidates WHERE id=?", (int(candidate_id),))
    if row is None:
        raise MasterDataError("master_data_candidate_missing", str(candidate_id))
    if row["status"] != "candidate":
        raise MasterDataError("master_data_candidate_not_pending", str(candidate_id))
    return row


def promote_candidate(connection: sqlite3.Connection, row: Mapping[str, Any], *, reviewer: str,
                      policy: MasterDataPolicy = DEFAULT_POLICY) -> None:
    """把一条待确认名称的写法记成它所指对象的别名（往来方走写法身份判断）。"""

    domain, entity_id = str(row["domain"]), int(row["suggested_entity_id"])
    if domain == "party":
        decision = writes.party_alias_identity(connection, party_id=entity_id, raw_text=row["raw_text"], policy=policy)
        if decision["action"] != "create_identity":
            return
        evidence = _load(row["evidence_json"], {})
        if not isinstance(evidence, dict):
            evidence = {"evidence": evidence}
        if str(row["business_role"] or "").strip():
            evidence.setdefault("role_hint", str(row["business_role"]).strip())
        writes.record_alias(connection, entity_type="party", entity_id=entity_id, alias_name=row["raw_text"],
                            source_scope=row["source_scope"] or "", origin=f"alias_candidate:{row['id']}",
                            confidence=row["confidence"], evidence=evidence, confirmed_by=reviewer, policy=policy)
        return
    writes.record_alias(connection, entity_type=domain, entity_id=entity_id, alias_name=row["raw_text"],
                        source_scope=(row["source_scope"] or "") if domain == "product" else "",
                        origin=f"alias_candidate:{row['id']}", confidence=row["confidence"],
                        evidence=row["evidence_json"] or "{}", confirmed_by=reviewer, policy=policy)


def _mark(connection: sqlite3.Connection, candidate_id: int, status: str, *, reviewer: str, review_note: str) -> None:
    connection.execute(
        "UPDATE master_data_alias_candidates SET status=?, reviewed_by=?, reviewed_at=?, review_note=?, updated_at=? WHERE id=?",
        (status, reviewer, storage_timestamp(), review_note, storage_timestamp(), int(candidate_id)),
    )


def confirm_alias_candidate(connection: sqlite3.Connection, *, candidate_id: int, reviewer: str, review_note: str = "",
                            policy: MasterDataPolicy = DEFAULT_POLICY) -> dict[str, Any]:
    row = _pending(connection, candidate_id)
    if row["suggested_entity_id"] is None:
        raise MasterDataError("master_data_candidate_needs_entity", "create the formal entity first")
    if row["domain"] in {"party", "product", "unit"}:
        writes.require_active(connection, row["domain"], int(row["suggested_entity_id"]))
    promote_candidate(connection, row, reviewer=reviewer, policy=policy)
    _mark(connection, candidate_id, "confirmed", reviewer=reviewer, review_note=review_note)
    return candidate_payload(writes._one(connection, "SELECT * FROM master_data_alias_candidates WHERE id=?", (candidate_id,)))


def reject_alias_candidate(connection: sqlite3.Connection, *, candidate_id: int, reviewer: str, review_note: str) -> dict[str, Any]:
    _pending(connection, candidate_id)
    _mark(connection, candidate_id, "rejected", reviewer=reviewer, review_note=review_note)
    return candidate_payload(writes._one(connection, "SELECT * FROM master_data_alias_candidates WHERE id=?", (candidate_id,)))


def attach_candidate_to_new_entity(connection: sqlite3.Connection, *, candidate_id: int, entity_id: int,
                                   canonical_name: str, reviewer: str,
                                   policy: MasterDataPolicy = DEFAULT_POLICY) -> None:
    """为“新对象候选”建好正式对象后：挂上、记成别名、确认。"""

    row = _pending(connection, candidate_id)
    connection.execute(
        "UPDATE master_data_alias_candidates SET suggested_entity_id=?, suggested_canonical_name=? WHERE id=?",
        (int(entity_id), canonical_name, int(candidate_id)),
    )
    promote_candidate(connection, {**row, "suggested_entity_id": int(entity_id), "suggested_canonical_name": canonical_name},
                      reviewer=reviewer, policy=policy)
    _mark(connection, candidate_id, "confirmed", reviewer=reviewer, review_note="created formal entity")


__all__ = [
    "ALIAS_CANDIDATE_STATUSES",
    "STRONG_ANCHOR_TYPES",
    "attach_candidate_to_new_entity",
    "candidate_payload",
    "confirm_alias_candidate",
    "list_alias_candidates",
    "preview_resolution",
    "promote_candidate",
    "reject_alias_candidate",
    "remember_resolutions",
    "verified_strong_anchor_types",
]
