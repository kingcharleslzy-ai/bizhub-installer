"""Customer-neutral sales module."""
