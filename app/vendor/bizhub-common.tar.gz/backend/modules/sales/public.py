"""Stable facade for generic sales actions and reads."""

from __future__ import annotations

from backend.kernel.profile_registry import StorageTarget, read_storage, storage_connect

import sqlite3
from pathlib import Path
from typing import Any

from .contracts import SalesCommand, SalesLine, SalesPreview, SalesReturnCommand, SalesReturnItem, SalesReturnPreview, SalesInvoiceCommand, SalesInvoiceLine, SalesInvoicePreview, SalesPaymentCommand, SalesPaymentAllocation, SalesPaymentPreview, SalesPaymentLine
from .owner import (
    SalesOwnerError, apply_preview, preview_action, read_action, read_order,
    apply_return_preview, preview_return_action, read_return_case, read_document_action,
    apply_payment_preview, preview_payment_action, read_payment, read_payment_balances,
    apply_invoice_preview, preview_invoice_action, read_invoice, read_receivables,
)


def _connect(path: Path) -> sqlite3.Connection:
    connection = storage_connect(f"file:{path}?mode=ro", uri=True)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA query_only=ON")
    return connection


def list_orders(storage: StorageTarget, *, limit: int = 100) -> list[dict[str, Any]]:
    with read_storage(storage, _connect) as connection:
        return [
            dict(row)
            for row in connection.execute(
                "SELECT * FROM sales_orders ORDER BY ordered_at DESC, order_id DESC LIMIT ?",
                (max(1, min(int(limit), 500)),),
            )
        ]


__all__ = [
    "SalesPaymentCommand", "SalesPaymentAllocation", "SalesPaymentPreview", "SalesPaymentLine",
    "apply_payment_preview", "preview_payment_action", "read_payment", "read_payment_balances",
    "SalesInvoiceCommand", "SalesInvoiceLine", "SalesInvoicePreview",
    "apply_invoice_preview", "preview_invoice_action", "read_invoice", "read_receivables",
    "SalesReturnCommand",
    "SalesReturnItem",
    "SalesReturnPreview",
    "apply_return_preview",
    "preview_return_action",
    "read_return_case",
    "read_document_action",
    "SalesCommand",
    "SalesLine",
    "SalesOwnerError",
    "SalesPreview",
    "apply_preview",
    "list_orders",
    "preview_action",
    "read_action",
    "read_order",
]


from .owner import (
    preview_action_in_transaction,
    preview_return_action_in_transaction,
    preview_invoice_action_in_transaction,
    preview_payment_action_in_transaction,
    apply_preview_in_transaction,
    apply_return_preview_in_transaction,
    apply_invoice_preview_in_transaction,
    apply_payment_preview_in_transaction,
    read_action_in_transaction,
    read_document_action_in_transaction
)

__all__ += ['preview_action_in_transaction', 'preview_return_action_in_transaction', 'preview_invoice_action_in_transaction', 'preview_payment_action_in_transaction', 'apply_preview_in_transaction', 'apply_return_preview_in_transaction', 'apply_invoice_preview_in_transaction', 'apply_payment_preview_in_transaction', 'read_action_in_transaction', 'read_document_action_in_transaction']

from .owner import preview_reversal_action, apply_reversal_preview, list_reversals, read_reversal
from backend.modules.trade_core.public import TradeReversalCommand, TradeReversalPreview
__all__ += ["TradeReversalCommand", "TradeReversalPreview", "preview_reversal_action", "apply_reversal_preview", "list_reversals", "read_reversal"]

from .owner import party_reference_counts
__all__ += ["party_reference_counts"]
