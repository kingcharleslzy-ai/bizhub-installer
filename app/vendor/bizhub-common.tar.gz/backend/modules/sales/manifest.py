"""Runtime manifest for customer-neutral sales."""

from __future__ import annotations

from typing import Any


MODULE_ID = "sales"
MODULE_VERSION = "0.4.0-payments"
OWNER_REF = f"{MODULE_ID}:order-owner"
# Physical store of TABLES. Until this module's migration step moves it onto
# the customer database, its tables live in the standalone generic lineage.
STORAGE_LINEAGE = "generic-kernel"
TABLES = (
    "sales_payments",
    "sales_payment_allocations",
    "sales_invoices",
    "sales_invoice_lines",
    "sales_return_cases",
    "sales_return_case_items",
    "sales_return_case_events",
    "sales_document_action_receipts",
    "sales_action_receipts",
    "sales_audit_events",
    "sales_fulfillments",
    "sales_order_lines",
    "sales_orders",
)


# HTTP addresses the standalone generic app (generic.kernel_smoke) mounts for
# this module. They belong to that app; a customer Profile that enables this
# module gets no address until its own router declares one.
STANDALONE_APP_ROUTES = (
    {"surface_id": "generic_api", "method": "POST", "path": "/api/sales/reversals/preview"},
    {"surface_id": "generic_api", "method": "POST", "path": "/api/sales/reversals/apply"},
    {"surface_id": "generic_api", "method": "GET", "path": "/api/sales/reversals"},
    {"surface_id": "generic_api", "method": "GET", "path": "/api/sales/reversals/{reversal_id}"},

    {"surface_id": "generic_api", "method": "POST", "path": "/api/sales/payments/preview"},
    {"surface_id": "generic_api", "method": "POST", "path": "/api/sales/payments/apply"},
    {"surface_id": "generic_api", "method": "GET", "path": "/api/sales/payments/balances"},
    {"surface_id": "generic_api", "method": "GET", "path": "/api/sales/payments/{payment_id}"},
    {"surface_id": "generic_api", "method": "POST", "path": "/api/sales/invoices/preview"},
    {"surface_id": "generic_api", "method": "POST", "path": "/api/sales/invoices/apply"},
    {"surface_id": "generic_api", "method": "GET", "path": "/api/sales/invoices/{invoice_id}"},
    {"surface_id": "generic_api", "method": "GET", "path": "/api/sales/receivables"},
    {"surface_id": "generic_api", "method": "GET", "path": "/api/sales/orders"},
    {"surface_id": "generic_api", "method": "POST", "path": "/api/sales/preview"},
    {"surface_id": "generic_api", "method": "POST", "path": "/api/sales/apply"},
    {"surface_id": "generic_api", "method": "POST", "path": "/api/sales/returns/preview"},
    {"surface_id": "generic_api", "method": "POST", "path": "/api/sales/returns/apply"},
    {"surface_id": "generic_api", "method": "GET", "path": "/api/sales/returns/{case_id}"},
    {"surface_id": "generic_api", "method": "GET", "path": "/api/sales/document-actions/{idempotency_key}"},
)


def sales_module_manifest(
    source_commit: str,
    migrations: list[dict[str, Any]],
) -> dict[str, Any]:
    return {
        "schema_version": "bizhub.runtime-module-manifest.v1",
        "module_id": MODULE_ID,
        "module_version": MODULE_VERSION,
        "source": {"kind": "generic", "commit": source_commit},
        "package": {
            "backend": "backend.modules.sales",
            "public_api": "backend.modules.sales.public:preview_action",
            "frontend_entry": None,
        },
        "dependencies": [
            "kernel.profile_registry",
            "trade_core",
            "master_data",
            "inventory",
            "procurement",
        ],
        "capabilities": {
            "provides": ["sales.order", "sales.fulfillment", "sales.return", "sales.return-case", "sales.invoice", "sales.credit-note", "sales.receivables", "sales.payment", "sales.payment-allocation"],
            "requires": [
                "kernel.profile-registry",
                "trade.order-lifecycle",
                "master-data.identity",
                "inventory.movement",
            ],
        },
        "surfaces": {
            "routes": [],
            "ui_routes": [],
            "jobs": [],
            "mcp_tools": [],
            "actions": [{"action_id": "sales.reversal", "record_types": ["generic_sales_reversal"], "owner_ref": OWNER_REF}, {
                "action_id": "sales.apply",
                "record_types": ["sales_order", "sales_fulfillment", "sales_return", "generic_sales_return_case", "generic_sales_invoice", "generic_sales_credit_note", "generic_sales_payment", "generic_sales_payment_allocation"],
                "owner_ref": OWNER_REF,
            }],
            "migrations": migrations,
        },
        "ownership": {
            "record_types": [
                {"record_type": "generic_sales_reversal", "owner_ref": OWNER_REF,
                 "canonical_writer": "backend/modules/sales/owner.py:apply_reversal_preview"},
                {"record_type": "generic_sales_payment", "owner_ref": OWNER_REF,
                 "canonical_writer": "backend/modules/sales/owner.py:apply_payment_preview"},
                {"record_type": "generic_sales_payment_allocation", "owner_ref": OWNER_REF,
                 "canonical_writer": "backend/modules/sales/owner.py:apply_payment_preview"},
                {"record_type": "generic_sales_invoice", "owner_ref": OWNER_REF,
                 "canonical_writer": "backend/modules/sales/owner.py:apply_invoice_preview"},
                {"record_type": "generic_sales_credit_note", "owner_ref": OWNER_REF,
                 "canonical_writer": "backend/modules/sales/owner.py:apply_invoice_preview"},
                {"record_type": "sales_order", "owner_ref": OWNER_REF,
                 "canonical_writer": "backend/modules/sales/owner.py:apply_preview"},
                {"record_type": "sales_fulfillment", "owner_ref": OWNER_REF,
                 "canonical_writer": "backend/modules/sales/owner.py:apply_preview"},
                {"record_type": "sales_return", "owner_ref": OWNER_REF,
                 "canonical_writer": "backend/modules/sales/owner.py:apply_preview"},
                {"record_type": "generic_sales_return_case", "owner_ref": OWNER_REF,
                 "canonical_writer": "backend/modules/sales/owner.py:apply_return_preview"},
            ],
            "tables": [
                {
                    "table": table, "lineage_id": STORAGE_LINEAGE, "mode": "formal_writer", "owner_ref": OWNER_REF,
                    **({"canonical_writer": "backend/modules/sales/owner.py:apply_return_preview"}
                       if table == "sales_return_cases" else
                       {"canonical_writer": "backend/modules/sales/owner.py:apply_invoice_preview"}
                       if table in {"sales_invoices", "sales_invoice_lines"} else
                       {"canonical_writer": "backend/modules/sales/owner.py:apply_payment_preview"}
                       if table in {"sales_payments", "sales_payment_allocations"} else {}),
                }
                for table in TABLES
            ],
        },
        "activation": {"mode": "build-time", "retains_existing_data_when_disabled": True},
    }
