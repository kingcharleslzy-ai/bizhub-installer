"""通用库存账接入通用盘点单（``backend.kernel.runtime.stocktake``）。

盘点单只问这本账两件事：
- 系统数：截至生效日收盘、该产品 / 单位 / 仓位的账面数（只算该时刻及之前的 movement）；
- 以实盘为准：就是本账已有的 ``stocktake`` 动作，经本模块 Owner 的
  preview → apply → readback 写 ``inventory_stocktakes`` 与盘点调整 movement。
本账的盘点锚点只追加不改写：同一张单再存会被 Owner 以“已有同刻或更晚盘点”拒绝，
改实盘要用新的盘点日。本账不按编号核对。
"""

from __future__ import annotations

from datetime import date, datetime, time
from pathlib import Path
from typing import Any, Iterable, Mapping
from zoneinfo import ZoneInfo

from backend.modules.trade_core.public import BUSINESS_TIMEZONE

from .contracts import InventoryCommand
from .owner import apply_preview, balance_as_of, preview_action, read_action


def _day_close(day: date) -> str:
    return datetime.combine(day, time(23, 59, 59), ZoneInfo(BUSINESS_TIMEZONE)).isoformat()


class InventoryLedgerStocktake:
    """把盘点范围里的每一行绑定到本账的一个 (产品, 单位)，仓位由范围决定。"""

    ledger_tables = ("inventory_stocktakes", "inventory_movements")

    def __init__(
        self,
        path: Path,
        *,
        location_id: str,
        lines: Mapping[str, tuple[str, str]],
        enabled_module_ids: Iterable[str] | None = None,
    ):
        self._path = Path(path)
        self._location_id = location_id
        self._lines = dict(lines)
        self._enabled = None if enabled_module_ids is None else tuple(enabled_module_ids)

    def _identity(self, line_key: str) -> tuple[int, int]:
        try:
            return self._lines[line_key]
        except KeyError as exc:
            raise ValueError(f"盘点行没有绑定库存产品：{line_key}") from exc

    async def system_lines(self, db: Any, *, scope: Any, effective_date: date) -> list[dict[str, Any]]:
        cutoff = _day_close(effective_date)
        lines = []
        for line_key in self._lines:
            product_id, unit_id = self._identity(line_key)
            quantity = balance_as_of(
                self._path, product_id=product_id, unit_id=unit_id, location_id=self._location_id, as_of=cutoff
            )
            lines.append({"key": line_key, "system": quantity})
        return lines

    async def adopt_actual(self, db: Any, sheet: Any) -> dict[str, Any]:
        occurred_at = _day_close(sheet.effective_date)
        stocktake_ids: list[str] = []
        for row in sheet.rows:
            line_key = str(row[sheet.scope.line_field])
            product_id, unit_id = self._identity(line_key)
            command = InventoryCommand(
                action="stocktake",
                idempotency_key=f"stocktake-sheet:{sheet.scope.scope_id}:{sheet.record_id}:{line_key}",
                product_id=product_id,
                unit_id=unit_id,
                to_location_id=self._location_id,
                actual_quantity=str(row[sheet.scope.columns[0].actual_field]),
                occurred_at=occurred_at,
                source_ref=f"stocktake-sheet:{sheet.record_id}",
                reason=str(row.get("note") or ""),
            )
            preview = preview_action(self._path, command, enabled_module_ids=self._enabled)
            applied = apply_preview(self._path, preview, enabled_module_ids=self._enabled)
            readback = read_action(self._path, applied["action_id"])
            stocktake = readback.get("stocktake") or {}
            if str(stocktake.get("location_id")) != self._location_id or stocktake.get("product_id") != product_id:
                raise RuntimeError(f"库存盘点回读不一致：{line_key}")
            stocktake_ids.append(str(stocktake["stocktake_id"]))
        return {"ledger_stocktake_ids": stocktake_ids}


__all__ = ["InventoryLedgerStocktake"]
