"""The single writer for generic inventory movements and stocktakes."""

from __future__ import annotations

from backend.kernel.profile_registry import StorageTarget, read_storage, storage_connect, write_storage

import json
import sqlite3
import uuid
from datetime import UTC, datetime
from decimal import Decimal, localcontext
from pathlib import Path
from typing import Any, Iterable

from backend.modules.master_data.public import MasterDataError, digest_json, get_resource
from backend.inventory_core import InventoryRuleError, project_balance as project_inventory_balance, quantity_decimal, validate_direction
from backend.modules.trade_core.public import decimal_context, business_datetime, movement_references, TradeRuleError

from .contracts import InventoryCommand, InventoryPreview


MODULE_ID = "inventory"
OWNER_REF = f"{MODULE_ID}:movement-owner"


class InventoryOwnerError(RuntimeError):
    def __init__(self, code: str, message: str):
        super().__init__(f"{code}: {message}")
        self.code = code
        self.message = message


def _require_module_enabled(enabled_module_ids: Iterable[str] | None) -> None:
    if enabled_module_ids is None:
        from backend.generic_kernel.profile import get_generic_registry

        enabled_module_ids = [
            str(item["module_id"])
            for item in get_generic_registry().payload.get("modules", [])
        ]
    enabled = set(enabled_module_ids)
    if MODULE_ID not in enabled:
        raise InventoryOwnerError("inventory_module_disabled", f"{MODULE_ID} is not enabled")
    if "master_data" not in enabled:
        raise InventoryOwnerError("inventory_dependency_missing", "master_data is not enabled")


def _connect(path: Path, *, readonly: bool) -> sqlite3.Connection:
    connection = storage_connect(f"file:{path}?mode=ro" if readonly else path, uri=readonly)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys=ON")
    connection.execute("PRAGMA busy_timeout=10000")
    if readonly:
        connection.execute("PRAGMA query_only=ON")
    return connection


def _reading(storage: StorageTarget):
    return read_storage(storage, lambda path: _connect(path, readonly=True))


def _writing(storage: StorageTarget):
    return write_storage(storage, lambda path: _connect(path, readonly=False))


def _movement_row(row: sqlite3.Row) -> dict[str, Any]:
    result = dict(row)
    exact = result.pop("quantity_text", None)
    if exact is not None:
        result["quantity"] = exact
    return result


def _rows(connection: sqlite3.Connection) -> list[dict[str, Any]]:
    return [_movement_row(row) for row in connection.execute("SELECT * FROM inventory_movements ORDER BY movement_id")]


def _state_generation(connection: sqlite3.Connection) -> str:
    return digest_json({
        "movements": _rows(connection),
        "stocktakes": [dict(row) for row in connection.execute("SELECT * FROM inventory_stocktakes ORDER BY stocktake_id")],
    })


def _movement_id(command: InventoryCommand, suffix: str) -> str:
    return f"mov-{digest_json({'command': command.to_dict(), 'suffix': suffix})[:24]}"


def _stocktake_id(command: InventoryCommand) -> str:
    return f"stk-{digest_json(command.to_dict())[:24]}"


def _nonnegative_quantity(value: object) -> Decimal:
    try:
        quantity = Decimal(str(value))
    except (ArithmeticError, ValueError) as exc:
        raise InventoryOwnerError("inventory_quantity_invalid", str(value)) from exc
    if not quantity.is_finite() or quantity < 0:
        raise InventoryOwnerError("inventory_quantity_must_be_nonnegative", str(value))
    return quantity


def _positive_quantity(value: object) -> Decimal:
    try:
        return quantity_decimal(value)
    except InventoryRuleError as exc:
        raise InventoryOwnerError(str(exc), str(value)) from exc


def project_balance(rows: Iterable[dict[str, Any]], *, product_id: object, unit_id: object, location_id: object) -> Decimal:
    movements = list(rows)
    with localcontext(decimal_context(Decimal(str(row["quantity"])) for row in movements)):
        return project_inventory_balance(movements, product_id=product_id, unit_id=unit_id, location_id=location_id)


def _balance(
    connection: sqlite3.Connection,
    *,
    product_id: int,
    unit_id: int,
    location_id: str,
) -> Decimal:
    return project_balance(
        _rows(connection),
        product_id=product_id,
        unit_id=unit_id,
        location_id=location_id,
    )


def balance_as_of(storage: StorageTarget, *, product_id: int, unit_id: int, location_id: str, as_of: str) -> Decimal:
    """Book quantity at ``as_of``: only movements at or before that instant count."""

    try:
        cutoff = business_datetime(as_of)
    except TradeRuleError as exc:
        raise InventoryOwnerError("inventory_occurred_at_invalid", as_of) from exc
    with _reading(storage) as connection:
        rows = _rows(connection)
    dated = []
    for row in rows:
        try:
            if business_datetime(row["occurred_at"]) <= cutoff:
                dated.append(row)
        except TradeRuleError as exc:
            raise InventoryOwnerError("inventory_stocktake_history_unordered", str(row["movement_id"])) from exc
    return project_balance(dated, product_id=product_id, unit_id=unit_id, location_id=location_id)


def _validate_resource_refs(
    connection: sqlite3.Connection,
    *,
    product_id: int,
    unit_id: int,
    locations: Iterable[str | None],
) -> None:
    try:
        get_resource(connection, "product", product_id)
        get_resource(connection, "unit", unit_id)
        for location_id in locations:
            if location_id is not None:
                get_resource(connection, "location", location_id)
    except MasterDataError as exc:
        raise InventoryOwnerError(exc.code, exc.message) from exc


def _movement(
    command: InventoryCommand,
    *,
    suffix: str,
    movement_kind: str,
    product_id: int,
    unit_id: int,
    quantity: Decimal,
    from_location_id: str | None,
    to_location_id: str | None,
    reverses_movement_id: str | None = None,
) -> dict[str, Any]:
    try:
        validate_direction(movement_kind, from_location_id, to_location_id)
    except InventoryRuleError as exc:
        raise InventoryOwnerError(str(exc), movement_kind) from exc
    return {
        "movement_id": _movement_id(command, suffix),
        "movement_kind": movement_kind,
        "product_id": product_id,
        "unit_id": unit_id,
        "quantity": format(quantity, "f"),
        "from_location_id": from_location_id,
        "to_location_id": to_location_id,
        "reverses_movement_id": reverses_movement_id,
        "occurred_at": command.occurred_at,
        "source_ref": command.source_ref,
        "reason": command.reason,
    }


def _before_balances(
    connection: sqlite3.Connection,
    *,
    product_id: int,
    unit_id: int,
    locations: Iterable[str | None],
) -> tuple[dict[str, str], ...]:
    return tuple(
        {"location_id": location_id, "quantity": format(_balance(connection, product_id=product_id, unit_id=unit_id, location_id=location_id), "f")}
        for location_id in sorted({str(item) for item in locations if item is not None})
    )


def _protect_stocktake_anchors(connection: sqlite3.Connection, command: InventoryCommand,
                               planned: list[dict[str, Any]], stocktake: dict[str, Any] | None) -> None:
    affected = {(row["product_id"], row["unit_id"], location)
                for row in planned for location in (row["from_location_id"], row["to_location_id"])
                if location is not None}
    if stocktake is not None:
        affected.add((stocktake["product_id"], stocktake["unit_id"], stocktake["location_id"]))
    occurred_at = business_datetime(command.occurred_at)
    for product_id, unit_id, location_id in sorted(affected):
        for later in connection.execute(
            "SELECT stocktake_id, occurred_at FROM inventory_stocktakes "
            "WHERE product_id=? AND unit_id=? AND location_id=? ORDER BY stocktake_id",
            (product_id, unit_id, location_id),
        ):
            try:
                later_at = business_datetime(later["occurred_at"])
            except TradeRuleError as exc:
                raise InventoryOwnerError("inventory_stocktake_history_unordered", str(later["stocktake_id"])) from exc
            if later_at >= occurred_at:
                raise InventoryOwnerError("inventory_stocktake_precedes_later_stocktake", json.dumps(dict(later)))


def preview_action_in_transaction(
    connection: sqlite3.Connection,
    command: InventoryCommand,
    *,
    enabled_module_ids: Iterable[str] | None = None,
    trade_owner_ref: str | None = None,
) -> InventoryPreview:
    _require_module_enabled(enabled_module_ids)
    if not command.idempotency_key.strip():
        raise InventoryOwnerError("inventory_idempotency_key_required", "idempotency_key is required")
    try:
        stocktake_at = business_datetime(command.occurred_at)
    except TradeRuleError as exc:
        raise InventoryOwnerError("inventory_occurred_at_invalid", "use an ISO date or timestamp with timezone") from exc
    if not command.source_ref.strip():
        raise InventoryOwnerError("inventory_source_ref_required", "source_ref is required")
    if command.action not in {"inbound", "outbound", "transfer", "stocktake", "reverse", "correct"}:
        raise InventoryOwnerError("inventory_action_invalid", command.action)
    generation = _state_generation(connection)
    planned: list[dict[str, Any]] = []
    stocktake: dict[str, Any] | None = None
    if command.action in {"reverse", "correct"}:
        target = connection.execute(
            "SELECT * FROM inventory_movements WHERE movement_id=?",
            (command.target_movement_id,),
        ).fetchone()
        if target is None:
            raise InventoryOwnerError("inventory_reversal_target_missing", str(command.target_movement_id))
        owned_stocktake = connection.execute(
            "SELECT stocktake_id FROM inventory_action_receipts, json_each(movement_ids_json) "
            "WHERE json_each.value=? AND stocktake_id IS NOT NULL",
            (target["movement_id"],),
        ).fetchone()
        if owned_stocktake is not None:
            raise InventoryOwnerError("inventory_movement_owned_by_stocktake", json.dumps(dict(owned_stocktake)))
        references = movement_references(connection, str(target["movement_id"]))
        if references:
            owned_tables = {"procurement:order-owner": {"procurement_receipts"}, "sales:order-owner": {"sales_fulfillments"}}
            authorized = (command.action == "reverse" and trade_owner_ref in owned_tables
                          and all(row["document_type"] in owned_tables[trade_owner_ref] for row in references))
            if not authorized:
                raise InventoryOwnerError("inventory_movement_owned_by_trade", json.dumps([
                    {**row, "next_step": (
                        "请通过采购 Owner 的 /api/procurement/reversals preview→apply 作废/冲销；已核对发票或付款须转人工处理。"
                        if row["document_type"] == "procurement_receipts" else
                        "请通过销售 Owner 的 /api/sales/reversals preview→apply 冲销发货；已核对发票或收款须转人工处理。"
                        if row.get("fulfillment_kind") == "shipment" else
                        "请由所属单据的原交易 Owner 人工核对处理；退货流水不能作为发货单冲销。") }
                    for row in references], ensure_ascii=False))
        if connection.execute(
            "SELECT 1 FROM inventory_movements WHERE reverses_movement_id=?",
            (command.target_movement_id,),
        ).fetchone():
            raise InventoryOwnerError("inventory_movement_already_reversed", str(command.target_movement_id))
        target_payload = _movement_row(target)
        if command.action == "reverse" and command.reason.strip() == "":
            raise InventoryOwnerError("inventory_reversal_reason_required", "reason is required")
        planned.append(_movement(
            command,
            suffix="reversal",
            movement_kind="reversal",
            product_id=int(target_payload["product_id"]),
            unit_id=int(target_payload["unit_id"]),
            quantity=quantity_decimal(target_payload["quantity"]),
            from_location_id=target_payload["to_location_id"],
            to_location_id=target_payload["from_location_id"],
            reverses_movement_id=str(target_payload["movement_id"]),
        ))
        if command.action == "reverse":
            product_id = int(target_payload["product_id"])
            unit_id = int(target_payload["unit_id"])
            locations = (target_payload["from_location_id"], target_payload["to_location_id"])
        else:
            product_id, unit_id = command.product_id, command.unit_id
            if (
                product_id != int(target_payload["product_id"])
                or unit_id != int(target_payload["unit_id"])
            ):
                raise InventoryOwnerError(
                    "inventory_correction_identity_drift",
                    "correction must retain target product and unit",
                )
            locations = (command.from_location_id, command.to_location_id)
            replacement_quantity = _positive_quantity(command.quantity)
            planned.append(_movement(
                command,
                suffix="correction",
                movement_kind="correction",
                product_id=product_id,
                unit_id=unit_id,
                quantity=replacement_quantity,
                from_location_id=command.from_location_id,
                to_location_id=command.to_location_id,
            ))
            locations = (*locations, target_payload["from_location_id"], target_payload["to_location_id"])
    elif command.action == "stocktake":
        product_id, unit_id = command.product_id, command.unit_id
        if command.to_location_id is None or command.from_location_id is not None:
            raise InventoryOwnerError("inventory_stocktake_location_invalid", "use to_location_id only")
        locations = (command.to_location_id,)
        _validate_resource_refs(connection, product_id=product_id, unit_id=unit_id, locations=locations)
        actual = _nonnegative_quantity(command.actual_quantity)
        relevant = [row for row in _rows(connection)
                    if row["product_id"] == product_id and row["unit_id"] == unit_id
                    and command.to_location_id in (row["from_location_id"], row["to_location_id"])]
        dated = []
        unordered = []
        for row in relevant:
            try:
                dated.append((business_datetime(row["occurred_at"]), row))
            except TradeRuleError:
                unordered.append(row)
        # Legacy unknown timestamps can only retain current-balance behavior
        # when their recorded write time proves the stocktake is not backdated.
        if unordered and any(at > stocktake_at for at, _ in dated):
            raise InventoryOwnerError("inventory_stocktake_history_unordered", str(unordered[0]["movement_id"]))
        for row in unordered:
            try:
                receipt = connection.execute(
                    "SELECT created_at FROM inventory_action_receipts, json_each(movement_ids_json) "
                    "WHERE json_each.value=?", (row["movement_id"],)).fetchone()
                if receipt is None or stocktake_at < business_datetime(receipt["created_at"]):
                    raise TradeRuleError("history unordered")
            except (TradeRuleError, KeyError) as exc:
                raise InventoryOwnerError("inventory_stocktake_history_unordered", str(row["movement_id"])) from exc
        before = project_balance([row for at, row in dated if at <= stocktake_at] + unordered,
                                 product_id=product_id, unit_id=unit_id, location_id=command.to_location_id)
        delta = actual - before
        stocktake = {
            "stocktake_id": _stocktake_id(command),
            "product_id": product_id,
            "unit_id": unit_id,
            "location_id": command.to_location_id,
            "actual_quantity": format(actual, "f"),
            "projected_quantity": format(before, "f"),
            "occurred_at": command.occurred_at,
            "source_ref": command.source_ref,
        }
        if delta:
            planned.append(_movement(
                command,
                suffix="stocktake-adjustment",
                movement_kind="stocktake_adjustment",
                product_id=product_id,
                unit_id=unit_id,
                quantity=abs(delta),
                from_location_id=command.to_location_id if delta < 0 else None,
                to_location_id=command.to_location_id if delta > 0 else None,
            ))
    else:
        product_id, unit_id = command.product_id, command.unit_id
        locations = (command.from_location_id, command.to_location_id)
        planned.append(_movement(
            command,
            suffix="movement",
            movement_kind=command.action,
            product_id=product_id,
            unit_id=unit_id,
            quantity=_positive_quantity(command.quantity),
            from_location_id=command.from_location_id,
            to_location_id=command.to_location_id,
        ))
    _validate_resource_refs(connection, product_id=product_id, unit_id=unit_id, locations=locations)
    _protect_stocktake_anchors(connection, command, planned, stocktake)
    before_balances = _before_balances(connection, product_id=product_id, unit_id=unit_id, locations=locations)
    combined = [*_rows(connection), *planned]
    for item in before_balances:
        after = project_balance(
            combined,
            product_id=product_id,
            unit_id=unit_id,
            location_id=item["location_id"],
        )
        if after < 0:
            raise InventoryOwnerError("inventory_balance_would_be_negative", item["location_id"])
    content = {
        "command": command.to_dict(),
        "state_generation": generation,
        "planned_movements": planned,
        "planned_stocktake": stocktake,
        "before_balances": list(before_balances),
    }
    return InventoryPreview(
        command=command,
        state_generation=generation,
        planned_movements=tuple(planned),
        planned_stocktake=stocktake,
        before_balances=before_balances,
        preview_digest=digest_json(content),
    )


def preview_action(
    storage: StorageTarget,
    command: InventoryCommand,
    *,
    enabled_module_ids: Iterable[str] | None = None,
) -> InventoryPreview:
    _require_module_enabled(enabled_module_ids)
    with _reading(storage) as connection:
        return preview_action_in_transaction(
            connection,
            command,
            enabled_module_ids=enabled_module_ids,
        )


def _readback(connection: sqlite3.Connection, action_id: str) -> dict[str, Any]:
    receipt = connection.execute(
        "SELECT * FROM inventory_action_receipts WHERE action_id=?", (action_id,)
    ).fetchone()
    if receipt is None:
        raise InventoryOwnerError("inventory_readback_missing", action_id)
    movement_ids = json.loads(str(receipt["movement_ids_json"]))
    movements = [
        _movement_row(connection.execute("SELECT * FROM inventory_movements WHERE movement_id=?", (movement_id,)).fetchone())
        for movement_id in movement_ids
    ]
    stocktake = None
    if receipt["stocktake_id"]:
        row = connection.execute(
            "SELECT * FROM inventory_stocktakes WHERE stocktake_id=?", (receipt["stocktake_id"],)
        ).fetchone()
        stocktake = dict(row) if row else None
    return {
        "schema_version": "bizhub.inventory-readback.v1",
        "owner_ref": OWNER_REF,
        "action_id": action_id,
        "idempotency_key": str(receipt["idempotency_key"]),
        "command_digest": str(receipt["command_digest"]),
        "preview_digest": str(receipt["preview_digest"]),
        "movements": movements,
        "stocktake": stocktake,
        "audit_event_id": str(receipt["audit_event_id"]),
        "state_generation": _state_generation(connection),
    }


def read_action_in_transaction(
    connection: sqlite3.Connection,
    action_id: str,
) -> dict[str, Any]:
    return _readback(connection, action_id)


def read_action(storage: StorageTarget, action_id: str) -> dict[str, Any]:
    with _reading(storage) as connection:
        return _readback(connection, action_id)


def apply_preview_in_transaction(
    connection: sqlite3.Connection,
    preview: InventoryPreview,
    *,
    enabled_module_ids: Iterable[str] | None = None,
    trade_owner_ref: str | None = None,
) -> dict[str, Any]:
    _require_module_enabled(enabled_module_ids)
    if digest_json(preview.content()) != preview.preview_digest:
        raise InventoryOwnerError("inventory_preview_content_drift", "preview digest differs")
    existing = connection.execute(
        "SELECT action_id, command_digest FROM inventory_action_receipts WHERE idempotency_key=?",
        (preview.command.idempotency_key,),
    ).fetchone()
    if existing is not None:
        if str(existing["command_digest"]) != preview.command.command_digest:
            raise InventoryOwnerError(
                "inventory_idempotency_conflict",
                preview.command.idempotency_key,
            )
        result = _readback(connection, str(existing["action_id"]))
        result["disposition"] = "idempotent_noop"
        return result
    if _state_generation(connection) != preview.state_generation:
        raise InventoryOwnerError("inventory_state_generation_drift", "inventory changed")
    authoritative = preview_action_in_transaction(
        connection,
        preview.command,
        enabled_module_ids=enabled_module_ids,
        trade_owner_ref=trade_owner_ref,
    )
    if authoritative.preview_digest != preview.preview_digest:
        raise InventoryOwnerError(
            "inventory_preview_content_drift",
            "preview differs from authoritative planning",
        )
    preview = authoritative
    if preview.planned_stocktake:
        row = preview.planned_stocktake
        connection.execute(
            """INSERT INTO inventory_stocktakes
               (stocktake_id, product_id, unit_id, location_id, actual_quantity, projected_quantity, occurred_at, source_ref)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            tuple(row[key] for key in (
                "stocktake_id", "product_id", "unit_id", "location_id", "actual_quantity",
                "projected_quantity", "occurred_at", "source_ref",
            )),
        )
    exact_storage = any(row[1] == "quantity_text" for row in connection.execute("PRAGMA table_info(inventory_movements)"))
    for row in preview.planned_movements:
        columns = ["movement_id", "movement_kind", "product_id", "unit_id", "quantity",
                   "from_location_id", "to_location_id", "reverses_movement_id", "occurred_at", "source_ref", "reason"]
        values = [row[key] for key in columns]
        # Preserve the historical numeric read shape when SQLite represents the
        # quantity exactly; otherwise the text is the authoritative quantity.
        if exact_storage:
            stored = connection.execute("SELECT CAST(? AS NUMERIC)", (row["quantity"],)).fetchone()[0]
            columns.append("quantity_text")
            values.append(row["quantity"] if Decimal(str(stored)) != Decimal(row["quantity"]) else None)
        connection.execute(
            f"INSERT INTO inventory_movements ({', '.join(columns)}) VALUES ({', '.join('?' for _ in columns)})",
            values,
        )
    action_id = uuid.uuid4().hex
    audit_event_id = uuid.uuid4().hex
    now = datetime.now(UTC).isoformat()
    connection.execute(
        """INSERT INTO inventory_audit_events(event_id, event_type, payload_json, created_at)
           VALUES (?, 'inventory_action_applied', ?, ?)""",
        (audit_event_id, json.dumps(preview.to_dict(), sort_keys=True, separators=(",", ":")), now),
    )
    connection.execute(
        """INSERT INTO inventory_action_receipts
           (action_id, idempotency_key, command_digest, preview_digest, movement_ids_json,
            stocktake_id, audit_event_id, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            action_id,
            preview.command.idempotency_key,
            preview.command.command_digest,
            preview.preview_digest,
            json.dumps([item["movement_id"] for item in preview.planned_movements]),
            preview.planned_stocktake["stocktake_id"] if preview.planned_stocktake else None,
            audit_event_id,
            now,
        ),
    )
    result = _readback(connection, action_id)
    result["disposition"] = "applied"
    return result


def apply_preview(
    storage: StorageTarget,
    preview: InventoryPreview,
    *,
    enabled_module_ids: Iterable[str] | None = None,
) -> dict[str, Any]:
    _require_module_enabled(enabled_module_ids)
    try:
        with _writing(storage) as connection:
            return apply_preview_in_transaction(
                connection,
                preview,
                enabled_module_ids=enabled_module_ids,
            )
    except sqlite3.IntegrityError as exc:
        raise InventoryOwnerError("inventory_write_conflict", str(exc)) from exc


__all__ = [
    "InventoryOwnerError",
    "balance_as_of",
    "apply_preview",
    "apply_preview_in_transaction",
    "preview_action",
    "preview_action_in_transaction",
    "read_action",
    "read_action_in_transaction",
]
