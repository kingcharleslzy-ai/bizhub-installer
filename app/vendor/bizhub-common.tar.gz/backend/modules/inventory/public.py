"""Stable read and action facade for generic inventory."""

from __future__ import annotations

from backend.kernel.profile_registry import StorageTarget, read_storage, storage_connect

import sqlite3
from pathlib import Path
from typing import Any

from .contracts import InventoryCommand, InventoryPreview
from .stocktake_ledger import InventoryLedgerStocktake
from .owner import (
    InventoryOwnerError,
    balance_as_of,
    _movement_row,
    project_balance,
    apply_preview,
    apply_preview_in_transaction,
    preview_action,
    preview_action_in_transaction,
    read_action,
    read_action_in_transaction,
)


def _connect(path: Path) -> sqlite3.Connection:
    connection = storage_connect(f"file:{path}?mode=ro", uri=True)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys=ON")
    connection.execute("PRAGMA query_only=ON")
    return connection


def list_movements(storage: StorageTarget, *, limit: int = 100) -> list[dict[str, Any]]:
    with read_storage(storage, _connect) as connection:
        return [
            _movement_row(row)
            for row in connection.execute(
                "SELECT * FROM inventory_movements ORDER BY occurred_at DESC, movement_id DESC LIMIT ?",
                (max(1, min(int(limit), 500)),),
            )
        ]


def get_balance(
    storage: StorageTarget,
    *,
    product_id: int,
    unit_id: int,
    location_id: str,
) -> dict[str, str]:
    with read_storage(storage, _connect) as connection:
        rows = [_movement_row(row) for row in connection.execute("SELECT * FROM inventory_movements")]
    return {
        "product_id": product_id,
        "unit_id": unit_id,
        "location_id": location_id,
        "quantity": format(project_balance(rows, product_id=product_id, unit_id=unit_id, location_id=location_id), "f"),
    }


__all__ = [
    "InventoryCommand",
    "InventoryLedgerStocktake",
    "InventoryOwnerError",
    "InventoryPreview",
    "apply_preview",
    "apply_preview_in_transaction",
    "balance_as_of",
    "get_balance",
    "list_movements",
    "project_balance",
    "preview_action",
    "preview_action_in_transaction",
    "read_action",
    "read_action_in_transaction",
]
