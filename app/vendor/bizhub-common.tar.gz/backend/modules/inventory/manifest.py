"""Authoritative runtime manifest for generic inventory."""

from __future__ import annotations

from typing import Any


MODULE_ID = "inventory"
MODULE_VERSION = "0.1.0-cp3"
OWNER_REF = f"{MODULE_ID}:movement-owner"
# Physical store of TABLES. Until this module's migration step moves it onto
# the customer database, its tables live in the standalone generic lineage.
STORAGE_LINEAGE = "generic-kernel"
TABLES = (
    "inventory_action_receipts",
    "inventory_audit_events",
    "inventory_movements",
    "inventory_stocktakes",
)


# HTTP addresses the standalone generic app (generic.kernel_smoke) mounts for
# this module. They belong to that app; a customer Profile that enables this
# module gets no address until its own router declares one.
STANDALONE_APP_ROUTES = (
    {"surface_id": "generic_api", "method": "GET", "path": "/api/inventory/movements"},
    {"surface_id": "generic_api", "method": "GET", "path": "/api/inventory/balance"},
    {"surface_id": "generic_api", "method": "POST", "path": "/api/inventory/preview"},
    {"surface_id": "generic_api", "method": "POST", "path": "/api/inventory/apply"},
)


def inventory_module_manifest(source_commit: str, migrations: list[dict[str, Any]]) -> dict[str, Any]:
    return {
        "schema_version": "bizhub.runtime-module-manifest.v1",
        "module_id": MODULE_ID,
        "module_version": MODULE_VERSION,
        "source": {"kind": "generic", "commit": source_commit},
        "package": {
            "backend": "backend.modules.inventory",
            "public_api": "backend.modules.inventory.public:get_balance",
            "frontend_entry": None,
        },
        "dependencies": ["kernel.profile_registry", "master_data", "trade_core"],
        "capabilities": {
            "provides": ["inventory.movement", "inventory.balance", "inventory.stocktake"],
            "requires": ["kernel.profile-registry", "master-data.identity", "master-data.location-catalog"],
        },
        "surfaces": {
            "routes": [],
            "ui_routes": [], "jobs": [], "mcp_tools": [],
            "actions": [{"action_id": "inventory.apply", "record_types": ["inventory_movement", "inventory_stocktake"], "owner_ref": OWNER_REF}],
            "migrations": migrations,
        },
        "ownership": {
            "record_types": [
                {"record_type": "inventory_movement", "owner_ref": OWNER_REF,
                 "canonical_writer": "backend/modules/inventory/owner.py:apply_preview"},
                {"record_type": "inventory_stocktake", "owner_ref": OWNER_REF,
                 "canonical_writer": "backend/modules/inventory/owner.py:apply_preview"},
            ],
            "tables": [{"table": table, "lineage_id": STORAGE_LINEAGE, "mode": "formal_writer", "owner_ref": OWNER_REF}
                       for table in TABLES],
        },
        "activation": {"mode": "build-time", "retains_existing_data_when_disabled": True},
    }
