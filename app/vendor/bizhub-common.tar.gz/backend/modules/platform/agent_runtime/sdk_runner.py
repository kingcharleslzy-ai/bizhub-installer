"""Official SDK execution with the existing request admission and task deadline.

Callers supply tools and immutable input; this module owns no business writer.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from functools import lru_cache
import math
import re
from threading import Event
import time
from typing import Any

from .execution import bounded_request, current_execution_budget


_PARENT_BUDGET_COMPLETION_RESERVE_SECONDS = 5.0
_PARENT_BUDGET_COMPLETION_RESERVE_RATIO = 0.05


@lru_cache(maxsize=None)
def sdk_model_base() -> type:
    """The SDK ``Model`` base, imported on first model construction.

    Importing the SDK (and ``openai``) costs about 0.7 s, which every process
    used to pay at Agent Host startup even when it never runs an agent.
    """
    try:
        from agents import Model
    except ImportError:
        class Model:  # type: ignore[no-redef]
            pass
    return Model


@dataclass(frozen=True)
class SdkModelBinding:
    model: Any
    owned_client: Any
    model_name: str
    model_settings: Any
    stream_model_responses: bool = False


class AgentsToolLoopError(RuntimeError):
    def __init__(self, message: str, *, category: str, retryable: bool = False,
                 model_call_count: int = 0) -> None:
        super().__init__(message)
        self.category = category
        self.retryable = retryable
        self.model_call_count = model_call_count


@dataclass(frozen=True)
class AgentsToolLoopResult:
    result: Any
    model_name: str
    elapsed_seconds: float


async def finish_sdk_cleanup(
    task: asyncio.Future[Any], *, propagate_cancellation: bool = False,
) -> Any:
    """Join owned cleanup without forwarding a second consumer cancellation."""
    cancelled = False
    while not task.done():
        try:
            await asyncio.shield(task)
        except asyncio.CancelledError:
            cancelled = True
    result = task.result()
    if cancelled and propagate_cancellation:
        raise asyncio.CancelledError
    return result


async def close_sdk_client(client: Any) -> None:
    if client is not None:
        await finish_sdk_cleanup(asyncio.ensure_future(client.close()),
                                 propagate_cancellation=True)


def joined_responses_model(*, model: str, openai_client: Any) -> Any:
    """Use the SDK's Responses adapter and own its deferred HTTP cleanup."""
    from agents import OpenAIResponsesModel

    class JoinedResponsesModel(OpenAIResponsesModel):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self._stream_cleanup_tasks: set[asyncio.Task] = set()

        def _schedule_async_iterator_close(self, iterator):
            task = asyncio.create_task(self._maybe_aclose_async_iterator(iterator))
            self._stream_cleanup_tasks.add(task)
            task.add_done_callback(self._consume_background_cleanup_task_result)

        async def wait_stream_cleanup(self):
            tasks = tuple(self._stream_cleanup_tasks)
            if tasks:
                await finish_sdk_cleanup(asyncio.gather(*tasks), propagate_cancellation=True)
                self._stream_cleanup_tasks.difference_update(tasks)

        async def stream_response(self, *args, **kwargs):
            stream = super().stream_response(*args, **kwargs)
            try:
                async for event in stream:
                    yield event
            finally:
                async def close_stream():
                    try:
                        await stream.aclose()
                    finally:
                        await self.wait_stream_cleanup()
                await finish_sdk_cleanup(asyncio.create_task(close_stream()),
                                         propagate_cancellation=True)

    return JoinedResponsesModel(model=model, openai_client=openai_client)


def _deadline_before_parent_budget(
    requested_seconds: float,
    *,
    parent_budget: Any,
) -> float:
    """Leave time to persist a typed SDK timeout before the parent expires."""

    remaining = parent_budget.remaining()
    if requested_seconds < remaining:
        return requested_seconds
    reserve = min(
        _PARENT_BUDGET_COMPLETION_RESERVE_SECONDS,
        remaining * _PARENT_BUDGET_COMPLETION_RESERVE_RATIO,
    )
    return max(0.001, remaining - reserve)




@lru_cache(maxsize=None)
def counting_agents_model_class() -> type:
    class CountingAgentsModel(sdk_model_base()):
        def __init__(self, delegate: Any) -> None:
            self._delegate = delegate
            self.started_model_call_count = 0

        async def get_response(self, *args: Any, **kwargs: Any) -> Any:
            budget = current_execution_budget()
            if budget is not None:
                budget.check()
            self.started_model_call_count += 1
            return await self._delegate.get_response(*args, **kwargs)

        async def stream_response(self, *args: Any, **kwargs: Any) -> Any:
            budget = current_execution_budget()
            if budget is not None:
                budget.check()
            self.started_model_call_count += 1
            async for event in self._delegate.stream_response(*args, **kwargs):
                yield event

    CountingAgentsModel.__qualname__ = "CountingAgentsModel"
    return CountingAgentsModel


def __getattr__(name: str) -> Any:
    # ``CountingAgentsModel`` / ``_AgentsSdkModel`` stay importable by name; the SDK loads on first use.
    if name == "CountingAgentsModel":
        return counting_agents_model_class()
    if name == "_AgentsSdkModel":
        return sdk_model_base()
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def sdk_usage_payload(usage: Any) -> dict[str, int]:
    return {
        "input_tokens": int(getattr(usage, "input_tokens", 0) or 0),
        "output_tokens": int(getattr(usage, "output_tokens", 0) or 0),
        "cached_tokens": int(getattr(
            getattr(usage, "input_tokens_details", None), "cached_tokens", 0,
        ) or 0),
    }


async def run_agents_tool_loop(
    *, name: str, instructions: str, input: Any, tools: list[Any], context: Any,
    tool_use_behavior: Any, model_binding: SdkModelBinding, max_turns: int,
    deadline_seconds: float, request_owner: str, workflow_name: str,
    error_prefix: str = "business_agents_sdk",
    model_api: str = "responses", extra_body: dict[str, Any] | None = None,
    require_tool_completion: bool = False,
) -> AgentsToolLoopResult:
    """One SDK Runner; no fallback, external traces or business transaction."""
    client = model_binding.owned_client
    try:
        if (isinstance(max_turns, bool) or not isinstance(max_turns, int) or max_turns < 1
            or isinstance(deadline_seconds, bool)
            or not isinstance(deadline_seconds, (int, float))
            or not math.isfinite(deadline_seconds) or deadline_seconds <= 0):
            raise AgentsToolLoopError(f"{error_prefix}_budget_not_configured",
                                      category="runtime_configuration")
        try:
            from agents import Agent, MaxTurnsExceeded, ModelSettings, RunConfig, Runner, RunHooks
            from agents.run import ToolExecutionConfig
        except ImportError as exc:
            raise AgentsToolLoopError("openai_agents_sdk_not_installed",
                                      category="runtime_configuration") from exc

        budget = current_execution_budget()
        if budget is not None:
            budget.check()
            deadline_seconds = _deadline_before_parent_budget(
                deadline_seconds,
                parent_budget=budget,
            )
        deadline = time.monotonic() + deadline_seconds
        if model_api not in {"responses", "chat_completions"}:
            raise AgentsToolLoopError("unsupported_sdk_model_api", category="runtime_configuration")
        model = model_binding.model
        client = model_binding.owned_client
        model_name = model_binding.model_name
        agent = Agent(
            name=name, model=model, instructions=instructions, tools=tools,
            tool_use_behavior=tool_use_behavior,
            reset_tool_choice=not require_tool_completion,
            model_settings=model_binding.model_settings,
        )
        class BudgetHooks(RunHooks):
            async def on_tool_start(self, context: Any, agent: Any, tool: Any) -> None:
                if budget is not None:
                    budget.check()

        started = time.perf_counter()
        async def run_streamed() -> Any:
            result = Runner.run_streamed(
                agent, input, context=context, max_turns=max_turns, hooks=BudgetHooks(),
                run_config=RunConfig(
                    model=model, tracing_disabled=True, workflow_name=workflow_name,
                    tool_execution=ToolExecutionConfig(max_function_tool_concurrency=1),
                ),
            )
            async def consume_events():
                # The SDK owns response parsing, tool execution and acceptance.
                # A response terminal event is not the end of the agent loop.
                async for _event in result.stream_events():
                    pass
                return result

            consumer = asyncio.create_task(consume_events())
            try:
                return await asyncio.shield(consumer)
            finally:
                if not result.is_complete and not (
                    result.run_loop_task is not None and result.run_loop_task.cancelling()
                ):
                    result.cancel(mode="immediate")
                # Keep the SDK consumer alive during cancellation cleanup. Its
                # own cancellation path would cancel the already-closing model
                # a second time before HTTP close completes.
                tasks = [consumer]
                if result.run_loop_task is not None:
                    tasks.append(result.run_loop_task)
                await finish_sdk_cleanup(asyncio.gather(*tasks, return_exceptions=True),
                                         propagate_cancellation=True)

        try:
            result = await bounded_request(
                run_streamed() if model_binding.stream_model_responses else Runner.run(
                    agent, input, context=context, max_turns=max_turns, hooks=BudgetHooks(),
                    run_config=RunConfig(
                        model=model, tracing_disabled=True, workflow_name=workflow_name,
                        tool_execution=ToolExecutionConfig(max_function_tool_concurrency=1),
                    ),
                ), deadline_seconds,
            )
        except MaxTurnsExceeded as exc:
            raise AgentsToolLoopError(
                f"{error_prefix}_turn_budget_exhausted", category="sdk_turn_budget_exhausted",
                model_call_count=model.started_model_call_count,
            ) from exc
        except TimeoutError as exc:
            raise AgentsToolLoopError(
                f"{error_prefix}_deadline_exceeded", category="model_transport", retryable=True,
                model_call_count=model.started_model_call_count,
            ) from exc
        except Exception as exc:
            from agents.exceptions import ModelBehaviorError, ModelRefusalError, UserError
            from openai import APIConnectionError, APIStatusError, AuthenticationError, PermissionDeniedError

            if isinstance(exc, (PermissionError, AuthenticationError, PermissionDeniedError)):
                category, retryable = "model_auth_unavailable", False
            elif isinstance(exc, ModelBehaviorError) and re.match(
                r"^Responses stream ended with terminal event `error`\. code=server_is_overloaded(?:;|\.|$)", str(exc)
            ):
                from .cliproxy_agent_client import classify_cliproxy_failure
                _provider_category, retryable = classify_cliproxy_failure(str(exc))
                category = "model_transport" if retryable else "model_contract"
            elif isinstance(exc, (ModelBehaviorError, ModelRefusalError)):
                category, retryable = "model_contract", False
            elif isinstance(exc, UserError):
                category, retryable = "runtime_configuration", False
            elif isinstance(exc, APIConnectionError):
                category, retryable = "model_transport", True
            elif isinstance(exc, APIStatusError):
                retryable = exc.status_code in {408, 429} or exc.status_code >= 500
                category = "model_transport" if retryable else "runtime_configuration"
            else:
                category = str(getattr(exc, "category", "") or "runtime_execution")
                retryable = bool(getattr(exc, "retryable", False))
            raise AgentsToolLoopError(
                f"{error_prefix}_execution_failed:{type(exc).__name__}:{exc}",
                category=category, retryable=retryable,
                model_call_count=model.started_model_call_count,
            ) from exc
        return AgentsToolLoopResult(result, model_name, time.perf_counter() - started)
    finally:
        await close_sdk_client(client)
