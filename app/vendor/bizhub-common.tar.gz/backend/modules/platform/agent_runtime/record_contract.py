"""Customer-neutral observation contracts shared by module contributions."""

from __future__ import annotations

from copy import deepcopy

from dataclasses import dataclass

from typing import Any, Awaitable, Callable, Iterable, Literal

AgentName = str



CONTEXT_CAPABILITIES = (
    "resolve_master_data_candidates",
    "fetch_source_evidence",
    "find_formal_relation_candidates",
    "find_owner_linkage_candidates",
)


def _nullable(kind: str, *, enum: Iterable[Any] | None = None) -> dict[str, Any]:
    schema: dict[str, Any] = {"type": [kind, "null"]}
    if enum is not None:
        schema["enum"] = [*enum, None]
    return schema


def _strict_object(properties: dict[str, Any]) -> dict[str, Any]:
    return {
        "type": "object",
        "additionalProperties": False,
        "properties": properties,
        "required": list(properties),
    }


def _array(item_schema: dict[str, Any]) -> dict[str, Any]:
    return {"type": "array", "items": item_schema}


@dataclass(frozen=True)
class RuntimeRecordSpec:
    record_type: str
    agents: tuple[AgentName, ...]
    facts_schema: dict[str, Any]
    identity_fields: tuple[str, ...]
    required_fact_paths: tuple[str, ...]
    context_capabilities: tuple[str, ...]
    required_context_agents: tuple[AgentName, ...]
    compiler_key: str
    owner_record_type: str | None
    effect: Literal["write", "context", "ignore"]
    review_risks: tuple[str, ...]
    prompt_description_zh: str
    prompt_rules_zh: tuple[str, ...]
    owner_preview: str | None
    owner_writer: str | None
    owner_readback: str | None
    review_projector: str
    owner_schema_enricher: Callable[[Any, dict[str, Any]], dict[str, Any]] | None = None
    owner_case_context_reader: Callable[..., Any] | None = None
    owner_answer_basis_required: Callable[[dict[str, Any]], bool] | None = None
    owner_review_identity_matches: Callable[[Any, dict[str, Any], dict[str, Any]], Awaitable[bool]] | None = None
    owner_source_change_review: Callable[[Any, dict[str, Any], dict[str, Any]], Awaitable[list[dict[str, Any]] | None]] | None = None
    owner_review_risk_matches: Callable[..., bool] | None = None
    answerable_relation_fields: tuple[str, ...] = ()
    canonical_owner: str | None = None

    @property
    def owner(self) -> str | None:
        return self.canonical_owner

    def fingerprint_payload(self) -> dict[str, Any]:
        return {
            "record_type": self.record_type,
            "agents": list(self.agents),
            "facts_schema": self.facts_schema,
            "identity_fields": list(self.identity_fields),
            "required_fact_paths": list(self.required_fact_paths),
            "context_capabilities": list(self.context_capabilities),
            "required_context_agents": list(self.required_context_agents),
            "compiler_key": self.compiler_key,
            "owner_record_type": self.owner_record_type,
            "owner": self.owner,
            "effect": self.effect,
            "review_risks": list(self.review_risks),
            "prompt_description_zh": self.prompt_description_zh,
            "prompt_rules_zh": list(self.prompt_rules_zh),
            "owner_preview": self.owner_preview,
            "owner_writer": self.owner_writer,
            "owner_readback": self.owner_readback,
            "review_projector": self.review_projector,
            "answerable_relation_fields": list(self.answerable_relation_fields),
            "owner_case_context_reader": (
                f"{self.owner_case_context_reader.__module__}:{self.owner_case_context_reader.__qualname__}"
                if self.owner_case_context_reader is not None else None
            ),
            "owner_answer_basis_required": (
                f"{self.owner_answer_basis_required.__module__}:{self.owner_answer_basis_required.__qualname__}"
                if self.owner_answer_basis_required is not None else None
            ),
            "owner_review_identity_matches": (
                f"{self.owner_review_identity_matches.__module__}:{self.owner_review_identity_matches.__qualname__}"
                if self.owner_review_identity_matches is not None else None
            ),
            "owner_source_change_review": (
                f"{self.owner_source_change_review.__module__}:{self.owner_source_change_review.__qualname__}"
                if self.owner_source_change_review is not None else None
            ),
            "owner_review_risk_matches": (
                f"{self.owner_review_risk_matches.__module__}:{self.owner_review_risk_matches.__qualname__}"
                if self.owner_review_risk_matches is not None else None
            ),
        }


SOURCE_RISKS = (
    "visual_value_unreadable",
    "visual_value_conflict",
    "source_text_conflict",
    "source_required_field_missing",
)


RELATION_RISKS = (
    "master_data_ambiguous",
    "formal_relation_ambiguous",
    # Server-only: relation-first v1 raises one pick-one Review when formal
    # identifiers match several formal records.
    "formal_relation_multiple_matches",
    # Server-only: the counterparty's formal identity does not fit the record type.
    "party_role_record_type_mismatch",
)


OWNER_RISKS = (
    "owner_lifecycle_conflict",
    "duplicate_identity_conflict",
    "business_direction_conflict",
    "numeric_closure_failed",
    "formal_state_conflict",
)


WRITE_RISKS = SOURCE_RISKS + RELATION_RISKS + OWNER_RISKS


def _spec(
    record_type: str,
    *,
    agents: tuple[AgentName, ...],
    facts: dict[str, Any],
    identity: tuple[str, ...],
    compiler: str,
    owner: str | None,
    effect: Literal["write", "context", "ignore"],
    description: str,
    context: tuple[str, ...] = CONTEXT_CAPABILITIES,
    required_context: tuple[AgentName, ...] = (),
    risks: tuple[str, ...] | None = None,
    rules: tuple[str, ...] = (),
    required: tuple[str, ...] = (),
    owner_schema_enricher: Callable[[Any, dict[str, Any]], dict[str, Any]] | None = None,
    owner_case_context_reader: Callable[..., Any] | None = None,
    owner_answer_basis_required: Callable[[dict[str, Any]], bool] | None = None,
    owner_review_identity_matches: Callable[[Any, dict[str, Any], dict[str, Any]], Awaitable[bool]] | None = None,
    owner_source_change_review: Callable[[Any, dict[str, Any], dict[str, Any]], Awaitable[list[dict[str, Any]] | None]] | None = None,
    owner_review_risk_matches: Callable[..., bool] | None = None,
    answerable_relation_fields: tuple[str, ...] = (),
) -> RuntimeRecordSpec:
    owner_preview = (
        "backend/modules/platform/agent_runtime/business_agent_owner.py:preview_owner_command"
        if owner is not None
        else None
    )
    owner_writer = (
        "backend/modules/platform/agent_runtime/business_agent_owner.py:apply_owner_command"
        if owner is not None
        else None
    )
    owner_readback = (
        "backend/modules/platform/agent_runtime/business_agent_owner.py:readback_owner_apply"
        if owner is not None
        else None
    )
    return RuntimeRecordSpec(
        record_type=record_type,
        owner_schema_enricher=owner_schema_enricher,
        owner_case_context_reader=owner_case_context_reader,
        owner_answer_basis_required=owner_answer_basis_required,
        owner_review_identity_matches=owner_review_identity_matches,
        owner_source_change_review=owner_source_change_review,
        owner_review_risk_matches=owner_review_risk_matches,
        answerable_relation_fields=answerable_relation_fields,
        agents=agents,
        facts_schema=facts,
        identity_fields=identity,
        required_fact_paths=required,
        context_capabilities=context,
        required_context_agents=required_context,
        compiler_key=compiler,
        owner_record_type=owner,
        effect=effect,
        review_risks=risks if risks is not None else (WRITE_RISKS if effect == "write" else SOURCE_RISKS),
        prompt_description_zh=description,
        prompt_rules_zh=rules,
        owner_preview=owner_preview,
        owner_writer=owner_writer,
        owner_readback=owner_readback,
        review_projector=(
            "backend/modules/platform/agent_runtime/business_agent_review_v2_service.py:"
            "project_business_agent_review_v2"
        ),
    )



def shared_record_specs(roles):
    return (
    _spec(
        'source_correction_relation',
        agents=tuple(role.agent_name for role in roles if role.observation_role and role.source_corrections),
        facts={'type': 'object',
         'additionalProperties': False,
         'properties': {'correction_ref': {'type': ['string', 'null']},
                        'target_source_ref': {'type': ['string', 'null']},
                        'target_record_type': {'type': ['string', 'null']},
                        'target_field': {'type': ['string', 'null']},
                        'original_value': {'type': ['string', 'null']},
                        'corrected_value': {'type': ['string', 'null']},
                        'reason': {'type': ['string', 'null']}},
         'required': ['correction_ref',
                      'target_source_ref',
                      'target_record_type',
                      'target_field',
                      'original_value',
                      'corrected_value',
                      'reason']},
        identity=('correction_ref', 'target_source_ref', 'target_field'),
        compiler='source_correction_relation',
        owner=None,
        effect='context',
        description='服务端专用的自然语言纠错关系结果；模型不得作为普通候选输出。',
        context=(),
        risks=('formal_relation_ambiguous',),
        rules=('只由服务端根据纠错关系合成：唯一目标已经是新值时保留可审计 context，关系不能唯一闭合时形成 Review；它不把纠错消息当作第二笔业务。',),
    ),
    _spec(
        'ignore',
        agents=tuple(role.agent_name for role in roles if role.observation_role),
        facts={'type': 'object',
         'additionalProperties': False,
         'properties': {'reason': {'type': ['string', 'null']},
                        'source_kind': {'type': ['string', 'null']}},
         'required': ['reason', 'source_kind']},
        identity=('reason',),
        compiler='ignore',
        owner=None,
        effect='ignore',
        description='明确无业务效果的来源；若来源可能含业务但不可读或关系不明，必须保留 uncertainty 并进入 Review，不得静默跳过。',
        # Relation-first v1 also queries formal relations for ignore
        # candidates (read-only); it never grants write capabilities.
        context=('find_formal_relation_candidates',),
        risks=('visual_value_unreadable', 'visual_value_conflict', 'source_text_conflict', 'source_required_field_missing') + RELATION_RISKS,
        rules=('只有能够确定无业务效果时才输出无 uncertainty 的 ignore。若图片或表格可能含业务，但因缺表头、不可读、冲突或无法唯一关联而不能结构化，必须在 ignore 候选保留对应 uncertainty；系统会生成业务 Review。', '同一有序窗口随后文字已明确唯一当前事件且只匹配最近图片子组时，更早的不同编号、无方向裁剪图不属于本次业务效果；它只作无 uncertainty 的 ignore，不因可能属于其他历史事件制造 Review。当前来源明确声称业务效果但字段不清时才保留 uncertainty。', '仅通知既有事实有误、但没有明确原值、新值或当前可读业务来源的纠错片段，不形成可执行纠错，也不要求人工猜正确值；整条消息没有其他业务效果时，保留通知原因后作为无 uncertainty 的 ignore。同一消息另有明确新业务效果时，新效果必须单独保留，不能被纠错片段吞掉。'),
    ),
    )


def _extend_schema_object(
    schema: dict[str, Any],
    additions: dict[str, dict[str, Any]],
    *,
    required: Iterable[str] = (),
) -> None:
    properties = schema.setdefault("properties", {})
    properties.update(deepcopy(additions))
    current_required = list(schema.get("required") or [])
    schema["required"] = list(
        dict.fromkeys([*current_required, *required])
    )
    schema["additionalProperties"] = False

def _extend_schema_array_items(
    schema: dict[str, Any],
    field: str,
    additions: dict[str, dict[str, Any]],
) -> None:
    array_schema = (schema.get("properties") or {}).get(field)
    if not isinstance(array_schema, dict):
        raise ValueError(f"owner_payload_array_missing:{field}")
    item_schema = array_schema.get("items")
    if not isinstance(item_schema, dict):
        raise ValueError(f"owner_payload_array_items_missing:{field}")
    _extend_schema_object(item_schema, additions)
