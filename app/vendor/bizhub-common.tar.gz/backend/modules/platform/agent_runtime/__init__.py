"""Agent-neutral semantic runtime module."""
