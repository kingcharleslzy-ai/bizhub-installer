"""The one transaction-neutral prepared proposal → Owner → readback sequence."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal, Mapping, Protocol

from .decision_journal import DecisionJournal, decision_payload


class OwnerStateChanged(RuntimeError):
    pass


class PreparedOwnerExecutionError(RuntimeError):
    def __init__(self, code: str, *, effect=None, readback=None):
        super().__init__(code)
        self.code, self.effect, self.readback = code, effect, readback


@dataclass(frozen=True)
class ExecutionAuthorization:
    mode: Literal["prepare_only", "automatic", "confirmed"]
    authorized_by: str
    consumed_by: str
    expected_preview_token: str | None = None


@dataclass(frozen=True)
class OwnerPlan:
    decision: Mapping[str, object]
    status: str
    preview_token: str
    command_hash: str
    preview: Any
    non_write_readback: Mapping[str, object] | None = None


@dataclass(frozen=True)
class OwnerEffect:
    status: str
    result: Any


@dataclass(frozen=True)
class VerifiedReadback:
    verified: bool
    mismatches: tuple
    payload: Mapping[str, object]


@dataclass(frozen=True)
class DecisionExecution:
    decision: Mapping[str, object] | None
    state: str
    plan: OwnerPlan | None
    effect: OwnerEffect | None = None
    readback: Mapping[str, object] | None = None
    repreflight_count: int = 0
    disposition: str = "prepared"


class PreparedOwner(Protocol):
    async def preview(self) -> OwnerPlan: ...
    async def apply(self, plan: OwnerPlan) -> OwnerEffect: ...
    async def readback(self, plan: OwnerPlan, effect: OwnerEffect) -> VerifiedReadback: ...


async def execute_prepared_owner(*, journal: DecisionJournal, owner: PreparedOwner,
    authorization: ExecutionAuthorization, initial_plan: OwnerPlan | None = None,
    prior_verified_readback: Mapping[str, object] | None = None) -> DecisionExecution:
    # A matching historical receipt is the authority; never create a Decision
    # or replay its business effect merely to upgrade old source metadata.
    if prior_verified_readback is not None:
        return DecisionExecution(None, "consumed", None, readback=prior_verified_readback, disposition="idempotent_noop")
    plan = initial_plan or await owner.preview()
    repreflight = 0
    while True:
        if authorization.expected_preview_token is not None and authorization.expected_preview_token != plan.preview_token:
            raise PreparedOwnerExecutionError("preview_stale")
        if plan.decision.get("owner_command_hash") != plan.command_hash:
            raise PreparedOwnerExecutionError("owner_plan_command_mismatch")
        action = plan.decision["action"]
        effect_required = action == "write" or (action == "context" and plan.status == "context_reconcile_ready")
        if not effect_required and action in {"context", "ignore"}:
            completed = await journal.load(str(plan.decision["decision_id"]))
            if completed is not None and completed["state"] == "consumed":
                previous = decision_payload(completed).get("readback") or {}
                if previous.get("verified") is True and previous.get("status") == "non_write_terminal" and previous.get("runtime_fingerprint") == journal.runtime_fingerprint:
                    return DecisionExecution(decision_payload(completed), "consumed", plan, readback=previous, repreflight_count=repreflight)
        row = await journal.persist(plan.decision)
        decision_id = str(row["decision_id"])
        if action == "review" or (effect_required and authorization.mode == "prepare_only"):
            return DecisionExecution(decision_payload(row), str(row["state"]), plan, repreflight_count=repreflight)
        if not effect_required:
            readback = plan.non_write_readback
            if action not in {"context", "ignore"} or readback is None or readback.get("verified") is not True:
                raise PreparedOwnerExecutionError("non_write_terminal_invalid")
            row = await journal.finalize(decision_id=decision_id, readback=readback, consumed_by=authorization.consumed_by)
            return DecisionExecution(decision_payload(row), "consumed", plan, readback=readback, repreflight_count=repreflight)
        await journal.reserve(decision_id=decision_id, command_hash=plan.command_hash,
            authorized_by=authorization.authorized_by, allow_context_reconciliation=action == "context")
        try:
            effect = await owner.apply(plan)
        except OwnerStateChanged as exc:
            await journal.invalidate(decision_id=decision_id,
                reason="human_owner_state_changed" if authorization.mode == "confirmed" else str(exc))
            if authorization.mode != "automatic":
                raise
            if repreflight >= 1:
                raise PreparedOwnerExecutionError("owner_state_changed_twice") from exc
            refreshed = await owner.preview()
            if refreshed.preview_token == plan.preview_token:
                raise PreparedOwnerExecutionError("owner_state_change_not_reproducible") from exc
            plan, repreflight = refreshed, 1
            continue
        if effect.status != "applied":
            if authorization.mode == "automatic":
                await journal.invalidate(decision_id=decision_id, reason=f"owner_apply_non_applied:{effect.status}")
            raise PreparedOwnerExecutionError("owner_apply_non_applied", effect=effect)
        readback = await owner.readback(plan, effect)
        if not readback.verified:
            if authorization.mode == "automatic":
                await journal.invalidate(decision_id=decision_id, reason="owner_readback_failed")
            raise PreparedOwnerExecutionError("owner_readback_failed", effect=effect, readback=readback)
        row = await journal.finalize(decision_id=decision_id, readback=readback.payload, consumed_by=authorization.consumed_by)
        return DecisionExecution(decision_payload(row), "consumed", plan, effect, readback.payload, repreflight, "applied")
