"""Transaction-neutral Decision persistence shared by both runtime hosts."""
from __future__ import annotations

import json
from datetime import datetime, UTC
from typing import Mapping, Protocol

ACTIVE_STATES = {"current", "review_pending", "applying"}
TERMINAL_STATES = {"consumed", "superseded", "human_overridden", "invalidated"}
DECISION_ACTIONS = {"write", "context", "ignore", "review"}


class BusinessAgentDecisionV2Error(RuntimeError):
    pass


class DecisionSql(Protocol):
    async def one(self, sql: str, params: Mapping[str, object]) -> Mapping[str, object] | None: ...
    async def execute(self, sql: str, params: Mapping[str, object]) -> int: ...
    async def flush(self) -> None: ...


def stable_json(value: object) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)


def utc_now() -> datetime:
    return datetime.now(UTC).replace(tzinfo=None)


def decision_payload(row: Mapping[str, object]) -> dict:
    try:
        value = json.loads(row["decision_json"])
    except (TypeError, ValueError):
        value = {}
    return value if isinstance(value, dict) else {}


class DecisionJournal:
    def __init__(self, sql: DecisionSql, *, schema_version: str, runtime_fingerprint: str):
        self.sql = sql
        self.schema_version = schema_version
        self.runtime_fingerprint = runtime_fingerprint

    async def load(self, decision_id: str) -> Mapping[str, object] | None:
        await self.sql.flush()
        return await self.sql.one("SELECT * FROM business_agent_decisions WHERE decision_id=:decision_id LIMIT 1", {"decision_id": decision_id})

    async def _required(self, decision_id):
        row = await self.load(decision_id)
        if row is None:
            raise BusinessAgentDecisionV2Error("decision_not_found")
        return row

    async def _cas(self, row, values, error, *, action_predicate=""):
        columns = ", ".join(f"{key}=:{key}" for key in values)
        count = await self.sql.execute(
            f"UPDATE business_agent_decisions SET {columns} WHERE id=:row_id AND state=:previous_state{action_predicate}",
            {**values, "row_id": row["id"], "previous_state": row["state"]})
        if count != 1:
            raise BusinessAgentDecisionV2Error(error)

    async def persist(self, payload: Mapping[str, object]) -> Mapping[str, object]:
        action = str(payload.get("action") or "")
        if action not in DECISION_ACTIONS:
            raise BusinessAgentDecisionV2Error(f"decision_action_invalid:{action}")
        if payload.get("schema_version") != self.schema_version:
            raise BusinessAgentDecisionV2Error("decision_schema_version_invalid")
        if payload.get("runtime_fingerprint") != self.runtime_fingerprint:
            raise BusinessAgentDecisionV2Error("decision_runtime_fingerprint_invalid")
        source_key = str(payload.get("source_key") or "")
        if not source_key:
            raise BusinessAgentDecisionV2Error("decision_source_key_missing")
        await self.sql.flush()
        current = await self.sql.one("SELECT * FROM business_agent_decisions WHERE source_key=:source_key AND state IN ('current','review_pending','applying') ORDER BY id DESC LIMIT 1", {"source_key": source_key})
        parent = current
        if parent is None:
            parent = await self.sql.one("SELECT * FROM business_agent_decisions WHERE source_key=:source_key AND record_type=:record_type AND decision_id!=:decision_id ORDER BY id DESC LIMIT 1", {"source_key": source_key, "record_type": str(payload.get("record_type") or ""), "decision_id": str(payload.get("decision_id") or "")})
        if current is not None:
            if current["decision_id"] == payload["decision_id"]:
                return current
            if current["state"] == "applying":
                raise BusinessAgentDecisionV2Error("decision_apply_in_progress_requires_readback")
            await self._cas(current, {"state": "superseded", "invalidated_at": utc_now(), "updated_at": utc_now()}, "decision_supersede_cas_conflict")
        if parent is not None:
            command = decision_payload(parent).get("owner_command")
            payload = {**payload, "supersedes_decision_id": parent["decision_id"], "parent_proposed_payload": command.get("payload") if isinstance(command, dict) else None}
        now = utc_now()
        values = {
            "decision_id": str(payload["decision_id"]), "source_key": source_key,
            "source_kind": str(payload["source_kind"]), "source_id": str(payload["source_id"]) if payload.get("source_id") is not None else None,
            "agent_name": str(payload["agent_name"]), "record_type": str(payload["record_type"]),
            "input_hash": str(payload["observation_hash"]), "observed_facts_hash": str(payload["owner_command_hash"]),
            "evidence_snapshot_hash": str(payload["evidence_hash"]), "formal_state_version": str(payload["formal_state_version"]),
            "policy_version": self.schema_version, "model": str(payload.get("model") or "") or None,
            "action": action, "decision_json": stable_json(payload), "state": "review_pending" if action == "review" else "current",
            "supersedes_decision_id": payload.get("supersedes_decision_id"), "created_at": now, "updated_at": now,
        }
        await self.sql.execute(f"INSERT INTO business_agent_decisions ({', '.join(values)}) VALUES ({', '.join(':'+key for key in values)})", values)
        return await self._required(values["decision_id"])

    async def reserve(self, *, decision_id: str, command_hash: str, authorized_by: str, allow_context_reconciliation: bool = False):
        row = await self._required(decision_id)
        payload = decision_payload(row)
        context = allow_context_reconciliation and row["action"] == "context" and payload.get("owner_preview_status") == "context_reconcile_ready"
        if row["state"] != "current" or (row["action"] != "write" and not context) or payload.get("owner_command_hash") != command_hash:
            raise BusinessAgentDecisionV2Error("decision_not_authorizable")
        now = utc_now()
        await self._cas(row, {"state": "applying", "authorized_by": authorized_by, "apply_started_at": now, "updated_at": now}, "decision_authorize_cas_conflict", action_predicate=" AND action IN ('write','context')" if context else " AND action IN ('write')")
        return await self._required(decision_id)

    async def finalize(self, *, decision_id: str, readback: Mapping[str, object] | None, consumed_by: str):
        row = await self._required(decision_id)
        payload = decision_payload(row)
        expected = "applying" if row["action"] == "write" or (row["action"] == "context" and payload.get("owner_preview_status") == "context_reconcile_ready") else "current"
        if row["state"] != expected or row["action"] == "review":
            raise BusinessAgentDecisionV2Error(f"decision_not_finalizable:{row['state']}:{row['action']}")
        payload["readback"] = readback
        payload["finalized_at"] = utc_now().isoformat()
        now = utc_now()
        await self._cas(row, {"state": "consumed", "consumed_by": consumed_by, "consumed_at": now, "updated_at": now, "decision_json": stable_json(payload)}, "decision_finalize_cas_conflict")
        return await self._required(decision_id)

    async def invalidate(self, *, decision_id: str, reason: str, owner_effect_retracted: bool = False) -> None:
        row = await self.load(decision_id)
        allowed = ACTIVE_STATES | ({"consumed"} if owner_effect_retracted else set())
        if row is None or row["state"] not in allowed:
            return
        payload = decision_payload(row)
        payload["invalidation"] = {"reason": reason, "at": utc_now().isoformat()}
        await self._cas(row, {"state": "invalidated", "invalidated_at": utc_now(), "updated_at": utc_now(), "decision_json": stable_json(payload)}, "decision_invalidate_cas_conflict")

    async def supersede_review(self, *, decision_id: str, source_kind: str, source_id: int, reason: str) -> bool:
        row = await self.load(decision_id)
        if row is None or row["source_kind"] != source_kind or row["source_id"] != str(source_id) or row["state"] in TERMINAL_STATES:
            return False
        if row["state"] == "applying":
            raise BusinessAgentDecisionV2Error("decision_apply_in_progress_requires_readback")
        if row["state"] not in ACTIVE_STATES:
            return False
        now = utc_now()
        payload = decision_payload(row)
        payload["lifecycle_reconciliation"] = {"version": "business_agent_review_source_reconciliation.v1", "reason": reason, "previous_state": row["state"], "next_state": "superseded", "reconciled_at": now.isoformat()}
        await self._cas(row, {"state": "superseded", "invalidated_at": now, "updated_at": now, "decision_json": stable_json(payload)}, "decision_supersede_cas_conflict")
        return True
