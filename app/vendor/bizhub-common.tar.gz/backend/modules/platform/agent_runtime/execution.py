"""Customer-independent execution budgets and durable stage diagnostics.

Storage and business authority stay with their existing Owners. This module
contains no clients, credentials, database access or customer role definitions.
"""

from __future__ import annotations

import asyncio
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass, field
from datetime import datetime, timezone
import math
from threading import Event
import time
from typing import Any, Awaitable, Iterator, TypeVar


class ExecutionBudgetError(RuntimeError):
    category = "execution_budget"
    retryable = False


class UncertainTaskEffect(RuntimeError):
    """A started operation has no durable result and must not be replayed."""


def _utc_timestamp(value: datetime | None = None) -> float:
    current = value or datetime.now(timezone.utc)
    if current.tzinfo is None:
        current = current.replace(tzinfo=timezone.utc)
    return current.timestamp()


@dataclass
class ExecutionBudget:
    """One bounded execution; restoring a checkpoint never grants more time."""

    expires_at: float
    deadline: float
    cancel_event: Event = field(default_factory=Event, repr=False)

    @classmethod
    def start(cls, seconds: float, *, now: datetime | None = None) -> ExecutionBudget:
        seconds = float(seconds)
        if not math.isfinite(seconds) or seconds <= 0:
            raise ExecutionBudgetError("execution_budget_invalid_duration")
        return cls(_utc_timestamp(now) + seconds, time.monotonic() + seconds)

    @classmethod
    def restore(
        cls, payload: dict[str, Any], *, now: datetime | None = None,
    ) -> ExecutionBudget:
        try:
            if payload["version"] != 1:
                raise ValueError("version")
            expires_at = float(payload["expires_at"])
            saved_at = float(payload["saved_at"])
            remaining = float(payload["remaining_seconds"])
            if not all(math.isfinite(item) for item in (expires_at, saved_at, remaining)):
                raise ValueError("nonfinite")
            if remaining < 0 or expires_at < saved_at:
                raise ValueError("invalid interval")
            current = _utc_timestamp(now)
            if current < saved_at:
                raise ExecutionBudgetError("execution_budget_clock_regressed")
            remaining = min(remaining, expires_at - current)
        except (KeyError, TypeError, ValueError) as exc:
            raise ExecutionBudgetError("execution_budget_checkpoint_invalid") from exc
        if remaining <= 0:
            raise ExecutionBudgetError("execution_budget_exhausted")
        return cls(expires_at, time.monotonic() + remaining)

    def remaining(self) -> float:
        return max(0.0, min(self.deadline - time.monotonic(), self.expires_at - _utc_timestamp()))

    def check(self) -> None:
        if self.cancel_event.is_set():
            raise ExecutionBudgetError("execution_cancelled")
        if self.remaining() <= 0:
            raise ExecutionBudgetError("execution_budget_exhausted")

    def renew_after_completed_stage(self, seconds: float) -> None:
        """Start the next bounded stage without reviving cancelled work."""

        if self.cancel_event.is_set():
            raise ExecutionBudgetError("execution_cancelled")
        renewed = type(self).start(seconds)
        self.expires_at = renewed.expires_at
        self.deadline = renewed.deadline

    def checkpoint(self) -> dict[str, Any]:
        # Epoch timestamps are portable; monotonic deadlines are process-local.
        current = _utc_timestamp()
        return {
            "version": 1,
            "expires_at": self.expires_at,
            "saved_at": min(current, self.expires_at),
            "remaining_seconds": self.remaining(),
        }


_EXECUTION_BUDGET: ContextVar[ExecutionBudget | None] = ContextVar("agent_execution_budget", default=None)


def current_execution_budget() -> ExecutionBudget | None:
    return _EXECUTION_BUDGET.get()


_Response = TypeVar("_Response")


async def bounded_request(request: Awaitable[_Response], seconds: float) -> _Response:
    """Close async HTTP resources on deadline or cancellation of a thread caller."""
    budget = current_execution_budget()
    task = asyncio.ensure_future(request)
    try:
        if budget is not None:
            budget.check()
            seconds = min(seconds, budget.remaining())
        async with asyncio.timeout(max(0.0, seconds)):
            if budget is None:
                return await task
            while not task.done():
                budget.check()
                await asyncio.wait({task}, timeout=0.05)
            budget.check()
            return task.result()
    finally:
        if not task.done():
            task.cancel()
        await asyncio.gather(task, return_exceptions=True)


@contextmanager
def execution_scope(budget: ExecutionBudget) -> Iterator[ExecutionBudget]:
    """Propagate to async children and to_thread; cancel queued thread work."""
    parent = current_execution_budget()
    if parent is not None:
        budget.deadline = min(budget.deadline, parent.deadline)
        budget.expires_at = min(budget.expires_at, parent.expires_at)
        budget.cancel_event = parent.cancel_event
    token = _EXECUTION_BUDGET.set(budget)
    try:
        budget.check()
        yield budget
    except (asyncio.CancelledError, ExecutionBudgetError):
        budget.cancel_event.set()
        raise
    finally:
        if parent is None:
            budget.cancel_event.set()
        _EXECUTION_BUDGET.reset(token)


def stage_result(
    stage: str, *, source_refs: tuple[str, ...], required: bool,
    failure: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Keep optional failures observable without making sources unavailable."""
    return {
        "stage": stage,
        "status": "failed" if failure is not None else "completed",
        "required": required,
        "source_refs": list(source_refs),
        "failure": dict(failure) if failure is not None else None,
    }
