"""Customer-neutral composable platform modules."""
