"""Customer-neutral runtime kernel."""
