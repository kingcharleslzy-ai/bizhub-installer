"""Kernel numeric surface: finite decimals, canonical text, field precision and parsing.

One implementation for every Owner, compiler and importer:

- :func:`finite_decimal` — exact Decimal from int/str/Decimal/float (via ``str``),
  rejecting NaN, infinity, booleans and non-literal text.
- :func:`canonical_decimal_text` — fixed-point text without trailing zeros or
  exponent (``1`` / ``1.0`` / ``1E+0`` → ``"1"``; ``-0`` → ``"0"``), independent
  of the active ``decimal`` context.  Use it for comparison and digest input,
  never a ``float``. Existing text contracts can explicitly retain normalized
  scientific notation and signed zero; the default stays fixed and unsigned.
- :class:`DecimalSpec` / :func:`quantize_decimal` / :func:`decimal_spec_text` —
  per-field precision. Rounding defaults to ``ROUND_HALF_UP``; existing fields
  may explicitly retain ``ROUND_HALF_EVEN``. ``on_excess``
  declares whether extra places are rounded or rejected. An Owner may declare
  ``max_abs`` and its rejection message; the original value is checked before
  rounding. The generic specs
  below carry no customer data; an Owner may declare its own spec.
- :func:`parse_decimal_text` / :func:`parse_measure` — strict text parsing:
  thousands separators only as complete ``1,234,567`` groups, scientific
  notation accepted, mass units converted exactly (``1kg`` → ``1000`` g),
  count units and compound Chinese integers only for count targets; any other
  character rejects the value. Quantity expressions have bounded text/AST size.

Identifiers, PO numbers and specifications are text, not numbers; never pass
them through these helpers.
"""

from __future__ import annotations

import ast
import operator
import re
import unicodedata
from dataclasses import dataclass
from decimal import ROUND_HALF_EVEN, ROUND_HALF_UP, Context, Decimal, Inexact, InvalidOperation, localcontext
from typing import Any, Iterable, Literal

_QUANTITY_UNITS_RE = re.compile(r"\s*(?:片|块|个|件|只|张|pcs?|PCS?)\s*$")
_SAFE_EXPR_RE = re.compile(r"^[\d\s+\-*/.]+$")
_OPERATORS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
}
_MAX_QUANTITY_TEXT_LENGTH = 1024
_MAX_EXPRESSION_NODES = 128
_MAX_EXPRESSION_DEPTH = 32
_CHINESE_DIGITS = dict(zip("零一二两三四五六七八九", (0, 1, 2, 2, 3, 4, 5, 6, 7, 8, 9)))
_CHINESE_SMALL_UNITS = {"十": 10, "百": 100, "千": 1000}
_CHINESE_LARGE_UNITS = {"万": 10000, "亿": 100000000}
_CHINESE_NUMBER = r"[零一二两三四五六七八九十百千万亿]+"


def _chinese_integer(text: str) -> int | None:
    """Strict positional Chinese count, with descending units in each section."""
    if not text or len(text) > 64 or not re.fullmatch(_CHINESE_NUMBER, text):
        return None
    if text in _CHINESE_DIGITS:
        return _CHINESE_DIGITS[text]
    total = section = 0
    digit = None
    previous_small, previous_large = 10000, 1000000000
    zero = digit_after_zero = False
    for character in text:
        if character in _CHINESE_DIGITS:
            number = _CHINESE_DIGITS[character]
            if number == 0:
                if zero or digit is not None or not (section or total) or previous_small == 10:
                    return None
                zero = True
                continue
            if digit is not None:
                return None
            digit, digit_after_zero, zero = number, zero, False
        elif character in _CHINESE_SMALL_UNITS:
            unit = _CHINESE_SMALL_UNITS[character]
            if unit >= previous_small or zero:
                return None
            if digit is None:
                if unit != 10 or section:
                    return None
                digit = 1
            section += digit * unit
            digit, previous_small = None, unit
        else:
            unit = _CHINESE_LARGE_UNITS[character]
            section += digit or 0
            if unit >= previous_large or not section or zero:
                return None
            total += section * unit
            section, digit, previous_small, previous_large = 0, None, 10000, unit
    if zero:
        return None
    if digit is not None and (section or total) and previous_small > 10 and not digit_after_zero:
        # "一百二" / "一万二" omit a position and are ambiguous shorthand.
        return None
    return total + section + (digit or 0)


def _eval_safe_number_expr(text: str) -> Decimal | None:
    if len(text) > _MAX_QUANTITY_TEXT_LENGTH:
        return None
    try:
        node = ast.parse(text, mode="eval")
    except (SyntaxError, RecursionError):
        return None
    pending, count = [(node, 0)], 0
    while pending:
        current, depth = pending.pop()
        count += 1
        if count > _MAX_EXPRESSION_NODES or depth > _MAX_EXPRESSION_DEPTH:
            return None
        pending.extend((child, depth + 1) for child in ast.iter_child_nodes(current))

    def eval_node(current: ast.AST) -> Decimal | None:
        if isinstance(current, ast.Expression):
            return eval_node(current.body)
        if isinstance(current, ast.Constant) and isinstance(current.value, (int, float)):
            # AST float values can round integral decimal literals before validation.
            literal = ast.get_source_segment(text, current)
            return Decimal(literal) if literal is not None else None
        if isinstance(current, ast.UnaryOp) and isinstance(current.op, (ast.UAdd, ast.USub)):
            value = eval_node(current.operand)
            if value is None:
                return None
            return value if isinstance(current.op, ast.UAdd) else -value
        if isinstance(current, ast.BinOp):
            left = eval_node(current.left)
            right = eval_node(current.right)
            func = _OPERATORS.get(type(current.op))
            if left is None or right is None or func is None:
                return None
            if isinstance(current.op, ast.Div) and right == 0:
                return None
            return Decimal(str(func(left, right)))
        return None

    return eval_node(node)


def parse_quantity_num(value: Any) -> int | None:
    """Parse business quantity text without accepting arbitrary notes.

    Supported examples: ``2000``, ``2,000片``, ``43块``, ``487-28``,
    ``1000+5``.  Text such as ``9补货`` is intentionally rejected because
    the number is ambiguous business context rather than a clean quantity.
    """

    text = unicodedata.normalize("NFKC", str(value or "")).strip()
    if not text or len(text) > _MAX_QUANTITY_TEXT_LENGTH:
        return None
    measured = parse_measure(text, target_unit="count")
    if measured is not None:
        if measured and measured.adjusted() >= _MAX_QUANTITY_TEXT_LENGTH:
            return None  # Bound integer expansion too, e.g. a short "1e1000000".
        return int(measured) if measured >= 0 and measured == measured.to_integral_value() else None
    text = _QUANTITY_UNITS_RE.sub("", text).strip()
    if not text or not _SAFE_EXPR_RE.fullmatch(text):
        return None
    if not re.search(r"\d", text):
        return None
    result = _eval_safe_number_expr(text)
    if result is None:
        return None
    try:
        integral = result.to_integral_value()
    except InvalidOperation:
        return None
    if result != integral or result < 0:
        return None
    return int(integral)


# --------------------------------------------------------------------------- numeric base

_DECIMAL_LITERAL_RE = re.compile(r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?")
_GROUPED_LITERAL_RE = re.compile(r"[+-]?\d{1,3}(?:,\d{3})+(?:\.\d+)?")


class NumericPrecisionError(ValueError):
    """A value has more places than its field spec allows and the spec rejects excess."""


class NumericRangeError(ValueError):
    """A finite value exceeds the reasonable range declared by its Owner."""


def finite_decimal(value: Any) -> Decimal | None:
    """Exact finite Decimal, or ``None`` for empty, NaN, infinity, bool or non-literal text.

    Text must be a plain decimal literal (sign, digits, point, exponent) after
    NFKC and whitespace stripping; grouping separators belong to
    :func:`parse_decimal_text`.  A float is read through ``str`` (its shortest
    repr), never through its binary expansion.
    """

    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, Decimal):
        parsed = value
    elif isinstance(value, int):
        parsed = Decimal(value)
    elif isinstance(value, float):
        parsed = Decimal(str(value))
    else:
        text = unicodedata.normalize("NFKC", str(value)).strip()
        if not _DECIMAL_LITERAL_RE.fullmatch(text):
            return None
        parsed = Decimal(text)
    return parsed if parsed.is_finite() else None


def canonical_decimal_text(
    value: Any, *, notation: Literal["fixed", "normalized"] = "fixed", signed_zero: bool = False,
    significant_digits: int | None = None,
) -> str | None:
    """Context-independent text without trailing zeros (``None`` if not finite).

    ``normalized`` notation and ``signed_zero`` preserve existing text contracts.
    The explicit ``significant_digits`` option is solely for precision-declared
    probes (for example a legacy storage guard); default output is always exact.
    Such a probe must never replace the original value written to storage.
    """

    parsed = finite_decimal(value)
    if parsed is None:
        return None
    if significant_digits is not None:
        parsed = Context(prec=significant_digits, rounding=ROUND_HALF_EVEN).create_decimal(parsed)
    if not parsed:
        return "-0" if signed_zero and parsed.is_signed() else "0"
    sign, digits, exponent = parsed.as_tuple()
    coefficient = "".join(map(str, digits)).lstrip("0")
    stripped = coefficient.rstrip("0")
    exponent += len(coefficient) - len(stripped)
    if notation == "normalized":
        return str(Decimal((sign, tuple(map(int, stripped)), exponent)))
    if exponent >= 0:
        text = stripped + "0" * exponent
    elif len(stripped) > -exponent:
        text = f"{stripped[:exponent]}.{stripped[exponent:]}"
    else:
        text = "0." + "0" * (-exponent - len(stripped)) + stripped
    return ("-" if sign else "") + text


@dataclass(frozen=True)
class DecimalSpec:
    """Field places, explicit rounding and zero sign, excess rounded or rejected."""

    name: str
    places: int
    on_excess: Literal["round", "reject"] = "round"
    rounding: str = ROUND_HALF_UP
    signed_zero: bool = False
    max_abs: Decimal | None = None
    range_error: str = "数值超出合理范围"

    def __post_init__(self) -> None:
        if (self.places < 0 or self.on_excess not in {"round", "reject"}
                or self.rounding not in {ROUND_HALF_UP, ROUND_HALF_EVEN}):
            raise ValueError(f"decimal_spec_invalid:{self.name}")
        if self.max_abs is not None:
            limit = finite_decimal(self.max_abs)
            if limit is None or limit < 0:
                raise ValueError(f"decimal_spec_invalid:{self.name}")
            object.__setattr__(self, "max_abs", limit)

    @property
    def quantum(self) -> Decimal:
        return Decimal(1).scaleb(-self.places)


# Generic field kinds.  Gram weights keep 0.001 g, money 0.01, counts are whole
# (a fractional piece/block count is an error, not a rounding case), unit prices
# keep the existing 0.0001.  Owners whose stored scale differs declare their own.
WEIGHT_G = DecimalSpec("weight_g", 3, "round")
MONEY = DecimalSpec("money", 2, "round")
COUNT = DecimalSpec("count", 0, "reject")
UNIT_PRICE = DecimalSpec("unit_price", 4, "round")


def quantize_decimal(value: Any, spec: DecimalSpec) -> Decimal | None:
    """``value`` at the declared precision/rounding, independent of the active context.

    Returns ``None`` when ``value`` is not a finite number; raises
    :class:`NumericPrecisionError` when ``spec`` rejects excess places.
    """

    parsed = finite_decimal(value)
    if parsed is None:
        return None
    if spec.max_abs is not None and parsed.copy_abs() > spec.max_abs:
        # Check the original value: rounding may otherwise conceal an excess.
        raise NumericRangeError(spec.range_error)
    precision = max(28, parsed.adjusted() + spec.places + 2)
    result = parsed.quantize(spec.quantum, rounding=spec.rounding, context=Context(prec=precision))
    if spec.on_excess == "reject" and result != parsed:
        raise NumericPrecisionError(f"numeric_precision_exceeded:{spec.name}:{canonical_decimal_text(parsed)}")
    return result if result or spec.signed_zero else result.copy_abs()


def decimal_spec_text(value: Any, spec: DecimalSpec) -> str | None:
    """Fixed-place text at ``spec`` precision (``1.5`` → ``"1.500"`` for gram weights)."""

    result = quantize_decimal(value, spec)
    return None if result is None else format(result, "f")


def parse_decimal_text(value: Any) -> Decimal | None:
    """Strict number text: a decimal literal or complete thousands groups (``1,234.5``).

    ``1,23`` / ``12,34,567`` / ``1,234,5`` and any embedded letters, currency or
    notes are rejected rather than stripped.
    """

    if isinstance(value, (Decimal, int, float)) or value is None:
        return finite_decimal(value)
    text = unicodedata.normalize("NFKC", str(value)).strip()
    if "," in text:
        if not _GROUPED_LITERAL_RE.fullmatch(text):
            return None
        text = text.replace(",", "")
    return finite_decimal(text)


def _shift(value: Decimal, places: int) -> Decimal:
    """Exact ``value * 10**places`` (no context rounding)."""

    sign, digits, exponent = value.as_tuple()
    return Decimal((sign, digits, exponent + places))


# Unit vocabulary.  Mass words convert exactly to grams; count words only
# qualify a count.  Other units (斤, 吨, lengths) are rejected, not guessed.
MASS_UNIT_GRAMS: dict[str, Decimal] = {
    "g": Decimal(1),
    "克": Decimal(1),
    "kg": Decimal(1000),
    "公斤": Decimal(1000),
    "千克": Decimal(1000),
}
COUNT_UNITS = frozenset({"片", "块", "个", "件", "只", "张", "台", "份", "支", "套", "pc", "pcs"})
_UNIT_WORDS = sorted({*MASS_UNIT_GRAMS, *COUNT_UNITS}, key=len, reverse=True)
_MEASURE_RE = re.compile(
    r"(?P<number>[+-]?[\d.,]+(?:[eE][+-]?\d+)?|" + _CHINESE_NUMBER + r")\s*(?P<unit>"
    + "|".join(re.escape(word) for word in _UNIT_WORDS)
    + r")?",
    re.IGNORECASE,
)


def parse_measure(value: Any, *, target_unit: Literal["g", "kg", "count"] | None) -> Decimal | None:
    """Strict ``number + optional unit`` text expressed in ``target_unit``.

    ``target_unit`` is the unit of the receiving field: ``"g"``/``"kg"`` convert any
    mass word exactly and reject count words; ``"count"`` accepts count words and
    rejects mass words; ``None`` (a plain number field) rejects mass words because
    a unit cannot be dropped silently.  A bare number is already in the field unit.
    """

    if isinstance(value, (Decimal, int, float)) or value is None:
        return finite_decimal(value)
    text = unicodedata.normalize("NFKC", str(value)).strip()
    match = _MEASURE_RE.fullmatch(text)
    if match is None:
        return None
    number = parse_decimal_text(match.group("number"))
    if number is None and target_unit == "count":
        chinese = _chinese_integer(match.group("number"))
        number = Decimal(chinese) if chinese is not None else None
    if number is None:
        return None
    unit = (match.group("unit") or "").lower()
    if not unit:
        return number
    if unit in MASS_UNIT_GRAMS:
        if target_unit not in {"g", "kg"}:
            return None
        places = 3 if MASS_UNIT_GRAMS[unit] == 1000 else 0
        if target_unit == "kg":
            places -= 3
        return _shift(number, places)
    return number if target_unit in {"count", None} else None


_VISIBLE_MEASURE_RE = re.compile(
    r"(?<![0-9A-Za-z_./\-#＃])(?:[+-]?(?:\d[\d.,]*|\.\d[\d.,]*)(?:[eE][+-]?\d+)?|"
    + _CHINESE_NUMBER + r")\s*(?:" + "|".join(re.escape(word) for word in _UNIT_WORDS)
    + r")?(?![0-9A-Za-z_.])", re.IGNORECASE,
)


def find_measure_tokens(
    text: Any, *, target_unit: Literal["g", "kg", "count"] | None, require_unit: bool = False,
) -> tuple[str, ...]:
    """Locate complete tokens, retaining invalid number spellings for review.

    Unit dimension locates the relevant tokens; :func:`parse_measure` determines
    whether each is valid. A count assertion that cannot be parsed must remain
    visible to its caller instead of disappearing and granting implicit consent.
    """
    found = []
    for match in _VISIBLE_MEASURE_RE.finditer(unicodedata.normalize("NFKC", str(text or ""))):
        token = match.group().strip()
        measure = _MEASURE_RE.fullmatch(token)
        if measure is None or (require_unit and not measure.group("unit")):
            continue
        unit = (measure.group("unit") or "").lower()
        if unit and target_unit == "count" and unit not in COUNT_UNITS:
            continue
        if unit and target_unit in {"g", "kg"} and unit not in MASS_UNIT_GRAMS:
            continue
        found.append(token)
    return tuple(found)


def find_measure_values(
    text: Any, *, target_unit: Literal["g", "kg", "count"] | None, require_unit: bool = False,
) -> tuple[Decimal, ...]:
    """Read complete valid evidence values, never substrings of identifiers.

    A bare value uses the receiving field's unit; explicit units are converted by
    the strict parser. Call ``find_measure_tokens`` when invalid assertions must
    also be retained for review.
    """
    return tuple(value for token in find_measure_tokens(text, target_unit=target_unit, require_unit=require_unit)
                 if (value := parse_measure(token, target_unit=target_unit)) is not None)


def decimal_context(values: Iterable[Decimal]) -> Context:
    """Precision for exact aligned additions, including all possible carries."""
    operands = tuple(values)
    integer_digits = max((value.adjusted() + 1 for value in operands), default=1)
    fractional_digits = max((-value.as_tuple().exponent for value in operands), default=0)
    precision = max(1, integer_digits) + max(0, fractional_digits) + len(str(len(operands))) + 1
    return Context(prec=precision)


def decimal_sum(values: Iterable[Decimal]) -> Decimal:
    operands = tuple(values)
    with localcontext(decimal_context(operands)) as context:
        context.traps[Inexact] = True
        return sum(operands, Decimal("0"))
