"""Generic-kernel binding for the shared Profile Registry."""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from backend.kernel.module_contract import SHARED_KERNEL_SOURCE_PATHS, source_tree_digest
from backend.kernel.profile_registry import RegistryFiles, RuntimeRegistry


GENERIC_REGISTRY_FILES = RegistryFiles(
    profile_id="generic-kernel-smoke",
    registry="backend/generated/generic_kernel_smoke_runtime_registry.v1.json",
    profile_lock="backend/profiles/generic-kernel-smoke.lock.json",
)


# The generic code version: part of every Generic Agent execution identity.
GENERIC_PROFILE_SOURCE_PATHS = (
    *SHARED_KERNEL_SOURCE_PATHS,
    "backend/kernel/runtime/__init__.py",
    "backend/kernel/runtime/quantity_parser.py",
    "backend/generic_kernel/__init__.py",
    "backend/generic_kernel/app.py",
    "backend/generic_kernel/storage.py",
    "backend/generic_kernel/backup.py",
    "backend/generic_kernel/cobuild.py",
    "backend/generic_kernel/master_data_policy.py",
    "backend/generic_kernel/migrations.py",
    "backend/generic_kernel/models.py",
    "backend/generic_kernel/onboarding.py",
    "backend/generic_kernel/profile.py",
    "backend/generic_kernel/agent_common.py",
    "backend/modules/platform/agent_runtime/decision_journal.py",
    "backend/modules/platform/agent_runtime/prepared_owner_execution.py",
    "backend/modules/platform/agent_runtime/source_contract.py",
    "backend/modules/platform/agent_runtime/source_journal.py",
    "backend/modules/platform/agent_runtime/source_lifecycle.py",
    "backend/modules/platform/agent_runtime/execution.py",
    "backend/modules/platform/agent_runtime/sdk_runner.py",
    "backend/generic_kernel/procurement_agent.py",
    "backend/generic_kernel/procurement_sources.py",
    "backend/generic_kernel/sales_agent.py",
    "backend/generic_kernel/sales_sources.py",
    "backend/generic_kernel/ui/index.html",
    "backend/inventory_core.py",
    "backend/modules/inventory/__init__.py",
    "backend/modules/inventory/contracts.py",
    "backend/modules/inventory/manifest.py",
    "backend/modules/inventory/owner.py",
    "backend/modules/inventory/public.py",
    "backend/modules/master_data/__init__.py",
    "backend/modules/master_data/commands.py",
    "backend/modules/master_data/contracts.py",
    "backend/modules/master_data/intents.py",
    "backend/modules/master_data/lookup.py",
    "backend/modules/master_data/manifest.py",
    "backend/modules/master_data/matching.py",
    "backend/modules/master_data/owner.py",
    "backend/modules/master_data/policy.py",
    "backend/modules/master_data/public.py",
    "backend/modules/master_data/resolution.py",
    "backend/modules/master_data/schema.py",
    "backend/modules/master_data/writes.py",
    "backend/modules/procurement/__init__.py",
    "backend/modules/procurement/contracts.py",
    "backend/modules/procurement/manifest.py",
    "backend/modules/procurement/owner.py",
    "backend/modules/procurement/public.py",
    "backend/modules/sales/__init__.py",
    "backend/modules/sales/contracts.py",
    "backend/modules/sales/manifest.py",
    "backend/modules/sales/owner.py",
    "backend/modules/sales/public.py",
    "backend/modules/trade_core/__init__.py",
    "backend/modules/trade_core/manifest.py",
    "backend/modules/trade_core/public.py",
    "backend/modules/trade_core/reversal.py",
    "requirements-generic.txt",
)


@lru_cache(maxsize=4)
def generic_profile_source_digest(repo_root: Path | None = None) -> str:
    """Digest of the running generic code (the Registry ships with this code)."""
    root = (repo_root or Path(__file__).resolve().parents[2]).resolve()
    return source_tree_digest(root, GENERIC_PROFILE_SOURCE_PATHS)


@lru_cache(maxsize=1)
def get_generic_registry(repo_root: Path | None = None) -> RuntimeRegistry:
    return RuntimeRegistry.load(repo_root, files=GENERIC_REGISTRY_FILES)
