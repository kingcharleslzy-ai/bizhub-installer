"""Atomic migration governance for the independent generic-kernel lineage."""

from __future__ import annotations

from backend.kernel.profile_registry import storage_connect

import hashlib
import inspect
import json
import os
import sqlite3
import uuid
from decimal import Decimal
from fractions import Fraction
from contextlib import contextmanager
from dataclasses import dataclass, replace
from datetime import UTC, datetime
from pathlib import Path
from typing import Iterable, Iterator, Sequence


from backend.modules.inventory.location_schema import LOCATIONS
from backend.modules.inventory.movement_schema import MATERIAL_INVENTORY_EVENTS
from backend.modules.master_data.schema import MASTER_DATA_ALIASES, MASTER_DATA_ALIAS_CANDIDATES, MASTER_DATA_GOVERNANCE_ACTIONS, NAME_TABLES, Column, ForeignKey, Index, TableExtension, create_table_sql, extended_table
from backend.modules.procurement.order_schema import PROCUREMENT_BATCHES, PROCUREMENTS
from backend.modules.procurement.receipt_schema import PROCUREMENT_RECEIPT_ALLOCATIONS
from backend.modules.procurement.settlement_schema import PROCUREMENT_INVOICE_ALLOCATIONS, PROCUREMENT_PAYMENT_ALLOCATIONS
from backend.modules.sales.order_schema import SALES_BATCHES, SALES_FULFILLMENTS, SALES_ORDERS
from backend.modules.sales.return_schema import RETURN_STANDARD_TABLES, SALES_RETURN_CASE_ITEMS
from backend.modules.sales.settlement_schema import settlement_schema_sql

from backend.kernel.runtime.schema_lineage_tables import PLATFORM_MIGRATION_TABLE, PLATFORM_TABLES

from .models import MODEL_TABLES


PROFILE_ID = "generic-kernel-smoke"
LINEAGE_ID = "generic-kernel"


class GenericKernelDatabaseError(RuntimeError):
    def __init__(self, code: str, message: str):
        super().__init__(f"{code}: {message}")
        self.code = code
        self.message = message


def _canonical(payload: object) -> bytes:
    return (json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n").encode()


def _digest(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


@dataclass(frozen=True)
class KernelMigration:
    version: int
    migration_id: str
    dependencies: tuple[str, ...]
    statements: tuple[str, ...]
    owner_ref: str = "generic.kernel_smoke:runtime"
    # SQLite 改不了的列按“建新表 → 搬数据 → 删旧表 → 换名”重建：期间关外键，
    # 整批改完后做全库外键自检再提交。只影响执行方式，不进 checksum。
    rebuilds_tables: bool = False
    implementation_digest: str | None = None

    @property
    def checksum(self) -> str:
        payload = {
            "lineage_id": LINEAGE_ID,
            "version": self.version,
            "migration_id": self.migration_id,
            "dependencies": list(self.dependencies),
            "statements": list(self.statements),
        }
        if self.implementation_digest is not None:
            payload["implementation_digest"] = self.implementation_digest
        return _digest(_canonical(payload))

    def descriptor(self) -> dict[str, object]:
        return {
            "version": self.version,
            "migration_id": self.migration_id,
            "owner_ref": self.owner_ref,
            "dependencies": list(self.dependencies),
            "checksum": self.checksum,
        }


def _migration_payment_splits(amount, weights_json):
    """Exact cumulative cent apportionment for v16; no SQLite integer/float division."""
    from backend.modules.trade_core.public import money

    payment = Decimal(str(amount))
    cents = Fraction(payment) * 100 if payment.is_finite() else None
    if cents is None or cents.denominator != 1 or cents < 0:
        raise ValueError("generic_payment_amount_invalid")
    weights = {}
    for item in json.loads(weights_json):
        weight = Decimal(str(item["amount"]))
        if not weight.is_finite() or weight < 0:
            raise ValueError("generic_payment_weight_invalid")
        key = int(item["procurement_id"])
        weights[key] = weights.get(key, Fraction()) + Fraction(weight)
    total = sum(weights.values(), Fraction())
    if not total:
        return "[]"
    cumulative, previous, result = Fraction(), 0, []
    for key, weight in sorted(weights.items()):
        cumulative += weight
        target = int(cents) * cumulative / total
        whole, remainder = divmod(target.numerator, target.denominator)
        if remainder * 2 == target.denominator:
            # Delegate the exact half-cent boundary to the existing money Owner.
            rounded = int(Fraction(money(f"{whole // 100}.{whole % 100:02d}5")) * 100)
        else:
            rounded = whole + int(remainder * 2 > target.denominator)
        allocated = rounded - previous
        previous = rounded
        if allocated:
            result.append({"procurement_id": key, "amount": f"{allocated // 100}.{allocated % 100:02d}"})
    return json.dumps(result, separators=(",", ":"))


def _migration_decimal_sum(values_json):
    from backend.modules.trade_core.public import decimal_sum

    return format(decimal_sum(Decimal(str(value)) for value in json.loads(values_json)), "f")


def _migration_business_date(value):
    from backend.modules.trade_core.public import business_datetime

    return business_datetime(value).date().isoformat()


def _register_migration_functions(connection):
    connection.create_function("generic_decimal_text", 1, str, deterministic=True)
    connection.create_function("generic_payment_splits_v17", 2, _migration_payment_splits, deterministic=True)
    connection.create_function("generic_decimal_sum_v17", 1, _migration_decimal_sum, deterministic=True)
    connection.create_function("generic_business_date_v17", 1, _migration_business_date, deterministic=True)


# This database's return tables = sales return standard tables + the text case key its API and credit notes
# use, and each item's order line and unit.
GENERIC_RETURN_TABLE_EXTENSIONS = {
    "sales_return_cases": TableExtension(
        "sales_return_cases", columns=(Column("case_id", "TEXT"),),
        indexes=(Index("uq_sales_return_cases_case_id", ("case_id",), unique=True),),
    ),
    "sales_return_case_items": TableExtension(
        "sales_return_case_items", columns=(Column("order_line_id", "TEXT"), Column("unit_id", "INTEGER")),
        foreign_keys=(ForeignKey("order_line_id", "sales_orders", "line_id", "RESTRICT"),
                      ForeignKey("unit_id", "measurement_units", "id", "RESTRICT")),
        indexes=(Index("ix_sales_return_case_items_order_line", ("order_line_id",)),),
    ),
}


def _generic_return_schema_sql(header_name: str) -> tuple[str, ...]:
    statements: list[str] = []
    for table in RETURN_STANDARD_TABLES:
        extension = GENERIC_RETURN_TABLE_EXTENSIONS.get(table.name)
        if table.name == "sales_return_case_items":
            # v19 shipped referencing the pre-v22 line table; v22 rebuilds the table against the sales standard line table.
            extension = replace(extension, foreign_keys=tuple(
                replace(key, ref_table="sales_order_lines") if key.column == "order_line_id" else key for key in extension.foreign_keys))
        full = extended_table(table, extension)
        if table.name == "sales_return_cases":
            full = replace(full, name=header_name)
        statements.extend(create_table_sql(full))
    return tuple(statements)


# This database's location and movement tables = the inventory standard tables + what its commands and
# trade documents key on: a normalized display name per location, the text movement key the receipts and
# fulfillments reference, the aware instant stocktakes cut at, the pre-v20 kind, and the exact quantity text.
GENERIC_LOCATION_TABLE_EXTENSIONS = {
    "locations": TableExtension(
        "locations", columns=(Column("normalized_name", "TEXT"), Column("attributes_json", "TEXT")),
        indexes=(Index("uq_locations_normalized_name", ("normalized_name",), unique=True),),
    ),
}
GENERIC_MOVEMENT_TABLE_EXTENSIONS = {
    "material_inventory_events": TableExtension(
        "material_inventory_events",
        columns=(Column("movement_id", "TEXT"), Column("occurred_at", "TEXT"), Column("movement_kind", "TEXT"),
                 Column("quantity_text", "TEXT", nullable=True)),
        indexes=(Index("uq_material_inventory_events_movement_id", ("movement_id",), unique=True),),
    ),
}


def _generic_inventory_schema_sql() -> tuple[str, ...]:
    return (*create_table_sql(extended_table(LOCATIONS, GENERIC_LOCATION_TABLE_EXTENSIONS["locations"])),
            *create_table_sql(extended_table(MATERIAL_INVENTORY_EVENTS, GENERIC_MOVEMENT_TABLE_EXTENSIONS["material_inventory_events"])))


# This database's purchase order and receipt tables = the procurement standard tables + what its commands, previews
# and action receipts key on: the text order / line / receipt keys, the order's revision, evidence and source, each
# line's exact quantity text, received total and receiving location, and each receipt's inventory action and
# movement, arrival line and over-receipt allowance.
GENERIC_ORDER_TABLE_EXTENSIONS = {
    "procurement_batches": TableExtension(
        "procurement_batches",
        columns=(Column("order_id", "TEXT"), Column("ordered_at", "TEXT"), Column("revision", "INTEGER"),
                 Column("evidence_refs_json", "TEXT"), Column("source_ref", "TEXT"), Column("updated_at", "TEXT")),
        indexes=(Index("uq_procurement_batches_order_id", ("order_id",), unique=True),),
    ),
    "procurements": TableExtension(
        "procurements",
        columns=(Column("line_id", "TEXT"), Column("received_quantity", "TEXT"), Column("receive_location_id", "TEXT"),
                 Column("quantity_text", "TEXT")),
        indexes=(Index("uq_procurements_line_id", ("line_id",), unique=True),
                 Index("ix_procurements_batch_line", ("batch_id", "line_id"))),
        foreign_keys=(ForeignKey("receive_location_id", "locations", "key", "RESTRICT"),),
    ),
}
GENERIC_RECEIPT_TABLE_EXTENSIONS = {
    "procurement_receipt_allocations": TableExtension(
        "procurement_receipt_allocations",
        columns=(Column("receipt_id", "TEXT"), Column("order_id", "TEXT"), Column("inventory_action_id", "TEXT"),
                 Column("inventory_movement_id", "TEXT"), Column("occurred_at", "TEXT"), Column("evidence_refs_json", "TEXT"),
                 Column("receipt_line_id", "TEXT", nullable=True), Column("over_receipt_allowance", "TEXT"),
                 Column("quantity_text", "TEXT")),
        indexes=(Index("uq_procurement_receipt_allocations_receipt_id", ("receipt_id",), unique=True),),
        foreign_keys=(ForeignKey("receipt_event_id", "material_inventory_events", "id", "RESTRICT"),
                      ForeignKey("order_id", "procurement_batches", "order_id", "RESTRICT"),
                      ForeignKey("inventory_action_id", "inventory_action_receipts", "action_id", "RESTRICT"),
                      ForeignKey("inventory_movement_id", "material_inventory_events", "movement_id", "RESTRICT"),
                      ForeignKey("receipt_line_id", "procurement_receipt_lines", "line_id", "RESTRICT")),
    ),
}


def _generic_procurement_schema_sql() -> tuple[str, ...]:
    # v21 shipped with the receipt movement reference among the standard keys; keep that text so its checksum holds.
    extension = GENERIC_RECEIPT_TABLE_EXTENSIONS["procurement_receipt_allocations"]
    movement, *others = extension.foreign_keys
    standard = PROCUREMENT_RECEIPT_ALLOCATIONS
    allocations = extended_table(replace(standard, foreign_keys=(standard.foreign_keys[0], movement, *standard.foreign_keys[1:])),
                                 replace(extension, foreign_keys=tuple(others)))
    return (*create_table_sql(extended_table(PROCUREMENT_BATCHES, GENERIC_ORDER_TABLE_EXTENSIONS["procurement_batches"])),
            *create_table_sql(extended_table(PROCUREMENTS, GENERIC_ORDER_TABLE_EXTENSIONS["procurements"])),
            *create_table_sql(allocations))


def _rebuild_count_guard(source: str, target: str) -> str:
    # A row the copy dropped fails the upgrade (NOT NULL) and keeps the previous version.
    return f"INSERT INTO {target} (id) SELECT NULL WHERE (SELECT COUNT(*) FROM {source}) <> (SELECT COUNT(*) FROM {target})"


def _rebuild_standard_table(table, suffix: str = "_v21") -> tuple[str, ...]:
    """A standard table whose reference changes: rebuilt beside from its definition, renamed last."""
    return (create_table_sql(replace(table, name=f"{table.name}{suffix}"))[0],
            f"INSERT INTO {table.name}{suffix} SELECT * FROM {table.name}",
            f"DROP TABLE {table.name}",
            f"ALTER TABLE {table.name}{suffix} RENAME TO {table.name}",
            *create_table_sql(table)[1:])


def _typed_name_schema_sql() -> tuple[str, ...]:
    statements = []
    for table, new_column in ((MASTER_DATA_ALIASES, "entity_key"),
                              (MASTER_DATA_ALIAS_CANDIDATES, "suggested_entity_key"),
                              (MASTER_DATA_GOVERNANCE_ACTIONS, "selected_entity_key")):
        columns = ", ".join(column.name for column in table.columns if column.name != new_column)
        replacement = replace(table, name=f"{table.name}_v23")
        statements.extend((create_table_sql(replacement)[0],
            f"INSERT INTO {replacement.name} ({columns}) SELECT {columns} FROM {table.name}",
            _rebuild_count_guard(table.name, replacement.name),
            f"DROP TABLE {table.name}", f"ALTER TABLE {replacement.name} RENAME TO {table.name}",
            *create_table_sql(table)[1:]))
    for table in NAME_TABLES:
        statements.extend(create_table_sql(table))
    return tuple(statements)


# This database's sales order and fulfillment tables = the sales standard tables + what its commands, previews and
# action receipts key on: the text order / line / fulfillment keys, the order's revision, evidence and source, each
# line's fulfilled and returned totals and shipping location, and each fulfillment's inventory action and movement.
GENERIC_SALES_ORDER_TABLE_EXTENSIONS = {
    "sales_batches": TableExtension(
        "sales_batches",
        columns=(Column("order_id", "TEXT"), Column("ordered_at", "TEXT"), Column("revision", "INTEGER"),
                 Column("evidence_refs_json", "TEXT"), Column("source_ref", "TEXT"), Column("updated_at", "TEXT")),
        indexes=(Index("uq_sales_batches_order_id", ("order_id",), unique=True),),
    ),
    "sales_orders": TableExtension(
        "sales_orders",
        columns=(Column("line_id", "TEXT"), Column("fulfilled_quantity", "NUMERIC"), Column("returned_quantity", "NUMERIC"),
                 Column("ship_from_location_id", "TEXT")),
        indexes=(Index("uq_sales_orders_line_id", ("line_id",), unique=True),
                 Index("ix_sales_orders_batch_line", ("batch_id", "line_id"))),
        foreign_keys=(ForeignKey("ship_from_location_id", "locations", "key", "RESTRICT"),),
    ),
}
GENERIC_SALES_FULFILLMENT_TABLE_EXTENSIONS = {
    "sales_fulfillments": TableExtension(
        "sales_fulfillments",
        columns=(Column("fulfillment_id", "TEXT"), Column("order_id", "TEXT"), Column("line_id", "TEXT"),
                 Column("inventory_action_id", "TEXT"), Column("inventory_movement_id", "TEXT"), Column("occurred_at", "TEXT"),
                 Column("evidence_refs_json", "TEXT")),
        indexes=(Index("uq_sales_fulfillments_fulfillment_id", ("fulfillment_id",), unique=True),),
        foreign_keys=(ForeignKey("order_id", "sales_batches", "order_id", "RESTRICT"),
                      ForeignKey("line_id", "sales_orders", "line_id", "RESTRICT"),
                      ForeignKey("inventory_action_id", "inventory_action_receipts", "action_id", "RESTRICT"),
                      ForeignKey("inventory_movement_id", "material_inventory_events", "movement_id", "RESTRICT")),
    ),
}


def _service_order_schema_sql() -> tuple[str, ...]:
    from backend.modules.sales.service_fulfillment import service_schema_sql

    # Merchandise sales still require a dispatch location in their Owner.
    # A service line has no physical stock and can leave that reference empty.
    lines = extended_table(SALES_ORDERS, GENERIC_SALES_ORDER_TABLE_EXTENSIONS["sales_orders"])
    columns = tuple(replace(c, nullable=True) if c.name == "ship_from_location_id" else c for c in lines.columns)
    return (*_rebuild_standard_table(replace(lines, columns=columns), "_v24"), *service_schema_sql())


def _generic_sales_schema_sql() -> tuple[str, ...]:
    # The line table takes the old header's name and the fulfillment table keeps its own: both are created beside
    # and renamed last (as v19 did), so their foreign-key text already names the final tables.
    return (*create_table_sql(extended_table(SALES_BATCHES, GENERIC_SALES_ORDER_TABLE_EXTENSIONS["sales_batches"])),
            *create_table_sql(replace(extended_table(SALES_ORDERS, GENERIC_SALES_ORDER_TABLE_EXTENSIONS["sales_orders"]),
                                      name="sales_orders_v22")),
            *create_table_sql(replace(extended_table(SALES_FULFILLMENTS, GENERIC_SALES_FULFILLMENT_TABLE_EXTENSIONS["sales_fulfillments"]),
                                      name="sales_fulfillments_v22")))


_V20_MOVEMENT_COLUMNS = """(event_date, event_type, product_id, quantity, quantity_unit_id, from_location_id, to_location_id,
                source_kind, source_record_key, evidence_ref, is_reversal, reverses_event_id, status, notes, created_by, created_at,
                movement_id, occurred_at, movement_kind, quantity_text)"""
# The source key is the source_ref made unique with the movement key (what the Owner writes from v20 on); the write
# time is the action receipt's.
_V20_SOURCE_KEY = "m.source_ref || ':' || m.movement_id"
_V20_CREATED_AT = """COALESCE((SELECT r.created_at FROM inventory_action_receipts r, json_each(r.movement_ids_json) j
                WHERE j.value=m.movement_id), m.occurred_at)"""


MIGRATIONS: tuple[KernelMigration, ...] = (
    KernelMigration(
        version=1,
        migration_id="generic-kernel-baseline-v1",
        owner_ref="generic.kernel_smoke:runtime",
        dependencies=(),
        statements=(
            """CREATE TABLE kernel_instance_metadata (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            )""",
            """CREATE TABLE kernel_migration_ledger (
                lineage_id TEXT NOT NULL,
                migration_version INTEGER NOT NULL,
                migration_id TEXT NOT NULL,
                checksum TEXT NOT NULL,
                applied_at TEXT NOT NULL,
                PRIMARY KEY (lineage_id, migration_version),
                UNIQUE (lineage_id, migration_id)
            )""",
            """CREATE TABLE kernel_audit_events (
                event_id TEXT PRIMARY KEY,
                event_type TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                created_at TEXT NOT NULL
            )""",
        ),
    ),
    KernelMigration(
        version=2,
        migration_id="generic-master-data-catalog-v1",
        owner_ref="master_data:catalog-owner",
        dependencies=("generic-kernel-baseline-v1",),
        statements=(
            # 第 2 号已随 0.1.23 发出：标准表当时的建表语句原样写死，标准表以后再改要新加一条改表。
            """CREATE TABLE business_parties (
    id INTEGER NOT NULL,
    canonical_name VARCHAR(200) NOT NULL,
    legal_name VARCHAR(240) NOT NULL,
    status VARCHAR(30) NOT NULL,
    successor_party_id INTEGER,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uq_business_parties_canonical_name UNIQUE (canonical_name),
    CONSTRAINT ck_business_parties_status CHECK (status IN ('active', 'deprecated')),
    FOREIGN KEY(successor_party_id) REFERENCES business_parties (id) ON DELETE RESTRICT
)""",
            """CREATE INDEX ix_business_parties_status_name ON business_parties (status, canonical_name)""",
            """CREATE TABLE business_party_roles (
    id INTEGER NOT NULL,
    party_id INTEGER NOT NULL,
    role_key VARCHAR(40) NOT NULL,
    created_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uq_business_party_roles_party_role UNIQUE (party_id, role_key),
    FOREIGN KEY(party_id) REFERENCES business_parties (id) ON DELETE CASCADE
)""",
            """CREATE INDEX ix_business_party_roles_role_party ON business_party_roles (role_key, party_id)""",
            """CREATE TABLE business_party_identifiers (
    id INTEGER NOT NULL,
    party_id INTEGER NOT NULL,
    identifier_type VARCHAR(40) NOT NULL,
    normalized_value VARCHAR(80) NOT NULL,
    display_value VARCHAR(80) NOT NULL,
    status VARCHAR(30) DEFAULT 'active' NOT NULL,
    source_kind VARCHAR(60) NOT NULL,
    source_ref VARCHAR(240) NOT NULL,
    evidence_hash VARCHAR(64) NOT NULL,
    evidence_json TEXT NOT NULL,
    confirmed_by VARCHAR(120) NOT NULL,
    confirmed_at DATETIME,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uq_business_party_identifiers_type_value UNIQUE (identifier_type, normalized_value),
    CONSTRAINT ck_business_party_identifiers_type CHECK (identifier_type IN ('tax_id', 'unified_social_credit_code', 'registration_no', 'phone')),
    CONSTRAINT ck_business_party_identifiers_status CHECK (status IN ('active', 'deprecated')),
    FOREIGN KEY(party_id) REFERENCES business_parties (id) ON DELETE CASCADE
)""",
            """CREATE INDEX ix_business_party_identifiers_party_status ON business_party_identifiers (party_id, status)""",
            """CREATE INDEX ix_business_party_identifiers_value_status ON business_party_identifiers (normalized_value, status)""",
            """CREATE TABLE business_contacts (
    id INTEGER NOT NULL,
    party_id INTEGER NOT NULL,
    contact_name VARCHAR(120) NOT NULL,
    normalized_name VARCHAR(120) NOT NULL,
    contact_role VARCHAR(80) NOT NULL,
    email_domain VARCHAR(160) NOT NULL,
    source VARCHAR(160) NOT NULL,
    status VARCHAR(30) NOT NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uq_business_contacts_party_name UNIQUE (party_id, normalized_name),
    CONSTRAINT ck_business_contacts_status CHECK (status IN ('active', 'deprecated')),
    FOREIGN KEY(party_id) REFERENCES business_parties (id) ON DELETE CASCADE
)""",
            """CREATE INDEX ix_business_contacts_normalized_name ON business_contacts (normalized_name)""",
            """CREATE TABLE master_data_aliases (
    id INTEGER NOT NULL,
    entity_type VARCHAR(20) NOT NULL,
    entity_id INTEGER NOT NULL,
    alias_name VARCHAR(240) NOT NULL,
    normalized_alias VARCHAR(240) NOT NULL,
    source_scope VARCHAR(160) DEFAULT '' NOT NULL,
    alias_status VARCHAR(30) NOT NULL,
    origin VARCHAR(160) NOT NULL,
    confidence NUMERIC,
    evidence_json TEXT NOT NULL,
    confirmed_by VARCHAR(120) NOT NULL,
    confirmed_at DATETIME,
    created_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uq_master_data_aliases_entity_identity UNIQUE (entity_type, entity_id, normalized_alias, source_scope),
    CONSTRAINT ck_master_data_aliases_entity_type CHECK (entity_type IN ('party', 'product', 'unit')),
    CONSTRAINT ck_master_data_aliases_status CHECK (alias_status IN ('confirmed', 'ambiguous', 'deprecated'))
)""",
            """CREATE INDEX ix_master_data_aliases_entity_status ON master_data_aliases (entity_type, entity_id, alias_status)""",
            """CREATE UNIQUE INDEX uq_master_data_aliases_confirmed_wording ON master_data_aliases (entity_type, normalized_alias, source_scope) WHERE alias_status = 'confirmed'""",
            """CREATE TABLE measurement_units (
    id INTEGER NOT NULL,
    canonical_code VARCHAR(40) NOT NULL,
    display_name VARCHAR(60) NOT NULL,
    dimension VARCHAR(40) NOT NULL,
    factor_to_base NUMERIC,
    status VARCHAR(30) NOT NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uq_measurement_units_code UNIQUE (canonical_code),
    CONSTRAINT ck_measurement_units_status CHECK (status IN ('active', 'deprecated'))
)""",
            """CREATE INDEX ix_measurement_units_dimension_status ON measurement_units (dimension, status)""",
            """CREATE TABLE products (
    id INTEGER NOT NULL,
    canonical_name VARCHAR(160) NOT NULL,
    product_family VARCHAR(80) NOT NULL,
    status VARCHAR(30) NOT NULL,
    successor_product_id INTEGER,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uq_products_canonical_name UNIQUE (canonical_name),
    CONSTRAINT ck_products_status CHECK (status IN ('active', 'deprecated')),
    FOREIGN KEY(successor_product_id) REFERENCES products (id) ON DELETE RESTRICT
)""",
            """CREATE INDEX ix_products_status_family ON products (status, product_family)""",
            """CREATE TABLE master_data_alias_candidates (
    id INTEGER NOT NULL,
    domain VARCHAR(40) NOT NULL,
    raw_text VARCHAR(240) NOT NULL,
    normalized_text VARCHAR(240) NOT NULL,
    suggested_entity_type VARCHAR(40) NOT NULL,
    suggested_entity_id INTEGER,
    suggested_canonical_name VARCHAR(240) NOT NULL,
    business_role VARCHAR(40) NOT NULL,
    source_kind VARCHAR(40) NOT NULL,
    source_id INTEGER,
    source_key VARCHAR(240) NOT NULL,
    source_scope VARCHAR(160) NOT NULL,
    agent_name VARCHAR(80) NOT NULL,
    confidence NUMERIC,
    strong_anchors_json TEXT NOT NULL,
    evidence_json TEXT NOT NULL,
    status VARCHAR(30) NOT NULL,
    reviewed_by VARCHAR(120) NOT NULL,
    reviewed_at DATETIME,
    review_note TEXT NOT NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT ck_master_data_alias_candidates_domain CHECK (domain IN ('party', 'product', 'unit')),
    CONSTRAINT ck_master_data_alias_candidates_status CHECK (status IN ('candidate', 'confirmed', 'rejected', 'deprecated'))
)""",
            """CREATE INDEX ix_master_data_alias_candidates_normalized ON master_data_alias_candidates (domain, normalized_text)""",
            """CREATE INDEX ix_master_data_alias_candidates_status_domain ON master_data_alias_candidates (status, domain)""",
            """CREATE UNIQUE INDEX uq_master_data_alias_candidates_active_source ON master_data_alias_candidates (domain, normalized_text, source_key) WHERE status = 'candidate'""",
            """CREATE TABLE master_data_write_intents (
    id INTEGER NOT NULL,
    intent_key VARCHAR(80) NOT NULL,
    action VARCHAR(50) NOT NULL,
    domain VARCHAR(40) NOT NULL,
    raw_text VARCHAR(240) NOT NULL,
    normalized_text VARCHAR(240) NOT NULL,
    source_kind VARCHAR(60) NOT NULL,
    source_id INTEGER,
    source_key VARCHAR(240) NOT NULL,
    source_hash VARCHAR(64) NOT NULL,
    payload_json TEXT NOT NULL,
    evidence_refs_json TEXT NOT NULL,
    evidence_hash VARCHAR(64) NOT NULL,
    preview_token VARCHAR(64) NOT NULL,
    selected_canonical_ref VARCHAR(80) NOT NULL,
    selected_entity_id INTEGER,
    status VARCHAR(30) DEFAULT 'previewed' NOT NULL,
    owner VARCHAR(160) NOT NULL,
    requested_by VARCHAR(120) NOT NULL,
    applied_by VARCHAR(120) NOT NULL,
    governance_action_key VARCHAR(80) NOT NULL,
    error_text TEXT NOT NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    applied_at DATETIME,
    PRIMARY KEY (id),
    UNIQUE (intent_key),
    CONSTRAINT ck_master_data_write_intents_action CHECK (action IN ('link_alias_to_existing', 'enrich_party_profile', 'create_supplier', 'confirm_unit_alias')),
    CONSTRAINT ck_master_data_write_intents_domain CHECK (domain IN ('party', 'unit')),
    CONSTRAINT ck_master_data_write_intents_status CHECK (status IN ('previewed', 'applied', 'rejected', 'failed'))
)""",
            """CREATE INDEX ix_master_data_write_intents_source ON master_data_write_intents (source_kind, source_id)""",
            """CREATE INDEX ix_master_data_write_intents_status_created ON master_data_write_intents (status, created_at)""",
            """CREATE TABLE master_data_governance_actions (
    id INTEGER NOT NULL,
    action_key VARCHAR(80) NOT NULL,
    module_key VARCHAR(80) NOT NULL,
    source_kind VARCHAR(80) NOT NULL,
    source_field VARCHAR(80) NOT NULL,
    domain VARCHAR(40) NOT NULL,
    raw_text VARCHAR(240) NOT NULL,
    normalized_text VARCHAR(240) NOT NULL,
    selected_canonical_ref VARCHAR(80) NOT NULL,
    selected_entity_id INTEGER NOT NULL,
    selected_canonical_label VARCHAR(240) NOT NULL,
    affected_row_count INTEGER NOT NULL,
    affected_row_ids_json TEXT NOT NULL,
    projection_before_json TEXT NOT NULL,
    projection_after_json TEXT NOT NULL,
    status VARCHAR(30) NOT NULL,
    reviewed_by VARCHAR(120) NOT NULL,
    review_note TEXT NOT NULL,
    reverted_at DATETIME,
    created_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    UNIQUE (action_key),
    CONSTRAINT ck_master_data_governance_actions_domain CHECK (domain IN ('party', 'product', 'unit')),
    CONSTRAINT ck_master_data_governance_actions_status CHECK (status IN ('applied', 'reverted'))
)""",
            """CREATE INDEX ix_master_data_governance_actions_source ON master_data_governance_actions (module_key, source_kind, source_field)""",
            """CREATE INDEX ix_master_data_governance_actions_target ON master_data_governance_actions (domain, selected_entity_id)""",
            """CREATE TABLE master_data_resolution_events (
    id INTEGER NOT NULL,
    domain VARCHAR(40) NOT NULL,
    raw_text VARCHAR(240) NOT NULL,
    normalized_text VARCHAR(240) NOT NULL,
    canonical_entity_type VARCHAR(40) NOT NULL,
    canonical_entity_id INTEGER,
    canonical_label VARCHAR(240) NOT NULL,
    resolution_method VARCHAR(60) NOT NULL,
    confidence NUMERIC,
    evidence_refs_json TEXT NOT NULL,
    ambiguity_reasons_json TEXT NOT NULL,
    source_kind VARCHAR(40) NOT NULL,
    source_id INTEGER,
    source_key VARCHAR(240) NOT NULL,
    agent_name VARCHAR(80) NOT NULL,
    decision_id INTEGER,
    alias_candidate_id INTEGER,
    status VARCHAR(30) NOT NULL,
    created_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT ck_master_data_resolution_events_domain CHECK (domain IN ('party', 'product', 'unit')),
    CONSTRAINT ck_master_data_resolution_events_status CHECK (status IN ('resolved', 'review', 'new_entity_candidate')),
    FOREIGN KEY(alias_candidate_id) REFERENCES master_data_alias_candidates (id) ON DELETE SET NULL
)""",
            """CREATE INDEX ix_master_data_resolution_events_domain_created ON master_data_resolution_events (domain, created_at)""",
            """CREATE INDEX ix_master_data_resolution_events_entity ON master_data_resolution_events (canonical_entity_type, canonical_entity_id)""",
            """CREATE INDEX ix_master_data_resolution_events_source ON master_data_resolution_events (source_kind, source_id)""",
            """CREATE TABLE location_catalog (
                location_id TEXT PRIMARY KEY,
                canonical_name TEXT NOT NULL,
                normalized_name TEXT NOT NULL UNIQUE,
                status TEXT NOT NULL CHECK(status IN ('active', 'deprecated')),
                attributes_json TEXT NOT NULL
            )""",
            """CREATE TABLE master_data_external_identities (
                resource_kind TEXT NOT NULL CHECK(resource_kind IN ('party', 'product', 'unit', 'location')),
                source_id TEXT NOT NULL,
                external_id TEXT NOT NULL,
                resource_id TEXT NOT NULL,
                alias TEXT NOT NULL,
                normalized_alias TEXT NOT NULL,
                status TEXT NOT NULL CHECK(status IN ('active', 'deprecated')),
                PRIMARY KEY(resource_kind, source_id, external_id)
            )""",
            """CREATE UNIQUE INDEX uq_master_data_external_alias
                ON master_data_external_identities(resource_kind, source_id, normalized_alias)
                WHERE normalized_alias <> '' AND status = 'active'""",
        ),
    ),
    KernelMigration(
        version=3,
        migration_id="generic-inventory-core-v1",
        owner_ref="inventory:movement-owner",
        dependencies=("generic-master-data-catalog-v1",),
        statements=(
            """CREATE TABLE inventory_movements (
                movement_id TEXT PRIMARY KEY,
                movement_kind TEXT NOT NULL CHECK(movement_kind IN (
                    'inbound', 'outbound', 'transfer', 'stocktake_adjustment', 'reversal', 'correction'
                )),
                product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
                unit_id INTEGER NOT NULL REFERENCES measurement_units(id) ON DELETE RESTRICT,
                quantity NUMERIC NOT NULL CHECK(quantity > 0),
                from_location_id TEXT REFERENCES location_catalog(location_id) ON DELETE RESTRICT,
                to_location_id TEXT REFERENCES location_catalog(location_id) ON DELETE RESTRICT,
                reverses_movement_id TEXT UNIQUE REFERENCES inventory_movements(movement_id) ON DELETE RESTRICT,
                occurred_at TEXT NOT NULL,
                source_ref TEXT NOT NULL,
                reason TEXT NOT NULL,
                CHECK(
                    (from_location_id IS NULL AND to_location_id IS NOT NULL) OR
                    (from_location_id IS NOT NULL AND to_location_id IS NULL) OR
                    (from_location_id IS NOT NULL AND to_location_id IS NOT NULL AND from_location_id <> to_location_id)
                )
            )""",
            """CREATE INDEX ix_inventory_movements_product_unit_time
                ON inventory_movements(product_id, unit_id, occurred_at, movement_id)""",
            """CREATE INDEX ix_inventory_movements_from_location
                ON inventory_movements(from_location_id, product_id, unit_id)""",
            """CREATE INDEX ix_inventory_movements_to_location
                ON inventory_movements(to_location_id, product_id, unit_id)""",
            """CREATE TRIGGER inventory_movements_immutable_update
                BEFORE UPDATE ON inventory_movements
                BEGIN SELECT RAISE(ABORT, 'inventory_movements_immutable'); END""",
            """CREATE TRIGGER inventory_movements_immutable_delete
                BEFORE DELETE ON inventory_movements
                BEGIN SELECT RAISE(ABORT, 'inventory_movements_immutable'); END""",
            """CREATE TABLE inventory_stocktakes (
                stocktake_id TEXT PRIMARY KEY,
                product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
                unit_id INTEGER NOT NULL REFERENCES measurement_units(id) ON DELETE RESTRICT,
                location_id TEXT NOT NULL REFERENCES location_catalog(location_id) ON DELETE RESTRICT,
                actual_quantity NUMERIC NOT NULL CHECK(actual_quantity >= 0),
                projected_quantity NUMERIC NOT NULL,
                occurred_at TEXT NOT NULL,
                source_ref TEXT NOT NULL
            )""",
            """CREATE TABLE inventory_audit_events (
                event_id TEXT PRIMARY KEY,
                event_type TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                created_at TEXT NOT NULL
            )""",
            """CREATE TABLE inventory_action_receipts (
                action_id TEXT PRIMARY KEY,
                idempotency_key TEXT NOT NULL UNIQUE,
                command_digest TEXT NOT NULL,
                preview_digest TEXT NOT NULL,
                movement_ids_json TEXT NOT NULL,
                stocktake_id TEXT REFERENCES inventory_stocktakes(stocktake_id) ON DELETE RESTRICT,
                audit_event_id TEXT NOT NULL REFERENCES inventory_audit_events(event_id) ON DELETE RESTRICT,
                created_at TEXT NOT NULL
            )""",
        ),
    ),
    KernelMigration(
        version=4,
        migration_id="generic-procurement-v1",
        owner_ref="procurement:order-owner",
        dependencies=("generic-inventory-core-v1",),
        statements=(
            """CREATE TABLE procurement_orders (
                order_id TEXT PRIMARY KEY,
                supplier_party_id INTEGER NOT NULL REFERENCES business_parties(id) ON DELETE RESTRICT,
                ordered_at TEXT NOT NULL,
                status TEXT NOT NULL CHECK(status IN ('open', 'partially_received', 'received', 'cancelled')),
                revision INTEGER NOT NULL CHECK(revision >= 1),
                evidence_refs_json TEXT NOT NULL,
                source_ref TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )""",
            """CREATE TABLE procurement_order_lines (
                line_id TEXT PRIMARY KEY,
                order_id TEXT NOT NULL REFERENCES procurement_orders(order_id) ON DELETE RESTRICT,
                product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
                unit_id INTEGER NOT NULL REFERENCES measurement_units(id) ON DELETE RESTRICT,
                quantity NUMERIC NOT NULL CHECK(quantity > 0),
                received_quantity NUMERIC NOT NULL CHECK(received_quantity >= 0 AND received_quantity <= quantity),
                receive_location_id TEXT NOT NULL REFERENCES location_catalog(location_id) ON DELETE RESTRICT
            )""",
            """CREATE INDEX ix_procurement_order_lines_order
                ON procurement_order_lines(order_id, line_id)""",
            """CREATE TABLE procurement_receipts (
                receipt_id TEXT PRIMARY KEY,
                order_id TEXT NOT NULL REFERENCES procurement_orders(order_id) ON DELETE RESTRICT,
                line_id TEXT NOT NULL REFERENCES procurement_order_lines(line_id) ON DELETE RESTRICT,
                quantity NUMERIC NOT NULL CHECK(quantity > 0),
                inventory_action_id TEXT NOT NULL REFERENCES inventory_action_receipts(action_id) ON DELETE RESTRICT,
                inventory_movement_id TEXT NOT NULL REFERENCES inventory_movements(movement_id) ON DELETE RESTRICT,
                occurred_at TEXT NOT NULL,
                evidence_refs_json TEXT NOT NULL
            )""",
            """CREATE TABLE procurement_audit_events (
                event_id TEXT PRIMARY KEY,
                event_type TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                created_at TEXT NOT NULL
            )""",
            """CREATE TABLE procurement_action_receipts (
                action_id TEXT PRIMARY KEY,
                idempotency_key TEXT NOT NULL UNIQUE,
                command_digest TEXT NOT NULL,
                preview_digest TEXT NOT NULL,
                order_id TEXT NOT NULL REFERENCES procurement_orders(order_id) ON DELETE RESTRICT,
                audit_event_id TEXT NOT NULL REFERENCES procurement_audit_events(event_id) ON DELETE RESTRICT,
                inventory_action_id TEXT REFERENCES inventory_action_receipts(action_id) ON DELETE RESTRICT,
                created_at TEXT NOT NULL
            )""",
        ),
    ),
    KernelMigration(
        version=5,
        migration_id="generic-sales-v1",
        owner_ref="sales:order-owner",
        dependencies=("generic-procurement-v1",),
        statements=(
            """CREATE TABLE sales_orders (
                order_id TEXT PRIMARY KEY,
                customer_party_id INTEGER NOT NULL REFERENCES business_parties(id) ON DELETE RESTRICT,
                ordered_at TEXT NOT NULL,
                status TEXT NOT NULL CHECK(status IN ('open', 'partially_fulfilled', 'fulfilled', 'partially_returned', 'returned', 'cancelled')),
                revision INTEGER NOT NULL CHECK(revision >= 1),
                evidence_refs_json TEXT NOT NULL,
                source_ref TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )""",
            """CREATE TABLE sales_order_lines (
                line_id TEXT PRIMARY KEY,
                order_id TEXT NOT NULL REFERENCES sales_orders(order_id) ON DELETE RESTRICT,
                product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
                unit_id INTEGER NOT NULL REFERENCES measurement_units(id) ON DELETE RESTRICT,
                quantity NUMERIC NOT NULL CHECK(quantity > 0),
                fulfilled_quantity NUMERIC NOT NULL CHECK(fulfilled_quantity >= 0 AND fulfilled_quantity <= quantity),
                returned_quantity NUMERIC NOT NULL CHECK(returned_quantity >= 0 AND returned_quantity <= fulfilled_quantity),
                ship_from_location_id TEXT NOT NULL REFERENCES location_catalog(location_id) ON DELETE RESTRICT
            )""",
            """CREATE INDEX ix_sales_order_lines_order
                ON sales_order_lines(order_id, line_id)""",
            """CREATE TABLE sales_fulfillments (
                fulfillment_id TEXT PRIMARY KEY,
                fulfillment_kind TEXT NOT NULL CHECK(fulfillment_kind IN ('shipment', 'return')),
                order_id TEXT NOT NULL REFERENCES sales_orders(order_id) ON DELETE RESTRICT,
                line_id TEXT NOT NULL REFERENCES sales_order_lines(line_id) ON DELETE RESTRICT,
                quantity NUMERIC NOT NULL CHECK(quantity > 0),
                inventory_action_id TEXT NOT NULL REFERENCES inventory_action_receipts(action_id) ON DELETE RESTRICT,
                inventory_movement_id TEXT NOT NULL REFERENCES inventory_movements(movement_id) ON DELETE RESTRICT,
                occurred_at TEXT NOT NULL,
                evidence_refs_json TEXT NOT NULL
            )""",
            """CREATE TABLE sales_audit_events (
                event_id TEXT PRIMARY KEY,
                event_type TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                created_at TEXT NOT NULL
            )""",
            """CREATE TABLE sales_action_receipts (
                action_id TEXT PRIMARY KEY,
                idempotency_key TEXT NOT NULL UNIQUE,
                command_digest TEXT NOT NULL,
                preview_digest TEXT NOT NULL,
                order_id TEXT NOT NULL REFERENCES sales_orders(order_id) ON DELETE RESTRICT,
                audit_event_id TEXT NOT NULL REFERENCES sales_audit_events(event_id) ON DELETE RESTRICT,
                inventory_action_id TEXT REFERENCES inventory_action_receipts(action_id) ON DELETE RESTRICT,
                created_at TEXT NOT NULL
            )""",
        ),
    ),
    KernelMigration(
        version=6,
        migration_id="generic-sales-returns-v1",
        owner_ref="sales:order-owner",
        dependencies=("generic-sales-v1",),
        statements=(
            """CREATE TABLE sales_return_cases (
                case_id TEXT PRIMARY KEY,
                order_id TEXT NOT NULL REFERENCES sales_orders(order_id) ON DELETE RESTRICT,
                status TEXT NOT NULL CHECK(status IN ('registered', 'inspected', 'partially_disposed', 'disposed')),
                occurred_at TEXT NOT NULL,
                source_ref TEXT NOT NULL,
                evidence_refs_json TEXT NOT NULL,
                reason TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )""",
            """CREATE TABLE sales_return_case_items (
                case_id TEXT NOT NULL REFERENCES sales_return_cases(case_id) ON DELETE RESTRICT,
                order_line_id TEXT NOT NULL REFERENCES sales_order_lines(line_id) ON DELETE RESTRICT,
                unit_id INTEGER NOT NULL REFERENCES measurement_units(id) ON DELETE RESTRICT,
                quantity NUMERIC NOT NULL CHECK(quantity > 0),
                received_quantity NUMERIC NOT NULL CHECK(received_quantity >= 0 AND received_quantity <= quantity),
                good_quantity NUMERIC NOT NULL CHECK(good_quantity >= 0 AND good_quantity <= received_quantity),
                scrap_quantity NUMERIC NOT NULL CHECK(scrap_quantity >= 0 AND scrap_quantity <= received_quantity),
                disposed_good_quantity NUMERIC NOT NULL CHECK(disposed_good_quantity >= 0 AND disposed_good_quantity <= good_quantity),
                disposed_scrap_quantity NUMERIC NOT NULL CHECK(disposed_scrap_quantity >= 0 AND disposed_scrap_quantity <= scrap_quantity),
                PRIMARY KEY(case_id, order_line_id)
            )""",
            """CREATE TABLE sales_return_case_events (
                event_id TEXT PRIMARY KEY,
                case_id TEXT NOT NULL REFERENCES sales_return_cases(case_id) ON DELETE RESTRICT,
                action TEXT NOT NULL CHECK(action IN ('register', 'inspect', 'dispose')),
                occurred_at TEXT NOT NULL,
                source_ref TEXT NOT NULL,
                evidence_refs_json TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                created_at TEXT NOT NULL
            )""",
            """CREATE TABLE sales_document_action_receipts (
                action_id TEXT PRIMARY KEY,
                idempotency_key TEXT NOT NULL UNIQUE,
                command_digest TEXT NOT NULL,
                preview_digest TEXT NOT NULL,
                document_kind TEXT NOT NULL,
                document_id TEXT NOT NULL,
                order_id TEXT REFERENCES sales_orders(order_id) ON DELETE RESTRICT,
                audit_event_id TEXT NOT NULL REFERENCES sales_audit_events(event_id) ON DELETE RESTRICT,
                created_at TEXT NOT NULL
            )""",
        ),
    ),
    KernelMigration(
        version=7,
        migration_id="generic-sales-invoices-v1",
        owner_ref="sales:order-owner",
        dependencies=("generic-sales-returns-v1",),
        statements=(
            """CREATE TABLE sales_invoices (
                invoice_id TEXT PRIMARY KEY,
                kind TEXT NOT NULL CHECK(kind IN ('invoice', 'credit_note')),
                document_number TEXT NOT NULL,
                customer_party_id INTEGER NOT NULL REFERENCES business_parties(id) ON DELETE RESTRICT,
                currency TEXT NOT NULL CHECK(currency IN ('CNY', 'USD', 'EUR')),
                business_date TEXT NOT NULL,
                amount TEXT NOT NULL,
                original_invoice_id TEXT REFERENCES sales_invoices(invoice_id) ON DELETE RESTRICT,
                return_case_id TEXT REFERENCES sales_return_cases(case_id) ON DELETE RESTRICT,
                source_ref TEXT NOT NULL,
                evidence_refs_json TEXT NOT NULL,
                created_at TEXT NOT NULL,
                UNIQUE(customer_party_id, document_number),
                CHECK((kind='invoice' AND original_invoice_id IS NULL AND return_case_id IS NULL)
                   OR (kind='credit_note' AND original_invoice_id IS NOT NULL))
            )""",
            """CREATE INDEX ix_sales_invoices_original ON sales_invoices(original_invoice_id)""",
            """CREATE TABLE sales_invoice_lines (
                invoice_id TEXT NOT NULL REFERENCES sales_invoices(invoice_id) ON DELETE RESTRICT,
                line_id TEXT NOT NULL,
                amount TEXT NOT NULL,
                order_id TEXT REFERENCES sales_orders(order_id) ON DELETE RESTRICT,
                order_line_id TEXT REFERENCES sales_order_lines(line_id) ON DELETE RESTRICT,
                tax_rate TEXT,
                tax_amount TEXT,
                PRIMARY KEY(invoice_id, line_id),
                CHECK(order_line_id IS NULL OR order_id IS NOT NULL)
            )""",
        ),
    ),
    KernelMigration(
        version=8,
        migration_id="generic-sales-payments-v1",
        owner_ref="sales:order-owner",
        dependencies=("generic-sales-invoices-v1",),
        statements=(
            """CREATE TABLE sales_payments (
                payment_id TEXT PRIMARY KEY,
                business_identity TEXT NOT NULL UNIQUE,
                customer_party_id INTEGER REFERENCES business_parties(id) ON DELETE RESTRICT,
                currency TEXT NOT NULL CHECK(currency IN ('CNY', 'USD', 'EUR')),
                amount TEXT NOT NULL,
                channel TEXT NOT NULL,
                external_reference TEXT,
                reference_missing INTEGER NOT NULL CHECK(reference_missing IN (0, 1)),
                received_at TEXT NOT NULL,
                received_date TEXT NOT NULL,
                business_at TEXT NOT NULL,
                source_ref TEXT NOT NULL,
                evidence_refs_json TEXT NOT NULL,
                created_at TEXT NOT NULL,
                CHECK((external_reference IS NOT NULL AND reference_missing=0)
                   OR (external_reference IS NULL AND reference_missing=1))
            )""",
            """CREATE TABLE sales_payment_allocations (
                allocation_id TEXT PRIMARY KEY,
                payment_id TEXT NOT NULL REFERENCES sales_payments(payment_id) ON DELETE RESTRICT,
                invoice_id TEXT NOT NULL REFERENCES sales_invoices(invoice_id) ON DELETE RESTRICT,
                amount TEXT NOT NULL,
                active INTEGER NOT NULL CHECK(active IN (0, 1)),
                source_ref TEXT NOT NULL,
                evidence_refs_json TEXT NOT NULL,
                created_at TEXT NOT NULL,
                revoked_at TEXT,
                revoked_action_id TEXT REFERENCES sales_document_action_receipts(action_id) ON DELETE RESTRICT,
                CHECK((active=1 AND revoked_at IS NULL AND revoked_action_id IS NULL)
                   OR (active=0 AND revoked_at IS NOT NULL AND revoked_action_id IS NOT NULL))
            )""",
            "CREATE INDEX ix_sales_payment_allocations_invoice ON sales_payment_allocations(invoice_id, active)",
            "CREATE INDEX ix_sales_payment_allocations_payment ON sales_payment_allocations(payment_id, active)",
        ),
    ),
    KernelMigration(
        version=9,
        migration_id="generic-procurement-receipts-v1",
        owner_ref="procurement:order-owner",
        rebuilds_tables=True,
        dependencies=("generic-procurement-v1",),
        statements=(
            """ALTER TABLE inventory_movements ADD COLUMN quantity_text TEXT""",
            """CREATE TABLE procurement_receipt_documents (
                document_id TEXT PRIMARY KEY,
                supplier_party_id INTEGER NOT NULL REFERENCES business_parties(id) ON DELETE RESTRICT,
                source_identity TEXT NOT NULL,
                occurred_at TEXT NOT NULL,
                source_ref TEXT NOT NULL,
                evidence_refs_json TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                UNIQUE(supplier_party_id, source_identity)
            )""",
            """CREATE TABLE procurement_receipt_lines (
                line_id TEXT PRIMARY KEY,
                document_id TEXT NOT NULL REFERENCES procurement_receipt_documents(document_id) ON DELETE RESTRICT,
                product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
                unit_id INTEGER NOT NULL REFERENCES measurement_units(id) ON DELETE RESTRICT,
                order_line_id TEXT REFERENCES procurement_order_lines(line_id) ON DELETE RESTRICT,
                arrived_quantity TEXT NOT NULL,
                received_quantity TEXT NOT NULL,
                accepted_quantity TEXT NOT NULL DEFAULT '0',
                rejected_quantity TEXT NOT NULL DEFAULT '0',
                inspected_at TEXT,
                inspection_evidence_refs_json TEXT
            )""",
            """CREATE INDEX ix_procurement_receipt_lines_document ON procurement_receipt_lines(document_id, line_id)""",
            """CREATE TABLE procurement_order_lines_v9 (
                line_id TEXT PRIMARY KEY,
                order_id TEXT NOT NULL REFERENCES procurement_orders(order_id) ON DELETE RESTRICT,
                product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
                unit_id INTEGER NOT NULL REFERENCES measurement_units(id) ON DELETE RESTRICT,
                quantity TEXT NOT NULL CHECK(CAST(quantity AS NUMERIC) > 0),
                received_quantity TEXT NOT NULL CHECK(CAST(received_quantity AS NUMERIC) >= 0),
                receive_location_id TEXT NOT NULL REFERENCES location_catalog(location_id) ON DELETE RESTRICT
            )""",
            """INSERT INTO procurement_order_lines_v9 (line_id, order_id, product_id, unit_id, quantity, received_quantity, receive_location_id) SELECT line_id, order_id, product_id, unit_id, generic_decimal_text(quantity), generic_decimal_text(received_quantity), receive_location_id FROM procurement_order_lines""",
            """DROP TABLE procurement_order_lines""",
            """ALTER TABLE procurement_order_lines_v9 RENAME TO procurement_order_lines""",
            """CREATE INDEX ix_procurement_order_lines_order ON procurement_order_lines(order_id, line_id)""",
            """CREATE TABLE procurement_receipts_v9 (
                receipt_id TEXT PRIMARY KEY,
                order_id TEXT NOT NULL REFERENCES procurement_orders(order_id) ON DELETE RESTRICT,
                line_id TEXT NOT NULL REFERENCES procurement_order_lines(line_id) ON DELETE RESTRICT,
                quantity TEXT NOT NULL CHECK(CAST(quantity AS NUMERIC) > 0),
                inventory_action_id TEXT NOT NULL REFERENCES inventory_action_receipts(action_id) ON DELETE RESTRICT,
                inventory_movement_id TEXT NOT NULL REFERENCES inventory_movements(movement_id) ON DELETE RESTRICT,
                occurred_at TEXT NOT NULL,
                evidence_refs_json TEXT NOT NULL,
                receipt_line_id TEXT REFERENCES procurement_receipt_lines(line_id) ON DELETE RESTRICT,
                over_receipt_allowance TEXT NOT NULL DEFAULT '0'
            )""",
            """INSERT INTO procurement_receipts_v9 (receipt_id, order_id, line_id, quantity, inventory_action_id, inventory_movement_id, occurred_at, evidence_refs_json) SELECT receipt_id, order_id, line_id, generic_decimal_text(quantity), inventory_action_id, inventory_movement_id, occurred_at, evidence_refs_json FROM procurement_receipts""",
            """DROP TABLE procurement_receipts""",
            """ALTER TABLE procurement_receipts_v9 RENAME TO procurement_receipts""",
            """CREATE TABLE procurement_action_receipts_v9 (
                action_id TEXT PRIMARY KEY,
                idempotency_key TEXT NOT NULL UNIQUE,
                command_digest TEXT NOT NULL,
                preview_digest TEXT NOT NULL,
                order_id TEXT REFERENCES procurement_orders(order_id) ON DELETE RESTRICT,
                audit_event_id TEXT NOT NULL REFERENCES procurement_audit_events(event_id) ON DELETE RESTRICT,
                inventory_action_id TEXT REFERENCES inventory_action_receipts(action_id) ON DELETE RESTRICT,
                created_at TEXT NOT NULL,
                document_kind TEXT NOT NULL DEFAULT 'order',
                document_id TEXT NOT NULL DEFAULT ''
            )""",
            """INSERT INTO procurement_action_receipts_v9 (action_id, idempotency_key, command_digest, preview_digest, order_id, audit_event_id, inventory_action_id, created_at) SELECT action_id, idempotency_key, command_digest, preview_digest, order_id, audit_event_id, inventory_action_id, created_at FROM procurement_action_receipts""",
            """DROP TABLE procurement_action_receipts""",
            """ALTER TABLE procurement_action_receipts_v9 RENAME TO procurement_action_receipts""",
        ),
    ),
    KernelMigration(
        version=10,
        migration_id="generic-procurement-invoices-v1",
        owner_ref="procurement:order-owner",
        dependencies=("generic-procurement-receipts-v1",),
        statements=(
            """CREATE TABLE procurement_order_line_terms (
                terms_id TEXT PRIMARY KEY,
                order_line_id TEXT NOT NULL REFERENCES procurement_order_lines(line_id) ON DELETE RESTRICT,
                version INTEGER NOT NULL CHECK(version>0),
                active INTEGER NOT NULL CHECK(active IN (0, 1)),
                currency TEXT NOT NULL,
                pricing_quantity TEXT NOT NULL,
                pricing_unit_id INTEGER NOT NULL REFERENCES measurement_units(id) ON DELETE RESTRICT,
                unit_price TEXT,
                agreed_amount TEXT,
                tax_basis TEXT NOT NULL,
                quantity_tolerance TEXT,
                quantity_tolerance_unit_id INTEGER REFERENCES measurement_units(id) ON DELETE RESTRICT,
                amount_tolerance TEXT,
                amount_tolerance_currency TEXT,
                source_kind TEXT NOT NULL,
                source_ref TEXT NOT NULL,
                evidence_refs_json TEXT NOT NULL,
                created_at TEXT NOT NULL,
                superseded_by TEXT REFERENCES procurement_order_line_terms(terms_id) ON DELETE RESTRICT,
                UNIQUE(order_line_id, version),
                CHECK(unit_price IS NOT NULL OR agreed_amount IS NOT NULL)
            )""",
            "CREATE UNIQUE INDEX ux_procurement_current_terms ON procurement_order_line_terms(order_line_id) WHERE active=1",
            """CREATE TABLE procurement_invoices (
                invoice_id TEXT PRIMARY KEY,
                supplier_party_id INTEGER NOT NULL REFERENCES business_parties(id) ON DELETE RESTRICT,
                external_invoice_number TEXT NOT NULL,
                currency TEXT NOT NULL,
                business_date TEXT NOT NULL,
                tax_basis TEXT NOT NULL,
                total_amount TEXT NOT NULL,
                net_amount TEXT,
                tax_amount TEXT,
                tax_rate TEXT,
                source_ref TEXT NOT NULL,
                evidence_refs_json TEXT NOT NULL,
                created_at TEXT NOT NULL,
                UNIQUE(supplier_party_id, external_invoice_number)
            )""",
            """CREATE TABLE procurement_invoice_lines (
                line_id TEXT PRIMARY KEY,
                invoice_id TEXT NOT NULL REFERENCES procurement_invoices(invoice_id) ON DELETE RESTRICT,
                product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
                unit_id INTEGER NOT NULL REFERENCES measurement_units(id) ON DELETE RESTRICT,
                quantity TEXT NOT NULL,
                amount TEXT,
                unit_price TEXT,
                tax_amount TEXT
            )""",
            """CREATE TABLE procurement_invoice_matches (
                match_id TEXT PRIMARY KEY,
                invoice_line_id TEXT NOT NULL REFERENCES procurement_invoice_lines(line_id) ON DELETE RESTRICT,
                order_line_id TEXT NOT NULL REFERENCES procurement_order_lines(line_id) ON DELETE RESTRICT,
                receipt_id TEXT NOT NULL REFERENCES procurement_receipts(receipt_id) ON DELETE RESTRICT,
                terms_id TEXT REFERENCES procurement_order_line_terms(terms_id) ON DELETE RESTRICT,
                quantity TEXT NOT NULL,
                amount TEXT,
                expected_amount TEXT,
                quantity_difference TEXT NOT NULL,
                amount_difference TEXT,
                quantity_tolerance TEXT,
                quantity_tolerance_unit_id INTEGER,
                amount_tolerance TEXT,
                amount_tolerance_currency TEXT,
                quantity_status TEXT NOT NULL,
                amount_status TEXT NOT NULL,
                status TEXT NOT NULL,
                clarification_reason TEXT NOT NULL,
                active INTEGER NOT NULL CHECK(active IN (0, 1)),
                source_ref TEXT NOT NULL,
                evidence_refs_json TEXT NOT NULL,
                created_at TEXT NOT NULL,
                revoked_at TEXT,
                revoked_action_id TEXT REFERENCES procurement_action_receipts(action_id) ON DELETE RESTRICT,
                CHECK((active=1 AND revoked_at IS NULL AND revoked_action_id IS NULL)
                   OR (active=0 AND revoked_at IS NOT NULL AND revoked_action_id IS NOT NULL))
            )""",
            "CREATE UNIQUE INDEX ux_procurement_invoice_line_match ON procurement_invoice_matches(invoice_line_id) WHERE active=1",
            "CREATE INDEX ix_procurement_match_receipt ON procurement_invoice_matches(receipt_id, active)",
            "CREATE INDEX ix_procurement_match_order_line ON procurement_invoice_matches(order_line_id, active)",
        ),
    ),
    KernelMigration(
        version=11,
        migration_id="generic-procurement-payments-v1",
        owner_ref="procurement:order-owner",
        dependencies=("generic-procurement-invoices-v1",),
        statements=(
            """CREATE TABLE procurement_payments (
                payment_id TEXT PRIMARY KEY,
                business_identity TEXT NOT NULL UNIQUE,
                supplier_party_id INTEGER NOT NULL REFERENCES business_parties(id) ON DELETE RESTRICT,
                currency TEXT NOT NULL,
                amount TEXT NOT NULL,
                channel TEXT NOT NULL,
                external_reference TEXT NOT NULL,
                paid_at TEXT NOT NULL,
                paid_date TEXT NOT NULL,
                business_at TEXT NOT NULL,
                source_ref TEXT NOT NULL,
                evidence_refs_json TEXT NOT NULL,
                created_at TEXT NOT NULL,
                UNIQUE(supplier_party_id, external_reference)
            )""",
            """CREATE TABLE procurement_payment_allocations (
                allocation_id TEXT PRIMARY KEY,
                payment_id TEXT NOT NULL REFERENCES procurement_payments(payment_id) ON DELETE RESTRICT,
                invoice_id TEXT NOT NULL REFERENCES procurement_invoices(invoice_id) ON DELETE RESTRICT,
                amount TEXT NOT NULL,
                active INTEGER NOT NULL CHECK(active IN (0, 1)),
                source_ref TEXT NOT NULL,
                evidence_refs_json TEXT NOT NULL,
                created_at TEXT NOT NULL,
                revoked_at TEXT,
                revoked_action_id TEXT REFERENCES procurement_action_receipts(action_id) ON DELETE RESTRICT,
                CHECK((active=1 AND revoked_at IS NULL AND revoked_action_id IS NULL)
                   OR (active=0 AND revoked_at IS NOT NULL AND revoked_action_id IS NOT NULL))
            )""",
            "CREATE INDEX ix_procurement_payment_allocations_invoice ON procurement_payment_allocations(invoice_id, active)",
            "CREATE INDEX ix_procurement_payment_allocations_payment ON procurement_payment_allocations(payment_id, active)",
        ),
    ),
    KernelMigration(
        version=12,
        migration_id="generic-procurement-unit-conversion-v1",
        owner_ref="procurement:order-owner",
        dependencies=("generic-procurement-invoices-v1",),
        statements=(
            "ALTER TABLE procurement_order_line_terms ADD COLUMN conversion_from_unit_id INTEGER REFERENCES measurement_units(id) ON DELETE RESTRICT",
            "ALTER TABLE procurement_order_line_terms ADD COLUMN conversion_to_unit_id INTEGER REFERENCES measurement_units(id) ON DELETE RESTRICT",
            "ALTER TABLE procurement_order_line_terms ADD COLUMN conversion_factor TEXT",
            "ALTER TABLE procurement_order_line_terms ADD COLUMN conversion_source_ref TEXT",
            "ALTER TABLE procurement_invoice_matches ADD COLUMN original_quantity TEXT",
            "ALTER TABLE procurement_invoice_matches ADD COLUMN original_unit_id INTEGER REFERENCES measurement_units(id) ON DELETE RESTRICT",
            "ALTER TABLE procurement_invoice_matches ADD COLUMN converted_quantity TEXT",
        ),
    ),
    KernelMigration(
        version=13,
        migration_id="generic-procurement-post-reference-v1",
        owner_ref="procurement:order-owner",
        dependencies=("generic-procurement-receipts-v1",),
        statements=(
            "ALTER TABLE procurement_action_receipts ADD COLUMN post_reference TEXT",
        ),
    ),
    KernelMigration(
        version=14,
        migration_id="generic-prepared-decisions-v1",
        dependencies=("generic-procurement-post-reference-v1",),
        statements=(
            """CREATE TABLE business_agent_decisions (
                id INTEGER PRIMARY KEY, decision_id VARCHAR(64) NOT NULL UNIQUE,
                source_key VARCHAR(300) NOT NULL, source_kind VARCHAR(40) NOT NULL,
                source_id VARCHAR(120), agent_name VARCHAR(80) NOT NULL, record_type VARCHAR(80) NOT NULL,
                input_hash VARCHAR(64) NOT NULL, observed_facts_hash VARCHAR(64) NOT NULL,
                evidence_snapshot_hash VARCHAR(64) NOT NULL, formal_state_version VARCHAR(64) NOT NULL,
                policy_version VARCHAR(40) NOT NULL, model VARCHAR(120), action VARCHAR(40) NOT NULL,
                decision_json TEXT NOT NULL, state VARCHAR(40) NOT NULL,
                supersedes_decision_id VARCHAR(64), authorized_by TEXT, consumed_by TEXT,
                expires_at DATETIME, created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL,
                apply_started_at DATETIME, consumed_at DATETIME, invalidated_at DATETIME
            )""",
            "CREATE INDEX ix_business_agent_decisions_source_created ON business_agent_decisions (source_key, created_at)",
            "CREATE INDEX ix_business_agent_decisions_state_expires ON business_agent_decisions (state, expires_at)",
            "CREATE UNIQUE INDEX uq_business_agent_decisions_active_source ON business_agent_decisions (source_key) WHERE state IN ('current', 'review_pending', 'applying')",
        ),
    ),
    KernelMigration(
        version=15,
        migration_id="generic-source-clusters-v1",
        owner_ref="generic.kernel_smoke:runtime",
        dependencies=("generic-prepared-decisions-v1",),
        statements=(
            """CREATE TABLE business_agent_source_clusters (
                id INTEGER PRIMARY KEY, execution_key VARCHAR(64) NOT NULL UNIQUE,
                cluster_id VARCHAR(80) NOT NULL, agent_name VARCHAR(80) NOT NULL,
                business_date VARCHAR(10) NOT NULL, source_scope TEXT NOT NULL,
                runtime_version VARCHAR(80) NOT NULL, runtime_fingerprint VARCHAR(64) NOT NULL,
                inference_fingerprint VARCHAR(64) NOT NULL, visual_fingerprint VARCHAR(64) NOT NULL,
                deterministic_fingerprint VARCHAR(64) NOT NULL, code_version VARCHAR(80) NOT NULL,
                claim_generation INTEGER NOT NULL, manifest_hash VARCHAR(64) NOT NULL,
                status VARCHAR(40) NOT NULL, manifest_json TEXT NOT NULL,
                coverage_json TEXT, result_json TEXT,
                expected_source_count INTEGER NOT NULL, expected_part_count INTEGER NOT NULL,
                processed_source_count INTEGER NOT NULL, processed_part_count INTEGER NOT NULL,
                attempt_count INTEGER NOT NULL, model_call_count INTEGER NOT NULL,
                retryable BOOLEAN NOT NULL, failure_category VARCHAR(80), error_fingerprint VARCHAR(64),
                last_error TEXT, next_retry_at DATETIME, claim_token VARCHAR(64),
                lease_expires_at DATETIME, started_at DATETIME, completed_at DATETIME,
                created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL
            )""",
            """CREATE INDEX ix_business_agent_source_cluster_queue ON business_agent_source_clusters
                (agent_name, status, next_retry_at, created_at)""",
            """CREATE INDEX ix_business_agent_source_cluster_business_date ON business_agent_source_clusters
                (business_date, agent_name)""",
            """CREATE TABLE business_agent_source_cluster_members (
                id INTEGER PRIMARY KEY,
                cluster_id INTEGER NOT NULL REFERENCES business_agent_source_clusters(id) ON DELETE CASCADE,
                ordinal INTEGER NOT NULL, source_ref VARCHAR(160) NOT NULL,
                source_kind VARCHAR(40) NOT NULL, source_id VARCHAR(160) NOT NULL,
                source_sha256 VARCHAR(64) NOT NULL, coverage_status VARCHAR(40) NOT NULL,
                candidate_refs_json TEXT, error_fingerprint VARCHAR(64), processed_at DATETIME,
                created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL,
                UNIQUE(cluster_id, source_ref), UNIQUE(cluster_id, ordinal)
            )""",
            """CREATE INDEX ix_business_agent_source_cluster_member_source ON business_agent_source_cluster_members
                (source_kind, source_id)""",
        ),
    ),
    KernelMigration(
        version=16,
        migration_id="generic-sales-invoice-coverage-v1",
        owner_ref="sales:order-owner",
        dependencies=("generic-sales-invoices-v1",),
        statements=(
            "ALTER TABLE sales_invoices ADD COLUMN opening_settled INTEGER NOT NULL DEFAULT 0 CHECK(opening_settled IN (0,1))",
            "ALTER TABLE sales_invoices ADD COLUMN shipment_coverage_json TEXT NOT NULL DEFAULT '[]'",
        ),
    ),
    KernelMigration(
        version=17,
        migration_id="generic-procurement-standard-settlement-v1",
        implementation_digest=_digest(_canonical([
            inspect.getsource(_migration_payment_splits), inspect.getsource(_migration_decimal_sum),
            inspect.getsource(_migration_business_date),
        ])),
        owner_ref="procurement:order-owner",
        dependencies=("generic-source-clusters-v1",),
        rebuilds_tables=True,
        statements=('CREATE TEMP TABLE invoice_ids_v17 AS SELECT invoice_id AS source_key, ROW_NUMBER() OVER (ORDER BY '
         'invoice_id) AS id FROM procurement_invoices',
         'CREATE TEMP TABLE payment_ids_v17 AS SELECT payment_id AS source_key, ROW_NUMBER() OVER (ORDER BY '
         'payment_id) AS id FROM procurement_payments',
         'CREATE TABLE procurement_order_lines_v17 (\n'
         '                id INTEGER PRIMARY KEY, line_id TEXT NOT NULL UNIQUE,\n'
         '                order_id TEXT NOT NULL REFERENCES procurement_orders(order_id) ON DELETE RESTRICT,\n'
         '                product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE RESTRICT,\n'
         '                unit_id INTEGER NOT NULL REFERENCES measurement_units(id) ON DELETE RESTRICT,\n'
         '                quantity TEXT NOT NULL CHECK(CAST(quantity AS NUMERIC) > 0),\n'
         '                received_quantity TEXT NOT NULL CHECK(CAST(received_quantity AS NUMERIC) >= 0),\n'
         '                receive_location_id TEXT NOT NULL REFERENCES location_catalog(location_id) ON DELETE '
         'RESTRICT\n'
         '            )',
         'INSERT INTO procurement_order_lines_v17 SELECT ROW_NUMBER() OVER (ORDER BY line_id), * FROM '
         'procurement_order_lines',
         'CREATE TABLE procurement_invoices_v17 (\n'
         '    id INTEGER NOT NULL,\n'
         '    invoice_number VARCHAR(80) NOT NULL,\n'
         '    normalized_invoice_number VARCHAR(80) NOT NULL,\n'
         '    supplier_party_id INTEGER NOT NULL,\n'
         '    supplier_legal_name VARCHAR(240) NOT NULL,\n'
         '    supplier_tax_id VARCHAR(40) NOT NULL,\n'
         '    buyer_legal_name VARCHAR(240) NOT NULL,\n'
         '    buyer_tax_id VARCHAR(40) NOT NULL,\n'
         '    invoice_date DATE NOT NULL,\n'
         '    total_amount NUMERIC NOT NULL,\n'
         "    currency VARCHAR(3) DEFAULT 'CNY' NOT NULL,\n"
         "    positive_flag VARCHAR(20) DEFAULT 'unknown' NOT NULL,\n"
         '    source_key VARCHAR(240) NOT NULL,\n'
         '    tax_basis VARCHAR(30),\n'
         '    net_amount NUMERIC,\n'
         '    tax_amount NUMERIC,\n'
         '    tax_rate NUMERIC,\n'
         '    evidence_refs_json TEXT,\n'
         "    status VARCHAR(30) DEFAULT 'confirmed' NOT NULL,\n"
         "    source_kind VARCHAR(60) DEFAULT 'management_confirmed' NOT NULL,\n"
         '    source_ref TEXT NOT NULL,\n'
         '    notes TEXT NOT NULL,\n'
         '    confirmed_by VARCHAR(120) NOT NULL,\n'
         '    confirmed_at DATETIME NOT NULL,\n'
         '    reversed_by VARCHAR(120) NOT NULL,\n'
         '    reversed_at DATETIME,\n'
         '    created_at DATETIME NOT NULL,\n'
         '    PRIMARY KEY (id),\n'
         "    CONSTRAINT ck_procurement_invoices_positive_flag CHECK (positive_flag IN ('positive', 'negative', "
         "'unknown')),\n"
         "    CONSTRAINT ck_procurement_invoices_status CHECK (status IN ('confirmed', 'reversed')),\n"
         '    CONSTRAINT ck_procurement_invoices_amount_nonzero CHECK (total_amount <> 0),\n'
         '    CONSTRAINT ck_procurement_invoices_currency CHECK (length(currency)=3 AND currency NOT GLOB '
         "'*[^A-Z]*'),\n"
         '    FOREIGN KEY(supplier_party_id) REFERENCES business_parties (id) ON DELETE RESTRICT\n'
         ')',
         'CREATE TABLE procurement_invoice_allocations_v17 (\n'
         '    id INTEGER NOT NULL,\n'
         '    invoice_id INTEGER NOT NULL,\n'
         '    procurement_id INTEGER NOT NULL,\n'
         "    invoice_line_key VARCHAR(160) DEFAULT '' NOT NULL,\n"
         '    allocated_amount NUMERIC NOT NULL,\n'
         "    status VARCHAR(30) DEFAULT 'confirmed' NOT NULL,\n"
         "    source_kind VARCHAR(60) DEFAULT 'management_confirmed' NOT NULL,\n"
         '    source_ref TEXT NOT NULL,\n'
         '    notes TEXT NOT NULL,\n'
         '    confirmed_by VARCHAR(120) NOT NULL,\n'
         '    confirmed_at DATETIME NOT NULL,\n'
         '    reversed_by VARCHAR(120) NOT NULL,\n'
         '    reversed_at DATETIME,\n'
         '    created_at DATETIME NOT NULL,\n'
         '    PRIMARY KEY (id),\n'
         "    CONSTRAINT ck_procurement_invoice_allocation_status CHECK (status IN ('confirmed', 'reversed')),\n"
         '    CONSTRAINT ck_procurement_invoice_allocation_nonzero CHECK (allocated_amount <> 0),\n'
         '    FOREIGN KEY(invoice_id) REFERENCES procurement_invoices (id) ON DELETE CASCADE,\n'
         '    FOREIGN KEY(procurement_id) REFERENCES procurement_order_lines (id) ON DELETE RESTRICT\n'
         ')',
         'CREATE TABLE procurement_payments_v17 (\n'
         '    id INTEGER NOT NULL,\n'
         '    supplier_party_id INTEGER NOT NULL,\n'
         '    payer_legal_name VARCHAR(240) NOT NULL,\n'
         '    payer_tax_id VARCHAR(40) NOT NULL,\n'
         '    business_date DATE NOT NULL,\n'
         '    amount NUMERIC NOT NULL,\n'
         "    currency VARCHAR(3) DEFAULT 'CNY' NOT NULL,\n"
         "    payment_method VARCHAR(30) DEFAULT 'unknown' NOT NULL,\n"
         '    reference_no VARCHAR(160) NOT NULL,\n'
         '    source_key VARCHAR(240) NOT NULL,\n'
         '    paid_at DATETIME,\n'
         '    channel VARCHAR(60),\n'
         "    status VARCHAR(30) DEFAULT 'confirmed' NOT NULL,\n"
         "    source_kind VARCHAR(60) DEFAULT 'management_confirmed' NOT NULL,\n"
         '    source_ref TEXT NOT NULL,\n'
         '    notes TEXT NOT NULL,\n'
         '    confirmed_by VARCHAR(120) NOT NULL,\n'
         '    confirmed_at DATETIME NOT NULL,\n'
         '    reversed_by VARCHAR(120) NOT NULL,\n'
         '    reversed_at DATETIME,\n'
         '    created_at DATETIME NOT NULL,\n'
         '    PRIMARY KEY (id),\n'
         "    CONSTRAINT ck_procurement_payments_method CHECK (payment_method IN ('bank_transfer', "
         "'bank_acceptance', 'cash', 'other', 'unknown')),\n"
         "    CONSTRAINT ck_procurement_payments_status CHECK (status IN ('confirmed', 'reversed')),\n"
         '    CONSTRAINT ck_procurement_payments_amount_positive CHECK (amount > 0),\n'
         '    CONSTRAINT ck_procurement_payments_currency CHECK (length(currency)=3 AND currency NOT GLOB '
         "'*[^A-Z]*'),\n"
         '    FOREIGN KEY(supplier_party_id) REFERENCES business_parties (id) ON DELETE RESTRICT\n'
         ')',
         'CREATE TABLE procurement_payment_allocations_v17 (\n'
         '    id INTEGER NOT NULL,\n'
         '    payment_id INTEGER NOT NULL,\n'
         '    procurement_id INTEGER NOT NULL,\n'
         '    allocated_amount NUMERIC NOT NULL,\n'
         "    status VARCHAR(30) DEFAULT 'confirmed' NOT NULL,\n"
         "    source_kind VARCHAR(60) DEFAULT 'management_confirmed' NOT NULL,\n"
         '    source_ref TEXT NOT NULL,\n'
         '    notes TEXT NOT NULL,\n'
         '    confirmed_by VARCHAR(120) NOT NULL,\n'
         '    confirmed_at DATETIME NOT NULL,\n'
         '    reversed_by VARCHAR(120) NOT NULL,\n'
         '    reversed_at DATETIME,\n'
         '    created_at DATETIME NOT NULL,\n'
         '    PRIMARY KEY (id),\n'
         "    CONSTRAINT ck_procurement_payment_allocation_status CHECK (status IN ('confirmed', 'reversed')),\n"
         '    CONSTRAINT ck_procurement_payment_allocation_positive CHECK (allocated_amount > 0),\n'
         '    FOREIGN KEY(payment_id) REFERENCES procurement_payments (id) ON DELETE CASCADE,\n'
         '    FOREIGN KEY(procurement_id) REFERENCES procurement_order_lines (id) ON DELETE RESTRICT\n'
         ')',
         'CREATE TABLE procurement_settlement_date_revisions_v17 (\n'
         '    id INTEGER NOT NULL,\n'
         '    invoice_id INTEGER,\n'
         '    payment_id INTEGER,\n'
         '    before_date DATE NOT NULL,\n'
         '    after_date DATE NOT NULL,\n'
         '    editor VARCHAR(120) NOT NULL,\n'
         '    notes TEXT NOT NULL,\n'
         '    created_at DATETIME NOT NULL,\n'
         '    PRIMARY KEY (id),\n'
         '    CONSTRAINT ck_procurement_settlement_date_revision_single_owner CHECK ((invoice_id IS NOT NULL AND '
         'payment_id IS NULL) OR (invoice_id IS NULL AND payment_id IS NOT NULL)),\n'
         '    CONSTRAINT ck_procurement_settlement_date_revision_changed CHECK (before_date <> after_date),\n'
         '    FOREIGN KEY(invoice_id) REFERENCES procurement_invoices (id) ON DELETE RESTRICT,\n'
         '    FOREIGN KEY(payment_id) REFERENCES procurement_payments (id) ON DELETE RESTRICT\n'
         ')',
         'INSERT INTO procurement_invoices_v17 '
         '(id,invoice_number,normalized_invoice_number,supplier_party_id,supplier_legal_name,supplier_tax_id,buyer_legal_name,buyer_tax_id,invoice_date,total_amount,currency,positive_flag,source_key,tax_basis,net_amount,tax_amount,tax_rate,evidence_refs_json,status,source_kind,source_ref,notes,confirmed_by,confirmed_at,reversed_by,reversed_at,created_at)\n'
         'SELECT '
         "m.id,i.external_invoice_number,upper(trim(i.external_invoice_number)),i.supplier_party_id,'','','','',i.business_date,i.total_amount,i.currency,CASE "
         "WHEN CAST(i.total_amount AS NUMERIC)>0 THEN 'positive' ELSE 'negative' "
         "END,i.invoice_id,i.tax_basis,i.net_amount,i.tax_amount,i.tax_rate,i.evidence_refs_json,'confirmed','generic_migration',i.source_ref,'','generic_migration',i.created_at,'',NULL,i.created_at "
         'FROM procurement_invoices i JOIN invoice_ids_v17 m ON m.source_key=i.invoice_id',
         'INSERT INTO procurement_payments_v17 '
         '(id,supplier_party_id,payer_legal_name,payer_tax_id,business_date,amount,currency,payment_method,reference_no,source_key,paid_at,channel,status,source_kind,source_ref,notes,confirmed_by,confirmed_at,reversed_by,reversed_at,created_at)\n'
         "SELECT m.id,p.supplier_party_id,'','',generic_business_date_v17(p.business_at),p.amount,p.currency,CASE WHEN p.channel "
         "IN ('bank_transfer','bank_acceptance','cash','other','unknown') THEN p.channel ELSE 'unknown' "
         "END,p.external_reference,p.payment_id,p.paid_at,p.channel,'confirmed','generic_migration',p.source_ref,\n"
         "json_object('legacy_payment_id',p.payment_id,'business_identity',p.business_identity,'business_at',p.business_at,'paid_date',p.paid_date,'evidence_refs_json',p.evidence_refs_json,'legacy_invoice_allocations',json((SELECT "
         "json_group_array(json_object('allocation_id',a.allocation_id,'invoice_id',a.invoice_id,'invoice_number',i.external_invoice_number,'amount',a.amount,'active',a.active,'source_ref',a.source_ref,'evidence_refs_json',a.evidence_refs_json,'created_at',a.created_at,'revoked_at',a.revoked_at,'revoked_action_id',a.revoked_action_id)) "
         'FROM procurement_payment_allocations a JOIN procurement_invoices i ON i.invoice_id=a.invoice_id WHERE '
         'a.payment_id=p.payment_id))),\n'
         "'generic_migration',p.created_at,'',NULL,p.created_at FROM procurement_payments p JOIN payment_ids_v17 m "
         'ON m.source_key=p.payment_id',
         'CREATE TABLE procurement_invoice_lines_v17 (\n'
         '                line_id TEXT PRIMARY KEY,\n'
         '                invoice_id INTEGER NOT NULL REFERENCES procurement_invoices(id) ON DELETE RESTRICT,\n'
         '                product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE RESTRICT,\n'
         '                unit_id INTEGER NOT NULL REFERENCES measurement_units(id) ON DELETE RESTRICT,\n'
         '                quantity TEXT NOT NULL,\n'
         '                amount TEXT,\n'
         '                unit_price TEXT,\n'
         '                tax_amount TEXT\n'
         '            )',
         'INSERT INTO procurement_invoice_lines_v17 SELECT '
         'l.line_id,m.id,l.product_id,l.unit_id,l.quantity,l.amount,l.unit_price,l.tax_amount FROM '
         'procurement_invoice_lines l JOIN invoice_ids_v17 m ON m.source_key=l.invoice_id',
         'CREATE TABLE procurement_invoice_matches_v17 (\n'
         '                match_id TEXT PRIMARY KEY, invoice_id INTEGER NOT NULL REFERENCES '
         'procurement_invoices(id),\n'
         '                invoice_line_id TEXT NOT NULL REFERENCES procurement_invoice_lines(line_id) ON DELETE '
         'RESTRICT,\n'
         '                order_line_id TEXT NOT NULL REFERENCES procurement_order_lines(line_id) ON DELETE '
         'RESTRICT,\n'
         '                receipt_id TEXT NOT NULL REFERENCES procurement_receipts(receipt_id) ON DELETE RESTRICT,\n'
         '                terms_id TEXT REFERENCES procurement_order_line_terms(terms_id) ON DELETE RESTRICT,\n'
         '                original_quantity TEXT, original_unit_id INTEGER REFERENCES measurement_units(id), '
         'converted_quantity TEXT, quantity TEXT NOT NULL,\n'
         '                amount TEXT,\n'
         '                expected_amount TEXT,\n'
         '                quantity_difference TEXT NOT NULL,\n'
         '                amount_difference TEXT,\n'
         '                quantity_tolerance TEXT,\n'
         '                quantity_tolerance_unit_id INTEGER,\n'
         '                amount_tolerance TEXT,\n'
         '                amount_tolerance_currency TEXT,\n'
         '                quantity_status TEXT NOT NULL,\n'
         '                amount_status TEXT NOT NULL,\n'
         '                status TEXT NOT NULL,\n'
         '                clarification_reason TEXT NOT NULL,\n'
         '                active INTEGER NOT NULL CHECK(active IN (0, 1)),\n'
         '                source_ref TEXT NOT NULL,\n'
         '                evidence_refs_json TEXT NOT NULL,\n'
         '                created_at TEXT NOT NULL,\n'
         '                revoked_at TEXT,\n'
         '                revoked_action_id TEXT REFERENCES procurement_action_receipts(action_id) ON DELETE '
         'RESTRICT,\n'
         '                CHECK((active=1 AND revoked_at IS NULL AND revoked_action_id IS NULL)\n'
         '                   OR (active=0 AND revoked_at IS NOT NULL AND revoked_action_id IS NOT NULL))\n'
         '            )',
         'INSERT INTO procurement_invoice_matches_v17 '
         '(match_id,invoice_line_id,order_line_id,receipt_id,terms_id,quantity,amount,expected_amount,quantity_difference,amount_difference,quantity_tolerance,quantity_tolerance_unit_id,amount_tolerance,amount_tolerance_currency,quantity_status,amount_status,status,clarification_reason,active,source_ref,evidence_refs_json,created_at,revoked_at,revoked_action_id,original_quantity,original_unit_id,converted_quantity,invoice_id) '
         'SELECT '
         'm.match_id,m.invoice_line_id,m.order_line_id,m.receipt_id,m.terms_id,m.quantity,m.amount,m.expected_amount,m.quantity_difference,m.amount_difference,m.quantity_tolerance,m.quantity_tolerance_unit_id,m.amount_tolerance,m.amount_tolerance_currency,m.quantity_status,m.amount_status,m.status,m.clarification_reason,m.active,m.source_ref,m.evidence_refs_json,m.created_at,m.revoked_at,m.revoked_action_id,m.original_quantity,m.original_unit_id,m.converted_quantity,ids.id '
         'FROM procurement_invoice_matches m JOIN procurement_invoice_lines l ON l.line_id=m.invoice_line_id JOIN '
         'invoice_ids_v17 ids ON ids.source_key=l.invoice_id',
         'INSERT INTO procurement_invoice_allocations_v17 '
         '(invoice_id,procurement_id,allocated_amount,invoice_line_key,status,source_kind,source_ref,notes,confirmed_by,confirmed_at,reversed_by,reversed_at,created_at)\n'
         'SELECT '
         "m.invoice_id,p.id,m.amount,m.invoice_line_id,'confirmed','generic_migration',m.source_ref,json_object('match_id',m.match_id,'evidence_refs_json',m.evidence_refs_json),'generic_migration',m.created_at,'',NULL,m.created_at "
         'FROM procurement_invoice_matches_v17 m JOIN procurement_order_lines_v17 p ON p.line_id=m.order_line_id '
         'WHERE m.active=1 AND m.amount IS NOT NULL AND CAST(m.amount AS NUMERIC)<>0',
         'CREATE TEMP TABLE payment_splits_v17 AS\n'
         'WITH weights AS (SELECT '
         "l.invoice_id,json_group_array(json_object('procurement_id',p.id,'amount',m.amount)) AS values_json FROM "
         'procurement_invoice_matches m JOIN procurement_invoice_lines l ON l.line_id=m.invoice_line_id JOIN '
         'procurement_order_lines_v17 p ON p.line_id=m.order_line_id WHERE m.active=1 AND m.amount IS NOT NULL GROUP '
         'BY l.invoice_id)\n'
         "SELECT a.*,json_extract(part.value,'$.procurement_id') AS "
         "procurement_id,json_extract(part.value,'$.amount') AS split_amount FROM procurement_payment_allocations a "
         'JOIN weights w ON w.invoice_id=a.invoice_id JOIN procurement_invoices i ON i.invoice_id=a.invoice_id JOIN '
         'procurement_payments p ON p.payment_id=a.payment_id JOIN '
         'json_each(generic_payment_splits_v17(a.amount,w.values_json)) part WHERE i.currency=p.currency',
         'INSERT INTO procurement_payment_allocations_v17 '
         '(payment_id,procurement_id,allocated_amount,status,source_kind,source_ref,notes,confirmed_by,confirmed_at,reversed_by,reversed_at,created_at)\n'
         'SELECT ids.id,s.procurement_id,generic_decimal_sum_v17(json_group_array(s.split_amount)),CASE WHEN '
         "s.active=1 THEN 'confirmed' ELSE 'reversed' "
         "END,'generic_migration',MIN(s.source_ref),json_group_array(json_object('legacy_allocation_id',s.allocation_id,'legacy_invoice_id',s.invoice_id,'amount',s.amount,'evidence_refs_json',s.evidence_refs_json)),'generic_migration',MIN(s.created_at),COALESCE(MIN(s.revoked_action_id),''),MIN(s.revoked_at),MIN(s.created_at) "
         'FROM payment_splits_v17 s JOIN payment_ids_v17 ids ON ids.source_key=s.payment_id WHERE s.split_amount>0 '
         'GROUP BY ids.id,s.procurement_id,s.active',
         'DROP TABLE procurement_invoice_matches',
         'ALTER TABLE procurement_invoice_matches_v17 RENAME TO procurement_invoice_matches',
         'DROP TABLE procurement_invoice_lines',
         'ALTER TABLE procurement_invoice_lines_v17 RENAME TO procurement_invoice_lines',
         'DROP TABLE procurement_payment_allocations',
         'ALTER TABLE procurement_payment_allocations_v17 RENAME TO procurement_payment_allocations',
         'DROP TABLE procurement_payments',
         'ALTER TABLE procurement_payments_v17 RENAME TO procurement_payments',
         'DROP TABLE procurement_invoices',
         'ALTER TABLE procurement_invoices_v17 RENAME TO procurement_invoices',
         'DROP TABLE procurement_order_lines',
         'ALTER TABLE procurement_order_lines_v17 RENAME TO procurement_order_lines',
         'ALTER TABLE procurement_invoice_allocations_v17 RENAME TO procurement_invoice_allocations',
         'ALTER TABLE procurement_settlement_date_revisions_v17 RENAME TO procurement_settlement_date_revisions',
         'CREATE UNIQUE INDEX uq_procurement_invoices_source_key ON procurement_invoices (source_key) WHERE '
         "source_key != ''",
         'CREATE INDEX ix_procurement_invoices_supplier_date ON procurement_invoices (supplier_party_id, '
         'invoice_date)',
         'CREATE INDEX ix_procurement_invoices_status_date ON procurement_invoices (status, invoice_date)',
         'CREATE UNIQUE INDEX uq_procurement_invoice_allocation_pair ON procurement_invoice_allocations (invoice_id, '
         "procurement_id, invoice_line_key) WHERE status = 'confirmed'",
         'CREATE INDEX ix_procurement_invoice_allocation_invoice ON procurement_invoice_allocations (invoice_id, '
         'status)',
         'CREATE INDEX ix_procurement_invoice_allocation_procurement ON procurement_invoice_allocations '
         '(procurement_id, status)',
         'CREATE UNIQUE INDEX uq_procurement_payments_supplier_reference ON procurement_payments (supplier_party_id, '
         "reference_no) WHERE reference_no != '' AND status = 'confirmed'",
         'CREATE UNIQUE INDEX uq_procurement_payments_source_key ON procurement_payments (source_key) WHERE '
         "source_key != ''",
         'CREATE INDEX ix_procurement_payments_supplier_date ON procurement_payments (supplier_party_id, '
         'business_date)',
         'CREATE INDEX ix_procurement_payments_status_date ON procurement_payments (status, business_date)',
         'CREATE UNIQUE INDEX uq_procurement_payment_allocation_pair ON procurement_payment_allocations (payment_id, '
         "procurement_id) WHERE status = 'confirmed'",
         'CREATE INDEX ix_procurement_payment_allocation_payment ON procurement_payment_allocations (payment_id, '
         'status)',
         'CREATE INDEX ix_procurement_payment_allocation_procurement ON procurement_payment_allocations '
         '(procurement_id, status)',
         'CREATE INDEX ix_procurement_settlement_date_revision_invoice ON procurement_settlement_date_revisions '
         '(invoice_id, created_at)',
         'CREATE INDEX ix_procurement_settlement_date_revision_payment ON procurement_settlement_date_revisions '
         '(payment_id, created_at)',
         'CREATE INDEX ix_procurement_order_lines_order ON procurement_order_lines(order_id,line_id)',
         'CREATE UNIQUE INDEX ux_procurement_invoice_line_match ON procurement_invoice_matches(invoice_line_id) '
         'WHERE active=1',
         'CREATE INDEX ix_procurement_match_receipt ON procurement_invoice_matches(receipt_id, active)',
         'CREATE INDEX ix_procurement_match_order_line ON procurement_invoice_matches(order_line_id, active)',
         'CREATE INDEX ix_procurement_match_invoice ON procurement_invoice_matches(invoice_id,active)',
         'UPDATE procurement_action_receipts SET document_id=(SELECT id FROM invoice_ids_v17 WHERE '
         "source_key=document_id) WHERE document_kind='invoice'",
         'UPDATE procurement_action_receipts SET document_id=(SELECT id FROM payment_ids_v17 WHERE '
         "source_key=document_id) WHERE document_kind='payment'",
         'DROP TABLE payment_splits_v17',
         'DROP TABLE invoice_ids_v17',
         'DROP TABLE payment_ids_v17'),
    ),
    KernelMigration(
        version=18,
        migration_id="generic-sales-standard-settlement-v1",
        # Same exact-cent apportionment as v17; JSON key name is v17's, the value is a sales order id (0 = no order).
        implementation_digest=_digest(_canonical([
            inspect.getsource(_migration_payment_splits), inspect.getsource(_migration_decimal_sum),
        ])),
        owner_ref="sales:order-owner",
        dependencies=("generic-sales-invoice-coverage-v1",),
        rebuilds_tables=True,
        statements=(
            # Integer identities for the standard allocation targets; text keys stay unique for existing links.
            """CREATE TABLE sales_orders_v18 (
                id INTEGER PRIMARY KEY,
                order_id TEXT NOT NULL UNIQUE,
                customer_party_id INTEGER NOT NULL REFERENCES business_parties(id) ON DELETE RESTRICT,
                ordered_at TEXT NOT NULL,
                status TEXT NOT NULL CHECK(status IN ('open', 'partially_fulfilled', 'fulfilled', 'partially_returned', 'returned', 'cancelled')),
                revision INTEGER NOT NULL CHECK(revision >= 1),
                evidence_refs_json TEXT NOT NULL,
                source_ref TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )""",
            "INSERT INTO sales_orders_v18 SELECT ROW_NUMBER() OVER (ORDER BY order_id), * FROM sales_orders",
            """CREATE TABLE sales_invoices_v18 (
                id INTEGER PRIMARY KEY,
                invoice_id TEXT NOT NULL UNIQUE,
                kind TEXT NOT NULL CHECK(kind IN ('invoice', 'credit_note')),
                document_number TEXT NOT NULL,
                customer_party_id INTEGER NOT NULL REFERENCES business_parties(id) ON DELETE RESTRICT,
                currency TEXT NOT NULL CHECK(currency IN ('CNY', 'USD', 'EUR')),
                business_date TEXT NOT NULL,
                total_amount TEXT NOT NULL,
                original_invoice_id TEXT REFERENCES sales_invoices(invoice_id) ON DELETE RESTRICT,
                return_case_id TEXT REFERENCES sales_return_cases(case_id) ON DELETE RESTRICT,
                source_ref TEXT NOT NULL,
                evidence_refs_json TEXT NOT NULL,
                created_at TEXT NOT NULL,
                opening_settled INTEGER NOT NULL DEFAULT 0 CHECK(opening_settled IN (0,1)),
                shipment_coverage_json TEXT NOT NULL DEFAULT '[]',
                status TEXT NOT NULL DEFAULT 'confirmed' CHECK(status IN ('confirmed', 'reversed')),
                UNIQUE(customer_party_id, document_number),
                CHECK((kind='invoice' AND original_invoice_id IS NULL AND return_case_id IS NULL)
                   OR (kind='credit_note' AND original_invoice_id IS NOT NULL))
            )""",
            """INSERT INTO sales_invoices_v18 (id, invoice_id, kind, document_number, customer_party_id, currency,
                business_date, total_amount, original_invoice_id, return_case_id, source_ref, evidence_refs_json,
                created_at, opening_settled, shipment_coverage_json)
               SELECT ROW_NUMBER() OVER (ORDER BY invoice_id), invoice_id, kind, document_number, customer_party_id,
                currency, business_date, amount, original_invoice_id, return_case_id, source_ref, evidence_refs_json,
                created_at, opening_settled, shipment_coverage_json FROM sales_invoices""",
            """CREATE TABLE sales_payments_v18 (
                id INTEGER PRIMARY KEY,
                payment_id TEXT NOT NULL UNIQUE,
                business_identity TEXT NOT NULL UNIQUE,
                customer_party_id INTEGER REFERENCES business_parties(id) ON DELETE RESTRICT,
                currency TEXT NOT NULL CHECK(currency IN ('CNY', 'USD', 'EUR')),
                amount TEXT NOT NULL,
                channel TEXT NOT NULL,
                external_reference TEXT,
                reference_missing INTEGER NOT NULL CHECK(reference_missing IN (0, 1)),
                received_at TEXT NOT NULL,
                received_date TEXT NOT NULL,
                business_at TEXT NOT NULL,
                source_ref TEXT NOT NULL,
                evidence_refs_json TEXT NOT NULL,
                created_at TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'confirmed' CHECK(status IN ('confirmed', 'reversed')),
                notes TEXT NOT NULL DEFAULT '',
                CHECK((external_reference IS NOT NULL AND reference_missing=0)
                   OR (external_reference IS NULL AND reference_missing=1))
            )""",
            # The retired invoice allocations stay on the payment as evidence.
            """INSERT INTO sales_payments_v18 (id, payment_id, business_identity, customer_party_id, currency, amount,
                channel, external_reference, reference_missing, received_at, received_date, business_at, source_ref,
                evidence_refs_json, created_at, notes)
               SELECT ROW_NUMBER() OVER (ORDER BY p.payment_id), p.*, COALESCE((SELECT json_object('legacy_invoice_allocations',
                json_group_array(json_object('allocation_id', a.allocation_id, 'invoice_id', a.invoice_id, 'amount', a.amount,
                'active', a.active, 'source_ref', a.source_ref, 'evidence_refs_json', a.evidence_refs_json,
                'created_at', a.created_at, 'revoked_at', a.revoked_at, 'revoked_action_id', a.revoked_action_id)))
                FROM sales_payment_allocations a WHERE a.payment_id=p.payment_id HAVING COUNT(*)>0), '')
               FROM sales_payments p""",
            # Each invoice payment is split by its invoice lines; lines without an order stay customer balance.
            """CREATE TEMP TABLE sales_payment_splits_v18 AS
               WITH weights AS (SELECT l.invoice_id, json_group_array(json_object('procurement_id', COALESCE(o.id, 0),
                   'amount', l.amount)) AS values_json
                 FROM sales_invoice_lines l LEFT JOIN sales_orders_v18 o ON o.order_id=l.order_id GROUP BY l.invoice_id)
               SELECT a.*, json_extract(part.value, '$.procurement_id') AS sales_order_id,
                 json_extract(part.value, '$.amount') AS split_amount
               FROM sales_payment_allocations a JOIN weights w ON w.invoice_id=a.invoice_id
               JOIN json_each(generic_payment_splits_v17(a.amount, w.values_json)) part""",
            "DROP TABLE sales_payment_allocations",
            "DROP TABLE sales_payments",
            "ALTER TABLE sales_payments_v18 RENAME TO sales_payments",
            "DROP TABLE sales_invoices",
            "ALTER TABLE sales_invoices_v18 RENAME TO sales_invoices",
            "DROP TABLE sales_orders",
            "ALTER TABLE sales_orders_v18 RENAME TO sales_orders",
            "CREATE INDEX ix_sales_invoices_original ON sales_invoices(original_invoice_id)",
            *settlement_schema_sql(),
            """INSERT INTO sales_invoice_allocations (invoice_id, sales_order_id, allocated_amount, status, source_kind,
                source_ref, notes, confirmed_by, confirmed_at, reversed_by, reversed_at, created_at)
               SELECT i.id, o.id, generic_decimal_sum_v17(json_group_array(l.amount)), 'confirmed', 'generic_migration',
                i.source_ref, json_object('invoice_line_ids', json_group_array(l.line_id)), 'generic_migration',
                i.created_at, '', NULL, i.created_at
               FROM sales_invoice_lines l JOIN sales_invoices i ON i.invoice_id=l.invoice_id
               JOIN sales_orders o ON o.order_id=l.order_id
               WHERE i.kind='invoice' AND i.opening_settled=0 GROUP BY i.id, o.id""",
            """INSERT INTO sales_payment_allocations (payment_id, sales_order_id, allocated_amount, status, source_kind,
                source_ref, notes, confirmed_by, confirmed_at, reversed_by, reversed_at, created_at)
               SELECT p.id, s.sales_order_id, generic_decimal_sum_v17(json_group_array(s.split_amount)),
                CASE WHEN s.active=1 THEN 'confirmed' ELSE 'reversed' END, 'generic_migration', MIN(s.source_ref),
                json_group_array(json_object('legacy_allocation_id', s.allocation_id, 'legacy_invoice_id', s.invoice_id,
                  'amount', s.amount, 'evidence_refs_json', s.evidence_refs_json)),
                'generic_migration', MIN(s.created_at), COALESCE(MIN(s.revoked_action_id), ''), MIN(s.revoked_at),
                MIN(s.created_at)
               FROM sales_payment_splits_v18 s JOIN sales_payments p ON p.payment_id=s.payment_id
               WHERE s.sales_order_id<>0 GROUP BY p.id, s.sales_order_id, s.active""",
            "DROP TABLE sales_payment_splits_v18",
        ),
    ),
    KernelMigration(
        version=19,
        migration_id="generic-sales-standard-returns-v1",
        owner_ref="sales:order-owner",
        dependencies=("generic-sales-standard-settlement-v1",),
        rebuilds_tables=True,
        statements=(
            # The header keeps its name so credit notes keep their reference; it is rebuilt beside and renamed last.
            "ALTER TABLE sales_return_case_items RENAME TO sales_return_case_items_v18",
            "ALTER TABLE sales_return_case_events RENAME TO sales_return_case_events_v18",
            *_generic_return_schema_sql("sales_return_cases_v19"),
            """INSERT INTO sales_return_cases_v19 (id, case_id, customer_key, customer_name, po_number, shipment_num,
                product_name, lifecycle_status, physical_return_mode, waybill_no, claimed_deduction_percentage,
                financial_adjustment_status, inventory_resolution_status, mismatch_note, notes, created_by,
                created_at, updated_at)
               SELECT ROW_NUMBER() OVER (ORDER BY c.case_id), c.case_id, CAST(o.customer_party_id AS TEXT),
                COALESCE(p.canonical_name, ''), '', '', '',
                CASE c.status WHEN 'registered' THEN 'accepted' WHEN 'disposed' THEN 'closed' ELSE 'weighed' END,
                'required', '', NULL, 'not_applicable', CASE c.status WHEN 'disposed' THEN 'applied' ELSE 'pending' END,
                '', c.reason, 'generic', c.created_at, c.updated_at
               FROM sales_return_cases c JOIN sales_orders o ON o.order_id=c.order_id
               LEFT JOIN business_parties p ON p.id=o.customer_party_id""",
            """INSERT INTO sales_return_case_order_links (sales_return_case_id, sales_order_id, created_at)
               SELECT h.id, o.id, h.created_at FROM sales_return_cases_v19 h
               JOIN sales_return_cases c ON c.case_id=h.case_id JOIN sales_orders o ON o.order_id=c.order_id""",
            """INSERT INTO sales_return_case_items (id, sales_return_case_id, item_index, item_name, spec,
                claimed_quantity, claimed_unit, claimed_deduction_percentage, physical_return_required, notes,
                created_at, updated_at, order_line_id, unit_id)
               SELECT ROW_NUMBER() OVER (ORDER BY h.id, i.order_line_id), h.id,
                ROW_NUMBER() OVER (PARTITION BY h.id ORDER BY i.order_line_id) - 1, COALESCE(p.canonical_name, ''), '',
                i.quantity, COALESCE(u.canonical_code, ''), NULL, 1, '', h.created_at, h.updated_at, i.order_line_id, i.unit_id
               FROM sales_return_case_items_v18 i JOIN sales_return_cases_v19 h ON h.case_id=i.case_id
               LEFT JOIN sales_order_lines l ON l.line_id=i.order_line_id LEFT JOIN products p ON p.id=l.product_id
               LEFT JOIN measurement_units u ON u.id=i.unit_id""",
            # Good units restock, scrap is kept; received = good + scrap.
            """INSERT INTO sales_return_case_inspection_results (sales_return_case_item_id, outcome_kind, quantity,
                disposed_quantity, notes, created_at, updated_at)
               SELECT n.id, kind.outcome, CASE kind.outcome WHEN 'restocked_saleable' THEN i.good_quantity ELSE i.scrap_quantity END,
                CASE kind.outcome WHEN 'restocked_saleable' THEN i.disposed_good_quantity ELSE i.disposed_scrap_quantity END,
                '', h.updated_at, h.updated_at
               FROM sales_return_case_items_v18 i JOIN sales_return_cases_v19 h ON h.case_id=i.case_id
               JOIN sales_return_case_items n ON n.sales_return_case_id=h.id AND n.order_line_id=i.order_line_id
               JOIN (SELECT 'restocked_saleable' AS outcome UNION ALL SELECT 'retained_defective') kind
               WHERE (CASE kind.outcome WHEN 'restocked_saleable' THEN i.good_quantity ELSE i.scrap_quantity END) > 0
               ORDER BY n.id, kind.outcome""",
            # Stage evidence stays in the payload's command; the command key identifies the event as new ones do.
            """INSERT INTO sales_return_case_events (sales_return_case_id, event_type, event_at, source_channel,
                source_id, actor, idempotency_key, payload_json, created_at)
               SELECT h.id, CASE e.action WHEN 'register' THEN 'accepted' WHEN 'inspect' THEN 'weighed' ELSE 'disposed' END,
                e.occurred_at, 'generic', e.source_ref, 'generic',
                COALESCE(json_extract(e.payload_json, '$.preview.command.idempotency_key'), 'generic-v18-event:' || e.event_id),
                e.payload_json, e.created_at
               FROM sales_return_case_events_v18 e JOIN sales_return_cases_v19 h ON h.case_id=e.case_id
               ORDER BY e.rowid""",
            "DROP TABLE sales_return_case_events_v18",
            "DROP TABLE sales_return_case_items_v18",
            "DROP TABLE sales_return_cases",
            "ALTER TABLE sales_return_cases_v19 RENAME TO sales_return_cases",
        ),
    ),
    KernelMigration(
        version=20,
        migration_id="generic-inventory-standard-tables-v1",
        # master_data's location table changes too, so a master_data-only database must reach this version.
        owner_ref="master_data:catalog-owner",
        dependencies=("generic-sales-standard-returns-v1",),
        rebuilds_tables=True,
        statements=(
            *_generic_inventory_schema_sql(),
            """INSERT INTO locations (key, display_name, item_kind, usage, counts_in_total, available_for_sale, sort_order,
                status, normalized_name, attributes_json)
               SELECT location_id, canonical_name, 'product', 'internal', 1, 1, 0, status, normalized_name, attributes_json
               FROM location_catalog ORDER BY location_id""",
            # Movements first, then the reversal rows that point at them (standard shape: same direction as the
            # original, is_reversal=1); stocktake adjustments and corrections keep their origin in source_kind.
            f"""INSERT INTO material_inventory_events {_V20_MOVEMENT_COLUMNS}
               SELECT generic_business_date_v17(m.occurred_at),
                CASE WHEN m.movement_kind='inbound' THEN 'receipt' WHEN m.movement_kind='outbound' THEN 'usage'
                     WHEN m.from_location_id IS NULL THEN 'receipt' WHEN m.to_location_id IS NULL THEN 'usage' ELSE 'transfer' END,
                m.product_id, m.quantity, m.unit_id, f.id, t.id,
                CASE m.movement_kind WHEN 'stocktake_adjustment' THEN 'stocktake' WHEN 'correction' THEN 'correction' ELSE 'manual' END,
                {_V20_SOURCE_KEY}, m.source_ref, 0, NULL, 'confirmed', m.reason, 'generic', {_V20_CREATED_AT},
                m.movement_id, m.occurred_at, m.movement_kind, m.quantity_text
               FROM inventory_movements m
               LEFT JOIN locations f ON f.key=m.from_location_id LEFT JOIN locations t ON t.key=m.to_location_id
               WHERE m.movement_kind <> 'reversal' ORDER BY m.rowid""",
            f"""INSERT INTO material_inventory_events {_V20_MOVEMENT_COLUMNS}
               SELECT generic_business_date_v17(m.occurred_at), o.event_type, m.product_id, m.quantity, m.unit_id,
                o.from_location_id, o.to_location_id, 'reversal', {_V20_SOURCE_KEY}, m.source_ref, 1, o.id, 'confirmed',
                m.reason, 'generic', {_V20_CREATED_AT}, m.movement_id, m.occurred_at, m.movement_kind, m.quantity_text
               FROM inventory_movements m JOIN material_inventory_events o ON o.movement_id=m.reverses_movement_id
               WHERE m.movement_kind='reversal' ORDER BY m.rowid""",
            """UPDATE material_inventory_events SET status='reversed'
               WHERE id IN (SELECT reverses_event_id FROM material_inventory_events WHERE is_reversal=1)""",
            # A reversal of a reversal has no standard shape: such a database fails the upgrade (NOT NULL) and keeps v19.
            """INSERT INTO material_inventory_events (id) SELECT NULL
               WHERE (SELECT COUNT(*) FROM inventory_movements) <> (SELECT COUNT(*) FROM material_inventory_events)""",
            """CREATE TRIGGER material_inventory_events_immutable_update
                BEFORE UPDATE OF id, event_date, event_type, product_id, quantity, quantity_unit_id, from_location_id,
                    to_location_id, source_kind, source_record_key, evidence_ref, is_reversal, reverses_event_id, notes,
                    created_by, created_at, movement_id, occurred_at, movement_kind, quantity_text
                ON material_inventory_events
                BEGIN SELECT RAISE(ABORT, 'inventory_movements_immutable'); END""",
            """CREATE TRIGGER material_inventory_events_immutable_delete
                BEFORE DELETE ON material_inventory_events
                BEGIN SELECT RAISE(ABORT, 'inventory_movements_immutable'); END""",
            # Tables that keyed on the old location or movement table are rebuilt beside and renamed last.
            """CREATE TABLE inventory_stocktakes_v20 (
                stocktake_id TEXT PRIMARY KEY,
                product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
                unit_id INTEGER NOT NULL REFERENCES measurement_units(id) ON DELETE RESTRICT,
                location_id TEXT NOT NULL REFERENCES locations(key) ON DELETE RESTRICT,
                actual_quantity NUMERIC NOT NULL CHECK(actual_quantity >= 0),
                projected_quantity NUMERIC NOT NULL,
                occurred_at TEXT NOT NULL,
                source_ref TEXT NOT NULL
            )""",
            "INSERT INTO inventory_stocktakes_v20 SELECT * FROM inventory_stocktakes",
            "DROP TABLE inventory_stocktakes",
            "ALTER TABLE inventory_stocktakes_v20 RENAME TO inventory_stocktakes",
            """CREATE TABLE procurement_order_lines_v20 (
                id INTEGER PRIMARY KEY, line_id TEXT NOT NULL UNIQUE,
                order_id TEXT NOT NULL REFERENCES procurement_orders(order_id) ON DELETE RESTRICT,
                product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
                unit_id INTEGER NOT NULL REFERENCES measurement_units(id) ON DELETE RESTRICT,
                quantity TEXT NOT NULL CHECK(CAST(quantity AS NUMERIC) > 0),
                received_quantity TEXT NOT NULL CHECK(CAST(received_quantity AS NUMERIC) >= 0),
                receive_location_id TEXT NOT NULL REFERENCES locations(key) ON DELETE RESTRICT
            )""",
            "INSERT INTO procurement_order_lines_v20 SELECT * FROM procurement_order_lines",
            "DROP TABLE procurement_order_lines",
            "ALTER TABLE procurement_order_lines_v20 RENAME TO procurement_order_lines",
            "CREATE INDEX ix_procurement_order_lines_order ON procurement_order_lines(order_id,line_id)",
            """CREATE TABLE sales_order_lines_v20 (
                line_id TEXT PRIMARY KEY,
                order_id TEXT NOT NULL REFERENCES sales_orders(order_id) ON DELETE RESTRICT,
                product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
                unit_id INTEGER NOT NULL REFERENCES measurement_units(id) ON DELETE RESTRICT,
                quantity NUMERIC NOT NULL CHECK(quantity > 0),
                fulfilled_quantity NUMERIC NOT NULL CHECK(fulfilled_quantity >= 0 AND fulfilled_quantity <= quantity),
                returned_quantity NUMERIC NOT NULL CHECK(returned_quantity >= 0 AND returned_quantity <= fulfilled_quantity),
                ship_from_location_id TEXT NOT NULL REFERENCES locations(key) ON DELETE RESTRICT
            )""",
            "INSERT INTO sales_order_lines_v20 SELECT * FROM sales_order_lines",
            "DROP TABLE sales_order_lines",
            "ALTER TABLE sales_order_lines_v20 RENAME TO sales_order_lines",
            "CREATE INDEX ix_sales_order_lines_order ON sales_order_lines(order_id, line_id)",
            """CREATE TABLE procurement_receipts_v20 (
                receipt_id TEXT PRIMARY KEY,
                order_id TEXT NOT NULL REFERENCES procurement_orders(order_id) ON DELETE RESTRICT,
                line_id TEXT NOT NULL REFERENCES procurement_order_lines(line_id) ON DELETE RESTRICT,
                quantity TEXT NOT NULL CHECK(CAST(quantity AS NUMERIC) > 0),
                inventory_action_id TEXT NOT NULL REFERENCES inventory_action_receipts(action_id) ON DELETE RESTRICT,
                inventory_movement_id TEXT NOT NULL REFERENCES material_inventory_events(movement_id) ON DELETE RESTRICT,
                occurred_at TEXT NOT NULL,
                evidence_refs_json TEXT NOT NULL,
                receipt_line_id TEXT REFERENCES procurement_receipt_lines(line_id) ON DELETE RESTRICT,
                over_receipt_allowance TEXT NOT NULL DEFAULT '0'
            )""",
            "INSERT INTO procurement_receipts_v20 SELECT * FROM procurement_receipts",
            "DROP TABLE procurement_receipts",
            "ALTER TABLE procurement_receipts_v20 RENAME TO procurement_receipts",
            """CREATE TABLE sales_fulfillments_v20 (
                fulfillment_id TEXT PRIMARY KEY,
                fulfillment_kind TEXT NOT NULL CHECK(fulfillment_kind IN ('shipment', 'return')),
                order_id TEXT NOT NULL REFERENCES sales_orders(order_id) ON DELETE RESTRICT,
                line_id TEXT NOT NULL REFERENCES sales_order_lines(line_id) ON DELETE RESTRICT,
                quantity NUMERIC NOT NULL CHECK(quantity > 0),
                inventory_action_id TEXT NOT NULL REFERENCES inventory_action_receipts(action_id) ON DELETE RESTRICT,
                inventory_movement_id TEXT NOT NULL REFERENCES material_inventory_events(movement_id) ON DELETE RESTRICT,
                occurred_at TEXT NOT NULL,
                evidence_refs_json TEXT NOT NULL
            )""",
            "INSERT INTO sales_fulfillments_v20 SELECT * FROM sales_fulfillments",
            "DROP TABLE sales_fulfillments",
            "ALTER TABLE sales_fulfillments_v20 RENAME TO sales_fulfillments",
            "DROP TABLE inventory_movements",
            "DROP TABLE location_catalog",
        ),
    ),
    KernelMigration(
        version=21,
        migration_id="generic-procurement-standard-tables-v1",
        owner_ref="procurement:order-owner",
        dependencies=("generic-inventory-standard-tables-v1",),
        rebuilds_tables=True,
        statements=(
            *_generic_procurement_schema_sql(),
            """INSERT INTO procurement_batches (business_date, supplier_party_id, status, notes, created_at, order_id, ordered_at,
                revision, evidence_refs_json, source_ref, updated_at)
               SELECT generic_business_date_v17(ordered_at), supplier_party_id, status, NULL, created_at, order_id, ordered_at,
                revision, evidence_refs_json, source_ref, updated_at
               FROM procurement_orders ORDER BY rowid""",
            # Line ids are kept: invoice and payment allocations reference them.
            """INSERT INTO procurements (id, batch_id, product_id, item_name, quantity, quantity_unit_id, unit_price, total_amount,
                is_taxed, business_date, purchase_date, goods_received_date, invoice_date, invoice_expectation,
                invoice_expectation_note, notes, created_at, line_id, received_quantity, receive_location_id, quantity_text)
               SELECT l.id, b.id, l.product_id, p.canonical_name, CAST(l.quantity AS NUMERIC), l.unit_id, NULL, NULL, 0, NULL,
                NULL, NULL, NULL, 'unknown', '', NULL, b.created_at, l.line_id, l.received_quantity, l.receive_location_id, l.quantity
               FROM procurement_order_lines l JOIN procurement_batches b ON b.order_id=l.order_id
               JOIN products p ON p.id=l.product_id ORDER BY l.id""",
            # A receipt whose movement was reversed is a reversed allocation: the line's received total already excludes it.
            """INSERT INTO procurement_receipt_allocations (procurement_id, receipt_event_id, allocated_quantity, quantity_unit_id,
                status, source_kind, source_ref, notes, confirmed_by, confirmed_at, reversed_by, reversed_at, created_at,
                receipt_id, order_id, inventory_action_id, inventory_movement_id, occurred_at, evidence_refs_json,
                receipt_line_id, over_receipt_allowance, quantity_text)
               SELECT l.id, m.id, CAST(r.quantity AS NUMERIC), l.unit_id,
                CASE m.status WHEN 'reversed' THEN 'reversed' ELSE 'confirmed' END, 'generic_receipt', r.inventory_action_id, '',
                'generic', r.occurred_at, CASE m.status WHEN 'reversed' THEN 'generic' ELSE '' END,
                (SELECT x.occurred_at FROM material_inventory_events x WHERE x.reverses_event_id=m.id), r.occurred_at,
                r.receipt_id, r.order_id, r.inventory_action_id, r.inventory_movement_id, r.occurred_at, r.evidence_refs_json,
                r.receipt_line_id, r.over_receipt_allowance, r.quantity
               FROM procurement_receipts r JOIN procurement_order_lines l ON l.line_id=r.line_id
               JOIN material_inventory_events m ON m.movement_id=r.inventory_movement_id ORDER BY r.rowid""",
            _rebuild_count_guard("procurement_orders", "procurement_batches"),
            _rebuild_count_guard("procurement_order_lines", "procurements"),
            _rebuild_count_guard("procurement_receipts", "procurement_receipt_allocations"),
            # Tables that keyed on the old order, line or receipt table are rebuilt beside and renamed last.
            """CREATE TABLE procurement_order_line_terms_v21 (
                terms_id TEXT PRIMARY KEY,
                order_line_id TEXT NOT NULL REFERENCES procurements(line_id) ON DELETE RESTRICT,
                version INTEGER NOT NULL CHECK(version>0),
                active INTEGER NOT NULL CHECK(active IN (0, 1)),
                currency TEXT NOT NULL,
                pricing_quantity TEXT NOT NULL,
                pricing_unit_id INTEGER NOT NULL REFERENCES measurement_units(id) ON DELETE RESTRICT,
                unit_price TEXT,
                agreed_amount TEXT,
                tax_basis TEXT NOT NULL,
                quantity_tolerance TEXT,
                quantity_tolerance_unit_id INTEGER REFERENCES measurement_units(id) ON DELETE RESTRICT,
                amount_tolerance TEXT,
                amount_tolerance_currency TEXT,
                source_kind TEXT NOT NULL,
                source_ref TEXT NOT NULL,
                evidence_refs_json TEXT NOT NULL,
                created_at TEXT NOT NULL,
                superseded_by TEXT REFERENCES procurement_order_line_terms(terms_id) ON DELETE RESTRICT,
                conversion_from_unit_id INTEGER REFERENCES measurement_units(id) ON DELETE RESTRICT,
                conversion_to_unit_id INTEGER REFERENCES measurement_units(id) ON DELETE RESTRICT,
                conversion_factor TEXT, conversion_source_ref TEXT,
                UNIQUE(order_line_id, version),
                CHECK(unit_price IS NOT NULL OR agreed_amount IS NOT NULL)
            )""",
            "INSERT INTO procurement_order_line_terms_v21 SELECT * FROM procurement_order_line_terms",
            "DROP TABLE procurement_order_line_terms",
            "ALTER TABLE procurement_order_line_terms_v21 RENAME TO procurement_order_line_terms",
            "CREATE UNIQUE INDEX ux_procurement_current_terms ON procurement_order_line_terms(order_line_id) WHERE active=1",
            """CREATE TABLE procurement_invoice_matches_v21 (
                match_id TEXT PRIMARY KEY, invoice_id INTEGER NOT NULL REFERENCES procurement_invoices(id),
                invoice_line_id TEXT NOT NULL REFERENCES procurement_invoice_lines(line_id) ON DELETE RESTRICT,
                order_line_id TEXT NOT NULL REFERENCES procurements(line_id) ON DELETE RESTRICT,
                receipt_id TEXT NOT NULL REFERENCES procurement_receipt_allocations(receipt_id) ON DELETE RESTRICT,
                terms_id TEXT REFERENCES procurement_order_line_terms(terms_id) ON DELETE RESTRICT,
                original_quantity TEXT, original_unit_id INTEGER REFERENCES measurement_units(id), converted_quantity TEXT, quantity TEXT NOT NULL,
                amount TEXT,
                expected_amount TEXT,
                quantity_difference TEXT NOT NULL,
                amount_difference TEXT,
                quantity_tolerance TEXT,
                quantity_tolerance_unit_id INTEGER,
                amount_tolerance TEXT,
                amount_tolerance_currency TEXT,
                quantity_status TEXT NOT NULL,
                amount_status TEXT NOT NULL,
                status TEXT NOT NULL,
                clarification_reason TEXT NOT NULL,
                active INTEGER NOT NULL CHECK(active IN (0, 1)),
                source_ref TEXT NOT NULL,
                evidence_refs_json TEXT NOT NULL,
                created_at TEXT NOT NULL,
                revoked_at TEXT,
                revoked_action_id TEXT REFERENCES procurement_action_receipts(action_id) ON DELETE RESTRICT,
                CHECK((active=1 AND revoked_at IS NULL AND revoked_action_id IS NULL)
                   OR (active=0 AND revoked_at IS NOT NULL AND revoked_action_id IS NOT NULL))
            )""",
            "INSERT INTO procurement_invoice_matches_v21 SELECT * FROM procurement_invoice_matches",
            "DROP TABLE procurement_invoice_matches",
            "ALTER TABLE procurement_invoice_matches_v21 RENAME TO procurement_invoice_matches",
            "CREATE INDEX ix_procurement_match_invoice ON procurement_invoice_matches(invoice_id,active)",
            "CREATE INDEX ix_procurement_match_order_line ON procurement_invoice_matches(order_line_id, active)",
            "CREATE INDEX ix_procurement_match_receipt ON procurement_invoice_matches(receipt_id, active)",
            "CREATE UNIQUE INDEX ux_procurement_invoice_line_match ON procurement_invoice_matches(invoice_line_id) WHERE active=1",
            *_rebuild_standard_table(PROCUREMENT_INVOICE_ALLOCATIONS),
            *_rebuild_standard_table(PROCUREMENT_PAYMENT_ALLOCATIONS),
            """CREATE TABLE procurement_action_receipts_v21 (
                action_id TEXT PRIMARY KEY,
                idempotency_key TEXT NOT NULL UNIQUE,
                command_digest TEXT NOT NULL,
                preview_digest TEXT NOT NULL,
                order_id TEXT REFERENCES procurement_batches(order_id) ON DELETE RESTRICT,
                audit_event_id TEXT NOT NULL REFERENCES procurement_audit_events(event_id) ON DELETE RESTRICT,
                inventory_action_id TEXT REFERENCES inventory_action_receipts(action_id) ON DELETE RESTRICT,
                created_at TEXT NOT NULL,
                document_kind TEXT NOT NULL DEFAULT 'order',
                document_id TEXT NOT NULL DEFAULT '',
                post_reference TEXT
            )""",
            "INSERT INTO procurement_action_receipts_v21 SELECT * FROM procurement_action_receipts",
            "DROP TABLE procurement_action_receipts",
            "ALTER TABLE procurement_action_receipts_v21 RENAME TO procurement_action_receipts",
            """CREATE TABLE procurement_receipt_lines_v21 (
                line_id TEXT PRIMARY KEY,
                document_id TEXT NOT NULL REFERENCES procurement_receipt_documents(document_id) ON DELETE RESTRICT,
                product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
                unit_id INTEGER NOT NULL REFERENCES measurement_units(id) ON DELETE RESTRICT,
                order_line_id TEXT REFERENCES procurements(line_id) ON DELETE RESTRICT,
                arrived_quantity TEXT NOT NULL,
                received_quantity TEXT NOT NULL,
                accepted_quantity TEXT NOT NULL DEFAULT '0',
                rejected_quantity TEXT NOT NULL DEFAULT '0',
                inspected_at TEXT,
                inspection_evidence_refs_json TEXT
            )""",
            "INSERT INTO procurement_receipt_lines_v21 SELECT * FROM procurement_receipt_lines",
            "DROP TABLE procurement_receipt_lines",
            "ALTER TABLE procurement_receipt_lines_v21 RENAME TO procurement_receipt_lines",
            "CREATE INDEX ix_procurement_receipt_lines_document ON procurement_receipt_lines(document_id, line_id)",
            "DROP TABLE procurement_receipts",
            "DROP TABLE procurement_order_lines",
            "DROP TABLE procurement_orders",
        ),
    ),
    KernelMigration(
        version=22,
        migration_id="generic-sales-standard-tables-v1",
        owner_ref="sales:order-owner",
        dependencies=("generic-procurement-standard-tables-v1",),
        rebuilds_tables=True,
        statements=(
            *_generic_sales_schema_sql(),
            # Header ids are kept: the allocations and return links that referenced them are repointed below.
            """INSERT INTO sales_batches (id, business_date, status, notes, created_at, order_id, ordered_at, revision,
                evidence_refs_json, source_ref, updated_at)
               SELECT id, generic_business_date_v17(ordered_at), status, NULL, created_at, order_id, ordered_at, revision,
                evidence_refs_json, source_ref, updated_at
               FROM sales_orders ORDER BY id""",
            # The customer moves from the header onto every line; lines get integer ids in (header, line key) order.
            """INSERT INTO sales_orders_v22 (batch_id, seq_no, customer_party_id, product_id, product_name, quantity_num,
                quantity_unit_id, business_date, created_at, line_id, fulfilled_quantity, returned_quantity, ship_from_location_id)
               SELECT h.id, ROW_NUMBER() OVER (PARTITION BY h.id ORDER BY l.line_id), h.customer_party_id, l.product_id,
                p.canonical_name, l.quantity, l.unit_id, generic_business_date_v17(h.ordered_at), h.created_at, l.line_id,
                l.fulfilled_quantity, l.returned_quantity, l.ship_from_location_id
               FROM sales_order_lines l JOIN sales_orders h ON h.order_id=l.order_id JOIN products p ON p.id=l.product_id
               ORDER BY h.id, l.line_id""",
            # Every fulfillment must resolve its movement (the join drops one otherwise and the count guard fails).
            """INSERT INTO sales_fulfillments_v22 (sales_order_id, fulfillment_kind, quantity, quantity_unit_id, event_id,
                business_date, source_kind, source_ref, notes, created_at, fulfillment_id, order_id, line_id,
                inventory_action_id, inventory_movement_id, occurred_at, evidence_refs_json)
               SELECT n.id, f.fulfillment_kind, f.quantity, n.quantity_unit_id, m.id, generic_business_date_v17(f.occurred_at),
                'generic_fulfillment', f.inventory_action_id, NULL, f.occurred_at, f.fulfillment_id, f.order_id, f.line_id,
                f.inventory_action_id, f.inventory_movement_id, f.occurred_at, f.evidence_refs_json
               FROM sales_fulfillments f JOIN sales_orders_v22 n ON n.line_id=f.line_id
               JOIN material_inventory_events m ON m.movement_id=f.inventory_movement_id ORDER BY f.rowid""",
            _rebuild_count_guard("sales_orders", "sales_batches"),
            _rebuild_count_guard("sales_order_lines", "sales_orders_v22"),
            _rebuild_count_guard("sales_fulfillments", "sales_fulfillments_v22"),
            # Settlement allocations now reference the line. A header with several lines and an allocation has no
            # standard shape: the upgrade fails (NOT NULL) and keeps v21.
            """INSERT INTO sales_batches (id) SELECT NULL WHERE EXISTS (
                SELECT 1 FROM (SELECT sales_order_id FROM sales_payment_allocations
                               UNION SELECT sales_order_id FROM sales_invoice_allocations) r
                WHERE (SELECT COUNT(*) FROM sales_orders_v22 n WHERE n.batch_id=r.sales_order_id) <> 1)""",
            """UPDATE sales_payment_allocations SET sales_order_id=(SELECT n.id FROM sales_orders_v22 n
                WHERE n.batch_id=sales_payment_allocations.sales_order_id)""",
            """UPDATE sales_invoice_allocations SET sales_order_id=(SELECT n.id FROM sales_orders_v22 n
                WHERE n.batch_id=sales_invoice_allocations.sales_order_id)""",
            # A return case links to its order's first line; its items carry the per-line detail.
            """UPDATE sales_return_case_order_links SET sales_order_id=(SELECT MIN(n.id) FROM sales_orders_v22 n
                WHERE n.batch_id=sales_return_case_order_links.sales_order_id)""",
            # Tables that keyed on the old header or line table by text are rebuilt beside and renamed last.
            """CREATE TABLE sales_action_receipts_v22 (
                action_id TEXT PRIMARY KEY,
                idempotency_key TEXT NOT NULL UNIQUE,
                command_digest TEXT NOT NULL,
                preview_digest TEXT NOT NULL,
                order_id TEXT NOT NULL REFERENCES sales_batches(order_id) ON DELETE RESTRICT,
                audit_event_id TEXT NOT NULL REFERENCES sales_audit_events(event_id) ON DELETE RESTRICT,
                inventory_action_id TEXT REFERENCES inventory_action_receipts(action_id) ON DELETE RESTRICT,
                created_at TEXT NOT NULL
            )""",
            "INSERT INTO sales_action_receipts_v22 SELECT * FROM sales_action_receipts",
            "DROP TABLE sales_action_receipts",
            "ALTER TABLE sales_action_receipts_v22 RENAME TO sales_action_receipts",
            """CREATE TABLE sales_document_action_receipts_v22 (
                action_id TEXT PRIMARY KEY,
                idempotency_key TEXT NOT NULL UNIQUE,
                command_digest TEXT NOT NULL,
                preview_digest TEXT NOT NULL,
                document_kind TEXT NOT NULL,
                document_id TEXT NOT NULL,
                order_id TEXT REFERENCES sales_batches(order_id) ON DELETE RESTRICT,
                audit_event_id TEXT NOT NULL REFERENCES sales_audit_events(event_id) ON DELETE RESTRICT,
                created_at TEXT NOT NULL
            )""",
            "INSERT INTO sales_document_action_receipts_v22 SELECT * FROM sales_document_action_receipts",
            "DROP TABLE sales_document_action_receipts",
            "ALTER TABLE sales_document_action_receipts_v22 RENAME TO sales_document_action_receipts",
            """CREATE TABLE sales_invoice_lines_v22 (
                invoice_id TEXT NOT NULL REFERENCES sales_invoices(invoice_id) ON DELETE RESTRICT,
                line_id TEXT NOT NULL,
                amount TEXT NOT NULL,
                order_id TEXT REFERENCES sales_batches(order_id) ON DELETE RESTRICT,
                order_line_id TEXT REFERENCES sales_orders(line_id) ON DELETE RESTRICT,
                tax_rate TEXT,
                tax_amount TEXT,
                PRIMARY KEY(invoice_id, line_id),
                CHECK(order_line_id IS NULL OR order_id IS NOT NULL)
            )""",
            "INSERT INTO sales_invoice_lines_v22 SELECT * FROM sales_invoice_lines",
            "DROP TABLE sales_invoice_lines",
            "ALTER TABLE sales_invoice_lines_v22 RENAME TO sales_invoice_lines",
            *_rebuild_standard_table(extended_table(SALES_RETURN_CASE_ITEMS, GENERIC_RETURN_TABLE_EXTENSIONS["sales_return_case_items"]), "_v22"),
            "DROP TABLE sales_fulfillments",
            "ALTER TABLE sales_fulfillments_v22 RENAME TO sales_fulfillments",
            "DROP TABLE sales_order_lines",
            "DROP TABLE sales_orders",
            "ALTER TABLE sales_orders_v22 RENAME TO sales_orders",
        ),
    ),
    KernelMigration(
        version=23, migration_id="generic-typed-name-identities-v23", dependencies=("generic-sales-standard-tables-v1",),
        owner_ref="master_data:catalog-owner", statements=_typed_name_schema_sql(), rebuilds_tables=True,
    ),
    KernelMigration(
        version=24, migration_id="generic-sales-service-acceptance-v1",
        dependencies=("generic-typed-name-identities-v23",), owner_ref="sales:order-owner",
        statements=_service_order_schema_sql(), rebuilds_tables=True,
    ),
)


def validate_catalog(migrations: Sequence[KernelMigration] = MIGRATIONS) -> None:
    versions = [item.version for item in migrations]
    if versions != list(range(1, len(migrations) + 1)):
        raise GenericKernelDatabaseError("generic_migration_version_invalid", "versions must start at 1 and be contiguous")
    by_id = {item.migration_id: item for item in migrations}
    if len(by_id) != len(migrations):
        raise GenericKernelDatabaseError("generic_migration_identity_duplicate", "migration IDs must be unique")
    applied: set[str] = set()
    for migration in migrations:
        unknown = sorted(set(migration.dependencies) - set(by_id))
        if unknown:
            raise GenericKernelDatabaseError("generic_migration_dependency_unknown", str(unknown))
        unmet = sorted(set(migration.dependencies) - applied)
        if unmet:
            raise GenericKernelDatabaseError("generic_migration_dependency_order_invalid", str(unmet))
        applied.add(migration.migration_id)


def migration_set_digest(migrations: Sequence[KernelMigration] = MIGRATIONS) -> str:
    validate_catalog(migrations)
    return _digest(_canonical([item.descriptor() for item in migrations]))


def _connect(path: Path) -> sqlite3.Connection:
    connection = storage_connect(path)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys=ON")
    if connection.execute("PRAGMA foreign_keys").fetchone()[0] != 1:
        connection.close()
        raise GenericKernelDatabaseError("generic_foreign_keys_disabled", "foreign key enforcement is required")
    return connection


def _schema_rows(connection: sqlite3.Connection, foreign: frozenset[str] = frozenset()) -> list[dict[str, str]]:
    """Schema objects of this lineage; ``foreign`` names tables (and their indexes) another line owns."""

    rows = connection.execute(
        """SELECT type, name, tbl_name, COALESCE(sql, '') AS sql
           FROM sqlite_master
           WHERE name NOT LIKE 'sqlite_%'
           ORDER BY type, name"""
    ).fetchall()
    return [
        {"type": str(row["type"]), "name": str(row["name"]), "sql": " ".join(str(row["sql"]).split())}
        for row in rows
        if str(row["tbl_name"]) not in foreign
    ]


def schema_fingerprint(connection: sqlite3.Connection, foreign: frozenset[str] = frozenset()) -> str:
    return _digest(_canonical(_schema_rows(connection, foreign)))


def _platform_line_tables(migrations: Sequence[KernelMigration]) -> frozenset[str]:
    """平台线建在同一个库里的表：本线只核自己建的表（agent 运行时那 3 张本线第 14、15 版已建，仍归本线核）。"""

    return frozenset((*PLATFORM_TABLES, PLATFORM_MIGRATION_TABLE)) - _expected_table_names(migrations)


def expected_schema_fingerprint(
    migrations: Sequence[KernelMigration] = MIGRATIONS,
) -> str:
    connection = storage_connect(":memory:")
    connection.row_factory = sqlite3.Row
    try:
        _register_migration_functions(connection)
        for migration in migrations:
            for statement in migration.statements:
                connection.execute(statement)
        return schema_fingerprint(connection)
    finally:
        connection.close()


def catalog_payload() -> dict[str, object]:
    return {
        "lineage_id": LINEAGE_ID,
        "current_schema_version": len(MIGRATIONS),
        "migration_set_digest": migration_set_digest(),
        "schema_fingerprint": expected_schema_fingerprint(),
        "items": [item.descriptor() for item in MIGRATIONS],
    }


def _metadata(connection: sqlite3.Connection) -> dict[str, str]:
    exists = connection.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name='kernel_instance_metadata'"
    ).fetchone()
    if not exists:
        return {}
    return {str(row["key"]): str(row["value"]) for row in connection.execute("SELECT key, value FROM kernel_instance_metadata")}


def _ledger(connection: sqlite3.Connection) -> list[dict[str, object]]:
    exists = connection.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name='kernel_migration_ledger'"
    ).fetchone()
    if not exists:
        return []
    rows = connection.execute(
        """SELECT lineage_id, migration_version, migration_id, checksum, applied_at
           FROM kernel_migration_ledger ORDER BY migration_version"""
    ).fetchall()
    return [dict(row) for row in rows]


def _newer_than_program(version: int, known: int) -> GenericKernelDatabaseError:
    # 装回旧版本时库已被新版本升级过：旧程序不认识新改表，不降级、不动库。
    return GenericKernelDatabaseError(
        "generic_database_newer_than_program",
        f"database was upgraded to migration {version} by a newer BizHub version; this program knows "
        f"{known}. Install that newer version again, or restore the pre-upgrade backup.",
    )


def _recorded_migrations(
    connection: sqlite3.Connection,
    migrations: Sequence[KernelMigration],
) -> dict[int, dict[str, object]]:
    catalog = {item.version: item for item in migrations}
    recorded: dict[int, dict[str, object]] = {}
    for row in _ledger(connection):
        if row["lineage_id"] != LINEAGE_ID:
            raise GenericKernelDatabaseError(
                "generic_database_ledger_lineage_drift",
                f"unexpected lineage {row['lineage_id']!r}",
            )
        version = int(row["migration_version"])
        migration = catalog.get(version)
        if version > max(catalog, default=0):
            raise _newer_than_program(version, max(catalog, default=0))
        if migration is None:
            raise GenericKernelDatabaseError(
                "generic_migration_content_drift",
                f"recorded migration version {version} is not in the catalog",
            )
        if row["migration_id"] != migration.migration_id or row["checksum"] != migration.checksum:
            raise GenericKernelDatabaseError(
                "generic_migration_content_drift",
                f"recorded migration {version} differs",
            )
        recorded[version] = row
    versions = sorted(recorded)
    if versions != list(range(1, len(versions) + 1)):
        raise GenericKernelDatabaseError(
            "generic_database_ledger_drift",
            f"recorded versions are not a contiguous prefix: {versions}",
        )
    return recorded


def _expected_table_names(migrations: Sequence[KernelMigration]) -> set[str]:
    active_owners = {item.owner_ref.split(":", 1)[0] for item in migrations}
    highest_version = max((item.version for item in migrations), default=0)
    names = {
        table.name for table in MODEL_TABLES
        if table.owner_ref.split(":", 1)[0] in active_owners and table.introduced_version <= highest_version
    }
    if highest_version < 20:  # the tables v20 replaced with the inventory standard tables
        names |= {name for name, owner in (("location_catalog", "master_data"), ("inventory_movements", "inventory"))
                  if owner in active_owners}
    if highest_version < 21 and "procurement" in active_owners:  # the tables v21 replaced with the procurement standard tables
        names |= {"procurement_orders", "procurement_order_lines", "procurement_receipts"}
    if highest_version < 22 and "sales" in active_owners:  # the line table v22 replaced with the sales standard line table
        names.add("sales_order_lines")
    return names


def migrations_for_modules(module_ids: Iterable[str]) -> tuple[KernelMigration, ...]:
    enabled = set(module_ids)
    if "inventory" in enabled and "master_data" not in enabled:
        raise GenericKernelDatabaseError(
            "generic_migration_dependency_module_missing",
            "inventory requires master_data",
        )
    if "procurement" in enabled and not {"master_data", "inventory"} <= enabled:
        raise GenericKernelDatabaseError(
            "generic_migration_dependency_module_missing",
            "procurement requires master_data and inventory",
        )
    if "sales" in enabled and not {"master_data", "inventory", "procurement"} <= enabled:
        raise GenericKernelDatabaseError(
            "generic_migration_dependency_module_missing",
            "sales requires master_data, inventory, and procurement "
            "for the current linear schema lineage",
        )
    highest_version = 1
    enabled_owner_ids = {"generic.kernel_smoke", *enabled}
    for item in MIGRATIONS:
        if item.migration_id in {"generic-prepared-decisions-v1", "generic-source-clusters-v1"} and not ({"sales", "procurement"} & enabled):
            continue
        if item.owner_ref.split(":", 1)[0] in enabled_owner_ids:
            highest_version = max(highest_version, item.version)
    # A SQLite lineage is a contiguous prefix. Earlier module schema is retained
    # when its Runtime capability is disabled; this does not activate its writer.
    return MIGRATIONS[:highest_version]


def retained_migrations_for_database(
    path: Path,
    active_migrations: Sequence[KernelMigration],
) -> tuple[KernelMigration, ...]:
    """Retain already-applied module schema without activating its runtime."""

    if not path.exists():
        return tuple(active_migrations)
    connection = storage_connect(f"file:{path.resolve()}?mode=ro", uri=True)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA query_only=ON")
    try:
        ledger = _ledger(connection)
    finally:
        connection.close()
    recorded_versions = [int(item["migration_version"]) for item in ledger]
    if recorded_versions and max(recorded_versions) > len(MIGRATIONS):
        raise _newer_than_program(max(recorded_versions), len(MIGRATIONS))
    if any(version < 1 for version in recorded_versions):
        raise GenericKernelDatabaseError(
            "generic_migration_content_drift",
            f"recorded migration version outside catalog: {recorded_versions}",
        )
    active_versions = [item.version for item in active_migrations]
    target_version = max((*recorded_versions, *active_versions), default=0)
    return MIGRATIONS[:target_version]


def _verify_complete_state(
    connection: sqlite3.Connection,
    migrations: Sequence[KernelMigration],
    recorded: dict[int, dict[str, object]],
) -> None:
    foreign = _platform_line_tables(migrations)
    expected_fingerprint = expected_schema_fingerprint(migrations)
    actual_fingerprint = schema_fingerprint(connection, foreign)
    if actual_fingerprint != expected_fingerprint:
        raise GenericKernelDatabaseError(
            "generic_schema_fingerprint_drift",
            f"expected={expected_fingerprint}, actual={actual_fingerprint}",
        )
    expected_tables = _expected_table_names(migrations)
    actual_tables = {item["name"] for item in _schema_rows(connection, foreign) if item["type"] == "table"}
    if actual_tables != expected_tables:
        raise GenericKernelDatabaseError(
            "generic_schema_table_mismatch",
            f"expected={sorted(expected_tables)}, actual={sorted(actual_tables)}",
        )
    expected_metadata = {
        "profile_id": PROFILE_ID,
        "lineage_id": LINEAGE_ID,
        "migration_set_digest": migration_set_digest(migrations),
        "schema_fingerprint": expected_fingerprint,
    }
    metadata = _metadata(connection)
    if metadata != expected_metadata:
        raise GenericKernelDatabaseError(
            "generic_database_metadata_drift",
            f"expected={expected_metadata}, actual={metadata}",
        )
    if sorted(recorded) != [item.version for item in migrations]:
        raise GenericKernelDatabaseError("generic_database_ledger_drift", "migration ledger differs")


def _verify_applied_prefix_state(
    connection: sqlite3.Connection,
    migrations: Sequence[KernelMigration],
    recorded: dict[int, dict[str, object]],
) -> None:
    """Validate the pre-upgrade physical schema against the ledger's applied prefix.

    A database whose declared physical schema drifted (e.g. a lost unique
    index) must fail closed before any pending migration writes; without this
    check the pending branch would upgrade the drifted schema and re-sign it
    as the new trusted baseline (#880).
    """

    applied = migrations[: len(recorded)]
    expected_fingerprint = expected_schema_fingerprint(applied)
    actual_fingerprint = schema_fingerprint(connection, _platform_line_tables(applied))
    if actual_fingerprint != expected_fingerprint:
        raise GenericKernelDatabaseError(
            "generic_schema_pre_upgrade_drift",
            f"expected={expected_fingerprint}, actual={actual_fingerprint}",
        )
    expected_metadata = {
        "profile_id": PROFILE_ID,
        "lineage_id": LINEAGE_ID,
        "migration_set_digest": migration_set_digest(applied),
        "schema_fingerprint": expected_fingerprint,
    }
    metadata = _metadata(connection)
    if metadata != expected_metadata:
        raise GenericKernelDatabaseError(
            "generic_database_pre_upgrade_metadata_drift",
            f"expected={expected_metadata}, actual={metadata}",
        )


def _apply_connection(
    connection: sqlite3.Connection,
    migrations: Sequence[KernelMigration],
    *,
    fail_after_statement: int | None = None,
) -> list[str]:
    validate_catalog(migrations)
    _register_migration_functions(connection)
    metadata = _metadata(connection)
    if metadata and (
        metadata.get("profile_id") != PROFILE_ID or metadata.get("lineage_id") != LINEAGE_ID
    ):
        raise GenericKernelDatabaseError("generic_database_identity_mismatch", "profile or lineage differs")
    existing = _recorded_migrations(connection, migrations)
    pending = [migration for migration in migrations if migration.version not in existing]
    if not pending:
        _verify_complete_state(connection, migrations, existing)
        return []

    applied_ids: list[str] = []
    statement_count = 0
    rebuild = any(item.rebuilds_tables for item in pending)
    if rebuild:
        connection.execute("PRAGMA foreign_keys=OFF")
    try:
        connection.execute("BEGIN IMMEDIATE")
        metadata = _metadata(connection)
        if metadata and (
            metadata.get("profile_id") != PROFILE_ID or metadata.get("lineage_id") != LINEAGE_ID
        ):
            raise GenericKernelDatabaseError("generic_database_identity_mismatch", "profile or lineage differs")
        existing = _recorded_migrations(connection, migrations)
        if existing:
            _verify_applied_prefix_state(connection, migrations, existing)
        for migration in migrations:
            recorded = existing.get(migration.version)
            if recorded:
                continue
            applied_identities = {item["migration_id"] for item in existing.values()} | set(applied_ids)
            if not set(migration.dependencies).issubset(applied_identities):
                raise GenericKernelDatabaseError(
                    "generic_migration_dependency_unmet",
                    f"migration {migration.migration_id} dependencies are not applied",
                )
            for statement in migration.statements:
                connection.execute(statement)
                statement_count += 1
                if fail_after_statement is not None and statement_count >= fail_after_statement:
                    raise GenericKernelDatabaseError("generic_migration_injected_failure", "test-only failure")
            connection.execute(
                """INSERT INTO kernel_migration_ledger
                   (lineage_id, migration_version, migration_id, checksum, applied_at)
                   VALUES (?, ?, ?, ?, ?)""",
                (LINEAGE_ID, migration.version, migration.migration_id, migration.checksum, datetime.now(UTC).isoformat()),
            )
            applied_ids.append(migration.migration_id)

        expected_digest = migration_set_digest(migrations)
        # Sign the catalog's expected schema, never the just-upgraded actual
        # state, so a drifted database cannot be re-certified by its own
        # current bytes (#880).
        fingerprint = expected_schema_fingerprint(migrations)
        values = {
            "profile_id": PROFILE_ID,
            "lineage_id": LINEAGE_ID,
            "migration_set_digest": expected_digest,
            "schema_fingerprint": fingerprint,
        }
        for key, value in values.items():
            connection.execute(
                "INSERT INTO kernel_instance_metadata(key, value) VALUES (?, ?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (key, value),
            )
        _verify_complete_state(connection, migrations, _recorded_migrations(connection, migrations))
        if applied_ids:
            connection.execute(
                "INSERT INTO kernel_audit_events(event_id, event_type, payload_json, created_at) VALUES (?, ?, ?, ?)",
                (
                    uuid.uuid4().hex,
                    "kernel_migrations_applied",
                    json.dumps({"migration_ids": applied_ids}, sort_keys=True, separators=(",", ":")),
                    datetime.now(UTC).isoformat(),
                ),
            )
        if rebuild and connection.execute("PRAGMA foreign_key_check").fetchone() is not None:
            raise GenericKernelDatabaseError("generic_migration_foreign_key_violation", "rebuilt references differ")
        connection.commit()
        return applied_ids
    except Exception:
        connection.rollback()
        raise
    finally:
        if rebuild:
            connection.execute("PRAGMA foreign_keys=ON")


@contextmanager
def _initialization_lock(path: Path) -> Iterator[None]:
    """Serialize first-publish across processes for one database target path.

    The lock is an exclusive ``flock`` on the database's own directory: no lock
    file is left beside the database (Windows cannot lock a directory, so there it
    is a byte lock on one fixed hidden lock file beside it), and the existence check, temporary build,
    ``os.replace`` publish, and readback all happen inside the same critical
    section. A second process therefore can never observe a missing target
    while a first publish is in flight, nor replace a database the first
    process already published and wrote to (#881).
    """

    if os.name == "nt":
        # Windows 不能打开目录加锁：在库旁的固定锁文件上加独占锁（锁文件只用来排队，留着不删，
        # 删了会让后来者锁到另一个文件上）。桌面运行包在 Windows 上走这条路。
        import msvcrt

        lock_fd = os.open(path.parent / f".{path.name}.init-lock", os.O_RDWR | os.O_CREAT, 0o600)
        try:
            while True:
                try:
                    msvcrt.locking(lock_fd, msvcrt.LK_LOCK, 1)
                    break
                except OSError:
                    continue  # LK_LOCK 约 10 秒拿不到就报错：继续排队，与 flock 阻塞等待同义
            try:
                yield
            finally:
                os.lseek(lock_fd, 0, os.SEEK_SET)
                msvcrt.locking(lock_fd, msvcrt.LK_UNLCK, 1)
        finally:
            os.close(lock_fd)
        return
    import fcntl

    directory_fd = os.open(path.parent, os.O_RDONLY)
    try:
        fcntl.flock(directory_fd, fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(directory_fd, fcntl.LOCK_UN)
    finally:
        os.close(directory_fd)


PRE_UPGRADE_BACKUP_PREFIX = "pre-upgrade-"


def _backup_before_upgrade(
    path: Path,
    migrations: Sequence[KernelMigration],
    backup_dir: Path,
    keep: int,
) -> Path | None:
    """已装的库有待补的改表时，先做一份校验过的备份再升级；没有待补的不备份。"""

    from .backup import create_backup

    connection = storage_connect(f"file:{path}?mode=ro", uri=True)
    connection.row_factory = sqlite3.Row
    try:
        applied = len(_recorded_migrations(connection, migrations))
    finally:
        connection.close()
    if applied >= len(migrations):
        return None
    stamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%S%fZ")
    target = backup_dir.resolve() / f"{PRE_UPGRADE_BACKUP_PREFIX}{stamp}-v{applied}-to-v{len(migrations)}.sqlite"
    create_backup(path, target, migrations=migrations[:applied])
    # 只轮换自动备份，手动备份不碰。
    for stale in sorted(backup_dir.glob(f"{PRE_UPGRADE_BACKUP_PREFIX}*.sqlite"))[:-keep]:
        stale.with_suffix(stale.suffix + ".manifest.json").unlink(missing_ok=True)
        stale.unlink(missing_ok=True)
    return target


def ensure_generic_database(
    path: Path,
    *,
    migrations: Sequence[KernelMigration] = MIGRATIONS,
    fail_after_statement: int | None = None,
    backup_dir: Path | None = None,
    keep_backups: int = 5,
) -> list[str]:
    """Create or verify the generic database without leaving a partial new file.

    With ``backup_dir`` an installed database that has pending migrations is
    backed up (and the backup validated) before any of them run; a failed
    backup leaves the database untouched.
    """

    path = path.resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    with _initialization_lock(path):
        is_new = not path.exists()
        if backup_dir is not None and not is_new:
            _backup_before_upgrade(path, migrations, backup_dir, keep_backups)
        working_path = path
        if is_new:
            working_path = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
        connection = _connect(working_path)
        try:
            applied = _apply_connection(connection, migrations, fail_after_statement=fail_after_statement)
        except Exception:
            connection.close()
            if is_new:
                working_path.unlink(missing_ok=True)
            raise
        connection.close()
        if is_new:
            os.replace(working_path, path)
        readback_database(path, migrations=migrations)
        return applied


def readback_database(
    path: Path,
    *,
    migrations: Sequence[KernelMigration] = MIGRATIONS,
) -> dict[str, object]:
    if not path.exists():
        raise GenericKernelDatabaseError("generic_database_missing", str(path))
    connection = _connect(path)
    try:
        metadata = _metadata(connection)
        ledger = _ledger(connection)
        foreign = _platform_line_tables(migrations)
        tables = sorted(item["name"] for item in _schema_rows(connection, foreign) if item["type"] == "table")
        fingerprint = schema_fingerprint(connection, foreign)
        expected_fingerprint = expected_schema_fingerprint(migrations)
        if fingerprint != expected_fingerprint:
            raise GenericKernelDatabaseError(
                "generic_schema_fingerprint_drift",
                f"expected={expected_fingerprint}, actual={fingerprint}",
            )
        expected_ledger = [item.descriptor() for item in migrations]
        actual_ledger = [
            {
                "version": int(item["migration_version"]),
                "migration_id": str(item["migration_id"]),
                "owner_ref": migrations[int(item["migration_version"]) - 1].owner_ref,
                "dependencies": list(migrations[int(item["migration_version"]) - 1].dependencies),
                "checksum": str(item["checksum"]),
            }
            for item in ledger
        ]
        expected = {
            "profile_id": PROFILE_ID,
            "lineage_id": LINEAGE_ID,
            "migration_set_digest": migration_set_digest(migrations),
            "schema_fingerprint": expected_fingerprint,
        }
        if metadata != expected:
            raise GenericKernelDatabaseError("generic_database_metadata_drift", f"expected={expected}, actual={metadata}")
        if actual_ledger != expected_ledger:
            raise GenericKernelDatabaseError("generic_database_ledger_drift", "migration ledger differs")
        if tables != sorted(_expected_table_names(migrations)):
            raise GenericKernelDatabaseError("generic_schema_table_mismatch", str(tables))
        return {
            **expected,
            "schema_version": len(migrations),
            "tables": tables,
            "migration_ids": [item.migration_id for item in migrations],
        }
    finally:
        connection.close()


async def run_generic_migrations_locked(async_engine, metadata) -> tuple[str, ...]:
    """Full-backend runner signature: this lineage on the engine's SQLite file, then the platform line.

    The full backend serves the platform modules, so their tables come from
    the shared platform line; the generic small backend never loads
    SQLAlchemy and keeps only this lineage.
    """

    import asyncio

    import backend.models  # noqa: F401 - registers the platform tables' models
    from backend.kernel.runtime.schema_lineage_platform import run_platform_schema_migrations_locked

    from .profile import get_generic_registry

    module_ids = {str(item["module_id"]) for item in get_generic_registry().payload.get("modules", [])}
    path = Path(async_engine.url.database)
    migrations = retained_migrations_for_database(path, migrations_for_modules(module_ids))
    applied = tuple(await asyncio.to_thread(ensure_generic_database, path, migrations=migrations))
    await run_platform_schema_migrations_locked(async_engine, metadata)
    return applied
