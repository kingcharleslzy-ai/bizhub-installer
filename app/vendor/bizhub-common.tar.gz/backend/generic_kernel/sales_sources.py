"""Immutable source lifecycle for the thin generic sales agent.

One channel message is one source, identified by the channel-provided stable
``source_ref``. A source stores two immutable ``kernel_audit_events`` rows:

* ``sales_agent_source_received`` — the verbatim text, business time, raw
  ``extra`` payload and the content digest.
* ``sales_agent_source_prepared`` — the first fixed typed proposal (stable
  ``SalesCommand`` or an explicit clarification), never rewritten.

Applied state is read back from the existing Sales Owner receipts; this module
never writes business facts and never stores a third "applied" event.
"""

from __future__ import annotations

import json
import sqlite3
import uuid
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Iterable

from backend.modules.sales.contracts import SalesCommand
from backend.modules.sales.public import (
    SalesOwnerError,
    preview_action as preview_sales_action,
    read_action as read_sales_action,
)
from backend.modules.trade_core.public import digest_json


MODULE_ID = "generic.kernel_smoke"
OWNER_REF = f"{MODULE_ID}:runtime"
RECEIVED_EVENT = "sales_agent_source_received"
PREPARED_EVENT = "sales_agent_source_prepared"
RECEIVED_SCHEMA = "bizhub.sales-agent-source-received.v1"
PREPARED_SCHEMA = "bizhub.sales-agent-source-prepared.v1"
STATE_SCHEMA = "bizhub.sales-agent-source-state.v1"
COMMAND_DISPOSITIONS = {"create_order", "fulfill"}
PLAIN_DISPOSITIONS = {"needs_clarification", "not_covered"}
MAX_TEXT_LENGTH = 20000
MAX_SOURCE_REF_LENGTH = 200


class SalesSourceError(RuntimeError):
    def __init__(self, code: str, message: str):
        super().__init__(f"{code}: {message}")
        self.code = code
        self.message = message


def _require_module_enabled(enabled_module_ids: Iterable[str] | None) -> None:
    if enabled_module_ids is None:
        from .profile import get_generic_registry

        enabled_module_ids = [
            str(item["module_id"])
            for item in get_generic_registry().payload.get("modules", [])
        ]
    enabled = set(enabled_module_ids)
    if "sales" not in enabled or MODULE_ID not in enabled:
        raise SalesSourceError("sales_agent_module_disabled", "sales agent requires the sales module")


def _connect(path: Path, *, readonly: bool) -> sqlite3.Connection:
    database_path = path.resolve()
    if not database_path.is_file():
        raise SalesSourceError("sales_agent_database_missing", str(database_path))
    connection = sqlite3.connect(
        f"file:{database_path}?mode=ro" if readonly else database_path,
        uri=readonly,
    )
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys=ON")
    connection.execute("PRAGMA busy_timeout=10000")
    if readonly:
        connection.execute("PRAGMA query_only=ON")
    return connection


def _canonical(payload: object) -> str:
    return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def source_id_for_ref(source_ref: str) -> str:
    return uuid.uuid5(
        uuid.NAMESPACE_URL,
        f"https://bizhub.local/sales-agent-source/received/{source_ref}",
    ).hex


def _prepared_event_id(source_id: str) -> str:
    return uuid.uuid5(
        uuid.NAMESPACE_URL,
        f"https://bizhub.local/sales-agent-source/prepared/{source_id}",
    ).hex


def evidence_ref(source_id: str) -> str:
    return f"sales-agent-source:{source_id}"


def assigned_order_id(source_id: str) -> str:
    return f"so-agent-{source_id[:20]}"


def assigned_idempotency_key(source_id: str) -> str:
    return f"sales-agent:{source_id}"


def _content_digest(text: str, business_at: str, extra: object) -> str:
    return digest_json({"text": text, "business_at": business_at, "extra": extra})


def _received_row(connection: sqlite3.Connection, source_id: str) -> sqlite3.Row | None:
    return connection.execute(
        "SELECT * FROM kernel_audit_events WHERE event_id=? AND event_type=?",
        (source_id, RECEIVED_EVENT),
    ).fetchone()


def _prepared_row(connection: sqlite3.Connection, source_id: str) -> sqlite3.Row | None:
    return connection.execute(
        "SELECT * FROM kernel_audit_events WHERE event_id=? AND event_type=?",
        (_prepared_event_id(source_id), PREPARED_EVENT),
    ).fetchone()


def _parse_payload(row: sqlite3.Row) -> dict[str, Any]:
    payload = json.loads(str(row["payload_json"]))
    if not isinstance(payload, dict):
        raise SalesSourceError("sales_agent_source_event_invalid", str(row["event_id"]))
    return payload


def validate_prepared_proposal(proposal: dict[str, Any], *, source_id: str) -> None:
    """Fail closed on any proposal shape this kernel cannot replay."""

    allowed = {"schema_version", "source_id", "disposition", "command", "command_digest", "unsupported_details", "clarifications", "not_covered_reason"}
    if set(proposal) != allowed:
        raise SalesSourceError("sales_agent_proposal_fields_invalid", ",".join(sorted(set(proposal) ^ allowed)))
    if proposal["source_id"] != source_id:
        raise SalesSourceError("sales_agent_proposal_source_mismatch", str(proposal["source_id"]))
    disposition = proposal["disposition"]
    command = proposal["command"]
    if disposition in PLAIN_DISPOSITIONS:
        if command is not None or proposal["command_digest"] is not None:
            raise SalesSourceError("sales_agent_proposal_command_not_allowed", disposition)
        return
    if disposition not in COMMAND_DISPOSITIONS:
        raise SalesSourceError("sales_agent_proposal_disposition_invalid", str(disposition))
    if not isinstance(command, dict):
        raise SalesSourceError("sales_agent_proposal_command_required", disposition)
    try:
        parsed = SalesCommand.from_dict(command)
    except (TypeError, KeyError) as exc:
        raise SalesSourceError("sales_agent_proposal_command_invalid", str(exc)) from exc
    if parsed.command_digest != proposal.get("command_digest"):
        raise SalesSourceError("sales_agent_proposal_command_invalid", "command digest mismatch")
    if parsed.idempotency_key != assigned_idempotency_key(source_id):
        raise SalesSourceError("sales_agent_proposal_command_invalid", "idempotency key must be server-assigned")
    if not parsed.evidence_refs or evidence_ref(source_id) not in parsed.evidence_refs:
        raise SalesSourceError("sales_agent_proposal_command_invalid", "missing source evidence ref")
    if disposition == "create_order" and parsed.order_id != assigned_order_id(source_id):
        raise SalesSourceError("sales_agent_proposal_command_invalid", "create order id must be server-assigned")
    if disposition == "fulfill" and parsed.action != "fulfill":
        raise SalesSourceError("sales_agent_proposal_command_invalid", "fulfill disposition requires a fulfill command")


def receive_source(
    path: Path,
    *,
    source_ref: str,
    text: str,
    business_at: str,
    extra: object,
    enabled_module_ids: Iterable[str] | None = None,
) -> dict[str, Any]:
    """Persist the verbatim source once per (source_ref, content)."""

    _require_module_enabled(enabled_module_ids)
    ref = str(source_ref or "").strip()
    if not 3 <= len(ref) <= MAX_SOURCE_REF_LENGTH:
        raise SalesSourceError("sales_agent_source_ref_invalid", "source_ref must contain 3 to 200 characters")
    body = str(text or "")
    if not 1 <= len(body) <= MAX_TEXT_LENGTH:
        raise SalesSourceError("sales_agent_text_invalid", "text must contain 1 to 20000 characters")
    when = str(business_at or "").strip()
    if len(when) > 64:
        raise SalesSourceError("sales_agent_business_at_invalid", "business_at is too long")
    raw_extra = json.loads(json.dumps(extra, ensure_ascii=False)) if extra is not None else None
    if extra is not None and not isinstance(raw_extra, (dict, list)):
        raise SalesSourceError("sales_agent_extra_invalid", "extra must be a JSON object or array")
    if len(_canonical(raw_extra)) > 65536:
        raise SalesSourceError("sales_agent_extra_invalid", "extra is too large")
    source_id = source_id_for_ref(ref)
    payload = {
        "schema_version": RECEIVED_SCHEMA,
        "source_id": source_id,
        "source_ref": ref,
        "text": body,
        "business_at": when,
        "extra": raw_extra,
        "content_digest": _content_digest(body, when, raw_extra),
    }
    with _connect(path, readonly=False) as connection:
        connection.execute("BEGIN IMMEDIATE")
        try:
            existing = _received_row(connection, source_id)
            if existing is not None:
                recorded = _parse_payload(existing)
                if recorded.get("content_digest") != payload["content_digest"]:
                    raise SalesSourceError(
                        "sales_agent_source_content_conflict",
                        "the same source_ref already stored different content",
                    )
                connection.rollback()
                return {
                    "source_id": source_id,
                    "disposition": "idempotent_replay",
                }
            connection.execute(
                """INSERT INTO kernel_audit_events
                   (event_id, event_type, payload_json, created_at) VALUES (?, ?, ?, ?)""",
                (source_id, RECEIVED_EVENT, _canonical(payload), datetime.now(UTC).isoformat()),
            )
            connection.commit()
            return {"source_id": source_id, "disposition": "received"}
        except Exception:
            connection.rollback()
            raise


def record_prepared(
    path: Path,
    source_id: str,
    proposal: dict[str, Any],
    *,
    enabled_module_ids: Iterable[str] | None = None,
) -> dict[str, Any]:
    """Fix the first typed proposal for one source; later proposals never rewrite it."""

    _require_module_enabled(enabled_module_ids)
    validate_prepared_proposal(proposal, source_id=source_id)
    prepared = {**proposal, "prepared_at": datetime.now(UTC).isoformat()}
    event_id = _prepared_event_id(source_id)
    with _connect(path, readonly=False) as connection:
        connection.execute("BEGIN IMMEDIATE")
        try:
            if _received_row(connection, source_id) is None:
                raise SalesSourceError("sales_agent_source_not_found", source_id)
            existing = _prepared_row(connection, source_id)
            if existing is not None:
                connection.rollback()
                return {
                    "source_id": source_id,
                    "disposition": "first_prepared_wins",
                    "proposal": _parse_payload(existing),
                }
            connection.execute(
                """INSERT INTO kernel_audit_events
                   (event_id, event_type, payload_json, created_at) VALUES (?, ?, ?, ?)""",
                (event_id, PREPARED_EVENT, _canonical(prepared), prepared["prepared_at"]),
            )
            connection.commit()
            return {"source_id": source_id, "disposition": "prepared", "proposal": prepared}
        except sqlite3.IntegrityError as exc:
            connection.rollback()
            raise SalesSourceError("sales_agent_prepare_conflict", str(exc)) from exc
        except Exception:
            connection.rollback()
            raise


def _applied_readback(
    path: Path,
    command: SalesCommand,
    *,
    enabled_module_ids: Iterable[str] | None,
) -> dict[str, Any] | None:
    try:
        readback = read_sales_action(
            path, command.idempotency_key, enabled_module_ids=enabled_module_ids
        )
    except SalesOwnerError as exc:
        if exc.code == "sales_readback_missing":
            return None
        raise
    if readback["command_digest"] != command.command_digest:
        raise SalesSourceError(
            "sales_agent_receipt_command_conflict",
            "an applied receipt exists for a different command",
        )
    return readback


def load_source_state(
    path: Path,
    source_id: str,
    *,
    include_preview: bool = True,
    enabled_module_ids: Iterable[str] | None = None,
) -> dict[str, Any]:
    """Assemble the formal state of one source from kernel events and Owner receipts."""

    _require_module_enabled(enabled_module_ids)
    with _connect(path, readonly=True) as connection:
        received = _received_row(connection, source_id)
        if received is None:
            raise SalesSourceError("sales_agent_source_not_found", source_id)
        recorded = _parse_payload(received)
        prepared_row = _prepared_row(connection, source_id)
        proposal = _parse_payload(prepared_row) if prepared_row is not None else None
        prepared_at = str(prepared_row["created_at"]) if prepared_row is not None else None
    state: dict[str, Any] = {
        "schema_version": STATE_SCHEMA,
        "owner_ref": OWNER_REF,
        "source_id": source_id,
        "source_ref": recorded["source_ref"],
        "text": recorded["text"],
        "business_at": recorded["business_at"],
        "extra": recorded.get("extra"),
        "content_digest": recorded["content_digest"],
        "received_at": str(received["created_at"]),
        "evidence_ref": evidence_ref(source_id),
        "status": "received",
        "proposal": None,
        "prepared_at": prepared_at,
        "preview": None,
        "preview_error": None,
        "applied": None,
    }
    if proposal is None:
        return state
    state["proposal"] = proposal
    if proposal["disposition"] in PLAIN_DISPOSITIONS:
        state["status"] = proposal["disposition"]
        return state
    command = SalesCommand.from_dict(proposal["command"])
    readback = _applied_readback(path, command, enabled_module_ids=enabled_module_ids)
    if readback is not None:
        state["status"] = "applied"
        state["applied"] = readback
        return state
    state["status"] = "prepared"
    if not include_preview:
        return state
    try:
        preview = preview_sales_action(path, command, enabled_module_ids=enabled_module_ids)
        state["preview"] = preview.to_dict()
    except SalesOwnerError as exc:
        state["preview_error"] = {"code": exc.code, "message": exc.message}
    return state


def list_sources(
    path: Path,
    *,
    order_id: str = "",
    limit: int = 50,
    enabled_module_ids: Iterable[str] | None = None,
) -> list[dict[str, Any]]:
    """Summarize recorded sources, optionally filtered by a sales order id."""

    _require_module_enabled(enabled_module_ids)
    wanted_order = str(order_id or "").strip()
    with _connect(path, readonly=True) as connection:
        rows = connection.execute(
            """SELECT event_id, payload_json, created_at FROM kernel_audit_events
               WHERE event_type=? ORDER BY created_at DESC, event_id DESC""",
            (RECEIVED_EVENT,),
        ).fetchall()
        prepared_by_source = {
            str(_parse_payload(row)["source_id"]): row
            for row in connection.execute(
                "SELECT event_id, payload_json, created_at FROM kernel_audit_events WHERE event_type=?",
                (PREPARED_EVENT,),
            )
        }
    items: list[dict[str, Any]] = []
    for row in rows:
        payload = _parse_payload(row)
        source_id = str(payload["source_id"])
        proposal = None
        prepared_row = prepared_by_source.get(source_id)
        if prepared_row is not None:
            proposal = _parse_payload(prepared_row)
        command_order = ""
        if proposal is not None and isinstance(proposal.get("command"), dict):
            command_order = str(proposal["command"].get("order_id") or "")
        if wanted_order and command_order != wanted_order:
            continue
        items.append(
            {
                "source_id": source_id,
                "source_ref": payload["source_ref"],
                "business_at": payload.get("business_at") or "",
                "received_at": str(row["created_at"]),
                "prepared_at": str(prepared_row["created_at"]) if prepared_row is not None else None,
                "disposition": proposal["disposition"] if proposal else None,
                "order_id": command_order or None,
            }
        )
        if len(items) >= max(1, min(int(limit), 200)):
            break
    return items


__all__ = [
    "COMMAND_DISPOSITIONS",
    "OWNER_REF",
    "PLAIN_DISPOSITIONS",
    "PREPARED_EVENT",
    "PREPARED_SCHEMA",
    "RECEIVED_EVENT",
    "RECEIVED_SCHEMA",
    "STATE_SCHEMA",
    "SalesSourceError",
    "assigned_idempotency_key",
    "assigned_order_id",
    "evidence_ref",
    "list_sources",
    "load_source_state",
    "receive_source",
    "record_prepared",
    "source_id_for_ref",
    "validate_prepared_proposal",
]
