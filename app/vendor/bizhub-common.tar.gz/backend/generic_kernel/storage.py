"""One HTTP projection for synchronous SQLite storage work and errors."""
from __future__ import annotations

import asyncio
from functools import partial, wraps
import inspect
import math
import os
import sqlite3
import time

import anyio

from fastapi import HTTPException
from fastapi.routing import APIRoute

from backend.kernel.profile_registry import STORAGE_BUDGET, StorageBudget, StorageBusy


def storage_wait_seconds() -> float:
    value = float(os.environ.get("BIZHUB_GENERIC_STORAGE_WAIT_SECONDS", "5"))
    if not math.isfinite(value) or value <= 0 or value >= 10:
        raise ValueError("Generic storage waiting budget must be positive and below 10 seconds")
    return value


def storage_error(exc: BaseException) -> HTTPException | None:
    current = exc
    seen = set()
    while current is not None and id(current) not in seen:
        seen.add(id(current))
        if isinstance(current, sqlite3.Error):
            code = getattr(current, "sqlite_errorcode", None)
            if isinstance(current, StorageBusy) or (code is not None and code & 255 in {sqlite3.SQLITE_BUSY, sqlite3.SQLITE_LOCKED}):
                return HTTPException(503, detail={"code": "generic_storage_busy", "message": "Storage is busy; retry the request."})
            if isinstance(current, sqlite3.IntegrityError) and code in {sqlite3.SQLITE_CONSTRAINT_UNIQUE, sqlite3.SQLITE_CONSTRAINT_PRIMARYKEY}:
                detail = exc.detail if isinstance(exc, HTTPException) and isinstance(exc.detail, dict) else {}
                return HTTPException(409, detail={**detail, "code": detail.get("code", "generic_storage_conflict"), "message": "The requested identity already exists."})
            return HTTPException(500, detail={"code": "generic_storage_error", "message": "Storage operation failed."})
        current = current.__cause__ or current.__context__
    return None


async def run_storage_sync(function, *args, **kwargs):
    """Bound default-pool admission, then execute one complete sync work unit."""
    budget = STORAGE_BUDGET.get()
    if budget is None:
        from starlette.concurrency import run_in_threadpool
        return await run_in_threadpool(function, *args, **kwargs)
    limiter = anyio.to_thread.current_default_thread_limiter()
    borrower = object()
    started = time.monotonic()
    try:
        with anyio.fail_after(budget.available()):
            await limiter.acquire_on_behalf_of(borrower)
    except TimeoutError as exc:
        raise StorageBusy("storage thread admission exhausted") from exc
    finally:
        budget.remaining -= time.monotonic() - started
    try:
        budget.available()
        # Own the default pool token once, rather than acquiring it again in
        # run_sync. This private limiter does not permit extra default capacity.
        return await anyio.to_thread.run_sync(
            partial(function, *args, **kwargs), limiter=anyio.CapacityLimiter(1),
        )
    finally:
        limiter.release_on_behalf_of(borrower)


class StorageRoute(APIRoute):
    def __init__(self, path, endpoint, *args, **kwargs):
        self.storage_synchronous = not inspect.iscoroutinefunction(endpoint)
        if self.storage_synchronous:
            synchronous_endpoint = endpoint

            @wraps(synchronous_endpoint)
            async def endpoint(*values, **named):
                return await run_storage_sync(synchronous_endpoint, *values, **named)

            endpoint.__signature__ = inspect.signature(synchronous_endpoint, eval_str=True)
        super().__init__(path, endpoint, *args, **kwargs)

    def get_route_handler(self):
        handler = super().get_route_handler()
        synchronous = self.storage_synchronous

        async def storage_handler(request):
            seconds = request.app.state.storage_wait_seconds
            # Sync work includes thread-pool admission in its budget. Async AI
            # orchestration charges SQLite time, not model/network execution.
            budget = StorageBudget(seconds, time.monotonic() + seconds if synchronous else None)
            token = STORAGE_BUDGET.set(budget)
            pending = None
            try:
                if not synchronous:
                    return await handler(request)
                pending = asyncio.ensure_future(handler(request))
                return await asyncio.shield(pending)
            except asyncio.CancelledError:
                budget.cancelled = True
                # Keep ownership of the native operation until it has rolled
                # back/closed. Never return a detached writer to the pool.
                if pending is not None:
                    while not pending.done():
                        try:
                            await asyncio.shield(pending)
                        except asyncio.CancelledError:
                            continue
                        except Exception:
                            break
                    if not pending.cancelled():
                        pending.exception()
                raise
            except Exception as exc:
                projected = storage_error(exc)
                if projected is not None:
                    raise projected from exc
                # Framework validation/HTTP errors and non-storage failures
                # retain their existing response/exception behavior.
                raise
            finally:
                STORAGE_BUDGET.reset(token)

        return storage_handler
