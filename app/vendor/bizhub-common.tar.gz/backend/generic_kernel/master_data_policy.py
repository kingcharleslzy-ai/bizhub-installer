"""通用独立产品的主数据规则：通用默认，加上已启用业务模块对往来方合并的把关。

通用销售、采购的单据目前只由各自的正式写入函数写，还没有“合并时改指往来方”的处理；
所以被合并的往来方名下还有这些单据时，合并拒收，请先在单据里处理好。
"""

from __future__ import annotations

from typing import Callable, Iterable

from backend.modules.master_data.policy import MasterDataPolicy
from backend.modules.master_data.public import MasterDataError


def _blocking(counter: Callable[..., dict[str, int]]) -> Callable[..., dict[str, int]]:
    def check(connection, *, source_party_id, target_party_id, reason, actor, dry_run) -> dict[str, int]:
        counts = counter(connection, source_party_id)
        if any(counts.values()):
            busy = {table: count for table, count in counts.items() if count}
            raise MasterDataError("master_data_merge_documents_exist", f"party:{source_party_id} {busy}")
        return counts

    return check


def generic_master_data_policy(enabled_module_ids: Iterable[str]) -> MasterDataPolicy:
    enabled = set(enabled_module_ids)
    guards = []
    if "sales" in enabled:
        from backend.modules.sales.public import party_reference_counts as sales_counts

        guards.append(_blocking(sales_counts))
    if "procurement" in enabled:
        from backend.modules.procurement.public import party_reference_counts as procurement_counts

        guards.append(_blocking(procurement_counts))
    return MasterDataPolicy(merge_reference_movers=tuple(guards))


__all__ = ["generic_master_data_policy"]
